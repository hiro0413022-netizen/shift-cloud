"""capture/uvc.py — UVCカメラ（ELP AR0234 などのスイング撮影用）

■ Windows で高フレームレートを出すための要点

  1. **FOURCC を先に MJPG にする。** これをやらないと OpenCV は
     無圧縮 YUY2 で開こうとし、1920x1200 では 5〜10fps しか出ない。
     順番は FOURCC → 幅 → 高さ → fps。この順でないと効かないことがある。

  2. **バックエンドは DSHOW を優先。** MSMF は ELP 系で
     解像度・fps の設定が無視されることがある。DSHOW で開けなければ MSMF に落とす。

  3. **バッファを 1 にする。** 既定では数フレーム溜め込むため、
     ライブ調整中に遅延が効いてくる。

MJPEG を使うのは画質の妥協ではなく **帯域の必然** である。
1280x720/120fps は 無圧縮なら 221MB/s、MJPEG なら 13MB/s。
2台つないでも 27MB/s で済み、計測カメラのぶんが空く。
"""

from __future__ import annotations

import platform
import threading
import time
from typing import Optional

import cv2
import numpy as np

from .base import CaptureSource, SourceInfo

IS_WINDOWS = platform.system() == "Windows"


def _backends() -> list:
    if IS_WINDOWS:
        return [("DSHOW", cv2.CAP_DSHOW), ("MSMF", cv2.CAP_MSMF)]
    if platform.system() == "Darwin":
        return [("AVFOUNDATION", cv2.CAP_AVFOUNDATION)]
    return [("V4L2", cv2.CAP_V4L2), ("ANY", cv2.CAP_ANY)]


class UvcCamera(CaptureSource):
    def __init__(self, key: str, label: str, index: int,
                 width: int = 1280, height: int = 720, fps: float = 120.0,
                 fourcc: str = "MJPG", ring_seconds: float = 8.0,
                 settings: Optional[dict] = None):
        super().__init__(SourceInfo(key=key, label=label, kind="uvc",
                                    width=width, height=height, fps=fps,
                                    fourcc=fourcc, device=f"index {index}"),
                         ring_seconds=ring_seconds)
        self.index = index
        self.req = dict(width=width, height=height, fps=fps, fourcc=fourcc)
        self.settings = dict(settings or {})
        self._cap: Optional[cv2.VideoCapture] = None

    # ---------------------------------------------------------------- open
    def _ladder(self, compressed: bool = True) -> list:
        """要求モードと、それが駄目だったときの降り方。

        圧縮できるかどうかで、現実的な重さがまったく変わる。
        MJPEG なら 1920x1200@120 でも 1台 20MB/s 程度だが、
        無圧縮 YUY2 では同じ設定で 553MB/s。USB3 でも1台で埋まる。
        だから無圧縮に落ちたときは、最初から小さい設定を狙う。
        """
        w, h, f = self.req["width"], self.req["height"], self.req["fps"]
        if compressed:
            seq = [(w, h, f)]
            for cand in [(w, h, 60.0), (1280, 800, f), (1280, 720, f),
                         (1280, 720, 60.0), (640, 480, 60.0)]:
                if cand not in seq and cand[0] <= w:
                    seq.append(cand)
            return seq
        # 無圧縮でも通る重さ（MB/s は 幅×高さ×2×fps）
        return [(1280, 720, 60.0),      #  110MB/s
                (960, 600, 60.0),       #   69MB/s
                (800, 600, 60.0),       #   58MB/s
                (640, 480, 120.0),      #   74MB/s
                (640, 480, 60.0),       #   37MB/s
                (640, 480, 30.0)]       #   18MB/s

    def _try_one(self, api, w, h, f, need: str):
        """1つの組み合わせを試す。**同時に2つのハンドルを開かない。**

        ここを間違えると、1本目を開いたまま2本目を開こうとして
        両方おかしくなる。実際それで解像度が -1x-1 になり、
        形式表示が文字化けした。試すたびに必ず閉じてから次へ行く。

        need: 要求する圧縮形式（空なら形式は問わない）
        戻り値: (cap, 実際のfourcc) / 駄目なら (None, 理由)
        """
        why = "開けません"
        for order in ("fourcc_first", "size_first"):
            cap = cv2.VideoCapture(self.index, api)
            if not cap.isOpened():
                cap.release()
                time.sleep(0.15)
                return None, "開けません（他のアプリが使用中か、番号が違います）"
            self._configure(cap, w, h, f, order=order)
            img, t0 = None, time.perf_counter()
            while time.perf_counter() - t0 < 0.7:
                ok, fr = cap.read()
                if ok and fr is not None:
                    img = fr
                    break
            if img is None:
                cap.release()
                time.sleep(0.15)
                why = "絵が出ません"
                continue
            gh, gw = img.shape[:2]
            got = self._read_fourcc(cap)
            if (gw, gh) != (w, h):
                cap.release()
                time.sleep(0.15)
                why = f"{gw}x{gh} しか出ません"
                continue
            if need and not got.upper().startswith(need[:4]):
                cap.release()                        # ← 必ず閉じてから次の順番へ
                time.sleep(0.15)
                why = f"形式が {got} になります"
                continue
            return cap, got
        return None, why

    def _open(self) -> None:
        """開く。**まず要求形式（MJPEG）で開ける組み合わせを全部探す。**

        DSHOW で MJPEG にできなくても、MSMF ならできる機体がある。
        形式を妥協する前に、バックエンドと解像度を一通り試すのが順番として正しい。
        無圧縮を受け入れるのは、それでも駄目だったときだけ。
        """
        want = (self.req["width"], self.req["height"], self.req["fps"])
        fc_want = (self.req["fourcc"] or "").upper()
        last_err = ""

        for strict in (True, False):
            if strict and not fc_want:
                continue
            need = fc_want if strict else ""
            for name, api in _backends():
                lad = self._ladder(compressed=strict or not fc_want)
                if strict:
                    lad = lad[:3]        # 形式優先で探す段階では欲張らない
                for w, h, f in lad:
                    cap, res = self._try_one(api, w, h, f, need)
                    if cap is None:
                        last_err = f"{name} {w}x{h}@{int(f)}: {res}"
                        continue
                    self._cap = cap
                    self.info.device = f"index {self.index} / {name}"
                    self._readback(cap, w, h, f, res)
                    notes = []
                    if (w, h, f) != want:
                        notes.append(
                            f"要求 {want[0]}x{want[1]}@{int(want[2])} では開けず、"
                            f"{w}x{h}@{int(f)} で接続しました")
                    if fc_want and not (res or "").upper().startswith(fc_want[:4]):
                        mb = w * h * 2 * f / 1e6
                        notes.append(
                            f"圧縮形式が {res} です（MJPEG にできませんでした）。"
                            f"この設定で {mb:.0f}MB/s を1台で使います。"
                            "解像度かfpsをこれ以上上げると他のカメラが開けません")
                    self.info.note = "。".join(notes)
                    return
        raise RuntimeError(last_err or "カメラを開けません")

    @staticmethod
    def _read_fourcc(cap: cv2.VideoCapture) -> str:
        v = int(cap.get(cv2.CAP_PROP_FOURCC) or 0)
        if v <= 0:
            return ""
        t = "".join(chr((v >> (8 * i)) & 0xFF) for i in range(4)).strip()
        # 読めないと制御文字が返る。文字化けを画面に出さない
        return t if t.isprintable() and t.isascii() else ""

    def _configure(self, cap: cv2.VideoCapture,
                   width=None, height=None, fps=None, order="fourcc_first") -> None:
        """解像度とフレームレートと**圧縮形式**を決める。

        圧縮形式が本題である。MJPEG にできず YUY2（無圧縮）で開くと、
        1280x720/120fps で 221MB/s。MJPEGなら33MB/s なので7倍近い差になり、
        1台で USB を埋めて残りが開けなくなる。実際それが起きた。

        厄介なのは、設定する順番で結果が変わることである。
        DirectShow は解像度を変えるときに形式を勝手に戻すことがあり、
        FOURCC→解像度 の順だと最後に上書きされる。逆の順が効く機体もある。
        だから両方の順を試し、**読み戻して確かめる**。設定できた気になってはいけない。
        """
        w = int(width or self.req["width"])
        h = int(height or self.req["height"])
        f = float(fps or self.req["fps"])
        fc = self.req["fourcc"]
        code = cv2.VideoWriter_fourcc(*fc) if fc else None

        if order == "fourcc_first":
            if code is not None:
                cap.set(cv2.CAP_PROP_FOURCC, code)
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
        else:
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
            if code is not None:
                cap.set(cv2.CAP_PROP_FOURCC, code)
        if code is not None:
            cap.set(cv2.CAP_PROP_FOURCC, code)     # 念押し。戻されていたら効く
        cap.set(cv2.CAP_PROP_FPS, f)
        try:
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:                            # noqa: BLE001
            pass
        for k, v in self.settings.items():
            self.apply_setting(k, v, cap)

    def _readback(self, cap, w=0, h=0, f=0.0, fourcc="") -> None:
        """実際の値を控える。

        ドライバは平気で -1 を返す。読めた値だけを信じ、
        読めなければ**実際に効いた要求値**を使う。画面に -1x-1 と
        出るのは、読めない値をそのまま信じたときである。
        """
        gw = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        gh = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        gf = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
        self.info.width = gw if gw > 0 else (w or self.req["width"])
        self.info.height = gh if gh > 0 else (h or self.req["height"])
        self.info.fps = gf if gf > 0 else (f or self.req["fps"])
        fc = fourcc or self._read_fourcc(cap)
        self.info.fourcc = fc if fc.isprintable() and fc.strip() else "?"

    def _grab(self) -> Optional[np.ndarray]:
        if self._cap is None:
            return None
        ok, img = self._cap.read()
        return img if ok else None

    def _close(self) -> None:
        if self._cap is not None:
            self._cap.release()
            self._cap = None

    # ------------------------------------------------------------ 調整
    PROPS = {
        "exposure": cv2.CAP_PROP_EXPOSURE,
        "gain": cv2.CAP_PROP_GAIN,
        "brightness": cv2.CAP_PROP_BRIGHTNESS,
        "contrast": cv2.CAP_PROP_CONTRAST,
        "saturation": cv2.CAP_PROP_SATURATION,
        "gamma": cv2.CAP_PROP_GAMMA,
        "sharpness": cv2.CAP_PROP_SHARPNESS,
        "auto_exposure": cv2.CAP_PROP_AUTO_EXPOSURE,
        "wb_temperature": cv2.CAP_PROP_WB_TEMPERATURE,
        "auto_wb": cv2.CAP_PROP_AUTO_WB,
        "focus": cv2.CAP_PROP_FOCUS,
        "autofocus": cv2.CAP_PROP_AUTOFOCUS,
    }

    def apply_setting(self, key: str, value: float,
                      cap: Optional[cv2.VideoCapture] = None) -> bool:
        cap = cap or self._cap
        prop = self.PROPS.get(key)
        if cap is None or prop is None:
            return False
        ok = bool(cap.set(prop, float(value)))
        if ok:
            self.settings[key] = float(value)
        return ok

    # DirectShow の露光は「2のべき乗の秒数」で指定する独特の仕様。
    #   -1 = 1/2秒, -6 = 1/64秒, -10 = 1/1024秒 …
    # 数字だけ見ても何秒か分からないので、画面には秒に直して出す。
    @staticmethod
    def exposure_to_seconds(v: float) -> float:
        return 2.0 ** float(v)

    @staticmethod
    def seconds_to_exposure(sec: float) -> float:
        import math as _m
        return round(_m.log2(max(1e-6, sec)))

    def set_manual_exposure(self, shutter_sec: float) -> dict:
        """自動露出を切って、シャッター速度を秒で指定する。

        **自動露出のままだと暗い場所で露光が伸び、fpsが落ちる。**
        「120fpsのはずが30fpsしか出ない」の原因はたいていこれ。
        """
        # DSHOW: 0.25=手動 / 0.75=自動  という慣習。効かない機種は 1/3 を試す
        ok_auto = False
        for v in (0.25, 1.0):
            if self.apply_setting("auto_exposure", v):
                ok_auto = True
                break
        raw = self.seconds_to_exposure(shutter_sec)
        ok_exp = self.apply_setting("exposure", raw)
        return {"auto_off": ok_auto, "exposure_set": ok_exp, "raw": raw,
                "actual_sec": self.exposure_to_seconds(raw)}

    def read_settings(self) -> dict:
        if self._cap is None:
            return dict(self.settings)
        out = {}
        for k, prop in self.PROPS.items():
            try:
                out[k] = float(self._cap.get(prop))
            except Exception:                        # noqa: BLE001
                pass
        return out


# -------------------------------------------------------------- 機器の探索
def _fourcc_of(cap) -> str:
    v = int(cap.get(cv2.CAP_PROP_FOURCC) or 0)
    if v <= 0:
        return ""
    t = "".join(chr((v >> (8 * i)) & 0xFF) for i in range(4)).strip()
    return t if t.isprintable() and t.isascii() else ""


def probe_indices(max_index: int = 10, warmup_frames: int = 20,
                  warmup_sec: float = 1.2, on_step=None) -> list:
    """つながっているカメラを列挙し、1枚ずつ静止画を取る。

    OpenCV は機器名を返さないので、**実際の絵を見て役割を割り当てる** のが
    一番確実。UIの『機器を割り当てる』画面がこれを使う。

    ■ 最初の数枚は捨てる

    UVCカメラは開いた直後の数枚が真っ黒になる。自動露出とゲインが
    まだ効いていないため。**1枚目だけ見て「映らない」と判断してはいけない。**
    ここでは1秒ちょっとフレームを回してから、最後の1枚を使う。
    """
    found = []
    for api_name, api in _backends():
        for i in range(max_index):
            if on_step:
                try:
                    on_step(i, max_index, api_name)
                except Exception:                    # noqa: BLE001
                    pass
            cap = cv2.VideoCapture(i, api)
            if not cap.isOpened():
                cap.release()
                continue
            cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
            try:
                cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.75)   # 探索中は自動露出を使う
            except Exception:                        # noqa: BLE001
                pass

            img, n, t0 = None, 0, time.perf_counter()
            while n < warmup_frames and (time.perf_counter() - t0) < warmup_sec:
                ok, f = cap.read()
                if ok and f is not None:
                    img = f
                    n += 1
                else:
                    time.sleep(0.01)

            w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            f_ = float(cap.get(cv2.CAP_PROP_FPS))
            cap.release()
            if img is None:
                found.append(dict(index=i, backend=api_name, width=w, height=h,
                                  fps=f_, thumb=None, frames=0, brightness=0.0,
                                  note="フレームが取れません"))
                continue

            g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
            bright = float(g.mean())
            note = ""
            if bright < 8:
                note = "ほぼ真っ暗。レンズキャップ／部屋の明るさ／露出設定を確認"
            elif bright < 25:
                note = "暗いので明るさを持ち上げて表示しています"
            found.append(dict(index=i, backend=api_name, width=w, height=h,
                              fps=f_, thumb=img, frames=n,
                              brightness=round(bright, 1), note=note))
        if found:
            break                                    # 最初に成功したAPIで確定
    return found


def boost_for_view(img, target: float = 110.0):
    """暗い絵を見分けられる明るさまで持ち上げる（識別用。計測には使わない）。"""
    if img is None:
        return None
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    m = float(g.mean())
    if m >= target or m < 0.5:
        return img
    return cv2.convertScaleAbs(img, alpha=min(12.0, target / max(m, 1.0)), beta=8)


def probe_modes(index: int, candidates: Optional[list] = None,
                measure_sec: float = 1.2, warmup_sec: float = 0.8,
                on_step=None) -> list:
    """その機器が実際に出せる 解像度×fps×**圧縮形式** を、バックエンド別に調べる。

    知りたいのは「何fps出るか」ではなく「**MJPEGで開けるのか**」である。
    無圧縮しか出ないなら、fps がいくつ出ようと3台は同時に動かない。
    DirectShow で MJPEG にできなくても Media Foundation ならできる機体があるので、
    両方試して並べる。ここが分かれば、あとは設定を選ぶだけになる。
    """
    cands = candidates or [
        (1920, 1200, 120), (1280, 800, 120), (1280, 720, 120),
        (1280, 720, 60), (640, 480, 120),
    ]
    out = []
    plan = [(n, a, fc) for (n, a) in _backends() for fc in ("MJPG", "")]
    total = len(plan) * len(cands)
    k = 0
    for api_name, api, want_fc in plan:
        for w, h, f in cands:
            k += 1
            if on_step:
                try:
                    on_step(w, h, f, k, total, api_name, want_fc or "指定なし")
                except Exception:                    # noqa: BLE001
                    pass
            cap = cv2.VideoCapture(index, api)
            if not cap.isOpened():
                cap.release()
                continue
            try:
                if want_fc:
                    code = cv2.VideoWriter_fourcc(*want_fc)
                    cap.set(cv2.CAP_PROP_FOURCC, code)
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
                if want_fc:
                    cap.set(cv2.CAP_PROP_FOURCC, code)   # 解像度変更で戻る機体対策
                cap.set(cv2.CAP_PROP_FPS, f)
                try:
                    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                except Exception:                    # noqa: BLE001
                    pass

                img, t0 = None, time.perf_counter()
                while time.perf_counter() - t0 < warmup_sec:
                    ok, fr = cap.read()
                    if ok and fr is not None:
                        img = fr
                if img is None:
                    continue
                gh, gw = img.shape[:2]
                if (gw, gh) != (w, h):
                    continue

                n, t0 = 0, time.perf_counter()
                while time.perf_counter() - t0 < measure_sec:
                    ok, fr = cap.read()
                    if ok and fr is not None:
                        n += 1
                real = n / (time.perf_counter() - t0)
                fc = _fourcc_of(cap)
                mj = fc.upper().startswith("MJP")
                mbps = gw * gh * (2 if not mj else 0.3) * real / 1e6
                out.append(dict(width=gw, height=gh, requested_fps=f,
                                backend=api_name, asked=want_fc or "指定なし",
                                fourcc=fc or "不明", mjpg=mj,
                                mbps=round(mbps, 0),
                                measured_fps=round(real, 1)))
            finally:
                cap.release()
                time.sleep(0.15)
    return out


def find_working_mode(entries: list, ladder: Optional[list] = None,
                      accept: float = 0.75, measure_sec: float = 1.2,
                      warmup_sec: float = 0.9, on_step=None) -> dict:
    """全台が同時に出せる、いちばん重い設定を探す。

    USBは「どのカメラが悪いか」ではなく「合計で何MB/s流せるか」で決まる。
    1台ずつ試しても答えは出ないので、必ず全台同時に開いて確かめる。
    上から順に試し、最初に通ったところで止める＝それが上限。
    """
    # 段は少ないほうがよい。1段ごとに全台を開き直すので、
    # 段数がそのまま所要時間とリスク（開き直しの失敗）になる。
    lad = ladder or [
        (1920, 1200, 120), (1280, 800, 120), (1280, 720, 120),
        (1280, 720, 60), (640, 480, 120),
    ]
    api_name, api = _backends()[0]
    tried = []
    found = None
    for i, (w, h, f) in enumerate(lad, 1):
        if on_step:
            try:
                on_step(w, h, f, i, len(lad))
            except Exception:                         # noqa: BLE001
                pass
        caps, opened = {}, True
        try:
            for e in entries:
                k = str(e.get("label", e["index"]))
                cap = cv2.VideoCapture(int(e["index"]), api)
                if not cap.isOpened():
                    cap.release()
                    opened = False
                    tried.append(dict(width=w, height=h, fps=f, ok=False,
                                      detail=f"{k}: 開けません", got={}))
                    break
                code = cv2.VideoWriter_fourcc(*"MJPG")
                cap.set(cv2.CAP_PROP_FOURCC, code)
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
                cap.set(cv2.CAP_PROP_FOURCC, code)
                cap.set(cv2.CAP_PROP_FPS, f)
                try:
                    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                except Exception:                     # noqa: BLE001
                    pass
                t0, img = time.perf_counter(), None
                while time.perf_counter() - t0 < warmup_sec:
                    ok, fr = cap.read()
                    if ok and fr is not None:
                        img = fr
                        break
                fc = _fourcc_of(cap) if img is not None else ""
                bad_fc = img is not None and not fc.upper().startswith("MJP")
                if img is None or img.shape[1] != w or img.shape[0] != h or bad_fc:
                    cap.release()
                    opened = False
                    if img is None:
                        why = "絵が出ません"
                    elif bad_fc:
                        why = f"MJPEGにできません（{fc}）。無圧縮では帯域が足りません"
                    else:
                        why = f"{img.shape[1]}x{img.shape[0]} しか出ません"
                    tried.append(dict(width=w, height=h, fps=f, ok=False,
                                      detail=f"{k}: {why}", got={}))
                    break
                caps[k] = cap
            if not opened:
                continue

            # 同時に回す。1本のループで順に読むと台数ぶん遅く見えるので必ず別スレッド
            counts = {k: 0 for k in caps}
            stop = threading.Event()

            def run(k, cap):
                n = 0
                while not stop.is_set():
                    ok, fr = cap.read()
                    if ok and fr is not None:
                        n += 1
                counts[k] = n

            ths = [threading.Thread(target=run, args=(k, c), daemon=True)
                   for k, c in caps.items()]
            t0 = time.perf_counter()
            for t in ths:
                t.start()
            time.sleep(measure_sec)
            stop.set()
            for t in ths:
                t.join(timeout=2.0)
            el = time.perf_counter() - t0
            got = {k: round(v / el, 1) for k, v in counts.items()}
            ok_all = all(v >= f * accept for v in got.values())
            tried.append(dict(width=w, height=h, fps=f, ok=ok_all, got=got,
                              detail="" if ok_all else
                              f"要求{f}fps に対して {min(got.values()):.0f}fps まで"))
            if ok_all:
                found = dict(width=w, height=h, fps=f, got=got)
                break
        finally:
            for cap in caps.values():
                cap.release()
            time.sleep(0.25)

    if found:
        verdict = (f'{len(entries)}台とも {found["width"]}x{found["height"]}@{int(found["fps"])} '
                   "で同時に出ました。これが今の配線での上限です。")
    else:
        verdict = ("どの設定でも全台同時には出ませんでした。ポートを別系統に分けるか、"
                   "セルフパワーのUSB3ハブを使ってください。")
    return dict(tried=tried, found=found, verdict=verdict, n=len(entries))


def bandwidth_test(entries: list, measure_sec: float = 2.0,
                   warmup_sec: float = 1.2) -> dict:
    """USBの帯域が足りているかを、単独 → 追加 の順で確かめる。

    「1台目は映るのに2台目から映らない」の原因はほぼ帯域か給電である。
    同じ設定で1台ずつ試し、次に同時に開いて、どこで壊れるかを見る。
    entries: [{index, width, height, fps, fourcc, label}, ...]
    """
    api_name, api = _backends()[0]

    def _open(e):
        cap = cv2.VideoCapture(int(e["index"]), api)
        if not cap.isOpened():
            cap.release()
            return None, "開けません（他のアプリが使用中か、番号が違います）"
        code = cv2.VideoWriter_fourcc(*e.get("fourcc", "MJPG"))
        cap.set(cv2.CAP_PROP_FOURCC, code)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(e["width"]))
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(e["height"]))
        cap.set(cv2.CAP_PROP_FOURCC, code)
        cap.set(cv2.CAP_PROP_FPS, float(e.get("fps", 120)))
        try:
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:                            # noqa: BLE001
            pass
        t0 = time.perf_counter()
        img = None
        while time.perf_counter() - t0 < warmup_sec:
            ok, fr = cap.read()
            if ok and fr is not None:
                img = fr
        if img is None:
            cap.release()
            return None, "開けたが1枚も取れません（帯域か給電の不足）"
        return cap, ""

    def _measure(caps, sec):
        """各カメラを別スレッドで読む。

        1本のループで順番に read すると、1台の待ち時間が他の台を止める。
        3台なら見かけ上 1/3 に落ち、帯域が足りていても『不足』と読めてしまう。
        本番の取り込みも1台1スレッドなので、測り方もそれに合わせる。
        """
        counts = {k: 0 for k in caps}
        stop = threading.Event()

        def run(k, cap):
            n = 0
            while not stop.is_set():
                ok, fr = cap.read()
                if ok and fr is not None:
                    n += 1
            counts[k] = n

        ths = [threading.Thread(target=run, args=(k, c), daemon=True)
               for k, c in caps.items()]
        t0 = time.perf_counter()
        for t in ths:
            t.start()
        time.sleep(sec)
        stop.set()
        for t in ths:
            t.join(timeout=2.0)
        el = time.perf_counter() - t0
        return {k: round(v / el, 1) for k, v in counts.items()}

    solo = []
    for e in entries:
        cap, err = _open(e)
        if cap is None:
            solo.append(dict(label=e.get("label", e["index"]), index=e["index"],
                             ok=False, fps=0.0, error=err))
            continue
        fps = _measure({"x": cap}, measure_sec)["x"]
        got = (f'{int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))}'
               f'x{int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))} {_fourcc_of(cap)}')
        cap.release()
        time.sleep(0.2)
        solo.append(dict(label=e.get("label", e["index"]), index=e["index"],
                         ok=True, fps=fps, size=got, error=""))

    # 累積：1台 → 2台 → 3台
    steps = []
    caps = {}
    try:
        for i, e in enumerate(entries, 1):
            cap, err = _open(e)
            if cap is None:
                steps.append(dict(n=i, added=e.get("label", e["index"]),
                                  ok=False, error=err, fps={}))
                break
            caps[e.get("label", str(e["index"]))] = cap
            fps = _measure(caps, measure_sec)
            steps.append(dict(n=i, added=e.get("label", e["index"]),
                              ok=True, error="", fps=fps))
    finally:
        for cap in caps.values():
            cap.release()

    # 判定
    verdict = ""
    bad_solo = [s for s in solo if not s["ok"] or s["fps"] < 10]
    if bad_solo:
        verdict = ("単独でも出ないカメラがあります。番号違い、ケーブル、"
                   "または他のアプリがカメラを掴んでいる可能性です。")
    elif steps and not steps[-1]["ok"]:
        verdict = (f'{steps[-1]["n"]}台目で開けなくなりました。'
                   "USBの帯域か給電の不足です。別系統のポートに分けるか、"
                   "セルフパワーのUSB3ハブを使ってください。")
    else:
        drops = []
        if steps:
            last = steps[-1]["fps"]
            for s in solo:
                k = str(s["label"])
                if k in last and s["fps"] > 0 and last[k] < s["fps"] * 0.6:
                    drops.append(f'{k}: 単独{s["fps"]} → 同時{last[k]}')
        verdict = ("同時に開くとfpsが落ちています（" + " / ".join(drops) + "）。"
                   "解像度かfpsを下げるか、ポートを分けてください。") if drops \
            else "全台が同時に出ています。この設定で問題ありません。"

    return dict(solo=solo, steps=steps, verdict=verdict)
