"""capture/manager.py — 複数台をまとめて扱う"""

from __future__ import annotations

import threading
import time
from typing import Dict, List, Optional

from .base import CaptureSource
from .synthetic import SyntheticCamera
from .uvc import UvcCamera
from .videofile import VideoFileCamera

try:
    from .genicam import GenICamCamera
except Exception:                                     # noqa: BLE001
    GenICamCamera = None


def build_source(cfg: dict) -> CaptureSource:
    kind = cfg.get("kind", "uvc")
    common = dict(key=cfg["key"], label=cfg.get("label", cfg["key"]),
                  ring_seconds=float(cfg.get("ring_seconds", 8.0)))
    if kind == "synthetic":
        return SyntheticCamera(width=int(cfg.get("width", 1280)),
                               height=int(cfg.get("height", 720)),
                               fps=float(cfg.get("fps", 60)), **common)
    if kind == "uvc":
        return UvcCamera(index=int(cfg.get("index", 0)),
                         width=int(cfg.get("width", 1280)),
                         height=int(cfg.get("height", 720)),
                         fps=float(cfg.get("fps", 120)),
                         fourcc=cfg.get("fourcc", "MJPG"),
                         settings=cfg.get("settings"), **common)
    if kind == "video":
        return VideoFileCamera(path=cfg["path"], speed=float(cfg.get("speed", 1.0)),
                               loop=bool(cfg.get("loop", True)),
                               max_width=int(cfg.get("max_width", 0)), **common)
    if kind == "genicam":
        if GenICamCamera is None:
            raise RuntimeError("genicam を使うには harvesters が要ります")
        return GenICamCamera(serial=cfg.get("serial", ""), cti=cfg.get("cti", ""),
                             width=int(cfg.get("width", 640)),
                             height=int(cfg.get("height", 480)),
                             offset_x=int(cfg.get("offset_x", 0)),
                             offset_y=int(cfg.get("offset_y", 0)),
                             exposure_us=float(cfg.get("exposure_us", 20)),
                             gain=float(cfg.get("gain", 0)),
                             trigger=cfg.get("trigger", "off"),
                             pixel_format=cfg.get("pixel_format", "Mono8"),
                             fps=float(cfg.get("fps", 751)), **common)
    raise ValueError(f"未対応の kind: {kind}")


class CaptureManager:
    def __init__(self):
        self.sources: Dict[str, CaptureSource] = {}
        self._lock = threading.Lock()

    def configure(self, cams: List[dict]) -> None:
        """設定を入れ替える。動いているものは一度止めてから作り直す。"""
        with self._lock:
            for s in self.sources.values():
                s.stop()
            self.sources = {}
            for c in cams:
                if not c.get("enabled", True):
                    continue
                try:
                    src = build_source(c)
                    if c.get("undistort", True):
                        self._attach_lens(src, c["key"])
                    self.sources[c["key"]] = src
                except Exception as e:               # noqa: BLE001
                    print(f"[capture] {c.get('key')}: {e}")

    @staticmethod
    def _attach_lens(src, key: str) -> None:
        """そのカメラの較正ファイルがあれば自動で適用する。"""
        try:
            from ..calib.lens import LensModel, Undistorter
            m = LensModel.load(key)
            if m is not None:
                src.set_undistorter(Undistorter(m))
                print(f"[lens] {key}: 歪み補正を適用（再投影誤差 {m.rms:.3f}px）")
        except Exception as e:                        # noqa: BLE001
            print(f"[lens] {key}: 適用できません ({e})")

    def reload_lens(self, key: str) -> bool:
        src = self.sources.get(key)
        if src is None:
            return False
        self._attach_lens(src, key)
        return src.has_undistort

    def start_all(self) -> None:
        for s in self.sources.values():
            s.start()

    def stop_all(self) -> None:
        for s in self.sources.values():
            s.stop()

    def get(self, key: str) -> Optional[CaptureSource]:
        return self.sources.get(key)

    def status(self) -> list:
        out = []
        for k, s in self.sources.items():
            i = s.info
            out.append(dict(key=k, label=i.label, kind=i.kind,
                            connected=i.connected, error=i.error,
                            width=i.width, height=i.height,
                            fourcc=i.fourcc, device=i.device, note=i.note,
                            requested_fps=round(i.fps, 1),
                            measured_fps=round(s.measured_fps, 1)))
        return out

    def set_recording(self, on: bool) -> None:
        for s in self.sources.values():
            s.set_recording(on)
