"""tools/camprobe.py — カメラを触る作業を『別プロセス』で行う

なぜ別プロセスなのか。

OpenCV の DirectShow / Media Foundation は、こちらの管理外にある
ネイティブのコードである。カメラを何十回も開き直すと、環境によっては
プロセスごと落ちる。同じプロセスの中で走らせていると、そのとき
**サーバーまで道連れになる**。画面には「Failed to fetch」としか出ず、
何が起きたのか分からなくなる（実際そうなった）。

別プロセスに出しておけば、落ちるのは子だけである。親は終了コードを見て
「探索中に落ちました」と報告できる。原因が分からなくても、
分からないなりに前へ進める状態を保てる。これが本題である。

使い方:
    python -m gsim.tools.camprobe discover --max-index 8
    python -m gsim.tools.camprobe modes --index 1
    python -m gsim.tools.camprobe bandwidth --entries <json>
    python -m gsim.tools.camprobe search   --entries <json>

結果は **標準出力に JSON 1個**。進み具合は **標準エラーに1行1件の JSON**
（{"progress": "..."}）で流す。親はそれを読んで画面に出す。
"""

from __future__ import annotations

import argparse
import base64
import json
import sys

import cv2

from ..capture.uvc import (bandwidth_test, boost_for_view, find_working_mode,
                           probe_indices, probe_modes)


def say(msg: str) -> None:
    sys.stderr.write(json.dumps({"progress": msg}, ensure_ascii=False) + "\n")
    sys.stderr.flush()


def _jpg(img, quality: int = 70):
    ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    return buf.tobytes() if ok else b""


def do_discover(max_index: int) -> dict:
    def step(i, n, api):
        say(f"番号 {i} を調べています（{i + 1}/{n}・{api}）")

    found = probe_indices(max_index=max_index, on_step=step)
    out = []
    for f in found:
        img = f.get("thumb")
        thumb = None
        if img is not None:
            view = boost_for_view(img)
            th = cv2.resize(view, (320, int(320 * view.shape[0] / view.shape[1])))
            thumb = "data:image/jpeg;base64," + base64.b64encode(_jpg(th)).decode()
        out.append(dict(index=f["index"], backend=f["backend"],
                        width=f["width"], height=f["height"],
                        fps=round(f["fps"], 1) if f["fps"] and f["fps"] > 0 else None,
                        brightness=f.get("brightness", 0.0),
                        frames=f.get("frames", 0), note=f.get("note", ""),
                        thumb=thumb))
    dark = [d["index"] for d in out if d["brightness"] < 8]
    if not out:
        note = ("1台も見つかりません。ケーブルと、他のアプリ（Zoom・カメラアプリなど）が"
                "掴んでいないかを確認してください")
    elif dark:
        note = (f"番号 {', '.join(map(str, dark))} がほぼ真っ暗です。"
                "部屋を明るくするか、レンズキャップを外して、もう一度探してください")
    else:
        note = "映っている絵を見て、どれがどの位置のカメラか決めてください"
    return {"devices": out, "note": note}


def do_modes(index: int) -> dict:
    def step(w, h, f, i, n, api="", asked=""):
        say(f"{i}/{n} 番号{index} を {api} / {asked} で {w}x{h}@{int(f)} …")

    return {"index": index, "modes": probe_modes(index, on_step=step)}


def do_bandwidth(entries: list) -> dict:
    say("1台ずつ測っています…")
    return bandwidth_test(entries)


def do_search(entries: list) -> dict:
    def step(w, h, f, i, n):
        say(f"{i}/{n} {w}x{h}@{int(f)} を全台同時で試しています…")

    return find_working_mode(entries, on_step=step)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["discover", "modes", "bandwidth", "search"])
    ap.add_argument("--index", type=int, default=0)
    ap.add_argument("--max-index", type=int, default=8)
    ap.add_argument("--entries", default="[]")
    a = ap.parse_args(argv)

    if a.cmd == "discover":
        res = do_discover(a.max_index)
    elif a.cmd == "modes":
        res = do_modes(a.index)
    elif a.cmd == "bandwidth":
        res = do_bandwidth(json.loads(a.entries))
    else:
        res = do_search(json.loads(a.entries))

    sys.stdout.write(json.dumps(res, ensure_ascii=False))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
