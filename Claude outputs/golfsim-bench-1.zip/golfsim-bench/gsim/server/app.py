"""server/app.py — ローカルの調整用サーバ

ブラウザで開いて、機器をつなぎながら見て直すための土台。
打席のPCで動かし、必要ならタブレットからも同じ画面を開ける。

  GET  /                        画面
  GET  /api/status              各カメラの状態と実測fps
  GET  /api/stream/{key}        ライブ映像（MJPEG）
  GET  /api/metrics             いまの姿勢指標
  POST /api/reference           アドレス姿勢を基準にする
  GET  /api/discover            つながっている機器を探す（サムネ付き）
  GET  /api/probe/{index}       その機器で実際に出る解像度×fpsを実測
  GET  /api/config              設定を読む
  POST /api/config              設定を書いて再起動
  POST /api/record/{on|off}     録画バッファの開始・停止
  POST /api/clip                いまのバッファを書き出す
"""

from __future__ import annotations

import base64
import io
import json
import os
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

import cv2
import numpy as np
from fastapi import Body, FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse

from .. import config as cfgmod
from ..capture.manager import CaptureManager
# カメラを直接触る処理は子プロセス（gsim.tools.camprobe）側で行う。
# ここで import しないのは、落ちる可能性のあるコードをサーバーに持ち込まないため。
from ..pose.estimator import PoseEstimator, draw_overlay
from ..pose import metrics as M
from ..calib.lens import CalibSession, LensModel, make_board_png

STATIC = Path(__file__).resolve().parent / "static"

app = FastAPI(title="GolfSim ローカル調整サーバ")

CFG: dict = {}
CAP = CaptureManager()
POSE: Dict[str, PoseEstimator] = {}
REF: Dict[str, dict] = {}
ROLES: Dict[str, str] = {}
CALIB: Dict[str, CalibSession] = {}

# 再接続のたびに増える通し番号。
# 配信中の映像ストリームは古いカメラを掴んだままなので、
# これが変わったら自分から終わってもらう（下の _mjpeg 参照）。
GEN = 0
JOB: dict = {"name": "", "running": False, "done": False,
             "result": None, "error": "", "progress": ""}


# ------------------------------------------------------------------ 起動
def _apply(cfg: dict) -> None:
    global CFG, POSE, ROLES, GEN
    CFG = cfg
    GEN += 1
    for p in POSE.values():
        p.stop()
    POSE = {}
    ROLES = {c["key"]: c.get("role", "front") for c in cfg["cameras"]}
    CAP.configure(cfg["cameras"])
    CAP.start_all()
    if cfg["pose"].get("enabled", True):
        for key, src in CAP.sources.items():
            est = PoseEstimator(key,
                                target_fps=float(cfg["pose"].get("target_fps", 25)),
                                model_complexity=int(cfg["pose"].get("model_complexity", 1)))
            est.bind(src)
            est.start()
            POSE[key] = est


@app.on_event("startup")
def _startup() -> None:
    # FastAPI は同期の関数をスレッドプールで動かす。既定は40本しかなく、
    # 映像配信が1本ずつ占有するため、再接続を繰り返すと枯渇して
    # サーバー全体が黙る（実際に「接続が切れた」のはこれ）。
    try:
        import anyio.to_thread
        anyio.to_thread.current_default_thread_limiter().total_tokens = 256
    except Exception as e:                            # noqa: BLE001
        print(f"[server] スレッド上限を変更できません: {e}")
    _apply(cfgmod.load())


@app.on_event("shutdown")
def _shutdown() -> None:
    for p in POSE.values():
        p.stop()
    CAP.stop_all()


# ------------------------------------------------------------------ 画面
@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return (STATIC / "index.html").read_text(encoding="utf-8")


# ------------------------------------------------------------------ 状態
@app.get("/api/status")
def status() -> dict:
    st = CAP.status()
    for row in st:
        est = POSE.get(row["key"])
        r = est.latest() if est else None
        row["role"] = ROLES.get(row["key"], "front")
        row["pose_available"] = bool(est and est.available)
        row["pose_ok"] = bool(r and r.ok)
        row["pose_ms"] = round(r.infer_ms, 1) if r else None
        row["pose_quality"] = round(M.quality(r), 2) if r else 0.0
        row["has_reference"] = row["key"] in REF and bool(REF[row["key"]])
        src = CAP.get(row["key"])
        row["undistort"] = bool(src and src.has_undistort)
        lm = LensModel.load(row["key"])
        row["lens"] = (dict(rms=round(lm.rms, 3), n=lm.n_images,
                            hfov=round(lm.hfov_deg, 1)) if lm else None)
        row["calib_n"] = CALIB[row["key"]].n if row["key"] in CALIB else 0
        row["calib_active"] = row["key"] in CALIB
    return {"site": CFG.get("site", {}), "cameras": st,
            "pose_enabled": CFG.get("pose", {}).get("enabled", True)}


@app.get("/api/metrics")
def metrics() -> dict:
    out = {}
    for key, est in POSE.items():
        r = est.latest()
        ms = M.compute(ROLES.get(key, "front"), r, REF.get(key))
        out[key] = [dict(key=x.key, label=x.label, value=round(float(x.value), 1),
                         unit=x.unit, hint=x.hint) for x in ms]
    return {"t": time.time(), "metrics": out}


@app.post("/api/reference")
def set_reference(payload: dict = Body(default={})) -> dict:
    keys = payload.get("keys") or list(POSE.keys())
    done = []
    for k in keys:
        est = POSE.get(k)
        if not est:
            continue
        ref = M.make_reference(est.latest())
        if ref:
            REF[k] = ref
            done.append(k)
    return {"ok": bool(done), "keys": done,
            "message": "アドレス姿勢を基準にしました" if done else "姿勢が取れていません"}


@app.post("/api/reference/clear")
def clear_reference() -> dict:
    REF.clear()
    return {"ok": True}


# ------------------------------------------------------------------ 映像
def _encode(img: np.ndarray, quality: int = 80) -> bytes:
    ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    return buf.tobytes() if ok else b""


def _mjpeg(key: str, overlay: bool, quality: int, max_fps: float):
    """映像を流し続ける。ただし『いつ終わるか』を必ず持たせる。

    再接続すると CAP.sources は作り直されるが、この生成器は古い方を
    掴んだままになる。ブラウザ側は新しい接続を張るので、古い方は
    誰にも見られないまま1本ずつスレッドを占有し続ける。
    数回繰り返すとプールを食い尽くしてサーバーが応答しなくなる。
    だから世代が変わったら自分から抜ける。
    """
    if CAP.get(key) is None:
        raise HTTPException(404, f"カメラ {key} がありません")
    my_gen = GEN
    interval = 1.0 / max(1.0, max_fps)
    last = -1
    idle = 0.0
    while GEN == my_gen:
        t0 = time.perf_counter()
        src = CAP.get(key)
        if src is None:
            break
        est = POSE.get(key)
        fr = src.latest()
        if fr is None:
            idle += 0.05
            if idle > 30.0:        # 30秒何も来ないなら見捨てる
                break
            time.sleep(0.05)
            continue
        idle = 0.0
        if fr.index != last:
            last = fr.index
            img = fr.image
            if overlay and est is not None:
                img = draw_overlay(img.copy(), est.latest())
            jpg = _encode(img, quality)
            if jpg:
                yield (b"--frame\r\nContent-Type: image/jpeg\r\n"
                       b"Content-Length: " + str(len(jpg)).encode() + b"\r\n\r\n"
                       + jpg + b"\r\n")
        rest = interval - (time.perf_counter() - t0)
        if rest > 0:
            time.sleep(rest)


@app.get("/api/stream/{key}")
def stream(key: str, overlay: int = 1, quality: int = 80, fps: float = 30.0):
    return StreamingResponse(_mjpeg(key, bool(overlay), quality, fps),
                             media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/snapshot/{key}")
def snapshot(key: str, overlay: int = 1):
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, "カメラがありません")
    fr = src.latest()
    if fr is None:
        raise HTTPException(503, "まだフレームがありません")
    img = fr.image
    if overlay and key in POSE:
        img = draw_overlay(img.copy(), POSE[key].latest())
    return StreamingResponse(io.BytesIO(_encode(img, 90)), media_type="image/jpeg")


# ------------------------------------------------------------------ 機器探索
@app.post("/api/discover")
def discover(max_index: int = 8) -> dict:
    """機器を探す。

    探すには一度カメラを離さないといけない。動いているカメラが
    番号を握ったままだと、その番号は「開けない」としか見えず、
    運が悪いと開こうとしたまま固まる（実際に固まったのはこれ）。
    """
    if JOB["running"]:
        raise HTTPException(409, "別の測定が動いています")
    _run_job("discover", ["discover", "--max-index", str(max_index)], timeout=180.0)
    return {"started": True}


@app.post("/api/probe/{index}")
def probe(index: int) -> dict:
    """その番号で実際に出る 解像度×fps を実測する。"""
    if JOB["running"]:
        raise HTTPException(409, "別の測定が動いています")

    _run_job("probe", ["modes", "--index", str(index)], timeout=240.0)
    return {"started": True}


def _uvc_entries() -> list:
    return [dict(index=int(c.get("index", 0)), width=int(c.get("width", 1280)),
                 height=int(c.get("height", 720)), fps=float(c.get("fps", 120)),
                 fourcc=c.get("fourcc", "MJPG"), label=c.get("label", c["key"]))
            for c in CFG["cameras"]
            if c.get("enabled", True) and c.get("kind") == "uvc"]


def _run_child(args: list, timeout: float) -> dict:
    """カメラを触る作業を別プロセスで走らせ、結果のJSONを受け取る。

    子が落ちても親（このサーバー）は生き残る。落ちたこと自体を結果として
    返せるので、画面から様子が分かる。**どこで落ちたか**も残す。
    直前に何を試していたかが分かれば、その設定を避けて進められる。

    標準出力は本文、標準エラーは進み具合。communicate() は両方を
    まとめて読んでしまい、進み具合を横取りするスレッドと衝突するので使わない。
    """
    cmd = [sys.executable, "-m", "gsim.tools.camprobe"] + args
    root = str(Path(__file__).resolve().parents[2])
    prev = os.environ.get("PYTHONPATH", "")
    env = dict(os.environ, PYTHONIOENCODING="utf-8",
               PYTHONPATH=(root + os.pathsep + prev) if prev else root)
    p = subprocess.Popen(cmd, cwd=root, env=env, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True, encoding="utf-8")

    state = {"last": "", "tail": []}

    def pump():
        try:
            for line in p.stderr:
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                except Exception:                    # noqa: BLE001
                    state["tail"].append(line)
                    del state["tail"][:-6]
                    continue
                if "progress" in d:
                    state["last"] = d["progress"]
                    JOB["progress"] = d["progress"]
        except Exception:                            # noqa: BLE001
            pass

    t = threading.Thread(target=pump, daemon=True)
    t.start()

    out = ""
    try:
        out = p.stdout.read()                        # 子が終わるまで
        p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        p.wait()
        raise RuntimeError(f"{int(timeout)}秒たっても終わりませんでした。"
                           "この配線では探索が通りません。直接指定を使ってください")
    finally:
        t.join(timeout=1.0)
        for f in (p.stdout, p.stderr):
            try:
                f.close()
            except Exception:                        # noqa: BLE001
                pass

    if p.returncode != 0 or not (out or "").strip():
        where = f"落ちた場所: {state['last']}" if state["last"] else ""
        extra = " / ".join(state["tail"][-2:])
        raise RuntimeError(
            f"カメラを調べる処理が異常終了しました（終了コード {p.returncode}）。"
            "カメラのドライバ側で落ちています。この設定は避けて、"
            f"直接指定から選んでください。{where} {extra}".strip())
    return json.loads(out)


def _run_job(name: str, args: list, timeout: float = 180.0) -> None:
    """重い測定を裏で1本だけ動かす。カメラは先に離し、最後に必ず戻す。"""
    def body():
        try:
            for p in POSE.values():
                p.stop()
            CAP.stop_all()
            time.sleep(0.6)
            JOB["result"] = _run_child(args, timeout)
        except Exception as e:                        # noqa: BLE001
            import traceback
            traceback.print_exc()
            JOB["error"] = f"{e}"
        finally:
            try:
                _apply(cfgmod.load())
            except Exception as e:                    # noqa: BLE001
                JOB["error"] = (JOB["error"] + f" / 再接続に失敗: {e}").strip()
            JOB["running"] = False
            JOB["done"] = True
            JOB["progress"] = ""

    JOB.update(name=name, running=True, done=False,
               result=None, error="", progress="準備中…")
    threading.Thread(target=body, daemon=True, name=f"job:{name}").start()


@app.get("/api/job")
def job_state() -> dict:
    return dict(JOB)


@app.post("/api/bandwidth")
def bandwidth() -> dict:
    """USBの帯域が足りているかを調べる（単独→同時）。"""
    if JOB["running"]:
        raise HTTPException(409, "別の測定が動いています")
    entries = _uvc_entries()
    if not entries:
        raise HTTPException(400, "種別が uvc のカメラがありません")

    _run_job("bandwidth", ["bandwidth", "--entries",
                           json.dumps(entries, ensure_ascii=False)], timeout=240.0)
    return {"started": True}


@app.post("/api/mode/search")
def mode_search() -> dict:
    """全台が同時に出せる、いちばん重い設定を探す（適用はしない）。"""
    if JOB["running"]:
        raise HTTPException(409, "別の測定が動いています")
    entries = _uvc_entries()
    if not entries:
        raise HTTPException(400, "種別が uvc のカメラがありません")

    _run_job("mode", ["search", "--entries",
                      json.dumps(entries, ensure_ascii=False)], timeout=240.0)
    return {"started": True}


@app.get("/api/mode/presets")
def mode_presets() -> dict:
    """探索を使わずに直接指定するための候補。

    探索はカメラを何十回も開き直すので、環境によっては通らない。
    設定を変えるだけなら開き直しは1回で済むので、こちらは必ず動く。
    """
    return {"presets": [
        dict(width=1920, height=1200, fps=120, note="いちばん重い。USB3が1台ずつ別系統なら"),
        dict(width=1920, height=1200, fps=60, note="解像度を保ったままfpsを半分に"),
        dict(width=1280, height=800, fps=120, note="体の測定はこれで十分。3台なら第一候補"),
        dict(width=1280, height=720, fps=120, note="さらに軽い"),
        dict(width=1280, height=720, fps=60, note="USB2.0でも3台通る"),
        dict(width=640, height=480, fps=120, note="最後の逃げ道。映ることの確認用"),
    ]}


@app.post("/api/mode/apply")
def mode_apply(body: dict = Body(...)) -> dict:
    """見つかった設定を、種別が uvc の全カメラに書き込んで再接続する。"""
    if JOB["running"]:
        raise HTTPException(409, "測定中です")
    w, h, f = int(body["width"]), int(body["height"]), float(body["fps"])
    cfg = cfgmod.load()
    n = 0
    for c in cfg["cameras"]:
        if c.get("kind") == "uvc":
            c["width"], c["height"], c["fps"] = w, h, f
            n += 1
    cfgmod.save(cfg)
    _apply(cfgmod.load())   # ここで CFG も入れ替わる
    return {"ok": True, "n": n,
            "message": f"{n}台を {w}x{h}@{int(f)} にして再接続しました"}


# ------------------------------------------------------------------ 設定
@app.get("/api/config")
def get_config() -> dict:
    return CFG


@app.post("/api/config")
def post_config(cfg: dict = Body(...)) -> dict:
    try:
        cfgmod.save(cfg)
        _apply(cfgmod.load())
        return {"ok": True, "message": "設定を保存して再接続しました"}
    except Exception as e:                            # noqa: BLE001
        raise HTTPException(400, f"{type(e).__name__}: {e}")


@app.get("/api/camera/{key}/settings")
def camera_settings(key: str) -> dict:
    src = CAP.get(key)
    if src is None or not hasattr(src, "read_settings"):
        raise HTTPException(404, "カメラがありません")
    cur = src.read_settings()
    out = {"key": key, "current": cur}
    if "exposure" in cur:
        try:
            sec = 2.0 ** float(cur["exposure"])
            out["shutter_sec"] = sec
            out["shutter_label"] = f"1/{round(1/sec)}秒" if sec < 1 else f"{sec:.2f}秒"
        except Exception:                             # noqa: BLE001
            pass
    return out


@app.post("/api/camera/{key}/shutter")
def camera_shutter(key: str, payload: dict = Body(...)) -> dict:
    """シャッター速度を秒で指定する（自動露出も切る）。"""
    src = CAP.get(key)
    if src is None or not hasattr(src, "set_manual_exposure"):
        raise HTTPException(404, "調整できないカメラです")
    sec = 1.0 / float(payload.get("denominator", 1000))
    r = src.set_manual_exposure(sec)
    a = r["actual_sec"]
    return {"ok": r["exposure_set"], **r,
            "label": f"1/{round(1/a)}秒" if a < 1 else f"{a:.2f}秒",
            "message": ("自動露出を切りました" if r["auto_off"]
                        else "自動露出を切れませんでした（機種によっては別の値が要ります）")}


@app.post("/api/camera/{key}/setting")
def camera_setting(key: str, payload: dict = Body(...)) -> dict:
    src = CAP.get(key)
    if src is None or not hasattr(src, "apply_setting"):
        raise HTTPException(404, "調整できないカメラです")
    name, value = payload.get("name"), payload.get("value")
    ok = src.apply_setting(str(name), float(value))
    return {"ok": ok, "current": src.read_settings() if ok else {}}




# ------------------------------------------------------------------ レンズ較正
@app.get("/api/lens/board")
def lens_board(cols: int = 10, rows: int = 7):
    """印刷用チェッカーボードを返す。A4に等倍で印刷して板に貼る。"""
    path = Path("config/lens") / f"board_{cols}x{rows}.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    make_board_png(str(path), cols=cols, rows=rows)
    return StreamingResponse(io.BytesIO(path.read_bytes()), media_type="image/png")


@app.post("/api/lens/{key}/start")
def lens_start(key: str, payload: dict = Body(default={})) -> dict:
    cols = int(payload.get("cols", 9))
    rows = int(payload.get("rows", 6))
    CALIB[key] = CalibSession(key=key, board=(cols, rows),
                              square_mm=float(payload.get("square_mm", 25.0)))
    return {"ok": True, "board": [cols, rows],
            "message": f"内側交点 {cols}×{rows} で開始しました。"
                       f"中央と四隅、傾けた画を合わせて15〜25枚撮ってください"}


@app.post("/api/lens/{key}/capture")
def lens_capture(key: str) -> dict:
    if key not in CALIB:
        raise HTTPException(400, "先に「較正を開始」を押してください")
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, "カメラがありません")
    fr = src.latest()
    if fr is None:
        raise HTTPException(503, "まだフレームがありません")
    # 較正は **補正前の生の絵** で行う必要がある
    was = src.undistort_enabled
    src.undistort_enabled = False
    time.sleep(0.15)
    fr = src.latest()
    r = CALIB[key].add(fr.image)
    src.undistort_enabled = was
    r["coverage"] = CALIB[key].coverage_report()
    return r


@app.post("/api/lens/{key}/compute")
def lens_compute(key: str) -> dict:
    ses = CALIB.get(key)
    if ses is None:
        raise HTTPException(400, "較正セッションがありません")
    model, msg = ses.compute()
    if model is None:
        return {"ok": False, "message": msg}
    model.save()
    applied = CAP.reload_lens(key)
    return {"ok": True, "message": msg, "applied": applied,
            "rms": round(model.rms, 3), "hfov": round(model.hfov_deg, 1),
            "n": model.n_images}


@app.post("/api/lens/{key}/reset")
def lens_reset(key: str) -> dict:
    CALIB.pop(key, None)
    return {"ok": True}


@app.post("/api/lens/{key}/toggle")
def lens_toggle(key: str, payload: dict = Body(default={})) -> dict:
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, "カメラがありません")
    src.undistort_enabled = bool(payload.get("on", True))
    return {"ok": True, "on": src.undistort_enabled,
            "has_model": src.has_undistort}


# ------------------------------------------------------------------ 記録
@app.post("/api/record/{state}")
def record(state: str) -> dict:
    on = state == "on"
    CAP.set_recording(on)
    return {"ok": True, "recording": on}


@app.post("/api/clip")
def clip() -> dict:
    root = Path(CFG.get("recording", {}).get("dir", "recordings"))
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = root / stamp
    out.mkdir(parents=True, exist_ok=True)
    saved = []
    for key, src in CAP.sources.items():
        frames = src.take_clip()
        if not frames:
            continue
        h, w = frames[0].image.shape[:2]
        span = frames[-1].t_mono - frames[0].t_mono
        fps = (len(frames) - 1) / span if span > 0 else 30.0
        path = out / f"{key}.mp4"
        vw = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
        for f in frames:
            vw.write(f.image)
        vw.release()
        saved.append(dict(key=key, file=str(path), frames=len(frames),
                          fps=round(fps, 1)))
    return {"ok": bool(saved), "dir": str(out), "files": saved}
