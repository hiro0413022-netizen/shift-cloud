"""capture/uvc.py — UVCカメラ（ELP AR0234 などのスイング撮影用）

■ Windows で高フレームレートを出すための要点

  1. **FOURCC を先に MJPG にする。** これをやらないと OpenCV は
     無圧縮 YUY2 で開こうとし、1920x1200 では 5〜10fps しか出ない。
     順番は FOURCC → 幅 → 高さ → fps。この順でないと効かないことがある。

  2. **バックエンドは DSHOW を優先。** MSMF は ELP 系で
     解像度・fps の設定が無視されることがある。DSHOW で開けなければ MSMF に落とす。

  3. **バッファを 1 にする。** 既定では数フレーム溜め込むため、
     ライブ調整中に遅延が効いてくる。

MJPEG を使うのは画質の妥協ではなく **帯域の必然** である。
1280x720/120fps は 無圧縮なら 221MB/s、MJPEG なら 13MB/s。
2台つないでも 27MB/s で済み、計測カメラのぶんが空く。
"""

from __future__ import annotations

import platform
import time
from typing import Optional

import cv2
import numpy as np

from .base import CaptureSource, SourceInfo

IS_WINDOWS = platform.system() == "Windows"


def _backends() -> list:
    if IS_WINDOWS:
        return [("DSHOW", cv2.CAP_DSHOW), ("MSMF", cv2.CAP_MSMF)]
    if platform.system() == "Darwin":
        return [("AVFOUNDATION", cv2.CAP_AVFOUNDATION)]
    return [("V4L2", cv2.CAP_V4L2), ("ANY", cv2.CAP_ANY)]


class UvcCamera(CaptureSource):
    def __init__(self, key: str, label: str, index: int,
                 width: int = 1280, height: int = 720, fps: float = 120.0,
                 fourcc: str = "MJPG", ring_seconds: float = 8.0,
                 settings: Optional[dict] = None):
        super().__init__(SourceInfo(key=key, label=label, kind="uvc",
                                    width=width, height=height, fps=fps,
                                    fourcc=fourcc, device=f"index {index}"),
                         ring_seconds=ring_seconds)
        self.index = index
        self.req = dict(width=width, height=height, fps=fps, fourcc=fourcc)
        self.settings = dict(settings or {})
        self._cap: Optional[cv2.VideoCapture] = None

    # ---------------------------------------------------------------- open
    def _open(self) -> None:
        last_err = ""
        for name, api in _backends():
            cap = cv2.VideoCapture(self.index, api)
            if not cap.isOpened():
                cap.release()
                last_err = f"{name} で開けません"
                continue
            self._configure(cap)
            ok, _ = cap.read()
            if not ok:
                cap.release()
                last_err = f"{name} で開けたが読めません"
                continue
            self._cap = cap
            self.info.device = f"index {self.index} / {name}"
            self._readback(cap)
            return
        raise RuntimeError(last_err or "カメラを開けません")

    def _configure(self, cap: cv2.VideoCapture) -> None:
        fc = self.req["fourcc"]
        if fc:
            cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*fc))
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.req["width"])
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.req["height"])
        cap.set(cv2.CAP_PROP_FPS, self.req["fps"])
        try:
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:                            # noqa: BLE001
            pass
        for k, v in self.settings.items():
            self.apply_setting(k, v, cap)

    def _readback(self, cap: cv2.VideoCapture) -> None:
        self.info.width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.info.height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.info.fps = float(cap.get(cv2.CAP_PROP_FPS))
        v = int(cap.get(cv2.CAP_PROP_FOURCC))
        self.info.fourcc = "".join(chr((v >> (8 * i)) & 0xFF) for i in range(4)).strip()

    def _grab(self) -> Optional[np.ndarray]:
        if self._cap is None:
            return None
        ok, img = self._cap.read()
        return img if ok else None

    def _close(self) -> None:
        if self._cap is not None:
            self._cap.release()
            self._cap = None

    # ------------------------------------------------------------ 調整
    PROPS = {
        "exposure": cv2.CAP_PROP_EXPOSURE,
        "gain": cv2.CAP_PROP_GAIN,
        "brightness": cv2.CAP_PROP_BRIGHTNESS,
        "contrast": cv2.CAP_PROP_CONTRAST,
        "saturation": cv2.CAP_PROP_SATURATION,
        "gamma": cv2.CAP_PROP_GAMMA,
        "sharpness": cv2.CAP_PROP_SHARPNESS,
        "auto_exposure": cv2.CAP_PROP_AUTO_EXPOSURE,
        "wb_temperature": cv2.CAP_PROP_WB_TEMPERATURE,
        "auto_wb": cv2.CAP_PROP_AUTO_WB,
        "focus": cv2.CAP_PROP_FOCUS,
        "autofocus": cv2.CAP_PROP_AUTOFOCUS,
    }

    def apply_setting(self, key: str, value: float,
                      cap: Optional[cv2.VideoCapture] = None) -> bool:
        cap = cap or self._cap
        prop = self.PROPS.get(key)
        if cap is None or prop is None:
            return False
        ok = bool(cap.set(prop, float(value)))
        if ok:
            self.settings[key] = float(value)
        return ok

    def read_settings(self) -> dict:
        if self._cap is None:
            return dict(self.settings)
        out = {}
        for k, prop in self.PROPS.items():
            try:
                out[k] = float(self._cap.get(prop))
            except Exception:                        # noqa: BLE001
                pass
        return out


# -------------------------------------------------------------- 機器の探索
def probe_indices(max_index: int = 10, warmup: float = 0.15) -> list:
    """つながっているカメラを列挙し、1枚ずつ静止画を取る。

    OpenCV は機器名を返さないので、**実際の絵を見て役割を割り当てる** のが
    一番確実。UIの『機器を割り当てる』画面がこれを使う。
    """
    found = []
    for api_name, api in _backends():
        for i in range(max_index):
            cap = cv2.VideoCapture(i, api)
            if not cap.isOpened():
                cap.release()
                continue
            cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
            time.sleep(warmup)
            ok, img = cap.read()
            w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            f = float(cap.get(cv2.CAP_PROP_FPS))
            cap.release()
            if ok and img is not None:
                found.append(dict(index=i, backend=api_name, width=w, height=h,
                                  fps=f, thumb=img))
        if found:
            break                                    # 最初に成功したAPIで確定
    return found


def probe_modes(index: int, candidates: Optional[list] = None) -> list:
    """その機器が実際に出せる 解像度×fps を調べる。

    カタログ値ではなく **その個体・そのPC・そのケーブルで出る値** を見る。
    ここで出た数字が設計の前提になる。
    """
    cands = candidates or [
        (1920, 1200, 60), (1920, 1200, 120), (1920, 1080, 60), (1920, 1080, 120),
        (1280, 800, 120), (1280, 720, 120), (1280, 720, 200),
        (640, 480, 200), (640, 480, 260),
    ]
    api = _backends()[0][1]
    out = []
    cap = cv2.VideoCapture(index, api)
    if not cap.isOpened():
        cap.release()
        return out
    try:
        for w, h, f in cands:
            cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
            cap.set(cv2.CAP_PROP_FPS, f)
            gw = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            gh = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            if (gw, gh) != (w, h):
                continue
            # 実測 fps を測る（設定値は信用しない）
            n, t0 = 0, time.perf_counter()
            while time.perf_counter() - t0 < 0.7:
                if cap.read()[0]:
                    n += 1
            real = n / (time.perf_counter() - t0)
            out.append(dict(width=w, height=h, requested_fps=f,
                            reported_fps=float(cap.get(cv2.CAP_PROP_FPS)),
                            measured_fps=round(real, 1)))
    finally:
        cap.release()
    return out
