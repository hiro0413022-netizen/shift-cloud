"""server/app.py — ローカルの調整用サーバ

ブラウザで開いて、機器をつなぎながら見て直すための土台。
打席のPCで動かし、必要ならタブレットからも同じ画面を開ける。

  GET  /                        画面
  GET  /api/status              各カメラの状態と実測fps
  GET  /api/stream/{key}        ライブ映像（MJPEG）
  GET  /api/metrics             いまの姿勢指標
  POST /api/reference           アドレス姿勢を基準にする
  GET  /api/discover            つながっている機器を探す（サムネ付き）
  GET  /api/probe/{index}       その機器で実際に出る解像度×fpsを実測
  GET  /api/config              設定を読む
  POST /api/config              設定を書いて再起動
  POST /api/record/{on|off}     録画バッファの開始・停止
  POST /api/clip                いまのバッファを書き出す
"""

from __future__ import annotations

import base64
import io
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

import cv2
import numpy as np
from fastapi import Body, FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse

from .. import config as cfgmod
from ..capture.manager import CaptureManager
from ..capture.uvc import probe_indices, probe_modes
from ..pose.estimator import PoseEstimator, draw_overlay
from ..pose import metrics as M
from ..calib.lens import CalibSession, LensModel, make_board_png

STATIC = Path(__file__).resolve().parent / "static"

app = FastAPI(title="GolfSim ローカル調整サーバ")

CFG: dict = {}
CAP = CaptureManager()
POSE: Dict[str, PoseEstimator] = {}
REF: Dict[str, dict] = {}
ROLES: Dict[str, str] = {}
CALIB: Dict[str, CalibSession] = {}


# ------------------------------------------------------------------ 起動
def _apply(cfg: dict) -> None:
    global CFG, POSE, ROLES
    CFG = cfg
    for p in POSE.values():
        p.stop()
    POSE = {}
    ROLES = {c["key"]: c.get("role", "front") for c in cfg["cameras"]}
    CAP.configure(cfg["cameras"])
    CAP.start_all()
    if cfg["pose"].get("enabled", True):
        for key, src in CAP.sources.items():
            est = PoseEstimator(key,
                                target_fps=float(cfg["pose"].get("target_fps", 25)),
                                model_complexity=int(cfg["pose"].get("model_complexity", 1)))
            est.bind(src)
            est.start()
            POSE[key] = est


@app.on_event("startup")
def _startup() -> None:
    _apply(cfgmod.load())


@app.on_event("shutdown")
def _shutdown() -> None:
    for p in POSE.values():
        p.stop()
    CAP.stop_all()


# ------------------------------------------------------------------ 画面
@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return (STATIC / "index.html").read_text(encoding="utf-8")


# ------------------------------------------------------------------ 状態
@app.get("/api/status")
def status() -> dict:
    st = CAP.status()
    for row in st:
        est = POSE.get(row["key"])
        r = est.latest() if est else None
        row["role"] = ROLES.get(row["key"], "front")
        row["pose_available"] = bool(est and est.available)
        row["pose_ok"] = bool(r and r.ok)
        row["pose_ms"] = round(r.infer_ms, 1) if r else None
        row["pose_quality"] = round(M.quality(r), 2) if r else 0.0
        row["has_reference"] = row["key"] in REF and bool(REF[row["key"]])
        src = CAP.get(row["key"])
        row["undistort"] = bool(src and src.has_undistort)
        lm = LensModel.load(row["key"])
        row["lens"] = (dict(rms=round(lm.rms, 3), n=lm.n_images,
                            hfov=round(lm.hfov_deg, 1)) if lm else None)
        row["calib_n"] = CALIB[row["key"]].n if row["key"] in CALIB else 0
        row["calib_active"] = row["key"] in CALIB
    return {"site": CFG.get("site", {}), "cameras": st,
            "pose_enabled": CFG.get("pose", {}).get("enabled", True)}


@app.get("/api/metrics")
def metrics() -> dict:
    out = {}
    for key, est in POSE.items():
        r = est.latest()
        ms = M.compute(ROLES.get(key, "front"), r, REF.get(key))
        out[key] = [dict(key=x.key, label=x.label, value=round(float(x.value), 1),
                         unit=x.unit, hint=x.hint) for x in ms]
    return {"t": time.time(), "metrics": out}


@app.post("/api/reference")
def set_reference(payload: dict = Body(default={})) -> dict:
    keys = payload.get("keys") or list(POSE.keys())
    done = []
    for k in keys:
        est = POSE.get(k)
        if not est:
            continue
        ref = M.make_reference(est.latest())
        if ref:
            REF[k] = ref
            done.append(k)
    return {"ok": bool(done), "keys": done,
            "message": "アドレス姿勢を基準にしました" if done else "姿勢が取れていません"}


@app.post("/api/reference/clear")
def clear_reference() -> dict:
    REF.clear()
    return {"ok": True}


# ------------------------------------------------------------------ 映像
def _encode(img: np.ndarray, quality: int = 80) -> bytes:
    ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    return buf.tobytes() if ok else b""


def _mjpeg(key: str, overlay: bool, quality: int, max_fps: float):
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, f"カメラ {key} がありません")
    est = POSE.get(key)
    interval = 1.0 / max(1.0, max_fps)
    last = -1
    while True:
        t0 = time.perf_counter()
        fr = src.latest()
        if fr is None:
            time.sleep(0.05)
            continue
        if fr.index != last:
            last = fr.index
            img = fr.image
            if overlay and est is not None:
                img = draw_overlay(img.copy(), est.latest())
            jpg = _encode(img, quality)
            if jpg:
                yield (b"--frame\r\nContent-Type: image/jpeg\r\n"
                       b"Content-Length: " + str(len(jpg)).encode() + b"\r\n\r\n"
                       + jpg + b"\r\n")
        rest = interval - (time.perf_counter() - t0)
        if rest > 0:
            time.sleep(rest)


@app.get("/api/stream/{key}")
def stream(key: str, overlay: int = 1, quality: int = 80, fps: float = 30.0):
    return StreamingResponse(_mjpeg(key, bool(overlay), quality, fps),
                             media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/snapshot/{key}")
def snapshot(key: str, overlay: int = 1):
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, "カメラがありません")
    fr = src.latest()
    if fr is None:
        raise HTTPException(503, "まだフレームがありません")
    img = fr.image
    if overlay and key in POSE:
        img = draw_overlay(img.copy(), POSE[key].latest())
    return StreamingResponse(io.BytesIO(_encode(img, 90)), media_type="image/jpeg")


# ------------------------------------------------------------------ 機器探索
@app.get("/api/discover")
def discover(max_index: int = 8) -> dict:
    found = probe_indices(max_index=max_index)
    out = []
    for f in found:
        th = cv2.resize(f["thumb"], (320, int(320 * f["thumb"].shape[0] / f["thumb"].shape[1])))
        out.append(dict(index=f["index"], backend=f["backend"],
                        width=f["width"], height=f["height"], fps=round(f["fps"], 1),
                        thumb="data:image/jpeg;base64," +
                              base64.b64encode(_encode(th, 70)).decode()))
    return {"devices": out,
            "note": "映っている絵を見て、どれがどの位置のカメラか決めてください"}


@app.get("/api/probe/{index}")
def probe(index: int) -> dict:
    return {"index": index, "modes": probe_modes(index),
            "note": "measured_fps が実際に出た値です。カタログ値ではなくこちらで設計します"}


# ------------------------------------------------------------------ 設定
@app.get("/api/config")
def get_config() -> dict:
    return CFG


@app.post("/api/config")
def post_config(cfg: dict = Body(...)) -> dict:
    try:
        cfgmod.save(cfg)
        _apply(cfgmod.load())
        return {"ok": True, "message": "設定を保存して再接続しました"}
    except Exception as e:                            # noqa: BLE001
        raise HTTPException(400, f"{type(e).__name__}: {e}")


@app.post("/api/camera/{key}/setting")
def camera_setting(key: str, payload: dict = Body(...)) -> dict:
    src = CAP.get(key)
    if src is None or not hasattr(src, "apply_setting"):
        raise HTTPException(404, "調整できないカメラです")
    name, value = payload.get("name"), payload.get("value")
    ok = src.apply_setting(str(name), float(value))
    return {"ok": ok, "current": src.read_settings() if ok else {}}




# ------------------------------------------------------------------ レンズ較正
@app.get("/api/lens/board")
def lens_board(cols: int = 10, rows: int = 7):
    """印刷用チェッカーボードを返す。A4に等倍で印刷して板に貼る。"""
    path = Path("config/lens") / f"board_{cols}x{rows}.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    make_board_png(str(path), cols=cols, rows=rows)
    return StreamingResponse(io.BytesIO(path.read_bytes()), media_type="image/png")


@app.post("/api/lens/{key}/start")
def lens_start(key: str, payload: dict = Body(default={})) -> dict:
    cols = int(payload.get("cols", 9))
    rows = int(payload.get("rows", 6))
    CALIB[key] = CalibSession(key=key, board=(cols, rows),
                              square_mm=float(payload.get("square_mm", 25.0)))
    return {"ok": True, "board": [cols, rows],
            "message": f"内側交点 {cols}×{rows} で開始しました。"
                       f"中央と四隅、傾けた画を合わせて15〜25枚撮ってください"}


@app.post("/api/lens/{key}/capture")
def lens_capture(key: str) -> dict:
    if key not in CALIB:
        raise HTTPException(400, "先に「較正を開始」を押してください")
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, "カメラがありません")
    fr = src.latest()
    if fr is None:
        raise HTTPException(503, "まだフレームがありません")
    # 較正は **補正前の生の絵** で行う必要がある
    was = src.undistort_enabled
    src.undistort_enabled = False
    time.sleep(0.15)
    fr = src.latest()
    r = CALIB[key].add(fr.image)
    src.undistort_enabled = was
    r["coverage"] = CALIB[key].coverage_report()
    return r


@app.post("/api/lens/{key}/compute")
def lens_compute(key: str) -> dict:
    ses = CALIB.get(key)
    if ses is None:
        raise HTTPException(400, "較正セッションがありません")
    model, msg = ses.compute()
    if model is None:
        return {"ok": False, "message": msg}
    model.save()
    applied = CAP.reload_lens(key)
    return {"ok": True, "message": msg, "applied": applied,
            "rms": round(model.rms, 3), "hfov": round(model.hfov_deg, 1),
            "n": model.n_images}


@app.post("/api/lens/{key}/reset")
def lens_reset(key: str) -> dict:
    CALIB.pop(key, None)
    return {"ok": True}


@app.post("/api/lens/{key}/toggle")
def lens_toggle(key: str, payload: dict = Body(default={})) -> dict:
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, "カメラがありません")
    src.undistort_enabled = bool(payload.get("on", True))
    return {"ok": True, "on": src.undistort_enabled,
            "has_model": src.has_undistort}


# ------------------------------------------------------------------ 記録
@app.post("/api/record/{state}")
def record(state: str) -> dict:
    on = state == "on"
    CAP.set_recording(on)
    return {"ok": True, "recording": on}


@app.post("/api/clip")
def clip() -> dict:
    root = Path(CFG.get("recording", {}).get("dir", "recordings"))
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = root / stamp
    out.mkdir(parents=True, exist_ok=True)
    saved = []
    for key, src in CAP.sources.items():
        frames = src.take_clip()
        if not frames:
            continue
        h, w = frames[0].image.shape[:2]
        span = frames[-1].t_mono - frames[0].t_mono
        fps = (len(frames) - 1) / span if span > 0 else 30.0
        path = out / f"{key}.mp4"
        vw = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
        for f in frames:
            vw.write(f.image)
        vw.release()
        saved.append(dict(key=key, file=str(path), frames=len(frames),
                          fps=round(fps, 1)))
    return {"ok": bool(saved), "dir": str(out), "files": saved}
