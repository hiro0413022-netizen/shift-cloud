"""shot_pipeline.py — 計測値を1本のショット記録にする

■ ここが何を埋めているか

これまで部品はあったが、つながっていなかった。

    shot_analysis.py  コマ列 → 初速・打ち出し方向        （Phase 1・完成）
    spin_model.py     回転の推定                          （完成）
    ball_flight.py    初速・角度・回転 → 弾道             （Phase 2・完成）
    range.html        弾道 → 画面                         （完成）
        ↑ ここが無かった

このモジュールが「計測ユニットが出した数字」を受け取り、弾道を計算し、
クラブを推定し、1件の記録にして残す。画面はその記録を見るだけでよくなる。

■ 残す形

1ショット = 1つの JSON。将来コーチAIに渡すのはこの記録の集まりで、
スイング映像・骨格とは `swing` フィールドで結びつける。

**2026-09-12：TrackMan の設計を調べて、3点を改めた。**

1. **弾道の座標列を記録に入れる**（以前は「再計算できるから入れない」としていた）。
   TrackMan は `BallTrajectory[]` を保存している。理由は明快で、
   **弾道エンジンを直すと過去のショットの絵が変わってしまう**から。
   計算し直せることと、そのとき同じ絵が出ることは別の話だった。
   60点に間引いて入れる（1球あたり2KB弱）。

2. **回転を「スピン量＋スピン軸」で持つ**。TrackMan は `SpinRate` / `SpinAxis`。
   バックスピンとサイドスピンに分けて持つと、合計の回転が見えず、
   球の曲がりが軸の傾きで決まることも伝わらない。両方入れるが、主はこちら。

3. **実測値と正規化値を両方持つ**。TrackMan は `Measurement` と
   `NormalizedMeasurement`。標高・気温・風が違う日の球を並べても比べられない。
   **標準条件（海抜0m・20℃・無風・平坦）に直した値**を別に持つ。

    shots/20260908/shot_20260908_143052_017.json

■ 単位

外から来る値は m/s でも mph でもよい。中では m/s に統一する。
角度は度、回転は rpm。距離はメートルで持ち、表示のときだけヤードにする。
"""
from __future__ import annotations

import json
import math
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Optional

from ball_flight import MPH, YARD, Shot, simulate

# ---------------------------------------------------------------------------
# クラブの目安
#
# 計測ユニットが測るのは**球**であって、クラブが何かは分からない。
# だが初速・打ち出し角・回転の組み合わせは、クラブごとにかなり離れている。
# ここでは「いちばん近いクラブ」を出しておいて、**人が直せる**ようにする。
#
# 直した記録が溜まれば、その人の実際の値でこの表を作り直せる。
# （レッスンではコーチが何番か分かっているので、直すのは手間にならない）
# ---------------------------------------------------------------------------
CLUBS = [
    # (id, 表示名, 代表の初速m/s, 打ち出し角, バックスピン)
    ("DR", "ドライバー",  62.0, 11.5, 2600),
    ("3W", "3番ウッド",   58.0, 12.5, 3400),
    ("5W", "5番ウッド",   56.0, 13.5, 4000),
    ("U4", "4番UT",      54.5, 14.5, 4400),
    ("I5", "5番アイアン", 52.0, 15.5, 5400),
    ("I6", "6番アイアン", 49.5, 17.0, 6200),
    ("I7", "7番アイアン", 47.0, 18.5, 7100),
    ("I8", "8番アイアン", 44.5, 20.5, 7900),
    ("I9", "9番アイアン", 42.0, 23.0, 8700),
    ("PW", "PW",         39.5, 25.5, 9300),
    ("AW", "AW",         36.0, 28.0, 9800),
    ("SW", "SW",         32.0, 31.0, 10400),
]

# 各項目のばらつきの目安。これで割ってから距離を測る（単位をそろえるため）
_SCALE = (6.0, 3.5, 1400.0)


def estimate_club(ball_speed_ms: float, launch_deg: float,
                  backspin_rpm: float) -> tuple[str, str, float]:
    """いちばん近いクラブを返す。 (id, 表示名, 確からしさ0〜1)

    確からしさは「1位と2位の離れ具合」で出す。両者が近ければ低くなり、
    画面でも「たぶん7番」と分かる出し方ができる。
    """
    d = []
    for cid, name, v, la, sp in CLUBS:
        e = (((ball_speed_ms - v) / _SCALE[0]) ** 2
             + ((launch_deg - la) / _SCALE[1]) ** 2
             + ((backspin_rpm - sp) / _SCALE[2]) ** 2) ** 0.5
        d.append((e, cid, name))
    d.sort()
    best, second = d[0], d[1]
    # 1位が2位よりどれだけ近いか。同じくらいなら確からしさは低い
    conf = 0.0 if second[0] <= 1e-9 else max(0.0, min(1.0, 1.0 - best[0] / second[0]))
    # そもそもどのクラブからも遠ければ下げる（変な計測値のとき）
    conf *= max(0.0, min(1.0, 1.0 - (best[0] - 1.0) / 3.0)) if best[0] > 1.0 else 1.0
    return best[1], best[2], round(conf, 3)


@dataclass
class Measured:
    """計測ユニットの出力。ここが唯一の入口。"""
    ball_speed_ms: float
    launch_deg: float
    azimuth_deg: float = 0.0
    backspin_rpm: float = 2500.0
    sidespin_rpm: float = 0.0
    head_speed_ms: Optional[float] = None       # 測れれば
    source: str = "manual"                      # camera / radar / manual / demo
    quality: Optional[float] = None             # 計測の確からしさ 0〜1
    warnings: list = field(default_factory=list)

    @classmethod
    def from_any(cls, d: dict) -> "Measured":
        """mph でも m/s でも受ける。外から来る形の揺れをここで吸収する。"""
        def num(*keys, default=None):
            for k in keys:
                if d.get(k) is not None:
                    return float(d[k])
            return default

        v = num("ball_speed_ms", "ball_ms", "speed_ms")
        if v is None:
            mph = num("ball_speed_mph", "ball_mph", "speed_mph")
            v = mph * MPH if mph is not None else None
        if v is None:
            raise ValueError("ボール初速がありません（ball_speed_ms か ball_speed_mph）")

        hs = num("head_speed_ms", "club_speed_ms")
        if hs is None:
            hm = num("head_speed_mph", "club_speed_mph")
            hs = hm * MPH if hm is not None else None

        # **回転は2通りの言い方で来る。**
        #   ・バックスピン＋サイドスピン（うちの旧来の形）
        #   ・スピン量＋スピン軸（TrackMan・GCQuad などの形。こちらが業界の標準）
        # どちらで来ても受けて、中では両方を持つ。
        back = num("backspin_rpm", "backspin")
        side = num("sidespin_rpm", "sidespin")
        rate = num("spin_rate_rpm", "spin_rate", "spin_rpm")
        axis = num("spin_axis_deg", "spin_axis")
        if back is None and rate is not None:
            a = math.radians(axis or 0.0)
            back = rate * math.cos(a)
            side = rate * math.sin(a)
        if back is None:
            back = 2500.0
        if side is None:
            side = 0.0

        return cls(
            ball_speed_ms=v,
            launch_deg=num("launch_deg", "launch", default=0.0),
            azimuth_deg=num("azimuth_deg", "azimuth", "direction_deg", default=0.0),
            backspin_rpm=back,
            sidespin_rpm=side,
            head_speed_ms=hs,
            source=str(d.get("source", "manual")),
            quality=num("quality"),
            warnings=list(d.get("warnings") or []),
        )


def _sanity(m: Measured) -> list[str]:
    """明らかにおかしい計測値に印を付ける。

    実データ（GOLFLAND 40,615球）には初速 84m/s のような計測異常が混ざっていた。
    そういう値をそのまま画面に出すと、お客さんが「300yd 出た」と誤解する。
    **弾かずに、印を付けて残す。** 計測側を直すための材料になるため。
    """
    w = []
    # 初速の目安（参考: PGAツアー平均 74.6 m/s = 167 mph）
    #   〜82 m/s  … 強い人ならあり得る
    #   82〜95    … ドラコン級。**練習場のお客さんではまず出ない**ので要確認
    #   95〜      … 物理的に出ない
    #
    # 実データ（GOLFLAND 40,615球）に 84 m/s のような値が混ざっていた。
    # 弾道計算は正直なので、そのまま入れると 300yd と表示され、
    # お客さんが「自分は300yd飛ぶ」と誤解する。**必ず印を付ける。**
    if m.ball_speed_ms > 95.0 or m.ball_speed_ms < 5.0:
        w.append(f"ボール初速が物理的に出ない値です（{m.ball_speed_ms:.1f} m/s"
                 f" = {m.ball_speed_ms / MPH:.0f} mph）")
    elif m.ball_speed_ms > 82.0:
        w.append(f"ボール初速がドラコン級です（{m.ball_speed_ms:.1f} m/s"
                 f" = {m.ball_speed_ms / MPH:.0f} mph）。計測ずれの可能性があります")
    if not (-15.0 <= m.launch_deg <= 60.0):
        w.append(f"打ち出し角が範囲外です（{m.launch_deg:.1f}°）")
    if not (-45.0 <= m.azimuth_deg <= 45.0):
        w.append(f"打ち出し方向が範囲外です（{m.azimuth_deg:.1f}°）")
    if not (0.0 <= m.backspin_rpm <= 15000.0):
        w.append(f"バックスピンが範囲外です（{m.backspin_rpm:.0f} rpm）")
    if abs(m.sidespin_rpm) > 6000:
        w.append(f"サイドスピンが大きすぎます（{m.sidespin_rpm:.0f} rpm）")
    if m.head_speed_ms and m.head_speed_ms > 1:
        smash = m.ball_speed_ms / m.head_speed_ms
        if smash > 1.55:
            w.append(f"ミート率が物理的に出ない値です（{smash:.2f}）")
        elif smash < 0.9:
            w.append(f"ミート率が低すぎます（{smash:.2f}）。計測ずれの可能性")
    return w


# ---------------------------------------------------------------------------
# 正規化（NormalizedMeasurement）
#
# 同じ球でも、標高・気温・風が違えば飛距離は変わる。
# 別の日・別の店の球を並べて比べるには、**条件を揃えた値**が要る。
# TrackMan は実測値とは別に NormalizedMeasurement を持っている。それに倣う。
# ---------------------------------------------------------------------------
STANDARD = {"altitude_m": 0.0, "temp_c": 20.0, "wind_ms": (0.0, 0.0),
            "surface": "fairway"}


def spin_axis(backspin_rpm: float, sidespin_rpm: float) -> tuple[float, float]:
    """バック／サイドの分解 → スピン量とスピン軸（度）。

    軸が正なら右に曲がる（右打ちのスライス）。
    球の曲がりは「回転の量」ではなく「軸の傾き」で決まる。
    分けて持つとそれが見えないので、こちらを主にする。
    """
    rate = math.hypot(backspin_rpm, sidespin_rpm)
    axis = math.degrees(math.atan2(sidespin_rpm, max(1e-6, backspin_rpm)))
    return rate, axis


def _flight(t, surface: str) -> dict:
    """弾道の結果を記録の形にする。**単位はSI（m・秒・度）を主にする。**"""
    return {
        "carry_m": round(t.carry_m, 2),
        "total_m": round(t.total_m, 2),
        "roll_m": round(t.total_m - t.carry_m, 2),
        "apex_m": round(t.apex_m, 2),
        "flight_time_s": round(t.flight_time_s, 3),
        "landing_angle_deg": round(t.landing_angle_deg, 1),
        "side_m": round(t.side_m, 2),
        "descent_speed_ms": round(t.descent_speed_ms, 2),
        "surface": surface,
    }


def _thin_path(path, n: int = 60) -> list:
    """弾道の座標列を n 点に間引く。**両端は必ず残す。**

    生のまま持つと1球で数百点になり、記録が重くなる。
    60点あれば、画面に出す線としても、あとで解析するにも足りる。
    """
    if path is None or len(path) == 0:
        return []
    m = len(path)
    if m <= n:
        idx = range(m)
    else:
        idx = [round(i * (m - 1) / (n - 1)) for i in range(n)]
    return [[round(float(path[i][0]), 3), round(float(path[i][1]), 3),
             round(float(path[i][2]), 3)] for i in idx]


def build(measured: dict | Measured, *, surface: str = "fairway",
          altitude_m: float = 0.0, temp_c: float = 20.0,
          wind_ms: tuple = (0.0, 0.0), club: Optional[str] = None,
          site: str = "", bay: str = "", swing: Optional[str] = None,
          seq: int = 0) -> dict:
    """計測値からショット記録を1件作る（保存はしない）。"""
    m = measured if isinstance(measured, Measured) else Measured.from_any(measured)
    warn = list(m.warnings) + _sanity(m)

    def shot_at(alt, tc, wind):
        return Shot(ball_speed_ms=m.ball_speed_ms, launch_deg=m.launch_deg,
                    azimuth_deg=m.azimuth_deg, backspin_rpm=m.backspin_rpm,
                    sidespin_rpm=m.sidespin_rpm, altitude_m=alt,
                    temp_c=tc, wind_ms=tuple(wind))

    # 実測の条件で。**弾道の座標列はここで取る**（画面に出すのはこちら）
    t = simulate(shot_at(altitude_m, temp_c, wind_ms),
                 surface=surface, keep_path=True)

    # 標準条件に揃えた値。別の日・別の店の球と比べるとき、こちらを使う
    same = (abs(altitude_m - STANDARD["altitude_m"]) < 1e-6
            and abs(temp_c - STANDARD["temp_c"]) < 1e-6
            and tuple(wind_ms) == STANDARD["wind_ms"]
            and surface == STANDARD["surface"])
    tn = t if same else simulate(
        shot_at(STANDARD["altitude_m"], STANDARD["temp_c"], STANDARD["wind_ms"]),
        surface=STANDARD["surface"], keep_path=False)

    rate, axis = spin_axis(m.backspin_rpm, m.sidespin_rpm)

    cid, cname, conf = estimate_club(m.ball_speed_ms, m.launch_deg, m.backspin_rpm)
    now = datetime.now()
    smash = (m.ball_speed_ms / m.head_speed_ms) if (m.head_speed_ms or 0) > 1 else None

    return {
        "id": f"shot_{now:%Y%m%d_%H%M%S}_{seq:03d}",
        "at": now.isoformat(timespec="seconds"),
        "site": site, "bay": bay,
        "swing": swing,                      # スイング映像と結びつける鍵
        "source": m.source,
        "measured": {
            "ball_speed_ms": round(m.ball_speed_ms, 3),
            "head_speed_ms": round(m.head_speed_ms, 3) if m.head_speed_ms else None,
            "smash": round(smash, 3) if smash else None,
            "launch_deg": round(m.launch_deg, 2),
            "azimuth_deg": round(m.azimuth_deg, 2),
            "backspin_rpm": round(m.backspin_rpm, 0),
            "sidespin_rpm": round(m.sidespin_rpm, 0),
            # **こちらが主。** 曲がりは軸の傾きで決まる
            "spin_rate_rpm": round(rate, 0),
            "spin_axis_deg": round(axis, 2),
            "quality": m.quality,
        },
        "club": {
            "id": club or cid,
            "name": cname if not club else
                    next((n for i, n, *_ in CLUBS if i == club), club),
            "estimated": club is None,       # 人が選んだのか、推定なのか
            "confidence": conf,
        },
        # **単位はSIで持ち、ヤード換算は表示側で行う。**
        # 同じ量を2つの単位で記録に入れると、片方だけ直す事故が起きる。
        # （carry_yd などは、古い画面のために当面だけ残す。いずれ消す）
        "flight": {
            **_flight(t, surface),
            "carry_yd": round(t.carry_m / YARD, 1),     # 旧画面向け。将来削除
            "total_yd": round(t.total_m / YARD, 1),     # 旧画面向け。将来削除
            "side_yd": round(t.side_m / YARD, 1),       # 旧画面向け。将来削除
        },
        # 標準条件（海抜0m・20℃・無風・フェアウェイ）に揃えた値。
        # 日や店をまたいで比べるときは必ずこちらを使う
        "flight_normalized": {**_flight(tn, STANDARD["surface"]),
                              "standard": dict(STANDARD, wind_ms=list(STANDARD["wind_ms"]))},
        # **弾道の座標列。** 弾道エンジンを直しても、この球の絵は変わらない
        "trajectory": _thin_path(t.path),
        "conditions": {"surface": surface, "altitude_m": altitude_m,
                       "temp_c": temp_c, "wind_ms": list(wind_ms)},
        "warnings": warn,
    }


# ---------------------------------------------------------------------------
# 保存
# ---------------------------------------------------------------------------
def shots_root(base: Optional[str] = None) -> str:
    root = base or os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "shots")
    return os.path.abspath(root)


def save(rec: dict, base: Optional[str] = None) -> str:
    """1件を JSON で残す。日付ごとのフォルダに分ける。"""
    day = rec["at"][:10].replace("-", "")
    d = os.path.join(shots_root(base), day)
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, rec["id"] + ".json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(rec, f, ensure_ascii=False, indent=1)
    return p


def load_day(day: Optional[str] = None, base: Optional[str] = None) -> list[dict]:
    """その日のショットを古い順に返す。"""
    day = day or datetime.now().strftime("%Y%m%d")
    d = os.path.join(shots_root(base), day)
    if not os.path.isdir(d):
        return []
    out = []
    for fn in sorted(os.listdir(d)):
        if not fn.endswith(".json"):
            continue
        try:
            with open(os.path.join(d, fn), encoding="utf-8") as f:
                out.append(json.load(f))
        except Exception:                                    # noqa: BLE001
            continue
    return out


def summarize(shots: list[dict]) -> dict:
    """セッションのまとめ。画面と、あとでコーチAIに渡す要約に使う。"""
    ok = [s for s in shots if not s.get("warnings")]
    if not ok:
        return {"n": len(shots), "n_used": 0}
    carry = [s["flight"]["carry_yd"] for s in ok]
    side = [s["flight"]["side_yd"] for s in ok]
    ball = [s["measured"]["ball_speed_ms"] for s in ok]

    def mean(a):
        return sum(a) / len(a)

    def sd(a):
        m = mean(a)
        return (sum((x - m) ** 2 for x in a) / len(a)) ** 0.5

    by_club: dict = {}
    for s in ok:
        by_club.setdefault(s["club"]["id"], []).append(s)

    def stats(rows):
        c = [r["flight"]["carry_yd"] for r in rows]
        sd_side = [r["flight"]["side_yd"] for r in rows]
        return {"n": len(rows), "name": rows[0]["club"]["name"],
                "avg_yd": round(mean(c), 1), "max_yd": round(max(c), 1),
                "sd_yd": round(sd(c), 1), "side_sd_yd": round(sd(sd_side), 1)}

    # **飛距離のばらつきはクラブごとにしか意味がない。**
    # ドライバーと PW を混ぜた σ を出すと、ただクラブを持ち替えた回数を
    # 測っているだけになる（最初これを出して σ67yd という数字が出た）。
    out = {
        "n": len(shots), "n_used": len(ok),
        "n_flagged": len(shots) - len(ok),
        "clubs": len(by_club),
        "ball_avg_ms": round(mean(ball), 1),
        "by_club": {k: stats(v) for k, v in sorted(by_club.items())},
    }
    if len(by_club) == 1:
        # 1本で打ち込んでいるときだけ、全体の数字が意味を持つ
        out["carry_avg_yd"] = round(mean(carry), 1)
        out["carry_max_yd"] = round(max(carry), 1)
        out["carry_sd_yd"] = round(sd(carry), 1)
        out["side_sd_yd"] = round(sd(side), 1)
    return out


# ---------------------------------------------------------------------------
# TrackMan 互換の書き出し
#
# 外に出すときの名前を、自分たちだけの言い方にしない。
# TrackMan のレポートJSON（スキーマ 2017-01-26）と同じ名前で出しておけば、
# コーチも、他社のツールも、そのまま読める。**名前を揃えるのは無料の互換性。**
#
# 対応表（うち → TrackMan）
#   ball_speed_ms      → BallSpeed        (m/s)
#   launch_deg         → LaunchAngle      (度)
#   azimuth_deg        → LaunchDirection  (度)
#   spin_rate_rpm      → SpinRate         (rpm)
#   spin_axis_deg      → SpinAxis         (度)
#   carry_m / total_m  → Carry / Total    (m)
#   side_m             → CarrySide / TotalSide (m)
#   apex_m             → MaxHeight        (m)
#   landing_angle_deg  → LandingAngle     (度)
#   flight_time_s      → HangTime         (秒)
#   head_speed_ms      → ClubSpeed        (m/s)
#   smash              → SmashFactor
#   trajectory         → BallTrajectory[] {X,Y,Z}
# ---------------------------------------------------------------------------
def to_trackman(rec: dict) -> dict:
    """1球を TrackMan の Stroke の形にする。"""
    m = rec.get("measured", {}) or {}
    f = rec.get("flight", {}) or {}
    n = rec.get("flight_normalized", {}) or {}

    def meas(src_f: dict) -> dict:
        d = {
            "BallSpeed": m.get("ball_speed_ms"),
            "LaunchAngle": m.get("launch_deg"),
            "LaunchDirection": m.get("azimuth_deg"),
            "SpinRate": m.get("spin_rate_rpm"),
            "SpinAxis": m.get("spin_axis_deg"),
            "Carry": src_f.get("carry_m"),
            "Total": src_f.get("total_m"),
            "CarrySide": src_f.get("side_m"),
            "TotalSide": src_f.get("side_m"),
            "MaxHeight": src_f.get("apex_m"),
            "LandingAngle": src_f.get("landing_angle_deg"),
            "HangTime": src_f.get("flight_time_s"),
        }
        if m.get("head_speed_ms"):
            d["ClubSpeed"] = m["head_speed_ms"]
        if m.get("smash"):
            d["SmashFactor"] = m["smash"]
        return {k: v for k, v in d.items() if v is not None}

    stroke = {
        "Id": rec.get("id"),
        "Time": rec.get("at"),
        "Club": (rec.get("club") or {}).get("name"),
        "Measurement": meas(f),
    }
    if n:
        stroke["NormalizedMeasurement"] = meas(n)
    if rec.get("trajectory"):
        stroke["Measurement"]["BallTrajectory"] = [
            {"X": p[0], "Y": p[1], "Z": p[2]} for p in rec["trajectory"]]
    if rec.get("swing"):
        stroke["Videos"] = [{"Id": rec["swing"], "Angle": "FO",
                             "Uri": f"/api/swing/{rec['swing']}/video/front.webm"}]
    if rec.get("warnings"):
        stroke["Warnings"] = rec["warnings"]
    return stroke


def to_trackman_report(shots: list[dict], *, player: str = "",
                       facility: str = "", kind: str = "ShotAnalysis") -> dict:
    """一連の球を TrackMan のレポートの形にまとめる。

    クラブごとに StrokeGroups を切る。TrackMan も「同じクラブの一連の球」を
    ひとかたまりにしている。番手を混ぜた平均やばらつきには意味がないため。
    """
    groups: dict[str, list] = {}
    for r in shots:
        key = (r.get("club") or {}).get("name") or "—"
        groups.setdefault(key, []).append(r)

    first = shots[0] if shots else {}
    cond = first.get("conditions", {}) or {}
    return {
        "$schema": "http://schemas.trackman.dk/json-schema/2017-01-26",
        "Kind": kind,
        "Client": {"Name": "YOZAN GolfSim", "Version": "0.1"},
        "Facility": facility or first.get("site", ""),
        "Environment": {"Altitude": cond.get("altitude_m", 0.0),
                        "Temperature": cond.get("temp_c", 20.0)},
        "StrokeGroups": [
            {
                "Club": club,
                "Player": {"Name": player},
                "Date": (rs[0].get("at") or "")[:10],
                "Strokes": [to_trackman(r) for r in rs],
            }
            for club, rs in groups.items()
        ],
    }
