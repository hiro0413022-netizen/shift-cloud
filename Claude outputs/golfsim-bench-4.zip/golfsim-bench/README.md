# GolfSim — 自作ゴルフ弾道計測システム

ゴルフランドの ImpactVision2 と同じ機材（ZWO ASI 系カメラ + IR ストロボ）を使い、
**既存ソフトを一切介さず**、カメラを直接掴んで動かすための自作システムです。

ImpactVision2 のオンライン認証もライセンスも関係ありません。
公開されている ZWO の公式 SDK に対して、ゼロから書いたコードです。

---

## Phase 0（今回）：カメラを映す

まずここまで。土台がしっかりしないと、その先の計測は絶対に安定しません。

- カメラを検出して接続する
- 露光・ゲイン・ROI をその場で調整できるライブビューア
- **実効フレームレートの計測** ← 弾道計測の精度を決める一番大事な数字
- インパクト前後を丸ごと残す高速バースト記録

---

## セットアップ

### 1. ZWO のドライバと SDK を入れる

ZWO 公式サイト（zwoastro.com）のダウンロードページから、以下を入手してください。

| 必要なもの | 用途 |
|---|---|
| ASI Camera Driver (Windows) | カメラを OS に認識させる。**Windows 11 対応の署名済み版** |
| ASI Camera SDK (Windows) | `ASICamera2.dll` が入っている |

SDK を展開すると `lib/x64/ASICamera2.dll` があります。このパスを控えておきます。

> **既存の IVCAM1.dll でも試せます**
> `F:\ImpactVision\ImpactVision2\IVCAM1.dll` は ASICamera2.dll v1.12 のリネーム版です。
> 手っ取り早く動作確認したいだけならこれを指定しても構いません。
> ただし 2017 年版なので、Windows 11 では公式の現行版に差し替えてください。

### 2. Python 環境

**64bit 版の Python 3.10 以降**を使ってください（32bit 版では x64 の DLL を読めません）。

```
cd F:\ImpactVision\GolfSim
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

### 3. 設定

`config.yaml` を開き、`sdk.dll_path` に DLL のパスを書きます。

```yaml
sdk:
  dll_path: "C:/ASI_SDK/lib/x64/ASICamera2.dll"
```

### 4. 既存ソフトの常駐を止める

`ivsb.exe`（ImpactVisionSensorBackground）は `HKLM\...\CurrentVersion\Run` に
登録されて自動起動し、カメラを掴んだままにします。
**これが動いているとこちらからカメラを開けません。**
タスクマネージャーで終了させ、スタートアップからも外してください。

---

## 使い方

```
cd src

python main.py doctor    # まずこれ。環境の不足を全部教えてくれます
python main.py list      # 接続されているカメラの一覧と仕様
python main.py live      # ライブビューア
python main.py record    # バースト記録
```

### ライブビューアのキー操作

| キー | 動作 |
|---|---|
| `q` / `ESC` | 終了 |
| `e` / `E` | 露光を下げる / 上げる |
| `g` / `G` | ゲインを下げる / 上げる |
| 左ドラッグ | ROI を矩形で指定 |
| `r` | ROI をフル解像度に戻す |
| `c` | **実効 FPS を計測** |
| `s` | 現在のフレームを PNG 保存 |
| `h` | ヒストグラム表示 |

---

## 最初にやるべきこと：フレームレートを稼ぐ

弾道計測の精度は、ほぼ **フレームレート** で決まります。
ボール初速 70m/s のとき、1000fps でも 1 コマの間に 7cm 進みます。

ライブビューアで `c` を押しながら、以下を調整して数字を追い込んでください。

1. **ROI を小さくする** — 効果が最大。左ドラッグでボール周辺だけに絞る
2. **露光を短くする** — `e` キー。IR ストロボが効いていれば数百 µs でも写る
3. **BandWidth を上げる** — `config.yaml` の `bandwidth`（80〜100 まで上げられる）
4. **USB3 ポートに直挿し** — ハブを噛ませると帯域が落ちます

目標は最低 **500fps**、できれば **1000fps 以上**です。

---

## 記録データの形式

`shots/shot_YYYYMMDD_HHMMSS/` に以下が保存されます。

| ファイル | 内容 |
|---|---|
| `frames.npy` | 全フレーム。`(N, H, W)` の uint8 配列 |
| `meta.json` | 撮影時刻・実効fps・各コマのタイムスタンプ・カメラ設定 |

`meta.json` の `timestamps_s` には**各コマの実測時刻**が入っています。
速度計算にはこれを使ってください。公称 fps ではなく実測値を使うのが精度の要です。

```python
import numpy as np, json
frames = np.load("shots/shot_.../frames.npy")
meta = json.load(open("shots/shot_.../meta.json", encoding="utf-8"))
print(frames.shape, meta["effective_fps"])
```

---

## この先のロードマップ

`docs/roadmap.md` を参照してください。

---

## 商用化を視野に入れる場合の注意

将来的に商品化を考えているとのことなので、先に書いておきます。

- **ImpactVision のコード・DLL・データファイルは一切流用しないでください。**
  このプロジェクトは公開 SDK に対する独自実装です。`IVCAM1.dll` を動作確認に使うのは
  グレーなので、製品版では必ず ZWO 公式の `ASICamera2.dll` を正規の配布条件で使ってください。
- **ZWO ASI SDK の再配布条件**を、商用利用前に ZWO に直接確認してください。
- **弾道計測の分野は特許が密集しています。**（Foresight、Trackman、GOLFZON など）
  特にストロボ多重露光やステレオ視の実装方式は要確認です。製品化の前に弁理士へ相談を。
- OpenCV は Apache 2.0 で商用利用可能です。

技術的に作れることと、売れる形にできることは別の話です。前者は問題なくいけます。
