// swing_analyze.js — 撮り終わった動画を、コマ送りで骨格にする
//
// ■ 撮影中に推定しない理由
//
// 撮影中は「実時間に間に合うこと」が絶対の制約になり、コマを落とすか
// 軽いモデルを使うかの二択になる。ダウンスイングは0.25秒しかないので、
// そこでコマを落とすのは致命的である。
// 撮り終わってからなら、何秒かけてもよい。落とすコマはゼロにできるし、
// 重いモデル（full）も使える。lesson-os も同じ理由で撮影後の解析にしている。
//
// ■ 30fpsでも足りるようにする工夫
//
//  1. **全コマ使う** — 撮影中の推定では毎秒8〜30回に間引いていたが、
//     ここでは動画に入っている30コマを1つも落とさない。
//  2. **重いモデルを使う** — full は lite より関節の飛びが少ない。
//  3. **コマの間を補う** — 表示と局面判定は、前後のコマから内挿する。
//     手元は0.25秒で画面の3割動くので、コマとコマの間にも意味がある。
//  4. **行って戻る飛びだけ直す** — 平滑化はしない。
//     低域通過をかけるとインパクトが別のスイングになる。
//     「出て行って戻ってきた」点だけを直す（lesson-os と同じ考え方）。

const VIS = 0.35;

// MediaPipe に渡す時刻は**必ず前より大きく**なければならない。
// 同じコマに二度当たったときや、2台目の解析に移ったときに0へ戻ると、
// そこで例外になって解析が止まる。通し番号を全体で1本にしておく。
let TS = 1;

/** 動画を最初から最後までコマ送りして、全コマの骨格を取る。 */
export async function analyzeVideo(video, landmarker, opt={}){
  const onProgress = opt.onProgress || (()=>{});
  const fps = opt.fps || 30;
  const step = 1/fps;
  const dur = opt.duration || video.duration;
  if(!isFinite(dur) || dur <= 0) throw new Error('動画の長さが取れません');

  // 録ってあるのは10秒ぶんだが、要るのはスイングの1〜2秒だけ。
  // 全部にかけると台数ぶん待たされるので、範囲を指定できるようにしてある。
  // 範囲が数えられない値（NaN など）で来ても、黙って0コマ返してはいけない。
  // 「解析したのに骨格が付かない」がいちばん分かりにくい壊れ方なので、
  // おかしければ全体を見る方に倒す。
  const num = (v, d) => Number.isFinite(v) ? v : d;
  const from = Math.max(0, num(opt.from, 0));
  const to   = Math.min(dur, num(opt.to, dur));
  if(!(to - from >= step)) throw new Error('解析する範囲がありません');

  const out = [];
  const seek = t => new Promise(res=>{
    const done = ()=>{ video.removeEventListener('seeked', done); res(); };
    video.addEventListener('seeked', done);
    video.currentTime = Math.min(t, Math.max(0, dur - 1e-3));
    setTimeout(res, 2000);                 // 頭出しが返らない機体でも止まらない
  });

  video.pause();
  let n = 0;
  const total = Math.max(1, Math.floor((to-from)/step));
  for(let t=from; t<to-1e-3; t+=step){
    await seek(t);
    // 実時間の締切がないので、1コマずつ確実に処理する
    let lm = null;
    try{
      const r = landmarker.detectForVideo(video, TS++);
      lm = (r.landmarks && r.landmarks[0]) || null;
    }catch(e){ lm = null; }
    out.push({t: video.currentTime*1000, lm});
    if((++n % 5) === 0) onProgress(n, total);
  }
  onProgress(total, total);
  return out;
}

/** 「行って戻る」飛びだけ直す。速い動きには触らない。 */
export function fixJumps(frames, thresh=0.06){
  const idx = [15,16,11,12,23,24,0];       // 手首・肩・腰・鼻
  let fixed = 0;
  for(let i=1; i<frames.length-1; i++){
    const a=frames[i-1].lm, b=frames[i].lm, c=frames[i+1].lm;
    if(!a||!b||!c) continue;
    for(const j of idx){
      if(!a[j]||!b[j]||!c[j]) continue;
      const d1=Math.hypot(b[j].x-a[j].x, b[j].y-a[j].y);
      const d2=Math.hypot(c[j].x-b[j].x, c[j].y-b[j].y);
      const d13=Math.hypot(c[j].x-a[j].x, c[j].y-a[j].y);
      // 出て行って戻ってきた＝両隣とは遠いのに、両隣どうしは近い
      if(d1>thresh && d2>thresh && d13 < Math.min(d1,d2)*0.5){
        b[j] = {x:(a[j].x+c[j].x)/2, y:(a[j].y+c[j].y)/2,
                z:((a[j].z??0)+(c[j].z??0))/2,
                visibility:Math.min(a[j].visibility??1, c[j].visibility??1)};
        fixed++;
      }
    }
  }
  return fixed;
}

/** 指定時刻の骨格を、前後のコマから内挿して作る。 */
export function lerpAt(frames, t){
  if(!frames.length) return null;
  let i = 0;
  while(i < frames.length-1 && frames[i+1].t <= t) i++;
  const a = frames[i], b = frames[Math.min(i+1, frames.length-1)];
  if(!a.lm) return b.lm || null;
  if(!b.lm || b === a) return a.lm;
  const span = b.t - a.t;
  const u = span > 0 ? Math.max(0, Math.min(1, (t - a.t)/span)) : 0;
  return a.lm.map((p,j)=>{
    const q = b.lm[j];
    if(!q) return p;
    // どちらかが見えていない点は、見えているほうを使う（混ぜると嘘になる）
    const va = p.visibility ?? 1, vb = q.visibility ?? 1;
    if(va < VIS && vb >= VIS) return q;
    if(vb < VIS && va >= VIS) return p;
    return {x:p.x+(q.x-p.x)*u, y:p.y+(q.y-p.y)*u,
            z:(p.z??0)+((q.z??0)-(p.z??0))*u,
            visibility:va+(vb-va)*u};
  });
}

/** 手元（両手首の中点）の軌跡。局面判定に使う。 */
export function handTrack(frames){
  return frames.map(f=>{
    const lm=f.lm;
    if(!lm) return {t:f.t, p:null};
    const ok=i=>lm[i] && (lm[i].visibility??1) > VIS;
    const a=ok(15)?lm[15]:null, b=ok(16)?lm[16]:null;
    const p = (a&&b) ? {x:(a.x+b.x)/2,y:(a.y+b.y)/2}
            : (a?{x:a.x,y:a.y}:(b?{x:b.x,y:b.y}:null));
    return {t:f.t, p};
  });
}

/** 3点を通る放物線の頂点の時刻。最接近した瞬間をコマとコマの間まで出す。 */
function vertex(a, b, c, f){
  const d1=f(a), d2=f(b), d3=f(c);
  const den=(a.t-b.t)*(a.t-c.t)*(b.t-c.t);
  if(!den) return b.t;
  const A=(c.t*(d2-d1)+b.t*(d1-d3)+a.t*(d3-d2))/den;
  const B=(c.t*c.t*(d1-d2)+b.t*b.t*(d3-d1)+a.t*a.t*(d2-d3))/den;
  if(!A) return b.t;
  const tv=-B/(2*A);
  return (tv>a.t && tv<c.t) ? tv : b.t;
}

/**
 * 撮り終わった軌跡から局面を出す。
 *
 * 順番はスイングの形そのままに、アドレス → インパクト → トップ で決める。
 *
 * ■ なぜ「いちばん離れた点＝トップ」ではいけないか
 *
 * 最初はそう書いていたが、間違いだった。**フォローはトップより高く上がる。**
 * 振り切った位置のほうがアドレスから遠いので、トップがフォローの側に取られ、
 * その後ろにインパクトを探しに行って何も見つからない、という壊れ方をする。
 * 実測でも、振り幅0.30のスイングでは1つも局面が取れなかった。
 *
 * 正しくは、アドレスの高さに**戻ってきた最初の瞬間**がインパクトで、
 * トップはその手前でいちばん離れた点、である。フォローはインパクトより後なので、
 * この順で決めれば混ざらない。
 */
export function findPhases(frames, opt={}){
  const tr = handTrack(frames).filter(x=>x.p);
  if(tr.length < 8) return null;

  const minTopAway = opt.minTopAway ?? 0.13;
  const impactNear = opt.impactNear ?? 0.09;
  // 動き出しの判定は「画面比/秒」で見る。コマ数で持つと、解析の刻みを変えた
  // とたんに意味が変わってしまう（撮影中の検出で実際にこれを踏んだ）。
  const startSpeed = opt.startSpeed ?? 0.36;

  // アドレス＝最初の静止区間の終わり
  let ai = 0;
  for(let i=1; i<tr.length; i++){
    const dt = Math.max(1, tr[i].t - tr[i-1].t) / 1000;
    const v = Math.hypot(tr[i].p.x-tr[i-1].p.x, tr[i].p.y-tr[i-1].p.y) / dt;
    if(v > startSpeed){ ai = Math.max(0, i-1); break; }
  }
  const addr = tr[ai], base = addr.p;
  const away = x => Math.hypot(x.p.x-base.x, x.p.y-base.y);
  const dy   = x => x.p.y - base.y;

  // じゅうぶん離れるまで進む。ここまで来なければスイングではない。
  let gi = -1;
  for(let i=ai+1; i<tr.length; i++){ if(away(tr[i]) >= minTopAway){ gi = i; break; } }
  if(gi < 0) return null;

  // インパクト＝そこから戻ってきて、アドレスの高さに最初に達する瞬間
  let impact = null;
  for(let i=gi+1; i<tr.length; i++){
    const y0 = dy(tr[i-1]), y1 = dy(tr[i]);
    if((y0 < 0 && y1 >= 0) || (y0 > 0 && y1 <= 0)){
      const f = (y1===y0) ? 0 : (0-y0)/(y1-y0);
      const u = Math.max(0, Math.min(1, f));
      impact = {t: tr[i-1].t + (tr[i].t-tr[i-1].t)*u, i};
      break;
    }
    // 横切らずに折り返すこともある（インパクトの手元はアドレスより少し前・少し下）。
    // 隔たりが減ってから増えに転じ、じゅうぶん近ければ、そこを最接近とみなす。
    if(i >= gi+2){
      const a=tr[i-2], b=tr[i-1], c=tr[i];
      const d=x=>Math.abs(dy(x));
      if(d(b) < d(a) && d(b) < d(c) && d(b) < impactNear){
        impact = {t: vertex(a,b,c,d), i, approx:true};
        break;
      }
    }
  }
  if(!impact) return null;

  // トップ＝アドレスとインパクトのあいだで、いちばん離れた点。
  // フォローはインパクトより後なので、ここには入らない。
  let top = tr[gi], topD = -1;
  for(let i=ai; i<=impact.i; i++){
    const d = away(tr[i]);
    if(d > topD){ topD = d; top = tr[i]; }
  }
  if(topD < minTopAway) return null;

  return {address:addr.t, top:top.t, impact:impact.t,
          approx:!!impact.approx, topAway:topD};
}
