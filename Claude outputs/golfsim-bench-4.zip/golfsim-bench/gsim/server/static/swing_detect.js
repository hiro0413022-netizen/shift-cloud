// swing_detect.js — アドレス → トップ → インパクト を骨格から見つける
//
// ■ 何を手がかりにするか
//
// 手元（両手首の中点）の位置だけを見る。クラブは骨格に写らないし、
// 体の回転は見る向きに依存するが、**手元はどのカメラからでも動く**。
//
//   アドレス : 手元が基準位置の近くで静止している
//   テイクバック: 基準から離れていく
//   トップ   : 離れる向きから戻る向きへ変わる瞬間（速度の符号が反転）
//   インパクト: 戻ってきて基準の高さを通過する瞬間
//
// ■ トップを合図にする
//
// **アドレスからトップまで行った時点で、1本のスイングとして確定させる。**
// インパクトが取れるかどうかは待たない。
//
// 録画はもう常に回っているので、「撮り始める合図」は要らない。
// 必要なのは「いつのスイングだったか」だけで、それはトップが分かれば決まる。
// インパクトが取れなければトップからの見積りで置き、あとで
// 「骨格を読み込む」を押したときに、映像の全コマから正確に取り直す。
//
// 以前はインパクトが取れないと1本にならず、取り逃していた。
//
// ■ 閾値は「コマ数」ではなく「時間」で持つ
//
// ここがいちばんの落とし穴だった。
// 姿勢推定は機械が重いと 30Hz → 8Hz まで自動で落ちる（落とさないと映像が固まる）。
// 「静止8コマでアドレス」「インパクト後12コマでスイング終了」のようにコマ数で
// 持っていると、8Hzでは 1秒・1.5秒 を意味してしまい、**何も検出できなくなる**。
// 実測でも 15Hz で終了しなくなり、10Hz 以下では1つも検出しなかった。
// 速さも「画面比/コマ」ではなく「画面比/秒」で見る。同じ理由である。

export const PHASE = {
  IDLE:'idle', ADDRESS:'address', BACK:'backswing', TOP:'top',
  DOWN:'downswing', IMPACT:'impact', FOLLOW:'follow',
};

export const DEFAULTS = {
  stillMs: 300,        // アドレスと認めるのに必要な静止時間
  stillSamples: 2,     // そのあいだに最低これだけのコマは見る
  stillSpeed: 0.10,    // 静止とみなす速さ（画面比/秒）
  stillNear: 0.10,     // 基準位置からこの範囲にいればアドレス
  startAway: 0.05,     // これ以上離れたらテイクバック開始
  minTopAway: 0.13,    // トップがこれ未満ならスイングとみなさない
  turnBack: 0.012,     // 離れる向きから戻る向きへ変わったと認める戻り量
  impactNear: 0.09,    // 基準の高さにこれだけ近づけばインパクトとみなす
  sideMax: 0.30,       // その位置が基準から左右にこれ以上離れていたら無視
  minDownSpeed: 0.6,   // ダウンでこの速さ（画面比/秒）が出ればスイング
  minBackSpeed: 0.18,  // または、トップまでの平均がこの速さ（画面比/秒）ならスイング
  followMs: 400,       // インパクト後、これだけ経ったら1本とする
  postTopMs: 900,      // トップからこれだけでインパクトが取れなくても1本とする
  downswingMs: 260,    // 取れなかったときのインパクトの見積り（トップから）
  maxSwingMs: 4000,    // これを超えたら取りやめ（構え直しなど）
};

const L_WRIST = 15, R_WRIST = 16;

// 手元＝両手首の中点。片方しか見えないときはその片方を使う。
// 打つ人の利き手を問わずに済むので、左右の想定を持たなくてよい。
export function handPoint(lm, visMin = 0.35){
  if(!lm) return null;
  const ok = i => lm[i] && (lm[i].visibility ?? 1) > visMin;
  const a = ok(L_WRIST) ? lm[L_WRIST] : null;
  const b = ok(R_WRIST) ? lm[R_WRIST] : null;
  if(a && b) return {x:(a.x+b.x)/2, y:(a.y+b.y)/2};
  return a ? {x:a.x, y:a.y} : (b ? {x:b.x, y:b.y} : null);
}

// 3点を通る放物線の頂点の時刻。最接近した瞬間をコマとコマの間まで出すのに使う。
// 骨格は毎秒8〜30回しか取れないので、コマ単位だと最大125msずれる。
function vertex(a, b, c){
  const t1=a.t, t2=b.t, t3=c.t, d1=a.d, d2=b.d, d3=c.d;
  const den = (t1-t2)*(t1-t3)*(t2-t3);
  if(!den) return b.t;
  const A = (t3*(d2-d1) + t2*(d1-d3) + t1*(d3-d2)) / den;
  const B = (t3*t3*(d1-d2) + t2*t2*(d3-d1) + t1*t1*(d2-d3)) / den;
  if(!A) return b.t;
  const tv = -B/(2*A);
  // 3点の外に出たら信用しない（谷でないときに起きる）
  return (tv > t1 && tv < t3) ? tv : b.t;
}

export class SwingDetector {
  constructor(opt){
    this.o = Object.assign({}, DEFAULTS, opt||{});
    this.reset();
  }
  reset(){
    this.phase = PHASE.IDLE;
    this.base = null;          // アドレスでの手元位置
    this.stillFrom = null;     // 静止し始めた時刻
    this.stillN = 0;
    this.hist = [];            // {t, x, y, away, v}
    this.tAddress = null; this.tTop = null; this.tImpact = null;
    this.tFollow = null;
    this.topAway = 0;
    this.impactApprox = false;
    this.near = [];            // ダウン中、基準の高さへの近づき具合（最接近を探す）
    this.downVmax = 0;         // ダウン中に出た最高の速さ（スイングかどうかの判断に使う）
    this.downN = 0;            // ダウン中に骨格が取れたコマ数
    this.events = [];
  }

  // 基準を外から与える（アドレスを手動で押した場合）
  setBase(p){ if(p) this.base = {x:p.x, y:p.y}; }

  /** 1コマぶん入れる。戻り値は、そのコマで起きた出来事（無ければ null）。 */
  push(t, lm){
    const p = handPoint(lm);
    // 人が見えなくても、時間で進む判断だけは進める。
    // インパクト前後は手がぶれて骨格が飛ぶので、ここで止まると1本にならない。
    if(!p) return this._tick(t);

    const prev = this.hist.length ? this.hist[this.hist.length-1] : null;
    const dt = prev ? Math.max(1, t - prev.t) : 0;
    // 速さは「画面比/秒」。コマ間隔が変わっても意味が変わらないようにする。
    const v = prev ? Math.hypot(p.x-prev.x, p.y-prev.y) / (dt/1000) : 0;
    const away = this.base ? Math.hypot(p.x-this.base.x, p.y-this.base.y) : 0;
    const rec = {t, x:p.x, y:p.y, away, v};
    this.hist.push(rec);
    if(this.hist.length > 600) this.hist.shift();

    const o = this.o;
    let ev = null;

    switch(this.phase){
      case PHASE.IDLE: {
        // 静止が続いたらそこをアドレスとみなす。基準が未設定ならその場所を基準にする。
        if(v < o.stillSpeed){
          if(this.stillFrom == null) this.stillFrom = t;
          this.stillN++;
        }else{
          this.stillFrom = null; this.stillN = 0;
        }
        if(this.stillFrom != null &&
           t - this.stillFrom >= o.stillMs && this.stillN >= o.stillSamples){
          if(!this.base) this.base = {x:p.x, y:p.y};
          if(Math.hypot(p.x-this.base.x, p.y-this.base.y) < o.stillNear){
            this.phase = PHASE.ADDRESS;
            this.tAddress = t;
            ev = {type:'address', t};
          }
        }
        break;
      }
      case PHASE.ADDRESS: {
        if(away > o.startAway){
          this.phase = PHASE.BACK;
          this.topAway = away;
          this.tTop = t;
          ev = {type:'takeaway', t};
        }
        break;
      }
      case PHASE.BACK: {
        if(away > this.topAway){ this.topAway = away; this.tTop = t; }
        // 離れる向きから戻る向きへ変わった＝トップ。**ここで1本と決める。**
        else if(this.topAway - away > o.turnBack && this.topAway >= o.minTopAway){
          this.phase = PHASE.DOWN;
          ev = {type:'top', t:this.tTop, away:this.topAway};
        }
        if(t - this.tAddress > o.maxSwingMs) this._giveUp();
        break;
      }
      case PHASE.DOWN: {
        // インパクト＝トップのあと、手元が基準の高さに**いちばん近づいた瞬間**。
        //
        // 以前は「基準の高さを横切ったら」で決めていたが、これが弱かった。
        //  ・横切るとはかぎらない。インパクトの手元はアドレスより少し前・少し下で、
        //    高さが一致せずに折り返すことがある（実測でも 0.013 手前で折り返した）
        //  ・さらに「基準の高さの近くで横切ったら」という条件まで付けていた。
        //    インパクト前後の手元は1コマで画面の5〜15%動く（30Hzでも）ので、
        //    その「近く」にはまず入らない。**これでインパクトが取れていなかった。**
        //
        // なので、横切ったときは補間で正確に取り、横切らなかったときは
        // 最接近した点を放物線の頂点で求める。どちらもコマとコマの間まで出せる。
        // ダウンの速さを見ておく。
        // **ゆっくり構え直しただけのものを弾く決め手はここ**である。
        // 本物のダウンスイングは 0.25秒で画面の3割動く（＝毎秒1.2）。
        // 構え直しは同じ振り幅でも1.5秒かけるので毎秒0.1にしかならない。桁が違う。
        this.downN++;
        if(v > this.downVmax) this.downVmax = v;

        if(prev && this.base){
          const y0 = prev.y - this.base.y, y1 = p.y - this.base.y;
          const nearOk = xAt => Math.abs(xAt - this.base.x) < o.sideMax
                                && this._fastEnough();

          if((y0 < 0 && y1 >= 0) || (y0 > 0 && y1 <= 0)){
            const f = (y1 === y0) ? 0 : (0 - y0) / (y1 - y0);   // 0〜1
            const u = Math.max(0, Math.min(1, f));
            if(nearOk(prev.x + (p.x - prev.x) * u)){
              this.tImpact = prev.t + (t - prev.t) * u;
              this.impactApprox = false;
              this.phase = PHASE.IMPACT;
              this.tFollow = t;
              ev = {type:'impact', t:this.tImpact, speed:v, between:[prev.t, t], frac:f};
            }
          }else{
            // 横切らない場合。基準の高さからの隔たりが、減ってから増えに転じた点を探す。
            this.near.push({t, d:Math.abs(y1), x:p.x});
            if(this.near.length > 3) this.near.shift();
            const [a, b, c] = this.near;
            if(c && b.d < a.d && b.d < c.d && b.d < o.impactNear && nearOk(b.x)){
              this.tImpact = vertex(a, b, c);
              this.impactApprox = false;
              this.phase = PHASE.IMPACT;
              this.tFollow = t;
              ev = {type:'impact', t:this.tImpact, speed:v, closest:b.d};
            }
          }
        }
        break;
      }
      case PHASE.IMPACT:
      case PHASE.FOLLOW: {
        this.phase = PHASE.FOLLOW;
        break;
      }
    }
    if(ev){ this.events.push(ev); return ev; }
    return this._tick(t);
  }

  /**
   * 時間だけで決まる進み方。骨格が取れたコマでも取れなかったコマでも通る。
   *
   * ここが「トップを合図にする」の実体。トップまで行ったスイングは、
   * インパクトが取れても取れなくても、必ず1本になって出てくる。
   */
  _tick(t){
    const o = this.o;
    if(this.phase === PHASE.IMPACT || this.phase === PHASE.FOLLOW){
      if(this.tFollow != null && t - this.tFollow >= o.followMs) return this._finish(t);
      return null;
    }
    if(this.phase === PHASE.DOWN){
      // インパクトが取れないまま時間が経った。
      // 速さから見てスイングだったなら、トップからの見積りで置いて1本にする。
      // 正確な値は、あとで映像の全コマから取り直せる。
      if(this.tTop != null && t - this.tTop >= o.postTopMs){
        if(!this._fastEnough()){ this._giveUp(); return null; }
        this.tImpact = this.tTop + o.downswingMs;
        this.impactApprox = true;
        return this._finish(t);
      }
      return null;
    }
    if(this.phase !== PHASE.IDLE && this.tAddress != null
       && t - this.tAddress > o.maxSwingMs) this._giveUp();
    return null;
  }

  /**
   * スイングだったと言えるだけの速さが出たか。
   *
   * 見るのは2つで、どちらかが満たされればよい。
   *
   *  ・ダウンの最高速度 … 本物は 0.25秒で画面の3割動く（毎秒1.2）。
   *    ゆっくり構え直しただけなら、同じ振り幅でも毎秒0.1にしかならない。
   *  ・トップまでの平均速度 … インパクト前後は手がぶれて骨格が飛ぶので、
   *    ダウンの速度が測れないことがある。そのときはテイクバックの速さで見る。
   *    本物は 0.30 を 0.8秒で（毎秒0.38）。構え直しは毎秒0.07。
   *
   * 片方でよいのは、遅く上げて速く振り下ろす人も、
   * 手がぶれてダウンが測れなかった人も、どちらも拾いたいからである。
   */
  _fastEnough(){
    if(this.downVmax >= this.o.minDownSpeed) return true;
    const ms = (this.tTop != null && this.tAddress != null) ? this.tTop - this.tAddress : 0;
    const back = ms > 0 ? this.topAway / (ms/1000) : 0;
    return back >= this.o.minBackSpeed;
  }

  _finish(t){
    const ev = {type:'complete', t,
                address:this.tAddress, top:this.tTop, impact:this.tImpact,
                topAway:this.topAway, approx:this.impactApprox};
    this.events.push(ev);
    const base = this.base;
    this.reset();
    this.base = base;           // 基準は持ち越す
    return ev;
  }

  _giveUp(){
    const base = this.base;
    this.reset();
    this.base = base;
  }
}
