"""
live_view.py — ライブビューア

カメラが映るか確認し、露光・ゲインをその場で調整しながら
「ボールが止まって写る設定」を探すためのツール。

キー操作:
    q / ESC : 終了
    e / E   : 露光を下げる / 上げる（×0.8 / ×1.25）
    g / G   : ゲインを下げる / 上げる（-10 / +10）
    r       : ROI をフル解像度に戻す
    c       : 実効 FPS を計測して表示
    s       : 現在のフレームを PNG 保存
    b       : バースト記録（burst_record を呼ぶ）
    h       : ヒストグラム表示の ON/OFF
    マウス左ドラッグ : ROI を矩形で指定
"""

from __future__ import annotations

import os
import time
from datetime import datetime
from typing import Optional

import cv2
import numpy as np

from asi_camera import ASICamera, CameraSettings, init_sdk


WINDOW = "GolfSim Live View"


class _RoiSelector:
    """マウスドラッグで ROI を選ばせる小さなヘルパ。"""

    def __init__(self) -> None:
        self.dragging = False
        self.start: Optional[tuple[int, int]] = None
        self.end: Optional[tuple[int, int]] = None
        self.result: Optional[tuple[int, int, int, int]] = None

    def on_mouse(self, event, x, y, flags, param) -> None:
        if event == cv2.EVENT_LBUTTONDOWN:
            self.dragging = True
            self.start = (x, y)
            self.end = (x, y)
        elif event == cv2.EVENT_MOUSEMOVE and self.dragging:
            self.end = (x, y)
        elif event == cv2.EVENT_LBUTTONUP and self.dragging:
            self.dragging = False
            self.end = (x, y)
            if self.start and self.end:
                x0, y0 = self.start
                x1, y1 = self.end
                x0, x1 = sorted((x0, x1))
                y0, y1 = sorted((y0, y1))
                if (x1 - x0) >= 16 and (y1 - y0) >= 16:
                    self.result = (x0, y0, x1 - x0, y1 - y0)

    def overlay(self, img: np.ndarray) -> None:
        if self.dragging and self.start and self.end:
            cv2.rectangle(img, self.start, self.end, (0, 255, 255), 1)


def _draw_hud(img: np.ndarray, cam: ASICamera, fps: float, hist: bool) -> np.ndarray:
    """情報表示を焼き込む。img はグレースケール想定。"""
    if img.ndim == 2:
        vis = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    else:
        vis = img.copy()

    s = cam.settings
    lines = [
        f"Exposure : {s.exposure_us} us",
        f"Gain     : {s.gain}",
        f"Size     : {vis.shape[1]} x {vis.shape[0]}",
        f"FPS      : {fps:6.1f}",
        f"Dropped  : {cam.dropped_frames()}",
    ]
    y = 20
    for line in lines:
        cv2.putText(vis, line, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(vis, line, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (0, 255, 0), 1, cv2.LINE_AA)
        y += 20

    # 飽和画素の警告（白飛びしているとボール輪郭が取れない）
    if img.ndim == 2:
        sat = float((img >= 250).mean()) * 100.0
        color = (0, 0, 255) if sat > 1.0 else (0, 255, 0)
        msg = f"Saturated: {sat:5.2f}%"
        cv2.putText(vis, msg, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(vis, msg, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    color, 1, cv2.LINE_AA)

    if hist and img.ndim == 2:
        h = cv2.calcHist([img], [0], None, [128], [0, 256]).flatten()
        h = h / (h.max() + 1e-9)
        hh, hw = 80, 128
        panel = np.zeros((hh, hw, 3), np.uint8)
        for i, v in enumerate(h):
            cv2.line(panel, (i, hh - 1), (i, hh - 1 - int(v * (hh - 2))),
                     (200, 200, 200), 1)
        vis[-hh:, -hw:] = panel

    return vis


def run(camera_id: int = 0,
        settings: Optional[CameraSettings] = None,
        output_dir: str = "captures") -> None:
    os.makedirs(output_dir, exist_ok=True)

    with ASICamera(camera_id, settings) as cam:
        print(cam.info.summary())
        print("\n[q]終了 [e/E]露光 [g/G]ゲイン [r]ROI解除 [c]FPS計測 "
              "[s]保存 [h]ヒストグラム / 左ドラッグでROI指定\n")

        cam.start_video()

        cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL)
        sel = _RoiSelector()
        cv2.setMouseCallback(WINDOW, sel.on_mouse)

        show_hist = False
        fps = 0.0
        t_last = time.perf_counter()
        n = 0

        while True:
            try:
                frame = cam.read(timeout_ms=2000)
            except Exception as e:
                print(f"フレーム取得に失敗: {e}")
                break

            n += 1
            now = time.perf_counter()
            if now - t_last >= 0.5:
                fps = n / (now - t_last)
                t_last, n = now, 0

            vis = _draw_hud(frame, cam, fps, show_hist)
            sel.overlay(vis)

            if sel.result is not None:
                x, y, w, h = sel.result
                sel.result = None
                base_x = cam.settings.roi_start_x or 0
                base_y = cam.settings.roi_start_y or 0
                cam.stop_video()
                cam.set_roi(base_x + x, base_y + y, w, h)
                cam.start_video()
                print(f"ROI を設定: start=({base_x + x}, {base_y + y}) "
                      f"size=({cam.settings.roi_width}x{cam.settings.roi_height})")
                continue

            cv2.imshow(WINDOW, vis)
            key = cv2.waitKey(1) & 0xFF

            if key in (ord('q'), 27):
                break
            elif key == ord('e'):
                cam.set_exposure(max(32, int(cam.settings.exposure_us * 0.8)))
            elif key == ord('E'):
                cam.set_exposure(int(cam.settings.exposure_us * 1.25) + 1)
            elif key == ord('g'):
                cam.set_gain(max(0, cam.settings.gain - 10))
            elif key == ord('G'):
                cam.set_gain(cam.settings.gain + 10)
            elif key == ord('r'):
                cam.stop_video()
                cam.settings.roi_start_x = None
                cam.settings.roi_start_y = None
                cam.settings.roi_width = None
                cam.settings.roi_height = None
                cam.apply_settings()
                cam.start_video()
                print("ROI をフル解像度に戻しました。")
            elif key == ord('c'):
                measured = cam.measure_fps(120)
                print(f"実効フレームレート: {measured:.1f} fps "
                      f"(ROI {cam.settings.roi_width or cam.info.max_width}"
                      f"x{cam.settings.roi_height or cam.info.max_height}, "
                      f"露光 {cam.settings.exposure_us}us)")
            elif key == ord('s'):
                name = datetime.now().strftime("frame_%Y%m%d_%H%M%S_%f.png")
                path = os.path.join(output_dir, name)
                cv2.imwrite(path, frame)
                print(f"保存: {path}")
            elif key == ord('h'):
                show_hist = not show_hist

        cv2.destroyAllWindows()


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser(description="GolfSim ライブビューア")
    p.add_argument("--dll", help="ASICamera2.dll のパス")
    p.add_argument("--camera-id", type=int, default=0)
    p.add_argument("--exposure", type=int, default=1201, help="露光時間(us)")
    p.add_argument("--gain", type=int, default=100)
    p.add_argument("--out", default="captures")
    a = p.parse_args()

    init_sdk(a.dll)
    run(a.camera_id,
        CameraSettings(exposure_us=a.exposure, gain=a.gain),
        a.out)
