"""
asi_camera.py — ZWO ASI カメラ制御ラッパー

ImpactVision2 が使っていたカメラは ZWO ASI 系（IVCAM1.dll = ASICamera2.dll v1.12）。
このモジュールは公式 ASI SDK を Python から叩き、ゴルフ計測向けの
「高フレームレート・短露光・ROI 切り出し」設定を扱いやすくまとめたもの。

依存:
    pip install zwoasi numpy
    ZWO 公式 ASI SDK（ASICamera2.dll）と Windows ドライバ
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field, asdict
from typing import Optional

import numpy as np

try:
    import zwoasi as asi
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "zwoasi が見つかりません。`pip install zwoasi` を実行してください。"
    ) from e


# ---------------------------------------------------------------------------
# ImpactVision2 の稼働ログから読み取れた実際の設定値
#   Log_2021_0130_090051.txt ほかより:
#     Gain 100 / Expose 885〜1201(計測時) 3918〜6066(待機時) / Gamma 85
#     WB_Red 43 / WB_Blue 60 / Brightness 0 / BandWidth 50 / Flip 3
# ---------------------------------------------------------------------------

@dataclass
class CameraSettings:
    """カメラ設定。ImpactVision2 のログ実測値をデフォルトにしている。"""

    # --- 計測（ショット検出）時 ---
    exposure_us: int = 1201       # 短露光。ボールを止めて写すため
    gain: int = 100
    gamma: int = 85
    wb_red: int = 43
    wb_blue: int = 60
    brightness: int = 0           # ASI では Offset に相当
    bandwidth: int = 50           # USB 帯域割当 (%)
    flip: int = 3                 # 3 = 上下左右反転（据付向き由来）
    high_speed_mode: int = 1      # RAW8 高速読み出し

    # --- 待機（アイドル）時の露光。IR ライト OFF 中に画を見るため長め ---
    idle_exposure_us: int = 6066

    # --- ROI ---
    # ImpactVision2 の .iss ヘッダにあった 364x306 は「保存された切り出し」
    # と思われる値。ASI の制約（幅 %8==0 / 高さ %2==0）を満たさないため、
    # ここでは None（フル解像度）を既定にし、実測しながら詰める方針。
    roi_width: Optional[int] = None
    roi_height: Optional[int] = None
    roi_start_x: Optional[int] = None
    roi_start_y: Optional[int] = None
    binning: int = 1

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class CameraInfo:
    name: str = ""
    camera_id: int = 0
    max_width: int = 0
    max_height: int = 0
    is_color: bool = False
    pixel_size_um: float = 0.0
    bit_depth: int = 0
    has_hardware_roi: bool = False
    supported_controls: list = field(default_factory=list)

    def summary(self) -> str:
        kind = "カラー" if self.is_color else "モノクロ"
        return (
            f"{self.name} (ID={self.camera_id})\n"
            f"  最大解像度 : {self.max_width} x {self.max_height}\n"
            f"  センサー   : {kind} / 画素 {self.pixel_size_um}um / {self.bit_depth}bit"
        )


class ASICameraError(RuntimeError):
    pass


def init_sdk(dll_path: Optional[str] = None) -> None:
    """ASI SDK を初期化する。

    dll_path を省略した場合は環境変数 ZWO_ASI_LIB を見る。

    既存の F:\\ImpactVision\\ImpactVision2\\IVCAM1.dll は ASICamera2.dll v1.12 の
    リネーム版なので、これを指定しても動く可能性はある。ただし v1.12 は 2017 年版で
    Windows 11 のドライバ事情に追随していないため、**公式サイトから現行 SDK を
    取得して使うことを強く推奨**する。
    """
    path = dll_path or os.environ.get("ZWO_ASI_LIB")
    if not path:
        raise ASICameraError(
            "ASICamera2.dll の場所が不明です。config.yaml の sdk.dll_path を設定するか、"
            "環境変数 ZWO_ASI_LIB を指定してください。"
        )
    if not os.path.exists(path):
        raise ASICameraError(f"ASICamera2.dll が見つかりません: {path}")
    asi.init(path)


class ASICamera:
    """ZWO ASI カメラ 1 台分のハンドル。

    使い方:
        init_sdk(r"C:\\ASI SDK\\lib\\x64\\ASICamera2.dll")
        with ASICamera(0, CameraSettings()) as cam:
            print(cam.info.summary())
            frame = cam.capture()
    """

    def __init__(self, camera_id: int = 0, settings: Optional[CameraSettings] = None):
        self.camera_id = camera_id
        self.settings = settings or CameraSettings()
        self._cam: Optional[asi.Camera] = None
        self.info = CameraInfo()
        self._video_running = False

    # -- ライフサイクル ----------------------------------------------------

    def __enter__(self) -> "ASICamera":
        self.open()
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    @staticmethod
    def list_cameras() -> list[str]:
        n = asi.get_num_cameras()
        if n == 0:
            return []
        return asi.list_cameras()

    def open(self) -> None:
        names = self.list_cameras()
        if not names:
            raise ASICameraError(
                "カメラが 1 台も見つかりません。\n"
                "  - USB3 ケーブルが挿さっているか\n"
                "  - デバイスマネージャーに ZWO のドライバが出ているか\n"
                "  - 別ソフト（ImpactVision2 / ivsb.exe）がカメラを掴んでいないか\n"
                "を確認してください。"
            )
        if self.camera_id >= len(names):
            raise ASICameraError(
                f"camera_id={self.camera_id} は範囲外です（検出 {len(names)} 台）。"
            )

        self._cam = asi.Camera(self.camera_id)
        props = self._cam.get_camera_property()

        self.info = CameraInfo(
            name=props["Name"],
            camera_id=self.camera_id,
            max_width=props["MaxWidth"],
            max_height=props["MaxHeight"],
            is_color=bool(props["IsColorCam"]),
            pixel_size_um=props["PixelSize"],
            bit_depth=props["BitDepth"],
            has_hardware_roi=not bool(props.get("IsUSB3Host", 0)) or True,
            supported_controls=[c["Name"] for c in self._cam.get_controls().values()],
        )

        self.apply_settings()

    def close(self) -> None:
        if self._cam is None:
            return
        try:
            if self._video_running:
                self._cam.stop_video_capture()
                self._video_running = False
        except Exception:
            pass
        try:
            self._cam.close()
        finally:
            self._cam = None

    # -- 設定 --------------------------------------------------------------

    def _set(self, control_name: str, value: int, auto: bool = False) -> None:
        """対応していないコントロールは黙ってスキップする。

        ASI は機種ごとに使えるコントロールが違うため（例: モノクロ機に WB は無い）。
        """
        controls = self._cam.get_controls()
        if control_name not in controls:
            return
        ctrl = controls[control_name]
        lo, hi = ctrl["MinValue"], ctrl["MaxValue"]
        clamped = max(lo, min(hi, int(value)))
        self._cam.set_control_value(ctrl["ControlType"], clamped, auto=auto)

    def apply_settings(self, measuring: bool = True) -> None:
        """設定をカメラに流し込む。

        measuring=True  … 計測用の短露光
        measuring=False … 待機用の長露光（IR ライト OFF 中の確認用）
        """
        if self._cam is None:
            raise ASICameraError("カメラが開かれていません。")

        s = self.settings

        # ROI（先に決めないと露光の最大値が変わることがある）
        w = s.roi_width or self.info.max_width
        h = s.roi_height or self.info.max_height
        w = (w // 8) * 8          # ASI 制約: 幅は 8 の倍数
        h = (h // 2) * 2          # ASI 制約: 高さは 2 の倍数
        self._cam.set_roi(
            start_x=s.roi_start_x,
            start_y=s.roi_start_y,
            width=w,
            height=h,
            bins=s.binning,
            image_type=asi.ASI_IMG_RAW8,   # 8bit = 最速。弾道計測では十分
        )

        exposure = s.exposure_us if measuring else s.idle_exposure_us
        self._set("Exposure", exposure)
        self._set("Gain", s.gain)
        self._set("Gamma", s.gamma)
        self._set("Brightness", s.brightness)
        self._set("Offset", s.brightness)
        self._set("BandWidth", s.bandwidth)
        self._set("Flip", s.flip)
        self._set("HighSpeedMode", s.high_speed_mode)
        if self.info.is_color:
            self._set("WB_R", s.wb_red)
            self._set("WB_B", s.wb_blue)

        # 自動系はすべて切る（計測では露光が揺れると致命的）
        for name in ("Exposure", "Gain", "WB_R", "WB_B"):
            controls = self._cam.get_controls()
            if name in controls and controls[name]["IsAutoSupported"]:
                v = self._cam.get_control_value(controls[name]["ControlType"])[0]
                self._cam.set_control_value(controls[name]["ControlType"], v, auto=False)

    def set_exposure(self, exposure_us: int) -> None:
        self.settings.exposure_us = int(exposure_us)
        self._set("Exposure", exposure_us)

    def set_gain(self, gain: int) -> None:
        self.settings.gain = int(gain)
        self._set("Gain", gain)

    def set_roi(self, start_x: int, start_y: int, width: int, height: int) -> None:
        self.settings.roi_start_x = start_x
        self.settings.roi_start_y = start_y
        self.settings.roi_width = width
        self.settings.roi_height = height
        self.apply_settings()

    # -- 取得 --------------------------------------------------------------

    def capture(self, timeout_ms: Optional[int] = None) -> np.ndarray:
        """単発撮影（静止画）。"""
        if self._cam is None:
            raise ASICameraError("カメラが開かれていません。")
        return self._cam.capture()

    def start_video(self) -> None:
        if self._cam is None:
            raise ASICameraError("カメラが開かれていません。")
        if not self._video_running:
            self._cam.start_video_capture()
            self._video_running = True

    def stop_video(self) -> None:
        if self._cam is not None and self._video_running:
            self._cam.stop_video_capture()
            self._video_running = False

    def read(self, timeout_ms: int = 2000) -> np.ndarray:
        """ビデオモードから 1 フレーム取り出す。start_video() 後に使う。"""
        if not self._video_running:
            self.start_video()
        return self._cam.capture_video_frame(timeout=timeout_ms)

    def dropped_frames(self) -> int:
        try:
            return self._cam.get_dropped_frames()
        except Exception:
            return -1

    # -- 計測 --------------------------------------------------------------

    def measure_fps(self, n_frames: int = 120) -> float:
        """実効フレームレートを測る。

        ゴルフの弾道計測では「1 秒あたり何コマ撮れるか」が精度に直結する。
        ROI を小さくするほど上がるので、この値を見ながら ROI を詰めていく。
        """
        self.start_video()
        self.read()  # 1 枚捨てて安定させる
        t0 = time.perf_counter()
        for _ in range(n_frames):
            self.read()
        dt = time.perf_counter() - t0
        return n_frames / dt if dt > 0 else 0.0
