"""
burst_record.py — 高速バースト記録

弾道計測の土台になる部分。カメラから連続でフレームを吸い出し、
「明るさが急変した瞬間（＝ボールが動いた／クラブが入った）」を
トリガーにして、その前後のフレームを丸ごと保存する。

リングバッファ方式なので「トリガーより前」のコマも残せる。
インパクト前のアドレス状態が要るので、これは必須の作り。

保存形式は .npy（生の8bit配列そのまま）＋ meta.json。
解析フェーズで扱いやすく、圧縮による劣化も無い。
"""

from __future__ import annotations

import json
import os
import time
from collections import deque
from dataclasses import asdict
from datetime import datetime
from typing import Optional

import numpy as np

from asi_camera import ASICamera, CameraSettings, init_sdk


class MotionTrigger:
    """フレーム間差分で「何か動いた」を検出する簡易トリガー。

    ゴルフの場合、静止したボールが急に消える／クラブヘッドが横切る、
    という形で必ず大きな差分が出る。閾値は現場で詰める前提。
    """

    def __init__(self, threshold: float = 8.0, min_pixels: int = 40,
                 cooldown_s: float = 1.5):
        self.threshold = threshold
        self.min_pixels = min_pixels
        self.cooldown_s = cooldown_s
        self._prev: Optional[np.ndarray] = None
        self._last_fire = 0.0

    def update(self, frame: np.ndarray) -> bool:
        prev, self._prev = self._prev, frame
        if prev is None or prev.shape != frame.shape:
            return False

        now = time.perf_counter()
        if now - self._last_fire < self.cooldown_s:
            return False

        diff = cv_absdiff(prev, frame)
        moved = int((diff > self.threshold).sum())
        if moved >= self.min_pixels:
            self._last_fire = now
            return True
        return False


def cv_absdiff(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """OpenCV を必須にしないための素朴な絶対差分。"""
    return np.abs(a.astype(np.int16) - b.astype(np.int16)).astype(np.uint8)


class BurstRecorder:
    def __init__(self,
                 cam: ASICamera,
                 pre_frames: int = 60,
                 post_frames: int = 120,
                 output_dir: str = "shots"):
        self.cam = cam
        self.pre_frames = pre_frames
        self.post_frames = post_frames
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def record_one(self, trigger: MotionTrigger,
                   timeout_s: float = 120.0) -> Optional[str]:
        """トリガーが掛かるまで待ち、掛かったら前後のフレームを保存する。

        戻り値: 保存先ディレクトリ（タイムアウト時は None）
        """
        ring: deque = deque(maxlen=self.pre_frames)
        stamps: deque = deque(maxlen=self.pre_frames)

        self.cam.start_video()
        t_start = time.perf_counter()

        print("待機中…（ボールを打つか、カメラ前で手を振ってください）")

        while True:
            if time.perf_counter() - t_start > timeout_s:
                print("タイムアウトしました。")
                return None

            frame = self.cam.read(timeout_ms=2000)
            t = time.perf_counter()
            ring.append(frame.copy())
            stamps.append(t)

            if trigger.update(frame):
                print("トリガー検出。記録します…")
                return self._capture_tail(list(ring), list(stamps))

    def _capture_tail(self, pre: list, pre_t: list) -> str:
        frames = pre
        times = pre_t

        for _ in range(self.post_frames):
            frames.append(self.cam.read(timeout_ms=2000).copy())
            times.append(time.perf_counter())

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(self.output_dir, f"shot_{stamp}")
        os.makedirs(path, exist_ok=True)

        arr = np.stack(frames, axis=0)
        np.save(os.path.join(path, "frames.npy"), arr)

        t0 = times[0]
        rel = [round(t - t0, 6) for t in times]
        intervals = np.diff(rel) if len(rel) > 1 else np.array([0.0])

        meta = {
            "recorded_at": datetime.now().isoformat(timespec="seconds"),
            "frame_count": int(arr.shape[0]),
            "frame_shape": [int(arr.shape[1]), int(arr.shape[2])],
            "trigger_index": len(pre) - 1,
            "timestamps_s": rel,
            "mean_interval_ms": float(intervals.mean() * 1000) if len(intervals) else 0.0,
            "effective_fps": float(1.0 / intervals.mean()) if intervals.mean() > 0 else 0.0,
            "camera": self.cam.info.name,
            "settings": asdict(self.cam.settings),
        }
        with open(os.path.join(path, "meta.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)

        print(f"保存しました: {path}")
        print(f"  {meta['frame_count']} フレーム / "
              f"実効 {meta['effective_fps']:.1f} fps / "
              f"平均間隔 {meta['mean_interval_ms']:.3f} ms")
        return path


def run(camera_id: int = 0,
        settings: Optional[CameraSettings] = None,
        pre: int = 60,
        post: int = 120,
        shots: int = 1,
        output_dir: str = "shots") -> None:
    with ASICamera(camera_id, settings) as cam:
        print(cam.info.summary())
        fps = cam.measure_fps(60)
        print(f"\n実効フレームレート: {fps:.1f} fps")
        if fps < 200:
            print("  ※ 弾道計測には最低でも数百 fps 欲しいところです。")
            print("     ROI を小さく、露光を短く、BandWidth を上げて詰めてください。")

        rec = BurstRecorder(cam, pre, post, output_dir)
        trig = MotionTrigger()

        for i in range(shots):
            print(f"\n--- {i + 1} / {shots} ---")
            rec.record_one(trig)


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser(description="GolfSim バースト記録")
    p.add_argument("--dll", help="ASICamera2.dll のパス")
    p.add_argument("--camera-id", type=int, default=0)
    p.add_argument("--exposure", type=int, default=1201)
    p.add_argument("--gain", type=int, default=100)
    p.add_argument("--pre", type=int, default=60, help="トリガー前に残すコマ数")
    p.add_argument("--post", type=int, default=120, help="トリガー後に撮るコマ数")
    p.add_argument("--shots", type=int, default=1)
    p.add_argument("--out", default="shots")
    a = p.parse_args()

    init_sdk(a.dll)
    run(a.camera_id,
        CameraSettings(exposure_us=a.exposure, gain=a.gain),
        a.pre, a.post, a.shots, a.out)
