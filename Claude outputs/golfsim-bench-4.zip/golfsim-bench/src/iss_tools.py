"""
iss_tools.py — ImpactVision2 の .iss / .ssi ショットファイルをデコードする

解析で判明したフォーマット（リバースエンジニアリング結果）:

  ■ .iss（ショットデータ本体）

    offset 0      ショットヘッダ（可変長。実測 5,548〜7,452 バイト）
                    +12/+16 : 364, 306   … センサー側の画像サイズ
                    +48〜   : 100, 595, 85, 43, 60, 0, 50, 3
                              (Gain / Expose_us / Gamma / WB_R / WB_B /
                               Brightness / BandWidth / Flip)
                    +136〜  : ボール／クラブの検出座標ペア
                  ※ 大半はゼロ埋め

    そのあと、フレームブロックが 138,512 バイト刻みで並ぶ:

                    int32 x6 = (1, 1, 192, 240, 3, 8)
                             = (枚数, ?, 幅, 高さ, ch, ビット深度)   24 バイト
                    画像データ 192 x 240 x 3 = 138,240 バイト（BGR, 無圧縮）
                    トレーラ 256 バイト（用途未解明）

    ヘッダ長が可変なので先頭位置は決め打ちできない。
    (192,240,3) の並びを走査して見つける方式にしている。

    フレーム数は通常 17。計測に失敗したショット（Error フォルダ）では
    18〜37 枚と多くなり、ファイルサイズも 2.3MB〜5.1MB と変動する。

  ■ SnapShot.ssi（直近ショットのスナップショット。毎回上書き）

    offset 0      int32 x10 = (18, 166, 192, 240, 3, 1, 192, 240, 3, 8)
    offset 40     画像データが 18 フレーム連続（トレーラ無し）

重要な点:
  - **動画コーデックは一切使われていない。** 無圧縮の BGR ビットマップの生並び。
  - つまり「スイング映像」は動画ファイルではなく、
    十数枚のパラパラ漫画をアプリが順に描画しているだけ。
  - 1 ファイル 2.3MB という大きさはこれが理由。

使い方:
    python iss_tools.py info   "F:/.../[Auto]01240804_145738(001).iss"
    python iss_tools.py play   "..."
    python iss_tools.py png    "..." --out out_dir
    python iss_tools.py gif    "..." --out shot.gif --fps 12
    python iss_tools.py mp4    "..." --out shot.mp4 --fps 12
    python iss_tools.py sheet  "..." --out sheet.png
    python iss_tools.py batch  "F:/.../ShotData" --out exported --format gif
"""

from __future__ import annotations

import argparse
import glob
import os
import struct
from dataclasses import dataclass
from typing import Optional

import numpy as np

# --- 解析で判明した定数 ---------------------------------------------------
FRAME_W = 192
FRAME_H = 240
FRAME_CH = 3
FRAME_BYTES = FRAME_W * FRAME_H * FRAME_CH      # 138,240
ISS_BLOCK_STRIDE = 138_512                      # 画像 + トレーラ 256
ISS_DATA_OFFSET = 16                            # (192,240,3) 位置からデータまで
SSI_DATA_OFFSET = 40

# ヘッダ内のカメラ設定オフセット（.iss / InfoData.cid 共通）
CAM_SETTING_OFFSETS = {
    "gain": 48,
    "exposure_us": 52,
    "gamma": 56,
    "wb_red": 60,
    "wb_blue": 64,
    "brightness": 68,
    "bandwidth": 72,
    "flip": 76,
}

_BLOCK_MAGIC = struct.pack("<3i", FRAME_W, FRAME_H, FRAME_CH)

# ---------------------------------------------------------------------------
# ストライドについて（2026-08-31 追記）
#
# 当初 ISS_BLOCK_STRIDE = 138,512 を固定値として使っていたが、これは .iss
# （メインカメラ）専用の値だった。サブカメラの .sid に同じ値を当てると
# **1 コマにつき 64 バイトずつ読み位置がずれていく**。
#
# 実際にサブの展開結果を位相相関で測ったところ、フレームごとに横へ
# -21.25 px（フル解像度）ずつ滑っており、21.25 px x 3 byte/px = 63.75 ≒ 64 byte。
# 色チャンネルが 3 コマ周期で B->G->R と回るのも 64 mod 3 == 1 で説明がつく。
#
#   .iss（メイン）: ストライド 138,512（画像 138,240 + トレーラ 272）
#   .sid（サブ）  : ストライド 138,576（画像 138,240 + トレーラ 336）
#
# ただしこの 64 バイトが何なのかは未解明で、機種や版で変わる可能性がある。
# そこで固定値に頼らず、**ブロック先頭マジックを走査して実測**する方式に変えた。
# 固定値は最後の保険としてのみ使う。
# ---------------------------------------------------------------------------
ISS_BLOCK_STRIDE_MAIN = 138_512     # .iss
ISS_BLOCK_STRIDE_SUB = 138_576      # .sid（実測 +64）


@dataclass
class ShotFile:
    path: str
    kind: str                # "iss" or "ssi"
    frames: np.ndarray       # (N, H, W, 3) RGB
    sensor_size: tuple       # (w, h) センサー側の画像サイズ
    camera: dict             # 撮影時のカメラ設定
    strides: list = None     # 実測したブロック間隔（.iss=138512 / .sid=138576）
    extras: list = None      # 各フレーム末尾のトレーラ（未解読。サブは 64 バイト多い）

    @property
    def frame_count(self) -> int:
        return int(self.frames.shape[0])

    def describe(self) -> str:
        c = self.camera
        s = (
            f"{os.path.basename(self.path)}\n"
            f"  形式        : {self.kind.upper()}（無圧縮 BGR ビットマップ列）\n"
            f"  フレーム数  : {self.frame_count}\n"
            f"  画像サイズ  : {FRAME_W} x {FRAME_H} x {FRAME_CH}ch (8bit)\n"
            f"  センサー側  : {self.sensor_size[0]} x {self.sensor_size[1]}"
        )
        if self.strides:
            uniq = sorted(set(self.strides))
            s += f"\n  ブロック間隔: {uniq}"
            if len(uniq) > 1:
                s += "  ← 不揃い。ファイルが壊れている可能性あり"
            elif uniq[0] == ISS_BLOCK_STRIDE_SUB:
                s += "  ← サブカメラ形式（トレーラ 336 byte）"
            elif uniq[0] == ISS_BLOCK_STRIDE_MAIN:
                s += "  ← メインカメラ形式（トレーラ 272 byte）"
        if c:
            s += (
                f"\n  カメラ設定  : Gain={c.get('gain')} "
                f"Expose={c.get('exposure_us')}us Gamma={c.get('gamma')} "
                f"Flip={c.get('flip')} BandWidth={c.get('bandwidth')}"
            )
        return s


def _read_camera_settings(data: bytes) -> dict:
    out = {}
    for name, off in CAM_SETTING_OFFSETS.items():
        try:
            out[name] = struct.unpack_from("<i", data, off)[0]
        except struct.error:
            out[name] = None
    return out


def _find_first_block(data: bytes, search_limit: int = 65536) -> Optional[int]:
    """最初のフレームブロックの (192,240,3) 位置を返す。画像はその +16 から。

    ブロックヘッダは int32 x6 = (1, 1, 192, 240, 3, 8)。
    先頭 2 個と最後の 8 を確認して誤検出を防ぐ。
    """
    pos = data.find(_BLOCK_MAGIC, 0, search_limit)
    while pos != -1:
        if pos >= 8:
            count = struct.unpack_from("<i", data, pos - 8)[0]
            depth = struct.unpack_from("<i", data, pos + 12)[0]
            if count == 1 and depth == 8:
                return pos
        pos = data.find(_BLOCK_MAGIC, pos + 1, search_limit)
    return None


def _scan_blocks(data: bytes, first: int) -> list[int]:
    """フレームブロックの先頭位置を、マジックを走査して実測する。

    固定ストライドを仮定しない。.iss と .sid でトレーラ長が違う（64 バイト差）
    ことが実測で分かっているため、ここを決め打ちにすると 1 コマごとに
    画像が横へずれていく。

    ブロックは int32 x6 = (1, 1, W, H, 3, 8) で始まる。
    (W, H, 3) のマジックを探し、その 8 バイト前が 1、12 バイト後が 8 であることで
    誤検出（画像データ中の偶然の一致）を弾く。
    """
    blocks: list[int] = []
    pos = first
    while pos != -1 and pos + ISS_DATA_OFFSET + FRAME_BYTES <= len(data):
        blocks.append(pos)
        # 画像本体の内側は探さない（偶然の一致を避ける）
        nxt = pos + ISS_DATA_OFFSET + FRAME_BYTES
        pos = -1
        cand = data.find(_BLOCK_MAGIC, nxt)
        while cand != -1:
            if (cand >= 8
                    and struct.unpack_from("<i", data, cand - 8)[0] == 1
                    and struct.unpack_from("<i", data, cand + 12)[0] == 8):
                pos = cand
                break
            cand = data.find(_BLOCK_MAGIC, cand + 1)
    return blocks


def _bgr_to_rgb(buf: bytes) -> np.ndarray:
    a = np.frombuffer(buf, dtype=np.uint8, count=FRAME_BYTES)
    return a.reshape(FRAME_H, FRAME_W, FRAME_CH)[:, :, ::-1]


def load(path: str) -> ShotFile:
    """.iss / .ssi を読み込んでフレーム列を返す。"""
    with open(path, "rb") as f:
        data = f.read()

    ext = os.path.splitext(path)[1].lower()

    # --- .ssi ---
    if ext == ".ssi":
        n = struct.unpack_from("<i", data, 0)[0]
        frames = []
        for i in range(n):
            off = SSI_DATA_OFFSET + i * FRAME_BYTES
            if off + FRAME_BYTES > len(data):
                break
            frames.append(_bgr_to_rgb(data[off:off + FRAME_BYTES]))
        if not frames:
            raise ValueError(f"フレームを抽出できませんでした: {path}")
        # .ssi にはカメラ設定ブロックが無い
        return ShotFile(path, "ssi", np.stack(frames), (FRAME_W, FRAME_H), {})

    # --- .iss ---
    sensor_w, sensor_h = struct.unpack_from("<2i", data, 12)

    first = _find_first_block(data)
    if first is None:
        raise ValueError(f"フレームブロックが見つかりません: {path}")

    blocks = _scan_blocks(data, first)
    frames = [_bgr_to_rgb(data[b + ISS_DATA_OFFSET:b + ISS_DATA_OFFSET + FRAME_BYTES])
              for b in blocks]
    extras = [data[b + ISS_DATA_OFFSET + FRAME_BYTES:
                   (blocks[i + 1] if i + 1 < len(blocks) else len(data))]
              for i, b in enumerate(blocks)]

    if not frames:
        raise ValueError(f"フレームを抽出できませんでした: {path}")

    strides = [blocks[i + 1] - blocks[i] for i in range(len(blocks) - 1)]
    return ShotFile(path, ext.lstrip("."), np.stack(frames),
                    (sensor_w, sensor_h), _read_camera_settings(data),
                    strides=strides, extras=extras)


# --- 出力 -----------------------------------------------------------------

def export_png(shot: ShotFile, out_dir: str) -> None:
    from PIL import Image
    os.makedirs(out_dir, exist_ok=True)
    for i, f in enumerate(shot.frames):
        Image.fromarray(f).save(os.path.join(out_dir, f"frame_{i:03d}.png"))
    print(f"{shot.frame_count} 枚を書き出しました → {out_dir}")


def _ensure_parent(path: str) -> None:
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)


def export_gif(shot: ShotFile, out_path: str, fps: float = 12.0,
               scale: int = 2) -> None:
    from PIL import Image
    imgs = [Image.fromarray(f).resize((FRAME_W * scale, FRAME_H * scale),
                                      Image.NEAREST)
            for f in shot.frames]
    _ensure_parent(out_path)
    imgs[0].save(out_path, save_all=True, append_images=imgs[1:],
                 duration=int(1000 / fps), loop=0)
    print(f"GIF を書き出しました → {out_path}")


def export_mp4(shot: ShotFile, out_path: str, fps: float = 12.0,
               scale: int = 2) -> None:
    import cv2
    h, w = FRAME_H * scale, FRAME_W * scale
    _ensure_parent(out_path)
    vw = cv2.VideoWriter(out_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
    for f in shot.frames:
        bgr = cv2.cvtColor(f, cv2.COLOR_RGB2BGR)
        vw.write(cv2.resize(bgr, (w, h), interpolation=cv2.INTER_NEAREST))
    vw.release()
    print(f"MP4 を書き出しました → {out_path}")


def export_sheet(shot: ShotFile, out_path: str, cols: int = 6) -> None:
    """コンタクトシート（全コマを1枚に並べる）。動きの確認に一番便利。"""
    from PIL import Image, ImageDraw
    n = shot.frame_count
    rows = (n + cols - 1) // cols
    sheet = Image.new("RGB", (FRAME_W * cols, FRAME_H * rows), (0, 0, 0))
    draw = ImageDraw.Draw(sheet)
    for i, f in enumerate(shot.frames):
        r, c = divmod(i, cols)
        sheet.paste(Image.fromarray(f), (c * FRAME_W, r * FRAME_H))
        draw.text((c * FRAME_W + 4, r * FRAME_H + 4), str(i), fill=(255, 255, 0))
    _ensure_parent(out_path)
    sheet.save(out_path)
    print(f"コンタクトシートを書き出しました → {out_path}")


def play(shot: ShotFile, fps: float = 12.0, scale: int = 2) -> None:
    """その場で再生する。左右キーでコマ送り、スペースで再生／一時停止。"""
    import time

    import cv2

    idx, playing = 0, True
    delay = 1.0 / fps
    last = time.perf_counter()
    win = "ISS Player  [Space]再生/停止  [<-][->]コマ送り  [q]終了"
    cv2.namedWindow(win, cv2.WINDOW_NORMAL)

    while True:
        f = shot.frames[idx]
        bgr = cv2.cvtColor(f, cv2.COLOR_RGB2BGR)
        bgr = cv2.resize(bgr, (FRAME_W * scale, FRAME_H * scale),
                         interpolation=cv2.INTER_NEAREST)
        label = f"{idx + 1}/{shot.frame_count}"
        cv2.putText(bgr, label, (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                    (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(bgr, label, (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                    (0, 255, 0), 1, cv2.LINE_AA)
        cv2.imshow(win, bgr)

        key = cv2.waitKey(10) & 0xFF
        if key in (ord("q"), 27):
            break
        elif key == ord(" "):
            playing = not playing
        elif key in (83, ord(".")):
            idx = min(idx + 1, shot.frame_count - 1)
            playing = False
        elif key in (81, ord(",")):
            idx = max(idx - 1, 0)
            playing = False

        if playing and time.perf_counter() - last >= delay:
            idx = (idx + 1) % shot.frame_count
            last = time.perf_counter()

    cv2.destroyAllWindows()


# --- CLI ------------------------------------------------------------------

def _run_batch(a) -> int:
    files = sorted(glob.glob(os.path.join(a.path, "*.iss")))
    if a.limit:
        files = files[:a.limit]
    if not files:
        print("該当する .iss がありません。")
        return 1
    os.makedirs(a.out, exist_ok=True)
    done = 0
    for i, f in enumerate(files, 1):
        try:
            shot = load(f)
        except Exception as e:
            print(f"[{i}/{len(files)}] スキップ {os.path.basename(f)}: {e}")
            continue
        stem = os.path.splitext(os.path.basename(f))[0]
        stem = stem.replace("[", "").replace("]", "")
        if a.format == "gif":
            export_gif(shot, os.path.join(a.out, stem + ".gif"), a.fps)
        elif a.format == "mp4":
            export_mp4(shot, os.path.join(a.out, stem + ".mp4"), a.fps)
        elif a.format == "sheet":
            export_sheet(shot, os.path.join(a.out, stem + ".png"))
        else:
            export_png(shot, os.path.join(a.out, stem))
        done += 1
    print(f"\n完了: {done} / {len(files)} 件")
    return 0


def main() -> int:
    p = argparse.ArgumentParser(description="ImpactVision2 .iss/.ssi デコーダ")
    sub = p.add_subparsers(dest="cmd", required=True)

    for name in ("info", "png", "gif", "mp4", "sheet", "play"):
        sp = sub.add_parser(name)
        sp.add_argument("path")
        sp.add_argument("--out", default=None)
        sp.add_argument("--fps", type=float, default=12.0)
        sp.add_argument("--scale", type=int, default=2)

    sb = sub.add_parser("batch", help="フォルダ内の全ショットを一括変換")
    sb.add_argument("path")
    sb.add_argument("--out", default="exported")
    sb.add_argument("--format", choices=["gif", "mp4", "sheet", "png"],
                    default="gif")
    sb.add_argument("--fps", type=float, default=12.0)
    sb.add_argument("--limit", type=int, default=0, help="先頭 N 件だけ処理")

    a = p.parse_args()

    if a.cmd == "batch":
        return _run_batch(a)

    shot = load(a.path)

    if a.cmd == "info":
        print(shot.describe())
    elif a.cmd == "play":
        play(shot, a.fps, a.scale)
    elif a.cmd == "png":
        export_png(shot, a.out or "frames")
    elif a.cmd == "gif":
        export_gif(shot, a.out or "shot.gif", a.fps, a.scale)
    elif a.cmd == "mp4":
        export_mp4(shot, a.out or "shot.mp4", a.fps, a.scale)
    elif a.cmd == "sheet":
        export_sheet(shot, a.out or "sheet.png")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
