"""
shot_analysis.py — 記録したコマ列からボールを検出し、初速と打ち出し方向を出す

GolfSim の Phase 1。burst_record.py が残した frames.npy / meta.json、または
ImpactVision2 の .iss をそのまま読んで解析する。

考え方（ImpactVision2 の実測解析から得た方針）:

  1. **物差しはボール自身**
     ゴルフボールの直径は 42.67mm と規格で決まっている。静止しているボールの
     見かけの直径を測れば、それだけで mm/px が出る。校正チャートは要らない。

  2. **静止球は「消えるもの」として見つける**
     画面には他にも白い物（オートティーのボール供給トレイなど）が写る。
     打った後に**消えている**白い塊がティーアップされたボールである、
     という条件で特定すると誤検出がほぼ無くなる。

  3. **等速直線モデルで外れ値を弾く**
     インパクト直後の数十cmでは、重力も空気抵抗も無視できる。
     2点から等速モデルを立てて他フレームの当てはまりを数え、
     最も支持の多いモデルを採用する（RANSAC）。1点の誤検出で
     結果が壊れる、という ImpactVision2 の弱点をここで潰す。

  4. **実測タイムスタンプを使う**
     公称 fps ではなく meta.json の timestamps_s を使う。USB カメラの
     フレーム間隔は揺れるので、ここを横着すると速度が数 % ずれる。

使い方:
    python shot_analysis.py shots/shot_20260831_101500
    python shot_analysis.py --iss "F:/.../shot.iss" --fps 300
    python shot_analysis.py shots/shot_... --overlay out.png
"""

from __future__ import annotations

import argparse
import glob
import json
import os
from dataclasses import dataclass, field
from typing import Optional, Sequence

import numpy as np

try:
    import cv2
except ImportError as e:  # pragma: no cover
    raise ImportError("opencv-python が必要です: pip install opencv-python") from e


BALL_DIAMETER_MM = 42.67   # ゴルフ規則で定められた最小直径


# ---------------------------------------------------------------------------
# データ構造
# ---------------------------------------------------------------------------

@dataclass
class Blob:
    frame: int
    cx: float
    cy: float
    area: int
    w: int
    h: int

    @property
    def xy(self) -> np.ndarray:
        return np.array([self.cx, self.cy])


@dataclass
class ShotResult:
    mm_per_px: float
    rest_ball: Optional[Blob]
    track: list = field(default_factory=list)      # 採用した Blob 列
    vx_px_s: float = 0.0
    vy_px_s: float = 0.0
    speed_ms: float = 0.0
    direction_deg: float = 0.0
    rms_residual_px: float = 0.0
    effective_exposure_us: Optional[float] = None
    fps: float = 0.0
    warnings: list = field(default_factory=list)

    @property
    def speed_mph(self) -> float:
        return self.speed_ms * 2.236936

    def report(self) -> str:
        L = []
        L.append("=" * 58)
        L.append("  ショット解析結果")
        L.append("=" * 58)
        if self.rest_ball:
            d = 2 * (self.rest_ball.area / np.pi) ** 0.5
            L.append(f"  静止球       : ({self.rest_ball.cx:.1f}, {self.rest_ball.cy:.1f}) "
                     f"等価直径 {d:.2f}px")
        L.append(f"  スケール     : {self.mm_per_px:.4f} mm/px")
        L.append(f"  撮影         : {self.fps:.1f} fps")
        L.append(f"  検出コマ数   : {len(self.track)}  "
                 f"(frame {[b.frame for b in self.track]})")
        L.append("-" * 58)
        L.append(f"  ボール初速   : {self.speed_ms:.2f} m/s  "
                 f"({self.speed_ms * 3.6:.1f} km/h / {self.speed_mph:.1f} mph)")
        L.append(f"  画像内方向   : {self.direction_deg:+.2f} 度")
        L.append(f"  当てはめ残差 : {self.rms_residual_px:.3f} px "
                 f"(= {self.rms_residual_px * self.mm_per_px:.2f} mm)")
        if self.effective_exposure_us:
            L.append(f"  実効露光     : 約 {self.effective_exposure_us:.0f} us "
                     f"(ボールのブレ幅から逆算)")
        if self.warnings:
            L.append("-" * 58)
            for w in self.warnings:
                L.append(f"  ! {w}")
        L.append("=" * 58)
        return "\n".join(L)


# ---------------------------------------------------------------------------
# 検出
# ---------------------------------------------------------------------------

def _to_gray(frames: np.ndarray) -> np.ndarray:
    if frames.ndim == 4:
        return np.stack([cv2.cvtColor(f, cv2.COLOR_RGB2GRAY) for f in frames])
    return frames


def _blobs(mask: np.ndarray, weight: np.ndarray, min_area: int) -> list[tuple]:
    """連結成分を取り、輝度で重み付けしたサブピクセル重心を返す。

    ImpactVision2 は自作の再帰塗りつぶしで同じことをしていた。
    OpenCV 4 の connectedComponentsWithStats で一行になる。
    """
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    out = []
    for j in range(1, n):
        a = int(st[j, cv2.CC_STAT_AREA])
        if a < min_area:
            continue
        ys, xs = np.where(lab == j)
        w = weight[ys, xs].astype(np.float64) + 1e-6
        out.append((a,
                    float((xs * w).sum() / w.sum()),
                    float((ys * w).sum() / w.sum()),
                    int(st[j, cv2.CC_STAT_WIDTH]),
                    int(st[j, cv2.CC_STAT_HEIGHT])))
    out.sort(reverse=True)
    return out


def _refine_diameter(img: np.ndarray, cx: float, cy: float, r_hint: int) -> float:
    """静止球の直径を「半値」で測り直す。

    固定しきい値で二値化すると、しきい値の取り方だけで直径が 2 割変わる。
    スケール（mm/px）が 2 割狂えば初速もそのまま 2 割狂うので、ここは
    しきい値に依存しない測り方をする。

    周囲のリングを背景レベル、中心付近を頂点レベルとして、その中間の
    輝度で切った面積から等価直径を出す（光学でいう半値全幅と同じ考え方）。
    """
    h, w = img.shape
    r = max(6, int(r_hint * 2.5))
    y0, y1 = max(0, int(cy) - r), min(h, int(cy) + r + 1)
    x0, x1 = max(0, int(cx) - r), min(w, int(cx) + r + 1)
    patch = img[y0:y1, x0:x1].astype(np.float32)
    if patch.size < 25:
        return float(r_hint * 2)

    yy, xx = np.mgrid[y0:y1, x0:x1]
    dist = np.hypot(xx - cx, yy - cy)
    ring = patch[dist > r * 0.8]
    core = patch[dist < max(2.0, r_hint * 0.5)]
    if ring.size < 5 or core.size < 3:
        return float(r_hint * 2)

    base = float(np.median(ring))
    peak = float(np.percentile(core, 80))
    if peak - base < 10:
        return float(r_hint * 2)

    half = (base + peak) / 2.0
    m = (patch >= half).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(m, connectivity=8)
    if n < 2:
        return float(r_hint * 2)
    # 中心に最も近い成分を採用
    best, bd = None, 1e9
    for j in range(1, n):
        ys, xs = np.where(lab == j)
        d = np.hypot(xs.mean() + x0 - cx, ys.mean() + y0 - cy)
        if d < bd:
            bd, best = d, int(st[j, cv2.CC_STAT_AREA])
    return float(2.0 * (best / np.pi) ** 0.5)


def find_rest_ball(gray: np.ndarray, tail: int = 3) -> Optional[Blob]:
    """静止しているボールを見つける。

    「最初のコマにあって、最後のほうのコマでは消えている明るい塊」を探す。
    供給トレイのボールや照明の映り込みは打っても消えないので、この条件だけで
    ほぼ一意に決まる。
    """
    first = gray[0]
    thr = max(120, int(np.percentile(first, 99.5)) - 30)
    _, m = cv2.threshold(first, thr, 255, cv2.THRESH_BINARY)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    cands = _blobs(m, first, min_area=30)
    if not cands:
        return None

    last = gray[-tail:].astype(np.int16).mean(axis=0)
    best = None
    for a, cx, cy, w, h in cands:
        r = max(3, int(0.6 * max(w, h)))
        y0, y1 = max(0, int(cy) - r), min(gray.shape[1], int(cy) + r + 1)
        x0, x1 = max(0, int(cx) - r), min(gray.shape[2], int(cx) + r + 1)
        before = float(first[y0:y1, x0:x1].mean())
        after = float(last[y0:y1, x0:x1].mean())
        drop = before - after
        circ = min(w, h) / max(w, h)
        if circ < 0.6:            # 細長いものはボールではない
            continue
        score = drop * circ
        if best is None or score > best[0]:
            best = (score, Blob(0, cx, cy, a, w, h))
    if best is None or best[0] < 5:
        # 消える塊が無い＝ボールが元々写っていない可能性
        a, cx, cy, w, h = cands[0]
        b = Blob(0, cx, cy, a, w, h)
    else:
        b = best[1]

    # 直径をしきい値に依存しない方法で測り直し、area をそれに合わせる
    d = _refine_diameter(first, b.cx, b.cy, max(b.w, b.h) / 2.0)
    b.area = int(np.pi * (d / 2.0) ** 2)
    b.w = b.h = int(round(d))
    return b


def find_moving(gray: np.ndarray, bg: np.ndarray, rest: Optional[Blob],
                diff_thresh: int = 45) -> dict[int, list[Blob]]:
    """各コマの「動いている明るいもの」候補を返す。"""
    ref_area = rest.area if rest else 200
    lo, hi = ref_area * 0.25, ref_area * 4.0
    out: dict[int, list[Blob]] = {}
    for i, f in enumerate(gray):
        d = np.clip(f.astype(np.float32) - bg, 0, 255)
        m = cv2.morphologyEx((d > diff_thresh).astype(np.uint8),
                             cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        cands = []
        for a, cx, cy, w, h in _blobs(m, d, min_area=int(lo)):
            if a > hi:
                continue                       # クラブヘッドやシャフトの筋
            if max(w, h) / max(1, min(w, h)) > 3.0:
                continue                       # 極端に細長いものは除外
            cands.append(Blob(i, cx, cy, a, w, h))
        if cands:
            out[i] = cands
    return out


# ---------------------------------------------------------------------------
# 軌道の当てはめ（RANSAC）
# ---------------------------------------------------------------------------

def fit_track(cands: dict[int, list[Blob]], times: np.ndarray,
              tol_px: float = 6.0, min_points: int = 3):
    """等速直線モデルで最も支持の多い組み合わせを選ぶ。

    ImpactVision2 は検出点をそのまま直線に当てはめていたため、1 点の誤検出が
    そのまま結果の狂いになった。ここでは支持数で選ぶので、外れ値に強い。
    """
    frames = sorted(cands)
    best = None
    for ii in range(len(frames)):
        for jj in range(ii + 1, len(frames)):
            fi, fj = frames[ii], frames[jj]
            dt = times[fj] - times[fi]
            if dt <= 0:
                continue
            for bi in cands[fi]:
                for bj in cands[fj]:
                    v = (bj.xy - bi.xy) / dt
                    if np.hypot(*v) < 1e-6:
                        continue
                    inliers, err = [], 0.0
                    for fk in frames:
                        pred = bi.xy + v * (times[fk] - times[fi])
                        pick = min(cands[fk],
                                   key=lambda b: np.linalg.norm(b.xy - pred))
                        d = float(np.linalg.norm(pick.xy - pred))
                        if d <= tol_px:
                            inliers.append(pick)
                            err += d * d
                    if len(inliers) < min_points:
                        continue
                    score = (len(inliers), -err)
                    if best is None or score > best[0]:
                        best = (score, inliers)
    if best is None:
        return [], (0.0, 0.0), 0.0

    inliers = sorted(best[1], key=lambda b: b.frame)
    t = np.array([times[b.frame] for b in inliers])
    x = np.array([b.cx for b in inliers])
    y = np.array([b.cy for b in inliers])
    vx, x0 = np.polyfit(t, x, 1)
    vy, y0 = np.polyfit(t, y, 1)
    rx, ry = x - (vx * t + x0), y - (vy * t + y0)
    rms = float(np.sqrt((rx ** 2 + ry ** 2).mean()))
    return inliers, (float(vx), float(vy)), rms


# ---------------------------------------------------------------------------
# 本体
# ---------------------------------------------------------------------------

def analyze(frames: np.ndarray,
            timestamps: Optional[Sequence[float]] = None,
            fps: Optional[float] = None,
            mm_per_px: Optional[float] = None,
            up_axis: str = "-y") -> ShotResult:
    """コマ列を解析する。

    timestamps: 各コマの実測時刻[秒]。無ければ fps から等間隔とみなす。
    up_axis   : 画像上のどちら向きを「飛球線の正方向」とみなすか。
                ImpactVision2 の据付では画像の上方向（-y）が飛球線だった。
    """
    gray = _to_gray(frames)
    n = len(gray)
    if timestamps is not None and len(timestamps) == n:
        t = np.asarray(timestamps, dtype=float)
        dt = np.diff(t)
        eff_fps = float(1.0 / dt.mean()) if len(dt) and dt.mean() > 0 else 0.0
    else:
        eff_fps = float(fps or 0.0)
        if eff_fps <= 0:
            raise ValueError("timestamps か fps のどちらかが必要です。")
        t = np.arange(n) / eff_fps

    warnings: list[str] = []

    rest = find_rest_ball(gray)
    if rest is None:
        warnings.append("静止しているボールを特定できませんでした。")
    if mm_per_px is None:
        if rest is None:
            raise ValueError("静止球が見つからないので mm_per_px を明示してください。")
        d_px = 2 * (rest.area / np.pi) ** 0.5
        mm_per_px = BALL_DIAMETER_MM / d_px

    bg = gray[:max(1, min(5, n // 4))].astype(np.float32).mean(axis=0)
    cands = find_moving(gray, bg, rest)

    # 静止球とほぼ完全に重なっている候補だけを除く。
    # 少し離れていれば「打たれた直後の 1 コマ目」である可能性が高く、
    # ここを広く切ると最も価値のある最初の点を落としてしまう。
    if rest is not None:
        r_excl = 0.6 * max(rest.w, rest.h)
        for k in list(cands):
            keep = [b for b in cands[k]
                    if np.linalg.norm(b.xy - rest.xy) > r_excl]
            if keep:
                cands[k] = keep
            else:
                del cands[k]

    track, (vx, vy), rms = fit_track(cands, t)
    if not track:
        warnings.append("飛行中のボールを追跡できませんでした。"
                        "露光・閾値・ROI を見直してください。")
        return ShotResult(mm_per_px, rest, fps=eff_fps, warnings=warnings)

    speed_px_s = float(np.hypot(vx, vy))
    speed_ms = speed_px_s * mm_per_px / 1000.0

    ux, uy = {"-y": (0.0, -1.0), "+y": (0.0, 1.0),
              "+x": (1.0, 0.0), "-x": (-1.0, 0.0)}[up_axis]
    along = vx * ux + vy * uy
    across = vx * (-uy) + vy * ux
    direction = float(np.degrees(np.arctan2(across, along)))

    # ブレ幅から実効露光を逆算（静止時との縦横差）
    eff_exp = None
    if rest is not None and track:
        elong = np.mean([max(b.w, b.h) for b in track]) - max(rest.w, rest.h)
        if elong > 0.5:
            eff_exp = float(elong * mm_per_px / 1000.0 / max(speed_ms, 1e-6) * 1e6)

    if len(track) < 5:
        warnings.append(f"検出コマ数が {len(track)} 点しかありません。"
                        "fps を上げるか ROI を広げると精度が上がります。")
    if rms > 1.5:
        warnings.append(f"当てはめ残差が {rms:.2f}px と大きめです。"
                        "検出が不安定な可能性があります。")
    if rest is not None:
        d_px = 2 * (rest.area / np.pi) ** 0.5
        # 直径の測定誤差はおおむね ±1px。それがそのまま速度の誤差になる。
        scale_err = 1.0 / d_px * 100.0
        if scale_err > 2.0:
            warnings.append(
                f"静止球が {d_px:.1f}px しかなく、スケール誤差が概ね ±{scale_err:.1f}% です。"
                f"初速 {speed_ms:.1f} m/s に対して ±{speed_ms * scale_err / 100:.1f} m/s。"
                "球をもっと大きく写す（望遠側にする／カメラを近づける）と直接効きます。")

    return ShotResult(mm_per_px, rest, track, vx, vy, speed_ms, direction,
                      rms, eff_exp, eff_fps, warnings)


def draw_overlay(frames: np.ndarray, res: ShotResult, out_path: str,
                 cols: int = 6) -> None:
    """検出位置と当てはめ直線を焼き込んだコンタクトシートを書き出す。"""
    gray = _to_gray(frames)
    n, h, w = gray.shape
    rows = (n + cols - 1) // cols
    sheet = np.zeros((rows * h, cols * w, 3), np.uint8)
    hit = {b.frame: b for b in res.track}
    for i in range(n):
        vis = cv2.cvtColor(gray[i], cv2.COLOR_GRAY2BGR)
        if res.rest_ball:
            cv2.circle(vis, (int(res.rest_ball.cx), int(res.rest_ball.cy)),
                       max(6, int(0.6 * max(res.rest_ball.w, res.rest_ball.h))),
                       (0, 200, 0), 1)
        if i in hit:
            b = hit[i]
            cv2.circle(vis, (int(b.cx), int(b.cy)), 20, (0, 0, 255), 2)
            cv2.putText(vis, f"{b.cx:.1f},{b.cy:.1f}",
                        (max(0, int(b.cx) - 60), max(14, int(b.cy) - 26)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 0, 255), 1, cv2.LINE_AA)
        if len(res.track) >= 2:
            p0, p1 = res.track[0], res.track[-1]
            cv2.line(vis, (int(p0.cx), int(p0.cy)), (int(p1.cx), int(p1.cy)),
                     (255, 200, 0), 1, cv2.LINE_AA)
        cv2.putText(vis, f"f{i}", (6, 18), cv2.FONT_HERSHEY_SIMPLEX,
                    0.55, (0, 255, 255), 1, cv2.LINE_AA)
        r, c = divmod(i, cols)
        sheet[r * h:(r + 1) * h, c * w:(c + 1) * w] = vis
    parent = os.path.dirname(os.path.abspath(out_path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    cv2.imwrite(out_path, sheet)
    print(f"確認用画像を書き出しました → {out_path}")


# ---------------------------------------------------------------------------
# 入力
# ---------------------------------------------------------------------------

def load_shot_dir(path: str):
    frames = np.load(os.path.join(path, "frames.npy"))
    meta_path = os.path.join(path, "meta.json")
    meta = {}
    if os.path.exists(meta_path):
        with open(meta_path, encoding="utf-8") as f:
            meta = json.load(f)
    return frames, meta.get("timestamps_s"), meta.get("effective_fps")


def main() -> int:
    p = argparse.ArgumentParser(description="GolfSim ショット解析")
    p.add_argument("path", nargs="?", help="shots/shot_YYYYmmdd_HHMMSS ディレクトリ")
    p.add_argument("--iss", help="ImpactVision2 の .iss / .sid を直接解析")
    p.add_argument("--fps", type=float, help="タイムスタンプが無い場合の撮影 fps")
    p.add_argument("--mm-per-px", type=float, help="スケールを手動指定")
    p.add_argument("--up-axis", default="-y", choices=["-y", "+y", "+x", "-x"],
                   help="画像上で飛球線の正方向にあたる向き")
    p.add_argument("--overlay", help="検出結果を焼いた画像の出力先")
    a = p.parse_args()

    if a.iss:
        import iss_tools
        shot = iss_tools.load(a.iss)
        frames, ts = shot.frames, None
        fps = a.fps
        if fps is None:
            print("※ .iss にはコマ時刻が入っていません。--fps を指定してください。")
            print("  ImpactVision2 の実測からは 300fps 前後と推定されます。")
            return 1
    elif a.path:
        frames, ts, fps = load_shot_dir(a.path)
        fps = a.fps or fps
    else:
        p.error("path か --iss のどちらかを指定してください。")
        return 1

    res = analyze(frames, ts, fps, a.mm_per_px, a.up_axis)
    print(res.report())
    if a.overlay:
        draw_overlay(frames, res, a.overlay)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
