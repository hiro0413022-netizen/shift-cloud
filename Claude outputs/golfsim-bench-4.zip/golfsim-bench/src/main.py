"""
main.py — GolfSim エントリポイント

使い方:
    python main.py doctor      環境チェック（まずこれ）
    python main.py list        接続されているカメラ一覧
    python main.py live        ライブビューア
    python main.py record      バースト記録
    python main.py analyze     記録したショットを解析（初速・方向）
"""

from __future__ import annotations

import argparse
import os
import sys

CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           "config.yaml")


def load_config() -> dict:
    defaults = {
        "sdk": {"dll_path": None},
        "camera": {
            "id": 0,
            "exposure_us": 1201,
            "gain": 100,
            "gamma": 85,
            "bandwidth": 50,
            "flip": 3,
        },
        "record": {"pre_frames": 60, "post_frames": 120, "output_dir": "shots"},
    }
    if not os.path.exists(CONFIG_PATH):
        return defaults
    try:
        import yaml
    except ImportError:
        print("警告: PyYAML が無いため config.yaml を読み飛ばします。")
        return defaults
    with open(CONFIG_PATH, encoding="utf-8") as f:
        user = yaml.safe_load(f) or {}
    for k, v in user.items():
        if isinstance(v, dict) and k in defaults:
            defaults[k].update(v)
        else:
            defaults[k] = v
    return defaults


def cmd_doctor(cfg: dict) -> int:
    """環境が揃っているかを順に確認する。"""
    ok = True

    print("=== GolfSim 環境チェック ===\n")

    print(f"Python : {sys.version.split()[0]} "
          f"({'64bit' if sys.maxsize > 2**32 else '32bit'})")
    if sys.maxsize <= 2**32:
        print("  ! 32bit Python です。64bit 版の ASICamera2.dll とは組み合わせられません。")
        ok = False

    for mod, hint in [("numpy", "pip install numpy"),
                      ("cv2", "pip install opencv-python"),
                      ("zwoasi", "pip install zwoasi"),
                      ("yaml", "pip install pyyaml")]:
        try:
            __import__(mod)
            print(f"  OK  {mod}")
        except ImportError:
            print(f"  NG  {mod}  → {hint}")
            ok = False

    dll = cfg["sdk"]["dll_path"] or os.environ.get("ZWO_ASI_LIB")
    print(f"\nASICamera2.dll : {dll or '(未設定)'}")
    if not dll:
        print("  NG  config.yaml の sdk.dll_path を設定してください。")
        ok = False
    elif not os.path.exists(dll):
        print("  NG  そのパスにファイルがありません。")
        ok = False
    else:
        print("  OK  ファイルは存在します。")
        if os.path.basename(dll).lower() == "ivcam1.dll":
            print("  ※ ImpactVision の IVCAM1.dll を指しています。中身は ASICamera2 v1.12"
                  "（2017年版）です。動く可能性はありますが、Windows 11 では"
                  " ZWO 公式の現行 SDK に差し替えることを推奨します。")

    if not ok:
        print("\n不足があります。上の NG を解消してから再実行してください。")
        return 1

    print("\nカメラを探しています…")
    try:
        from asi_camera import init_sdk, ASICamera
        init_sdk(dll)
        names = ASICamera.list_cameras()
        if not names:
            print("  NG  カメラが見つかりません。")
            print("      - USB3 ポートに直挿しになっているか")
            print("      - デバイスマネージャーに ZWO のドライバが出ているか")
            print("      - ImpactVision2.exe / ivsb.exe が常駐してカメラを掴んでいないか")
            return 1
        for i, n in enumerate(names):
            print(f"  OK  [{i}] {n}")
    except Exception as e:
        print(f"  NG  SDK の初期化に失敗: {e}")
        return 1

    print("\nすべて問題なさそうです。`python main.py live` を試してください。")
    return 0


def cmd_list(cfg: dict) -> int:
    from asi_camera import init_sdk, ASICamera
    init_sdk(cfg["sdk"]["dll_path"])
    names = ASICamera.list_cameras()
    if not names:
        print("カメラが見つかりません。")
        return 1
    for i, n in enumerate(names):
        print(f"[{i}] {n}")
        try:
            with ASICamera(i) as cam:
                print(cam.info.summary())
        except Exception as e:
            print(f"    (詳細取得に失敗: {e})")
    return 0


def _settings_from(cfg: dict):
    from asi_camera import CameraSettings
    c = cfg["camera"]
    return CameraSettings(
        exposure_us=c.get("exposure_us", 1201),
        gain=c.get("gain", 100),
        gamma=c.get("gamma", 85),
        bandwidth=c.get("bandwidth", 50),
        flip=c.get("flip", 3),
    )


def cmd_live(cfg: dict) -> int:
    from asi_camera import init_sdk
    import live_view
    init_sdk(cfg["sdk"]["dll_path"])
    live_view.run(cfg["camera"]["id"], _settings_from(cfg))
    return 0


def cmd_record(cfg: dict, shots: int) -> int:
    from asi_camera import init_sdk
    import burst_record
    init_sdk(cfg["sdk"]["dll_path"])
    r = cfg["record"]
    burst_record.run(cfg["camera"]["id"], _settings_from(cfg),
                     r["pre_frames"], r["post_frames"], shots, r["output_dir"])
    return 0


def cmd_analyze(cfg: dict, a) -> int:
    import shot_analysis
    if a.iss:
        import iss_tools
        shot = iss_tools.load(a.iss)
        if not a.fps:
            print("※ .iss にはコマ時刻が記録されていません。--fps を指定してください。")
            print("  ImpactVision2 の実測解析からは 300fps 前後と推定されます。")
            return 1
        res = shot_analysis.analyze(shot.frames, None, a.fps, a.mm_per_px, a.up_axis)
        frames = shot.frames
    else:
        frames, ts, fps = shot_analysis.load_shot_dir(a.path)
        res = shot_analysis.analyze(frames, ts, a.fps or fps, a.mm_per_px, a.up_axis)
    print(res.report())
    if a.overlay:
        shot_analysis.draw_overlay(frames, res, a.overlay)
    return 0


def main() -> int:
    p = argparse.ArgumentParser(prog="golfsim", description="GolfSim")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("doctor", help="環境チェック")
    sub.add_parser("list", help="カメラ一覧")
    sub.add_parser("live", help="ライブビューア")
    rec = sub.add_parser("record", help="バースト記録")
    rec.add_argument("--shots", type=int, default=1)
    an = sub.add_parser("analyze", help="記録したショットを解析")
    an.add_argument("path", nargs="?", help="shots/shot_... ディレクトリ")
    an.add_argument("--iss", help="ImpactVision2 の .iss/.sid を直接解析")
    an.add_argument("--fps", type=float)
    an.add_argument("--mm-per-px", type=float)
    an.add_argument("--up-axis", default="-y", choices=["-y", "+y", "+x", "-x"])
    an.add_argument("--overlay")
    a = p.parse_args()

    cfg = load_config()
    if a.cmd == "doctor":
        return cmd_doctor(cfg)
    if a.cmd == "list":
        return cmd_list(cfg)
    if a.cmd == "live":
        return cmd_live(cfg)
    if a.cmd == "record":
        return cmd_record(cfg, a.shots)
    if a.cmd == "analyze":
        return cmd_analyze(cfg, a)
    return 1


if __name__ == "__main__":
    sys.exit(main())
