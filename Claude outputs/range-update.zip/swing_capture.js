// 練習場画面のためのスイング録画
//
// **考え方：骨格推定はここでは回さない。**
// 3D描画と同じGPUを奪い合うと、練習場のコマ落ちが戻ってくる。
// この画面が知りたいのは「いつのスイングか」だけで、それは
// 弾道検出（計測ユニット）か、素振りボタンが教えてくれる。
// だからカメラは**録り続けるだけ**にして、切り出しは頼まれたときに行う。
//
// 映像の切り出しに再エンコードは使わない。
// 元の動画をそのまま再生し、**再生する範囲（開始秒・終了秒）だけを返す。**
// 再エンコードは1本1.5秒ほど掛かるので、打つたびに待たされることになる。

import { SegmentRecorder, loadedDuration } from '/swing_record.js';

export const ROLES = [
  ['front', '正面'],
  ['side',  '側面'],
  ['diag',  '右斜め'],
];
const ASSIGN_KEY = 'gsim.bench2.assign';   // 検証画面と割り当てを共有する
const REC = { segmentMs: 12000, bps: 8_000_000 };

// 開けなかったときに、黙って諦めずに軽い設定へ落ちていく。
const LADDER = [
  {w:1920, h:1200, fps:120},
  {w:1280, h:720,  fps:120},
  {w:1280, h:720,  fps:60},
  {w:640,  h:480,  fps:30},
];

export class SwingCapture {
  constructor(){
    this.cams = [];          // {key,label,stream,recorder}
    this.ready = false;
    this.error = '';
  }

  /** 検証画面で決めたカメラ割り当てを読む。無ければ名前順に当てる。 */
  static loadAssign(){
    try{ return JSON.parse(localStorage.getItem(ASSIGN_KEY) || '{}'); }
    catch(e){ return {}; }
  }

  async open(){
    if(this.ready) return true;
    this.error = '';
    try{
      // サーバがカメラを掴んでいると開けない。先に手放してもらう。
      try{ await fetch('/api/cameras/release', {method:'POST'});
           await new Promise(r=>setTimeout(r, 1200)); }catch(e){}

      let a = SwingCapture.loadAssign();
      let devices = (await navigator.mediaDevices.enumerateDevices())
                      .filter(d => d.kind === 'videoinput');
      // 名前が取れていない＝まだ許可が下りていない。1回だけ開いて許可を取る。
      if(devices.length && !devices[0].label){
        try{
          const tmp = await navigator.mediaDevices.getUserMedia({video:true});
          tmp.getTracks().forEach(t=>t.stop());
          devices = (await navigator.mediaDevices.enumerateDevices())
                      .filter(d => d.kind === 'videoinput');
        }catch(e){}
      }
      const need = ROLES.filter(([k]) => !a[k] || !devices.some(d=>d.deviceId===a[k]));
      if(need.length){
        const used = new Set(Object.values(a));
        const pool = devices.filter(d => !used.has(d.deviceId));
        need.forEach(([k], i)=>{ if(pool[i]) a[k] = pool[i].deviceId; });
      }

      for(const [key, label] of ROLES){
        const id = a[key];
        if(!id) continue;
        const stream = await this._openOne(id);
        if(!stream) continue;
        const recorder = new SegmentRecorder(stream,
          {segmentMs: REC.segmentMs, bitsPerSecond: REC.bps});
        recorder.start();
        this.cams.push({key, label, stream, recorder});
      }
      this.ready = this.cams.length > 0;
      if(!this.ready) this.error = 'カメラを開けませんでした';
      return this.ready;
    }catch(e){
      this.error = (e && e.message) || String(e);
      return false;
    }
  }

  async _openOne(deviceId){
    for(const c of LADDER){
      try{
        return await navigator.mediaDevices.getUserMedia({video:{
          deviceId:{exact:deviceId},
          width:{ideal:c.w}, height:{ideal:c.h}, frameRate:{ideal:c.fps}}});
      }catch(e){
        if(e.name === 'NotAllowedError' || e.name === 'NotFoundError') return null;
        await new Promise(r=>setTimeout(r, 300));
      }
    }
    return null;
  }

  close(){
    for(const c of this.cams){
      try{ c.recorder.stop(); }catch(e){}
      try{ c.stream.getTracks().forEach(t=>t.stop()); }catch(e){}
    }
    this.cams = [];
    this.ready = false;
  }

  /**
   * 実時刻 [t0, t1]（performance.now の値）の映像を取り出す。
   *
   * @returns {Promise<Array<{key,label,url,inSec,outSec,mime}>>}
   *   url は動画そのもの。inSec〜outSec の範囲だけを再生すればよい。
   */
  async clip(t0, t1, must){
    const out = [];
    for(const c of this.cams){
      let seg = null;
      try{ seg = await c.recorder.take(t0, t1, must ?? t1); }catch(e){}
      if(!seg || !seg.blob) continue;
      const url = URL.createObjectURL(seg.blob);
      const v = document.createElement('video');
      v.preload = 'auto'; v.muted = true; v.src = url;
      // **webm は長さがヘッダに入っていない。**
      // 末尾まで一度送らないと duration が Infinity のままで、
      // 時刻の対応づけが全部狂う。
      let dur = 0;
      try{ dur = await loadedDuration(v); }catch(e){}
      if(!isFinite(dur) || dur <= 0){ URL.revokeObjectURL(url); continue; }

      // **動画の時間と実時刻はずれる。** コマ落ちした分だけ動画は短くなる。
      // 撮り終わりが確かなので、**終わり側を合わせる。**
      const toVideo = wall => dur - (seg.end - wall) / 1000;
      const inSec  = Math.max(0,   toVideo(t0));
      const outSec = Math.min(dur, toVideo(t1));
      if(outSec - inSec < 0.2){ URL.revokeObjectURL(url); continue; }
      out.push({key:c.key, label:c.label, url, inSec, outSec,
                mime:seg.mime, duration:dur});
    }
    return out;
  }

  /** 録れている長さと容量。画面に出して様子を見るため。 */
  status(){
    const held = this.cams.map(c => c.recorder.held);
    return {
      cameras: this.cams.length,
      seconds: held.length ? Math.max(...held.map(h => h.cur + h.prev)) : 0,
      mb: held.reduce((a,h) => a + h.bytes, 0) / 1048576,
      error: this.cams.map(c => c.recorder.error).filter(Boolean)[0] || this.error,
    };
  }
}

/** 再生範囲を守ってループ再生させる。動画を切らずに範囲だけ回す。 */
export function loopRange(video, inSec, outSec, {rate = 1, onLoop} = {}){
  let stop = false;
  video.playbackRate = rate;
  const seek = ()=>{ try{ video.currentTime = inSec; }catch(e){} };
  const tick = ()=>{
    if(stop) return;
    if(video.currentTime >= outSec - 0.02 || video.currentTime < inSec - 0.5){
      seek();
      if(onLoop) onLoop();
    }
  };
  video.addEventListener('timeupdate', tick);
  seek();
  const p = video.play(); if(p && p.catch) p.catch(()=>{});
  return ()=>{ stop = true; video.removeEventListener('timeupdate', tick);
               try{ video.pause(); }catch(e){} };
}
