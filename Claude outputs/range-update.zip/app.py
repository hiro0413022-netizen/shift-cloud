"""server/app.py — ローカルの調整用サーバ

ブラウザで開いて、機器をつなぎながら見て直すための土台。
打席のPCで動かし、必要ならタブレットからも同じ画面を開ける。

  GET  /                        画面
  GET  /api/status              各カメラの状態と実測fps
  GET  /api/stream/{key}        ライブ映像（MJPEG）
  GET  /api/metrics             いまの姿勢指標
  POST /api/reference           アドレス姿勢を基準にする
  GET  /api/discover            つながっている機器を探す（サムネ付き）
  GET  /api/probe/{index}       その機器で実際に出る解像度×fpsを実測
  GET  /api/config              設定を読む
  POST /api/config              設定を書いて再起動
  POST /api/record/{on|off}     録画バッファの開始・停止
  POST /api/clip                いまのバッファを書き出す
"""

from __future__ import annotations

import base64
import io
import json
import os
import subprocess
import sys
import queue
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import cv2
import numpy as np
from fastapi import Body, FastAPI, HTTPException

# スイングの保存だけが python-multipart を要る。無いときに
# サーバー全体が起動しないのは筋が悪いので、その機能だけを止める。
# 部品の名前は版によって python_multipart だったり multipart だったりする。
# どちらかが入っていればよいので、両方試す。
def _has_multipart() -> bool:
    for n in ("python_multipart", "multipart"):
        try:
            __import__(n)
            return True
        except Exception:                             # noqa: BLE001
            continue
    return False


try:
    from fastapi import File, Form, UploadFile
    HAS_MULTIPART = _has_multipart()
except Exception:                                     # noqa: BLE001
    HAS_MULTIPART = False
from fastapi.responses import (FileResponse, HTMLResponse, JSONResponse,
                               StreamingResponse)

# src/ の弾道計算をそのまま使う（画面用に書き直さない。数字が2種類できるため）
_SRC = str(Path(__file__).resolve().parents[2] / "src")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)

from .. import config as cfgmod
from ..capture.manager import CaptureManager
# カメラを直接触る処理は子プロセス（gsim.tools.camprobe）側で行う。
# ここで import しないのは、落ちる可能性のあるコードをサーバーに持ち込まないため。
from ..pose.estimator import PoseEstimator, draw_overlay
from ..pose import metrics as M
from ..calib.lens import CalibSession, LensModel, make_board_png

STATIC = Path(__file__).resolve().parent / "static"

app = FastAPI(title="GolfSim ローカル調整サーバ")

CFG: dict = {}
CAP = CaptureManager()
POSE: Dict[str, PoseEstimator] = {}
REF: Dict[str, dict] = {}
ROLES: Dict[str, str] = {}
CALIB: Dict[str, CalibSession] = {}

# 再接続のたびに増える通し番号。
# 配信中の映像ストリームは古いカメラを掴んだままなので、
# これが変わったら自分から終わってもらう（下の _mjpeg 参照）。
GEN = 0
JOB: dict = {"name": "", "running": False, "done": False,
             "result": None, "error": "", "progress": ""}


# ------------------------------------------------------------------ 起動
def _apply(cfg: dict) -> None:
    global CFG, POSE, ROLES, GEN
    CFG = cfg
    GEN += 1
    for p in POSE.values():
        p.stop()
    POSE = {}
    ROLES = {c["key"]: c.get("role", "front") for c in cfg["cameras"]}
    CAP.configure(cfg["cameras"])
    CAP.start_all()
    if cfg["pose"].get("enabled", True):
        for key, src in CAP.sources.items():
            est = PoseEstimator(key,
                                target_fps=float(cfg["pose"].get("target_fps", 25)),
                                model_complexity=int(cfg["pose"].get("model_complexity", 1)))
            est.bind(src)
            est.start()
            POSE[key] = est


@app.on_event("startup")
def _startup() -> None:
    # FastAPI は同期の関数をスレッドプールで動かす。既定は40本しかなく、
    # 映像配信が1本ずつ占有するため、再接続を繰り返すと枯渇して
    # サーバー全体が黙る（実際に「接続が切れた」のはこれ）。
    try:
        import anyio.to_thread
        anyio.to_thread.current_default_thread_limiter().total_tokens = 256
    except Exception as e:                            # noqa: BLE001
        print(f"[server] スレッド上限を変更できません: {e}")
    _apply(cfgmod.load())


@app.on_event("shutdown")
def _shutdown() -> None:
    for p in POSE.values():
        p.stop()
    CAP.stop_all()


# ------------------------------------------------------------------ 画面
@app.get("/pose_metrics.js")
def pose_metrics_js():
    return FileResponse(str(STATIC / "pose_metrics.js"), media_type="text/javascript")


@app.get("/swing_detect.js")
def swing_detect_js():
    return FileResponse(str(STATIC / "swing_detect.js"), media_type="text/javascript")


@app.get("/swing_record.js")
def swing_record_js():
    return FileResponse(str(STATIC / "swing_record.js"), media_type="text/javascript")


@app.get("/swing_capture.js")
def swing_capture_js():
    return FileResponse(str(STATIC / "swing_capture.js"), media_type="text/javascript")


@app.get("/swing_analyze.js")
def swing_analyze_js():
    return FileResponse(str(STATIC / "swing_analyze.js"), media_type="text/javascript")


@app.get("/range", response_class=HTMLResponse)
def range_screen() -> str:
    """練習場画面。打席のプロジェクターに出す側。"""
    return (STATIC / "range.html").read_text(encoding="utf-8")


@app.get("/ball_flight.js")
def ball_flight_js():
    return FileResponse(str(STATIC / "ball_flight.js"), media_type="text/javascript")


# ------------------------------------------------------------------ ショット
#
# 計測ユニット → 弾道計算 → 画面 を1本につなぐところ。
#
# 画面（range.html）は「打った」ことを自分では知らない。ここに POST が来たら
# 弾道を計算して残し、つながっている画面へ**押し出す**。
# こうしておくと、計測ユニットができたときに繋ぐ先はここ1か所で済む。

_SHOT_SEQ = {"n": 0}
_SHOT_LOCK = threading.Lock()
_SHOT_SUBS: List["queue.Queue"] = []          # 画面ごとの送り先


def _shot_broadcast(rec: dict) -> None:
    """開いている画面すべてに1件送る。詰まっている画面は捨てる。"""
    dead = []
    for q in list(_SHOT_SUBS):
        try:
            q.put_nowait(rec)
        except Exception:                                 # noqa: BLE001
            dead.append(q)
    for q in dead:
        if q in _SHOT_SUBS:
            _SHOT_SUBS.remove(q)


@app.post("/api/shot")
def post_shot(payload: dict = Body(...)) -> dict:
    """計測値を1件受け取る。**ここが計測ユニットの繋ぎ先。**

    受ける形（mph でも m/s でもよい）:
        {"ball_speed_ms":67.2, "launch_deg":12.8, "azimuth_deg":0.5,
         "backspin_rpm":2450, "sidespin_rpm":300, "head_speed_ms":45.1,
         "source":"camera", "club":"DR", "swing":"swing_20260908_143000"}
    """
    try:
        import shot_pipeline as sp
    except Exception as e:                                # noqa: BLE001
        raise HTTPException(500, f"弾道計算を読み込めません: {e}")

    site = CFG.get("site", {}) if isinstance(CFG, dict) else {}
    with _SHOT_LOCK:
        _SHOT_SEQ["n"] += 1
        seq = _SHOT_SEQ["n"]
    try:
        rec = sp.build(
            payload,
            surface=payload.get("surface", "fairway"),
            altitude_m=float(payload.get("altitude_m", 0.0)),
            temp_c=float(payload.get("temp_c", 20.0)),
            wind_ms=tuple(payload.get("wind_ms") or (0.0, 0.0)),
            club=payload.get("club"),
            swing=payload.get("swing"),
            site=str(site.get("name", "")), bay=str(site.get("bay", "")),
            seq=seq,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    try:
        rec["file"] = sp.save(rec)
    except Exception as e:                                # noqa: BLE001
        rec["warnings"].append(f"保存できませんでした: {e}")
    _shot_broadcast(rec)
    return rec


@app.get("/api/shots")
def get_shots(day: Optional[str] = None, limit: int = 300) -> dict:
    """その日のショットと、セッションのまとめ。"""
    import shot_pipeline as sp
    shots = sp.load_day(day)
    return {"shots": shots[-limit:], "summary": sp.summarize(shots)}


@app.get("/api/shots/stream")
def shots_stream():
    """打つたびに画面へ押し出す（Server-Sent Events）。

    画面から取りに来る作りにすると、打ってから表示までが遅れる。
    ここから押すので、打った瞬間に出る。
    """
    q: "queue.Queue" = queue.Queue(maxsize=32)
    _SHOT_SUBS.append(q)

    def gen():
        try:
            yield "retry: 2000\n\n"
            while True:
                try:
                    rec = q.get(timeout=15.0)
                    yield "event: shot\ndata: " + json.dumps(rec, ensure_ascii=False) + "\n\n"
                except queue.Empty:
                    yield ": keepalive\n\n"      # 切断防止
        finally:
            if q in _SHOT_SUBS:
                _SHOT_SUBS.remove(q)

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


@app.get("/textures/{path:path}")
def textures(path: str):
    """質感テクスチャ。tools/make_textures.py で作ったもの。"""
    f = (STATIC / "textures" / path).resolve()
    root = (STATIC / "textures").resolve()
    if not str(f).startswith(str(root)) or not f.is_file():
        raise HTTPException(404, "ありません")
    mt = {".png": "image/png", ".jpg": "image/jpeg",
          ".webp": "image/webp"}.get(f.suffix.lower(), "application/octet-stream")
    return FileResponse(str(f), media_type=mt)


@app.get("/api/models")
def list_models() -> dict:
    """models/ に置いてある3Dデータを返す。

    画面側が「高解像度版があるか」を確かめるために使う。
    無いものを取りに行かせて404を出すのは、本当の不具合と見分けがつかなくなる。
    """
    d = STATIC / "models"
    out = []
    if d.is_dir():
        for f in sorted(d.glob("*.glb")):
            out.append({"file": f.name, "bytes": f.stat().st_size})
    return {"models": out}


@app.get("/models/{path:path}")
def models(path: str):
    """練習場の3Dデータ。外には取りに行かない（通信の無いブースでも動く）。"""
    f = (STATIC / "models" / path).resolve()
    root = (STATIC / "models").resolve()
    if not str(f).startswith(str(root)) or not f.is_file():
        raise HTTPException(404, "ありません")
    mt = {".glb": "model/gltf-binary", ".gltf": "model/gltf+json",
          ".json": "application/json", ".png": "image/png",
          ".jpg": "image/jpeg"}.get(f.suffix.lower(), "application/octet-stream")
    return FileResponse(str(f), media_type=mt)


@app.get("/vendor/{path:path}")
def vendor(path: str):
    """MediaPipe の本体を自分で配る。

    外部のCDNに取りに行かせない。ブースは通信が無くても動かないといけないし、
    配信元が変わったら動かなくなる作りにはできない。
    """
    f = (STATIC / "vendor" / path).resolve()
    if not str(f).startswith(str((STATIC / "vendor").resolve())) or not f.is_file():
        raise HTTPException(404, "ありません")
    mt = {".mjs": "text/javascript", ".js": "text/javascript",
          ".wasm": "application/wasm", ".mp4": "video/mp4", ".webm": "video/webm",
          ".task": "application/octet-stream"}.get(f.suffix, "application/octet-stream")
    return FileResponse(str(f), media_type=mt)


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return (STATIC / "index.html").read_text(encoding="utf-8")


@app.post("/api/cameras/release")
def cameras_release() -> dict:
    """カメラを手放す。

    ブラウザ側で同じカメラを開いて試すには、こちらが掴んだままでは駄目である。
    カメラは1つのアプリしか開けない。検証画面はこれを最初に呼ぶ。
    """
    for p in POSE.values():
        p.stop()
    CAP.stop_all()
    time.sleep(0.8)
    return {"ok": True, "message": "カメラを手放しました"}


@app.post("/api/cameras/resume")
def cameras_resume() -> dict:
    """カメラを開き直す（検証が終わったら元に戻す）。"""
    _apply(cfgmod.load())
    return {"ok": True, "message": "つなぎ直しています"}


@app.get("/bench2", response_class=HTMLResponse)
def bench2() -> str:
    """ブラウザ側で取り込みと骨格推定まで行う版。"""
    return (STATIC / "bench2.html").read_text(encoding="utf-8")


@app.get("/api/model")
def get_model(kind: str = "lite"):
    """姿勢推定のモデルを配る（外部に取りに行かせない）。

    lite は撮影中の表示用。full は撮り終わった動画をコマ送りで解析する用で、
    実時間の制約がないぶん重いモデルを使える。lesson-os も同じ理由で full にした。
    """
    name = "pose_landmarker_full.task" if kind == "full" else "pose_landmarker_lite.task"
    f = Path(__file__).resolve().parents[2] / "models" / name
    if not f.exists():
        raise HTTPException(404, f"モデルがありません: {name}")
    return FileResponse(str(f), media_type="application/octet-stream")


@app.get("/camtest", response_class=HTMLResponse)
def camtest() -> str:
    """ブラウザ自身のカメラ機能で同じことができるかを確かめる画面。

    getUserMedia は localhost なら安全な文脈として扱われるので、
    このサーバーから配れば追加の設定なしにカメラを使える。
    """
    return (STATIC / "camtest.html").read_text(encoding="utf-8")


# ------------------------------------------------------------------ 状態
@app.get("/api/status")
def status() -> dict:
    st = CAP.status()
    for row in st:
        src0 = CAP.get(row["key"])
        row["enhance"] = getattr(src0, "enhance_level", 0) if src0 else 0
        est = POSE.get(row["key"])
        r = est.latest() if est else None
        row["role"] = ROLES.get(row["key"], "front")
        row["pose_available"] = bool(est and est.available)
        row["pose_ok"] = bool(r and r.ok)
        row["pose_ms"] = round(r.infer_ms, 1) if r else None
        row["pose_quality"] = round(M.quality(r), 2) if r else 0.0
        row["has_reference"] = row["key"] in REF and bool(REF[row["key"]])
        src = CAP.get(row["key"])
        row["undistort"] = bool(src and src.has_undistort)
        lm = LensModel.load(row["key"])
        row["lens"] = (dict(rms=round(lm.rms, 3), n=lm.n_images,
                            hfov=round(lm.hfov_deg, 1)) if lm else None)
        row["calib_n"] = CALIB[row["key"]].n if row["key"] in CALIB else 0
        row["calib_active"] = row["key"] in CALIB
    return {"site": CFG.get("site", {}), "cameras": st,
            "pose_enabled": CFG.get("pose", {}).get("enabled", True)}


@app.get("/api/metrics")
def metrics() -> dict:
    out = {}
    for key, est in POSE.items():
        r = est.latest()
        ms = M.compute(ROLES.get(key, "front"), r, REF.get(key))
        out[key] = [dict(key=x.key, label=x.label, value=round(float(x.value), 1),
                         unit=x.unit, hint=x.hint) for x in ms]
    return {"t": time.time(), "metrics": out}


@app.post("/api/reference")
def set_reference(payload: dict = Body(default={})) -> dict:
    keys = payload.get("keys") or list(POSE.keys())
    done = []
    for k in keys:
        est = POSE.get(k)
        if not est:
            continue
        ref = M.make_reference(est.latest())
        if ref:
            REF[k] = ref
            done.append(k)
    return {"ok": bool(done), "keys": done,
            "message": "アドレス姿勢を基準にしました" if done else "姿勢が取れていません"}


@app.post("/api/reference/clear")
def clear_reference() -> dict:
    REF.clear()
    return {"ok": True}


# ------------------------------------------------------------------ 映像
def _encode(img: np.ndarray, quality: int = 80) -> bytes:
    ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    return buf.tobytes() if ok else b""


def _mjpeg(key: str, overlay: bool, quality: int, max_fps: float):
    """映像を流し続ける。ただし『いつ終わるか』を必ず持たせる。

    再接続すると CAP.sources は作り直されるが、この生成器は古い方を
    掴んだままになる。ブラウザ側は新しい接続を張るので、古い方は
    誰にも見られないまま1本ずつスレッドを占有し続ける。
    数回繰り返すとプールを食い尽くしてサーバーが応答しなくなる。
    だから世代が変わったら自分から抜ける。
    """
    if CAP.get(key) is None:
        raise HTTPException(404, f"カメラ {key} がありません")
    my_gen = GEN
    interval = 1.0 / max(1.0, max_fps)
    last = -1
    idle = 0.0
    while GEN == my_gen:
        t0 = time.perf_counter()
        src = CAP.get(key)
        if src is None:
            break
        est = POSE.get(key)
        fr = src.latest()
        if fr is None:
            idle += 0.05
            if idle > 30.0:        # 30秒何も来ないなら見捨てる
                break
            time.sleep(0.05)
            continue
        idle = 0.0
        if fr.index != last:
            last = fr.index
            img = fr.image
            if overlay and est is not None:
                img = draw_overlay(img.copy(), est.latest())
            jpg = _encode(img, quality)
            if jpg:
                yield (b"--frame\r\nContent-Type: image/jpeg\r\n"
                       b"Content-Length: " + str(len(jpg)).encode() + b"\r\n\r\n"
                       + jpg + b"\r\n")
        rest = interval - (time.perf_counter() - t0)
        if rest > 0:
            time.sleep(rest)


@app.get("/api/stream/{key}")
def stream(key: str, overlay: int = 1, quality: int = 80, fps: float = 30.0):
    return StreamingResponse(_mjpeg(key, bool(overlay), quality, fps),
                             media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/snapshot/{key}")
def snapshot(key: str, overlay: int = 1):
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, "カメラがありません")
    fr = src.latest()
    if fr is None:
        raise HTTPException(503, "まだフレームがありません")
    img = fr.image
    if overlay and key in POSE:
        img = draw_overlay(img.copy(), POSE[key].latest())
    return StreamingResponse(io.BytesIO(_encode(img, 90)), media_type="image/jpeg")


# ------------------------------------------------------------------ 機器探索
@app.post("/api/discover")
def discover(max_index: int = 8) -> dict:
    """機器を探す。

    探すには一度カメラを離さないといけない。動いているカメラが
    番号を握ったままだと、その番号は「開けない」としか見えず、
    運が悪いと開こうとしたまま固まる（実際に固まったのはこれ）。
    """
    if JOB["running"]:
        raise HTTPException(409, "別の測定が動いています")
    _run_job("discover", lambda: _discover_all(max_index))
    return {"started": True}


@app.post("/api/probe/{index}")
def probe(index: int) -> dict:
    """その番号で実際に出る 解像度×fps を実測する。"""
    if JOB["running"]:
        raise HTTPException(409, "別の測定が動いています")

    _run_job("probe", lambda: _probe_one_index(index))
    return {"started": True}


def _uvc_entries() -> list:
    return [dict(index=int(c.get("index", 0)), width=int(c.get("width", 1280)),
                 height=int(c.get("height", 720)), fps=float(c.get("fps", 120)),
                 fourcc=c.get("fourcc", "MJPG"), label=c.get("label", c["key"]))
            for c in CFG["cameras"]
            if c.get("enabled", True) and c.get("kind") == "uvc"]


def _run_child(args: list, timeout: float) -> dict:
    """カメラを触る作業を別プロセスで走らせ、結果のJSONを受け取る。

    子が落ちても親（このサーバー）は生き残る。落ちたこと自体を結果として
    返せるので、画面から様子が分かる。**どこで落ちたか**も残す。
    直前に何を試していたかが分かれば、その設定を避けて進められる。

    標準出力は本文、標準エラーは進み具合。communicate() は両方を
    まとめて読んでしまい、進み具合を横取りするスレッドと衝突するので使わない。
    """
    cmd = [sys.executable, "-m", "gsim.tools.camprobe"] + args
    root = str(Path(__file__).resolve().parents[2])
    prev = os.environ.get("PYTHONPATH", "")
    env = dict(os.environ, PYTHONIOENCODING="utf-8",
               PYTHONPATH=(root + os.pathsep + prev) if prev else root)
    p = subprocess.Popen(cmd, cwd=root, env=env, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True, encoding="utf-8")

    state = {"last": "", "tail": []}

    def pump():
        try:
            for line in p.stderr:
                line = line.strip()
                if not line:
                    continue
                try:
                    d = json.loads(line)
                except Exception:                    # noqa: BLE001
                    state["tail"].append(line)
                    del state["tail"][:-6]
                    continue
                if "progress" in d:
                    state["last"] = d["progress"]
                    JOB["progress"] = d["progress"]
        except Exception:                            # noqa: BLE001
            pass

    t = threading.Thread(target=pump, daemon=True)
    t.start()

    out = ""
    try:
        out = p.stdout.read()                        # 子が終わるまで
        p.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        p.wait()
        raise RuntimeError(f"{int(timeout)}秒たっても終わりませんでした。"
                           "この配線では探索が通りません。直接指定を使ってください")
    finally:
        t.join(timeout=1.0)
        for f in (p.stdout, p.stderr):
            try:
                f.close()
            except Exception:                        # noqa: BLE001
                pass

    if p.returncode != 0 or not (out or "").strip():
        where = f"落ちた場所: {state['last']}" if state["last"] else ""
        extra = " / ".join(state["tail"][-2:])
        raise RuntimeError(
            f"カメラを調べる処理が異常終了しました（終了コード {p.returncode}）。"
            "カメラのドライバ側で落ちています。この設定は避けて、"
            f"直接指定から選んでください。{where} {extra}".strip())
    return json.loads(out)


def _run_job(name: str, fn) -> None:
    """重い測定を裏で1本だけ動かす。カメラは先に離し、最後に必ず戻す。

    fn は結果を返す関数。中で _run_child を何度呼んでもよい。
    1試行ごとに子プロセスを分ければ、固まっても短い時間切れで次へ進める。
    """
    def body():
        try:
            for p in POSE.values():
                p.stop()
            CAP.stop_all()
            time.sleep(0.6)
            JOB["result"] = fn()
        except Exception as e:                        # noqa: BLE001
            import traceback
            traceback.print_exc()
            JOB["error"] = f"{e}"
        finally:
            try:
                _apply(cfgmod.load())
            except Exception as e:                    # noqa: BLE001
                JOB["error"] = (JOB["error"] + f" / 再接続に失敗: {e}").strip()
            JOB["running"] = False
            JOB["done"] = True
            JOB["progress"] = ""

    JOB.update(name=name, running=True, done=False,
               result=None, error="", progress="準備中…")
    threading.Thread(target=body, daemon=True, name=f"job:{name}").start()


def _discover_all(max_index: int = 8) -> dict:
    """番号ごとに別プロセスで探す。MSMF で固まったら DSHOW で見直す。"""
    devices = []
    for i in range(max_index):
        JOB["progress"] = f"番号 {i} を調べています（{i + 1}/{max_index}）"
        try:
            r = _run_child(["discover1", "--index", str(i)], timeout=25.0)
        except Exception:                            # noqa: BLE001
            try:
                r = _run_child(["discover1", "--index", str(i), "--backend", "DSHOW"],
                               timeout=25.0)
                if r.get("found"):
                    r["note"] = (r.get("note", "") + " MSMFでは固まりました").strip()
            except Exception:                        # noqa: BLE001
                continue
        if r.get("found"):
            devices.append(r)
    dark = [d["index"] for d in devices if d.get("brightness", 0) < 8]
    if not devices:
        note = ("1台も見つかりません。ケーブルと、他のアプリ（カメラアプリ・Zoom など）が"
                "掴んでいないかを確認してください")
    elif dark:
        note = (f"番号 {', '.join(map(str, dark))} がほぼ真っ暗です。"
                "部屋を明るくするか、レンズキャップを外して、もう一度探してください")
    else:
        note = "映っている絵を見て、どれがどの位置のカメラか決めてください"
    return {"devices": devices, "note": note}


def _probe_one_index(index: int) -> dict:
    """1組ずつ別プロセスで試す。固まっても25秒で次へ。"""
    cands = [(1920, 1200, 120), (1280, 720, 120), (1280, 720, 60)]
    plan = [("MSMF", "MJPG"), ("DSHOW", "MJPG")]
    modes = []
    total = len(plan) * len(cands)
    k = 0
    for backend, fc in plan:
        for (w, h, f) in cands:
            k += 1
            JOB["progress"] = f"{k}/{total} 番号{index} を {backend} / {fc or '指定なし'} で {w}x{h}@{f} …"
            try:
                r = _run_child(["mode1", "--index", str(index), "--width", str(w),
                                "--height", str(h), "--fps", str(f),
                                "--backend", backend, "--fourcc", fc], timeout=25.0)
            except Exception as e:                    # noqa: BLE001
                modes.append(dict(width=w, height=h, requested_fps=f, backend=backend,
                                  asked=fc or "指定なし", fourcc="—", kind="hang",
                                  mjpg=False, measured_fps=0.0,
                                  why="時間切れ（固まりました）" if "終わりません" in str(e) else "落ちました"))
                continue
            if not r.get("ok"):
                modes.append(dict(width=w, height=h, requested_fps=f, backend=backend,
                                  asked=fc or "指定なし", fourcc="—", kind="ng",
                                  mjpg=False, measured_fps=0.0, why=r.get("why", "")))
                continue
            modes.append(r)
    return {"index": index, "modes": modes}


@app.get("/api/job")
def job_state() -> dict:
    return dict(JOB)


@app.post("/api/bandwidth")
def bandwidth() -> dict:
    """USBの帯域が足りているかを調べる（単独→同時）。"""
    if JOB["running"]:
        raise HTTPException(409, "別の測定が動いています")
    entries = _uvc_entries()
    if not entries:
        raise HTTPException(400, "種別が uvc のカメラがありません")

    _run_job("bandwidth", lambda: _run_child(
        ["bandwidth", "--entries", json.dumps(entries, ensure_ascii=False)], 240.0))
    return {"started": True}


@app.post("/api/mode/search")
def mode_search() -> dict:
    """全台が同時に出せる、いちばん重い設定を探す（適用はしない）。"""
    if JOB["running"]:
        raise HTTPException(409, "別の測定が動いています")
    entries = _uvc_entries()
    if not entries:
        raise HTTPException(400, "種別が uvc のカメラがありません")

    _run_job("mode", lambda: _run_child(
        ["search", "--entries", json.dumps(entries, ensure_ascii=False)], 300.0))
    return {"started": True}


@app.get("/api/mode/presets")
def mode_presets() -> dict:
    """探索を使わずに直接指定するための候補。

    探索はカメラを何十回も開き直すので、環境によっては通らない。
    設定を変えるだけなら開き直しは1回で済むので、こちらは必ず動く。
    """
    # ELP AR0234 が実際に出せるのは 1920x1200 / 1280x720 / 640x480 のみ（診断で確認）
    return {"presets": [
        dict(width=1280, height=720, fps=120, note="体の測定はこれで十分。3台同時に120fps出ることを確認済み"),
        dict(width=1280, height=720, fps=60, note="暗い部屋向け。シャッターを1/60秒まで伸ばせる（120fpsの2倍の光）"),
        dict(width=1280, height=720, fps=30, note="かなり暗い部屋向け。1/30秒まで伸ばせる（4倍の光）"),
        dict(width=1920, height=1200, fps=120, note="最高画質。3台同時だと85fps前後（CPUの限界）"),
        dict(width=1920, height=1200, fps=60, note="解像度を保ったままfpsを半分に"),
        dict(width=1280, height=720, fps=60, note="軽い。確認用"),
        dict(width=640, height=480, fps=120, note="最後の逃げ道。映ることの確認用"),
    ]}


@app.post("/api/mode/apply")
def mode_apply(body: dict = Body(...)) -> dict:
    """見つかった設定を、種別が uvc の全カメラに書き込んで再接続する。"""
    if JOB["running"]:
        raise HTTPException(409, "測定中です")
    w, h, f = int(body["width"]), int(body["height"]), float(body["fps"])
    cfg = cfgmod.load()
    n = 0
    for c in cfg["cameras"]:
        if c.get("kind") == "uvc":
            c["width"], c["height"], c["fps"] = w, h, f
            n += 1
    cfgmod.save(cfg)
    _apply(cfgmod.load())   # ここで CFG も入れ替わる
    return {"ok": True, "n": n,
            "message": f"{n}台を {w}x{h}@{int(f)} にして再接続しました"}


# ------------------------------------------------------------------ 設定
@app.get("/api/config")
def get_config() -> dict:
    return CFG


@app.post("/api/config")
def post_config(cfg: dict = Body(...)) -> dict:
    try:
        cfgmod.save(cfg)
        _apply(cfgmod.load())
        return {"ok": True, "message": "設定を保存して再接続しました"}
    except Exception as e:                            # noqa: BLE001
        raise HTTPException(400, f"{type(e).__name__}: {e}")


@app.get("/api/camera/{key}/settings")
def camera_settings(key: str) -> dict:
    src = CAP.get(key)
    if src is None or not hasattr(src, "read_settings"):
        raise HTTPException(404, "カメラがありません")
    cur = src.read_settings()
    out = {"key": key, "current": cur}
    if "exposure" in cur:
        try:
            sec = 2.0 ** float(cur["exposure"])
            out["shutter_sec"] = sec
            out["shutter_label"] = f"1/{round(1/sec)}秒" if sec < 1 else f"{sec:.2f}秒"
        except Exception:                             # noqa: BLE001
            pass
    return out


@app.post("/api/camera/{key}/shutter")
def camera_shutter(key: str, payload: dict = Body(...)) -> dict:
    """シャッター速度を秒で指定する（自動露出も切る）。"""
    src = CAP.get(key)
    if src is None or not hasattr(src, "set_manual_exposure"):
        raise HTTPException(404, "調整できないカメラです")
    sec = 1.0 / float(payload.get("denominator", 1000))
    r = src.set_manual_exposure(sec)
    a = r["actual_sec"]
    return {"ok": r["exposure_set"], **r,
            "label": f"1/{round(1/a)}秒" if a < 1 else f"{a:.2f}秒",
            "message": ("自動露出を切りました" if r["auto_off"]
                        else "自動露出を切れませんでした（機種によっては別の値が要ります）")}


def _mean_brightness(src) -> float:
    fr = src.latest()
    if fr is None:
        return -1.0
    img = fr.image
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    return float(g.mean())


@app.post("/api/camera/{key}/gain")
def camera_gain(key: str, payload: dict = Body(...)) -> dict:
    """ゲイン（増幅）を上げて明るくする。

    シャッターを速くすると入る光が減る。スイングを止めるには速いシャッターが要るので、
    足りない分はゲインで補う。ただしゲインはノイズも一緒に増やすので、
    上げれば済む話ではない。最後は照明を足すのが本筋である。
    """
    src = CAP.get(key)
    if src is None or not hasattr(src, "apply_setting"):
        raise HTTPException(404, "調整できないカメラです")
    v = float(payload.get("value", 0))
    ok = src.apply_setting("gain", v)
    time.sleep(0.4)
    return {"ok": ok, "value": v, "brightness": round(_mean_brightness(src), 1)}


@app.post("/api/camera/{key}/autolevel")
def camera_autolevel(key: str, payload: dict = Body(...)) -> dict:
    """狙った明るさになるゲインを、実際に測りながら探す。

    カタログ値ではなく**その場の明るさ**で決める。
    ゲインの目盛りは機種ごとにばらばらなので、当てにせず二分探索する。
    """
    src = CAP.get(key)
    if src is None or not hasattr(src, "apply_setting"):
        raise HTTPException(404, "調整できないカメラです")
    target = float(payload.get("target", 105))
    lo, hi = 0.0, float(payload.get("max", 255))
    best = None
    tried = []
    for _ in range(7):
        mid = (lo + hi) / 2
        if not src.apply_setting("gain", mid):
            raise HTTPException(400, "この機種はゲインを変えられません")
        time.sleep(0.35)
        b = _mean_brightness(src)
        tried.append({"gain": round(mid, 1), "brightness": round(b, 1)})
        if b < 0:
            break
        if best is None or abs(b - target) < abs(best[1] - target):
            best = (mid, b)
        if b < target:
            lo = mid
        else:
            hi = mid
    if best is None:
        raise HTTPException(400, "明るさを測れません")
    src.apply_setting("gain", best[0])
    time.sleep(0.3)
    b = _mean_brightness(src)
    if b < 45:
        msg = ("これ以上ゲインを上げても明るくなりません。照明を足すか、"
               "シャッターを遅くしてください")
    elif b < 75:
        msg = "まだ暗めです。照明を足せるなら足してください"
    else:
        msg = "この明るさなら姿勢推定が効きます"
    return {"ok": True, "gain": round(best[0], 1), "brightness": round(b, 1),
            "tried": tried, "message": msg}


@app.post("/api/camera/{key}/enhance")
def camera_enhance(key: str, payload: dict = Body(...)) -> dict:
    """映像をソフト側で持ち上げる。0=そのまま／1=弱／2=中／3=強。

    センサーに入る光は増えない。増えるのはノイズも含めた信号である。
    それでも骨格の検出は輪郭のコントラストで決まるので、
    暗い映像でも検出が通るようになることが多い。
    """
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, f"カメラ {key} がありません")
    lv = int(payload.get("level", 0))
    src.set_enhance(lv)
    time.sleep(0.4)
    return {"ok": True, "level": src.enhance_level,
            "brightness": round(_mean_brightness(src), 1)}


@app.post("/api/camera/{key}/enhance_auto")
def camera_enhance_auto(key: str) -> dict:
    """狙った明るさに届く最小の持ち上げ量を選ぶ。

    強く持ち上げるほどノイズが増えるので、**足りる中でいちばん弱い**ものを採る。
    """
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, f"カメラ {key} がありません")
    target = float(80)
    results = []
    for lv in (0, 1, 2, 3):
        src.set_enhance(lv)
        time.sleep(0.45)
        b = _mean_brightness(src)
        results.append({"level": lv, "brightness": round(b, 1)})
        if b >= target:
            break
    best = next((r for r in results if r["brightness"] >= target), results[-1])
    src.set_enhance(best["level"])
    time.sleep(0.3)
    b = _mean_brightness(src)
    names = {0: "そのまま", 1: "弱", 2: "中", 3: "強"}
    if b >= target:
        msg = f"{names[best['level']]}で足ります。これ以上上げるとノイズが増えるだけです"
    else:
        msg = ("いちばん強くしても足りません。fpsを下げてシャッターを長くするか、"
               "照明を足してください")
    return {"ok": True, "level": best["level"], "name": names[best["level"]],
            "brightness": round(b, 1), "tried": results, "message": msg}


@app.post("/api/camera/{key}/lightcheck")
def camera_lightcheck(key: str) -> dict:
    """明るさに関わる設定が**本当に効いているか**を、書いて読み戻して確かめる。

    OpenCV の set() は、効かなくても True を返すことがある。
    Media Foundation は対応する項目が少なく、ゲインを受け付けない機種もある。
    「上げたのに変わらない」ときは、まずここを疑う。
    """
    src = CAP.get(key)
    if src is None or not hasattr(src, "apply_setting"):
        raise HTTPException(404, "調整できないカメラです")

    out = {"items": [], "backend": src.info.device}
    fps = float(src.info.fps or 0)
    out["max_exposure_sec"] = (1.0 / fps) if fps > 0 else None

    # 0 を試してはいけない。効かない項目は 0 のままなので「一致した」と誤判定する。
    # 必ず 0 以外の、互いに離れた2つの値で確かめる。
    for name, label, probe in (("exposure", "シャッター", (-6.0, -8.0)),
                               ("gain", "ゲイン", (64.0, 160.0)),
                               ("brightness", "明るさ補正", (32.0, 96.0)),
                               ("gamma", "ガンマ", (100.0, 200.0))):
        before = None
        try:
            before = float(src._cap.get(src.PROPS[name])) if src._cap else None
        except Exception:                            # noqa: BLE001
            pass
        # 2つとも要求どおりに変わったときだけ「効く」とする
        hits = 0
        for v in probe:
            src.apply_setting(name, v)
            time.sleep(0.25)
            try:
                got = float(src._cap.get(src.PROPS[name])) if src._cap else None
            except Exception:                        # noqa: BLE001
                got = None
            if got is not None and abs(got - v) < max(1.0, abs(v) * 0.25):
                hits += 1
        moved = hits == len(probe)
        if before is not None:
            src.apply_setting(name, before)
        out["items"].append({"key": name, "label": label,
                             "works": moved, "value": before})
    time.sleep(0.4)
    out["brightness"] = round(_mean_brightness(src), 1)
    ng = [i["label"] for i in out["items"] if not i["works"]]
    out["message"] = (f"{'・'.join(ng)} は、この経路（{src.info.device}）では変えられません。"
                      "照明を足すか、fpsを下げてシャッターを長くしてください") if ng \
        else "明るさに関わる設定はすべて効いています"
    return out


@app.post("/api/camera/{key}/auto_exposure")
def camera_auto_exposure(key: str) -> dict:
    """自動露出に戻す（手動で暗くしすぎたときの復帰用）。

    控えてある手動設定も消す。ここを消さないと、再接続のたびに
    暗い設定が復活して「直したはずなのにまた暗い」ことになる。
    ソフト側の持ち上げも同時に解除し、素の状態へ戻す。
    """
    src = CAP.get(key)
    if src is None or not hasattr(src, "apply_setting"):
        raise HTTPException(404, "調整できないカメラです")
    for k in ("exposure", "gain", "brightness", "gamma"):
        src.settings.pop(k, None)
    ok = False
    for v in (0.75, 3.0, 1.0):
        if src.apply_setting("auto_exposure", v):
            ok = True
            break
    src.settings.pop("auto_exposure", None)
    src.set_enhance(0)
    time.sleep(0.8)
    return {"ok": ok, "brightness": round(_mean_brightness(src), 1),
            "message": ("自動露出に戻し、手動設定と持ち上げも解除しました" if ok
                        else "自動露出には戻せませんでした（手動設定と持ち上げは解除しました）")}


@app.post("/api/camera/{key}/setting")
def camera_setting(key: str, payload: dict = Body(...)) -> dict:
    src = CAP.get(key)
    if src is None or not hasattr(src, "apply_setting"):
        raise HTTPException(404, "調整できないカメラです")
    name, value = payload.get("name"), payload.get("value")
    ok = src.apply_setting(str(name), float(value))
    return {"ok": ok, "current": src.read_settings() if ok else {}}




# ------------------------------------------------------------------ レンズ較正
@app.get("/api/lens/board")
def lens_board(cols: int = 10, rows: int = 7):
    """印刷用チェッカーボードを返す。A4に等倍で印刷して板に貼る。"""
    path = Path("config/lens") / f"board_{cols}x{rows}.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    make_board_png(str(path), cols=cols, rows=rows)
    return StreamingResponse(io.BytesIO(path.read_bytes()), media_type="image/png")


@app.post("/api/lens/{key}/start")
def lens_start(key: str, payload: dict = Body(default={})) -> dict:
    cols = int(payload.get("cols", 9))
    rows = int(payload.get("rows", 6))
    CALIB[key] = CalibSession(key=key, board=(cols, rows),
                              square_mm=float(payload.get("square_mm", 25.0)))
    return {"ok": True, "board": [cols, rows],
            "message": f"内側交点 {cols}×{rows} で開始しました。"
                       f"中央と四隅、傾けた画を合わせて15〜25枚撮ってください"}


@app.post("/api/lens/{key}/capture")
def lens_capture(key: str) -> dict:
    if key not in CALIB:
        raise HTTPException(400, "先に「較正を開始」を押してください")
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, "カメラがありません")
    fr = src.latest()
    if fr is None:
        raise HTTPException(503, "まだフレームがありません")
    # 較正は **補正前の生の絵** で行う必要がある
    was = src.undistort_enabled
    src.undistort_enabled = False
    time.sleep(0.15)
    fr = src.latest()
    r = CALIB[key].add(fr.image)
    src.undistort_enabled = was
    r["coverage"] = CALIB[key].coverage_report()
    return r


@app.post("/api/lens/{key}/compute")
def lens_compute(key: str) -> dict:
    ses = CALIB.get(key)
    if ses is None:
        raise HTTPException(400, "較正セッションがありません")
    model, msg = ses.compute()
    if model is None:
        return {"ok": False, "message": msg}
    model.save()
    applied = CAP.reload_lens(key)
    return {"ok": True, "message": msg, "applied": applied,
            "rms": round(model.rms, 3), "hfov": round(model.hfov_deg, 1),
            "n": model.n_images}


@app.post("/api/lens/{key}/reset")
def lens_reset(key: str) -> dict:
    CALIB.pop(key, None)
    return {"ok": True}


@app.post("/api/lens/{key}/toggle")
def lens_toggle(key: str, payload: dict = Body(default={})) -> dict:
    src = CAP.get(key)
    if src is None:
        raise HTTPException(404, "カメラがありません")
    src.undistort_enabled = bool(payload.get("on", True))
    return {"ok": True, "on": src.undistort_enabled,
            "has_model": src.has_undistort}


# ------------------------------------------------------------------ 記録
if HAS_MULTIPART:
  @app.post("/api/swing/save")
  async def swing_save(meta: str = Form(...), files: List[UploadFile] = File(...)) -> dict:
      """ブラウザで撮れたスイングを保存する。

      ファイル名に「カメラ／通し番号／アドレスからの経過ミリ秒」を入れておく。
      あとから見るときに、どのコマがいつのものかがファイル名だけで分かる。
      局面（アドレス・トップ・インパクト）は meta.json に書く。
      """
      try:
          m = json.loads(meta)
      except Exception as e:                            # noqa: BLE001
          raise HTTPException(400, f"meta が読めません: {e}")

      root = Path(__file__).resolve().parents[2] / "recordings"
      name = m.get("name") or datetime.now().strftime("swing_%Y%m%d_%H%M%S")
      d = root / name
      d.mkdir(parents=True, exist_ok=True)

      n = 0
      for f in files:
          safe = "".join(c for c in (f.filename or "") if c.isalnum() or c in "._-")
          if not safe:
              continue
          (d / safe).write_bytes(await f.read())
          n += 1
      (d / "meta.json").write_text(json.dumps(m, ensure_ascii=False, indent=2),
                                   encoding="utf-8")

      # 骨格は将来いちばん効く資産になる。映像より軽く、そのまま計算に使える。
      lm = m.pop("landmarks", None)
      if lm:
          (d / "landmarks.json").write_text(
              json.dumps(lm, ensure_ascii=False), encoding="utf-8")
          (d / "meta.json").write_text(json.dumps(m, ensure_ascii=False, indent=2),
                                       encoding="utf-8")
      return {"ok": True, "dir": str(d), "files": n, "name": name}

else:
  @app.post("/api/swing/save")
  def swing_save_unavailable() -> dict:
      raise HTTPException(
          503, "保存に必要な部品（python-multipart）が入っていません。"
               "start.bat を実行し直すと自動で入ります")


@app.get("/api/swing/list")
def swing_list() -> dict:
    """保存済みのスイングを新しい順に返す。"""
    root = Path(__file__).resolve().parents[2] / "recordings"
    out = []
    if root.is_dir():
        for d in sorted(root.iterdir(), reverse=True):
            mf = d / "meta.json"
            if d.is_dir() and mf.is_file():
                try:
                    m = json.loads(mf.read_text(encoding="utf-8"))
                except Exception:                     # noqa: BLE001
                    m = {}
                vids = len(list(d.glob("*.webm"))) + len(list(d.glob("*.mp4")))
                out.append({"name": d.name,
                            "frames": len(list(d.glob("*.jpg"))),
                            "videos": vids, "meta": m})
    return {"swings": out[:50]}


def _swing_dir(name: str) -> Path:
    """保存名からフォルダを引く。外に出る名前は受け付けない。"""
    root = (Path(__file__).resolve().parents[2] / "recordings").resolve()
    d = (root / name).resolve()
    if not str(d).startswith(str(root)) or not d.is_dir():
        raise HTTPException(404, "ありません")
    return d


@app.get("/api/swing/{name}/meta")
def swing_meta(name: str) -> dict:
    """1本ぶんの中身。コマのファイル名を時刻つきで返す。

    ファイル名に入れた「インパクトから何ミリ秒か」をそのまま時刻として使う。
    別に一覧を持たなくても、ファイルが揃っていれば再生できる。
    """
    d = _swing_dir(name)
    meta = {}
    mf = d / "meta.json"
    if mf.is_file():
        try:
            meta = json.loads(mf.read_text(encoding="utf-8"))
        except Exception:                             # noqa: BLE001
            meta = {}
    cams: Dict[str, list] = {}
    for f in sorted(d.glob("*.jpg")):
        # 例: front_012_m033ms.jpg → カメラ front / 13コマ目 / インパクト33ms前
        parts = f.stem.split("_")
        if len(parts) < 3:
            continue
        key = parts[0]
        tag = parts[-1]
        try:
            ms = int(tag[1:-2])
            rel = -ms if tag[0] == "m" else ms
        except Exception:                             # noqa: BLE001
            continue
        cams.setdefault(key, []).append({"file": f.name, "t": rel})
    for v in cams.values():
        v.sort(key=lambda x: x["t"])
    # 動画方式で保存されたもの。meta.cams に書いてある file を実在確認して返す。
    # 静止画方式（cams）は古い保存のために残してある。
    videos: Dict[str, dict] = {}
    for c in (meta.get("cams") or []):
        fn = c.get("file")
        if not fn:
            continue
        f = (d / str(fn)).resolve()
        if str(f).startswith(str(d)) and f.is_file():
            videos[str(c.get("key"))] = {
                "file": f.name, "bytes": f.stat().st_size,
                "offset": c.get("offset", 0), "fps": c.get("fps"),
            }
    lm = {}
    lf = d / "landmarks.json"
    if lf.is_file():
        try:
            lm = json.loads(lf.read_text(encoding="utf-8"))
        except Exception:                             # noqa: BLE001
            lm = {}
    return {"name": name, "meta": meta, "cams": cams, "videos": videos,
            "has_landmarks": bool(lm), "landmarks": lm}


@app.get("/api/swing/{name}/video/{fn}")
def swing_video(name: str, fn: str):
    """録った動画そのもの。再生は <video> に任せるので、範囲要求に応える。

    静止画を1コマずつ並べる方式をやめたので、ここが再生の本体になった。
    """
    d = _swing_dir(name)
    f = (d / fn).resolve()
    if not str(f).startswith(str(d)) or not f.is_file():
        raise HTTPException(404, "ありません")
    mt = "video/mp4" if f.suffix.lower() == ".mp4" else "video/webm"
    return FileResponse(str(f), media_type=mt)


@app.get("/api/swing/{name}/frame/{fn}")
def swing_frame(name: str, fn: str):
    d = _swing_dir(name)
    f = (d / fn).resolve()
    if not str(f).startswith(str(d)) or not f.is_file():
        raise HTTPException(404, "ありません")
    return FileResponse(str(f), media_type="image/jpeg")


@app.get("/api/swing/{name}/landmarks")
def swing_landmarks(name: str):
    d = _swing_dir(name)
    f = d / "landmarks.json"
    if not f.is_file():
        raise HTTPException(404, "骨格が保存されていません")
    return FileResponse(str(f), media_type="application/json")


@app.delete("/api/swing/{name}")
def swing_delete(name: str) -> dict:
    """1本消す。容量はすぐ埋まるので、消す手段は最初から要る。"""
    d = _swing_dir(name)
    n = 0
    for f in d.iterdir():
        if f.is_file():
            f.unlink()
            n += 1
    d.rmdir()
    return {"ok": True, "removed": n}


@app.get("/api/storage")
def storage() -> dict:
    """どれだけ使っているか。1本あたりの重さも出す。"""
    root = Path(__file__).resolve().parents[2] / "recordings"
    total, n = 0, 0
    per = []
    if root.is_dir():
        for d in root.iterdir():
            if not d.is_dir():
                continue
            sz = sum(f.stat().st_size for f in d.iterdir() if f.is_file())
            total += sz
            n += 1
            per.append({"name": d.name, "bytes": sz})
    per.sort(key=lambda x: x["name"], reverse=True)
    free = None
    try:
        import shutil as _sh
        free = _sh.disk_usage(str(root if root.is_dir() else Path("."))).free
    except Exception:                                 # noqa: BLE001
        pass
    return {"swings": n, "bytes": total, "free_bytes": free,
            "avg_bytes": (total // n) if n else 0, "per": per[:200],
            "path": str(root)}


@app.post("/api/record/{state}")
def record(state: str) -> dict:
    on = state == "on"
    CAP.set_recording(on)
    return {"ok": True, "recording": on}


@app.post("/api/clip")
def clip() -> dict:
    root = Path(CFG.get("recording", {}).get("dir", "recordings"))
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = root / stamp
    out.mkdir(parents=True, exist_ok=True)
    saved = []
    for key, src in CAP.sources.items():
        frames = src.take_clip()
        if not frames:
            continue
        h, w = frames[0].image.shape[:2]
        span = frames[-1].t_mono - frames[0].t_mono
        fps = (len(frames) - 1) / span if span > 0 else 30.0
        path = out / f"{key}.mp4"
        vw = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
        for f in frames:
            vw.write(f.image)
        vw.release()
        saved.append(dict(key=key, file=str(path), frames=len(frames),
                          fps=round(fps, 1)))
    return {"ok": bool(saved), "dir": str(out), "files": saved}
