"""
ball_flight.py — ゴルフボールの弾道計算

計測ユニットが出す「初速・打ち出し角・方向角・バックスピン・サイドスピン」から、
実際の飛距離と軌道を求める。GolfSim の Phase 2。

■ 何を計算しているか

飛んでいるボールには3つの力がかかる。

    重力      : 下向き。一定
    空気抵抗  : 進行方向の逆向き。速度の2乗に比例
    マグヌス力 : 回転により発生。バックスピンなら上向き＝揚力になる

このうち **マグヌス力がゴルフの弾道を決めている**。バックスピンが無ければ
ドライバーの当たりでも200ヤードそこそこしか飛ばない。回転が揚力を生み、
球を浮かせ続けることで初めて275ヤードが出る。

■ 係数の決め方（ここが実務的に重要）

抗力係数 Cd と揚力係数 Cl は、スピンレシオ S = ωr/v の関数になる。
理論式は存在するが、実際のボールでは表面のディンプルの影響が大きく、
文献値をそのまま使うと現実とずれる。

そこで本実装では **物理的に正しい「形」の式を用意し、係数だけを実測値に
合わせて較正する** 方式を採った。較正の基準は TrackMan が公表している
PGAツアー平均値（後述）。この2点に合わせ込んである。

これは ImpactVision の補正テーブルと同じ考え方だが、決定的な違いがある:
向こうは「どこから来たか分からない数字」だったのに対し、こちらは
**出典の明確な実測値に合わせている**。根拠が追える。

■ 使い方

    from ball_flight import Shot, simulate
    r = simulate(Shot(ball_speed_ms=74.6, launch_deg=10.9, backspin_rpm=2686))
    print(r.summary())
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

# --- 定数 -------------------------------------------------------------------

BALL_MASS_KG = 0.04593        # ゴルフ規則の上限 45.93 g
BALL_DIAMETER_M = 0.042672    # 同 下限 42.67 mm
BALL_RADIUS_M = BALL_DIAMETER_M / 2
BALL_AREA_M2 = math.pi * BALL_RADIUS_M ** 2
GRAVITY = 9.80665

RHO_SEA_LEVEL = 1.225         # 15°C / 1013hPa での空気密度 kg/m^3

YARD = 0.9144
MPH = 0.44704

# --- 空力係数（TrackMan の PGA ツアー平均に合わせて較正済み） ----------------
# Cd(S) = CD0 + CD1 * S              抗力はスピンでわずかに増える
# Cl(S) = CL_MAX * S / (CL_HALF + S) 揚力はスピンで増えるが頭打ちになる
CD0 = 0.1923
CD1 = 0.220
CL_MAX = 0.2205
CL_HALF = 0.0455
SPIN_DECAY_S = 22.0           # スピンの減衰時定数[秒]


@dataclass
class Shot:
    """計測ユニットの出力（＝この計算の入力）。"""
    ball_speed_ms: float
    launch_deg: float                 # 打ち出し角（上向きが正）
    azimuth_deg: float = 0.0          # 打ち出し方向（右が正）
    backspin_rpm: float = 2500.0
    sidespin_rpm: float = 0.0         # 右回転（スライス方向）が正
    altitude_m: float = 0.0           # 標高。空気密度に効く
    temp_c: float = 20.0
    wind_ms: tuple = (0.0, 0.0)       # (追い風+, 右からの横風+)

    @classmethod
    def from_imperial(cls, ball_speed_mph: float, launch_deg: float,
                      backspin_rpm: float, **kw) -> "Shot":
        return cls(ball_speed_ms=ball_speed_mph * MPH, launch_deg=launch_deg,
                   backspin_rpm=backspin_rpm, **kw)


@dataclass
class Trajectory:
    """計算結果。"""
    carry_m: float                    # キャリー（落下点までの直線距離）
    total_m: float                    # ラン込みの総距離
    apex_m: float                     # 最高到達点
    flight_time_s: float
    landing_angle_deg: float          # 落下角。グリーンで止まるかの目安
    side_m: float                     # 左右のズレ（右が正）
    descent_speed_ms: float
    path: np.ndarray = field(repr=False, default=None)   # (N,3) 軌跡

    @property
    def carry_yd(self) -> float: return self.carry_m / YARD
    @property
    def total_yd(self) -> float: return self.total_m / YARD
    @property
    def apex_yd(self) -> float: return self.apex_m / YARD
    @property
    def side_yd(self) -> float: return self.side_m / YARD

    def summary(self) -> str:
        side = "右" if self.side_m >= 0 else "左"
        return (f"キャリー {self.carry_yd:6.1f}yd ({self.carry_m:6.1f}m)   "
                f"トータル {self.total_yd:6.1f}yd\n"
                f"最高到達点 {self.apex_yd:5.1f}yd ({self.apex_m:5.1f}m)   "
                f"滞空 {self.flight_time_s:4.2f}s   落下角 {self.landing_angle_deg:4.1f}°\n"
                f"左右のズレ {abs(self.side_yd):5.1f}yd {side}")


def air_density(altitude_m: float = 0.0, temp_c: float = 20.0) -> float:
    """標高と気温から空気密度を出す。夏場と冬場で飛距離が変わる理由がこれ。"""
    p = 101325.0 * (1.0 - 2.25577e-5 * altitude_m) ** 5.25588
    return p / (287.058 * (temp_c + 273.15))


def _coefficients(spin_ratio: float) -> tuple[float, float]:
    s = max(0.0, spin_ratio)
    cd = CD0 + CD1 * s
    cl = CL_MAX * s / (CL_HALF + s)
    return cd, cl


def _accel(vx, vy, vz, ox, oy, oz, rho, wx, wz):
    """速度と回転から加速度を求める。ここが計算の心臓部。

    numpy の配列を使うと 1 ショットあたり数万回の小さな配列生成が発生し、
    そのオーバーヘッドが支配的になる。実時間で表示する用途なので、
    ここだけは素の float で書いてある。
    """
    ax_ = vx - wx
    ay_ = vy
    az_ = vz - wz
    speed = math.sqrt(ax_*ax_ + ay_*ay_ + az_*az_)
    if speed < 1e-6:
        return 0.0, -GRAVITY, 0.0

    spin = math.sqrt(ox*ox + oy*oy + oz*oz)
    s = (spin * BALL_RADIUS_M) / speed
    cd = CD0 + CD1 * s
    cl = CL_MAX * s / (CL_HALF + s) if s > 0 else 0.0

    q = 0.5 * rho * BALL_AREA_M2 * speed * speed / BALL_MASS_KG
    inv = 1.0 / speed
    ax = -cd * q * ax_ * inv
    ay = -cd * q * ay_ * inv - GRAVITY
    az = -cd * q * az_ * inv

    if spin > 1e-6:
        # マグヌス力の向きは ω × v
        cx = oy*az_ - oz*ay_
        cy = oz*ax_ - ox*az_
        cz = ox*ay_ - oy*ax_
        n = math.sqrt(cx*cx + cy*cy + cz*cz)
        if n > 1e-9:
            k = cl * q / n
            ax += k * cx
            ay += k * cy
            az += k * cz
    return ax, ay, az


def simulate(shot: Shot, dt: float = 0.008, max_time: float = 15.0,
             roll_factor: Optional[float] = None,
             keep_path: bool = True) -> Trajectory:
    """弾道を数値積分する（4次ルンゲ＝クッタ法）。

    座標系:  x = 飛球線方向（前）,  y = 上,  z = 右

    dt=0.008 でも dt=0.002 と結果は小数点以下2桁まで一致する（RK4のため）。
    軌跡の描画が不要なら keep_path=False で更に速くなる。
    """
    rho = air_density(shot.altitude_m, shot.temp_c)

    la = math.radians(shot.launch_deg)
    az = math.radians(shot.azimuth_deg)
    v0 = shot.ball_speed_ms
    vx = v0 * math.cos(la) * math.cos(az)
    vy = v0 * math.sin(la)
    vz = v0 * math.cos(la) * math.sin(az)

    # バックスピンは進行方向に垂直な水平軸まわり、サイドスピンは鉛直軸まわり
    back = shot.backspin_rpm * 2 * math.pi / 60.0
    side = shot.sidespin_rpm * 2 * math.pi / 60.0
    bx, bz = -math.sin(az), math.cos(az)
    ox0, oy0, oz0 = back * bx, -side, back * bz

    wx, wz = shot.wind_ms[0], shot.wind_ms[1]

    px = py = pz = 0.0
    t = 0.0
    apex = 0.0
    pts = [(0.0, 0.0, 0.0)] if keep_path else None

    while t < max_time:
        decay = math.exp(-t / SPIN_DECAY_S)
        ox, oy, oz = ox0 * decay, oy0 * decay, oz0 * decay

        a1 = _accel(vx, vy, vz, ox, oy, oz, rho, wx, wz)
        v2 = (vx + 0.5*dt*a1[0], vy + 0.5*dt*a1[1], vz + 0.5*dt*a1[2])
        a2 = _accel(*v2, ox, oy, oz, rho, wx, wz)
        v3 = (vx + 0.5*dt*a2[0], vy + 0.5*dt*a2[1], vz + 0.5*dt*a2[2])
        a3 = _accel(*v3, ox, oy, oz, rho, wx, wz)
        v4 = (vx + dt*a3[0], vy + dt*a3[1], vz + dt*a3[2])
        a4 = _accel(*v4, ox, oy, oz, rho, wx, wz)

        c = dt / 6.0
        nvx = vx + c*(a1[0] + 2*a2[0] + 2*a3[0] + a4[0])
        nvy = vy + c*(a1[1] + 2*a2[1] + 2*a3[1] + a4[1])
        nvz = vz + c*(a1[2] + 2*a2[2] + 2*a3[2] + a4[2])
        npx = px + c*(vx + 2*v2[0] + 2*v3[0] + v4[0])
        npy = py + c*(vy + 2*v2[1] + 2*v3[1] + v4[1])
        npz = pz + c*(vz + 2*v2[2] + 2*v3[2] + v4[2])

        if npy <= 0.0 and t > 0.05:
            f = py / (py - npy) if (py - npy) != 0 else 0.0
            px, py, pz = px + f*(npx-px), 0.0, pz + f*(npz-pz)
            vx, vy, vz = vx + f*(nvx-vx), vy + f*(nvy-vy), vz + f*(nvz-vz)
            t += f * dt
            if keep_path:
                pts.append((px, py, pz))
            break

        px, py, pz = npx, npy, npz
        vx, vy, vz = nvx, nvy, nvz
        t += dt
        if py > apex:
            apex = py
        if keep_path:
            pts.append((px, py, pz))

    carry = math.hypot(px, pz)
    vh = math.hypot(vx, vz)
    landing = math.degrees(math.atan2(abs(vy), vh)) if vh > 0 else 90.0
    descent = math.sqrt(vx*vx + vy*vy + vz*vz)

    # ラン: 落下角が浅いほど転がる。フェアウェイ想定の素朴なモデル
    if roll_factor is None:
        roll_factor = max(0.0, 0.55 - 0.012 * landing)
    total = carry * (1.0 + roll_factor)

    return Trajectory(carry_m=carry, total_m=total, apex_m=apex,
                      flight_time_s=t, landing_angle_deg=landing,
                      side_m=pz, descent_speed_ms=descent,
                      path=(np.array(pts) if keep_path else None))


# --- 較正の検証 -------------------------------------------------------------

BENCHMARKS = [
    # (名前, 初速mph, 打ち出し角, スピンrpm, 期待キャリーyd)  出典: TrackMan PGAツアー平均
    ("Driver  (PGA平均)", 167, 10.9, 2686, 275),
    ("5-Iron  (PGA平均)", 132, 12.1, 5361, 194),
]


def verify(verbose: bool = True) -> float:
    """公表されている実測値と突き合わせる。最大誤差[%]を返す。"""
    worst = 0.0
    lines = ["=" * 62, "  較正の検証 — TrackMan PGAツアー平均との比較", "=" * 62,
             f"  {'クラブ':<18}{'期待':>8}{'計算':>9}{'誤差':>9}"]
    for name, mph, la, spin, expect in BENCHMARKS:
        r = simulate(Shot.from_imperial(mph, la, spin))
        err = (r.carry_yd - expect) / expect * 100
        worst = max(worst, abs(err))
        lines.append(f"  {name:<18}{expect:>6}yd{r.carry_yd:>8.1f}yd{err:>8.1f}%")
    lines.append("=" * 62)
    if verbose:
        print("\n".join(lines))
    return worst


if __name__ == "__main__":
    verify()
    print()
    for label, s in [
        ("ドライバー(アマチュア 平均的)", Shot.from_imperial(130, 14.0, 3200)),
        ("ドライバー(スライス)", Shot.from_imperial(140, 13.0, 3000, sidespin_rpm=900)),
        ("7番アイアン", Shot.from_imperial(120, 16.5, 7000)),
    ]:
        print(f"--- {label}")
        print(simulate(s).summary())
        print()
