"""
sensor_fusion.py — 天井ステレオカメラ + ドップラーレーダの統合

■ 前提となる構成（2026-09-03 時点）

    計測カメラ  : 天井に2台（ステレオ）。高速・モノクロ・グローバルシャッター
    レーダー    : 天井内蔵 ／ 正面キオスク下 ／ 両方
    スイング撮影: 前方・後方に120fpsのカメラ（計測には使わない）

■ 前回の記述を訂正します

「天井カメラでは打ち出し角・入射角は測れない」と書きましたが、
これは **カメラ1台の場合** の話でした。**2台のステレオなら視差から高さが出るので、
垂直方向の角度も測れます。** 訂正します。

ただし精度は自動的には決まりません。ステレオの奥行き精度は

    σ_z  =  z² · σ_視差 / (f · B)

で決まり、**距離の2乗に比例して悪化し、基線長 B に反比例して改善します。**
天井高と2台の間隔が、そのまま打ち出し角の精度になります。

■ レーダーが効く理由（ここが本題）

レーダーは速度を **ドップラー効果から直接** 測ります。カメラのように
「位置の差分」から求めるのではないので、誤差の出方がまったく違います。

    カメラの速度誤差 : 画素分解能とフレーム間隔で決まる
    レーダーの速度誤差: 観測時間と S/N で決まる（画素分解能と無関係）

**誤差が独立なので、混ぜると必ず良くなります。** さらに大きいのは次の2点。

  1. レーダー単体の弱点である **コサイン誤差**（球がレーダー正面へ飛ばないと
     速度が低めに出る）を、**カメラが測った方向で補正できる**。
     カメラとレーダーは互いの弱点を埋め合う関係にある。

  2. レーダーは **カメラのスケール較正（mm/px）に依存しない**。
     カメラがぶつけられたり温度で焦点がずれたりしてスケールが狂っても、
     レーダーとの食い違いで **その場で気づける**。
     ImpactVision は初速84m/s(189mph)のような明らかな異常値をそのまま
     出力していた。ハイブリッドならこれを弾ける。

  3. レーダーを2台（天井＋キオスク）にすると、速度ベクトルの投影が2つ得られる。
     カメラの方位角と合わせると **打ち出し角がステレオの奥行きに頼らずに解ける**。
     天井が低い／2台の間隔が取れない現場ほど、これが効く。
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional, Sequence

import numpy as np


# =============================================================================
# 幾何とノイズのモデル
# =============================================================================

@dataclass
class StereoRig:
    """天井のステレオカメラ。"""
    height_m: float = 2.30          # ボールからカメラまでの距離
    baseline_m: float = 0.40        # 2台の間隔
    fov_width_m: float = 0.40       # 視野の幅
    width_px: int = 640
    fps: float = 815.0
    sigma_px_ball: float = 0.20     # ボール重心の位置ノイズ
    sigma_px_club: float = 1.50     # クラブ重心。丸くないので大幅に悪い

    @property
    def f_px(self) -> float:
        return self.width_px * self.height_m / self.fov_width_m

    @property
    def mm_per_px(self) -> float:
        return self.fov_width_m * 1000.0 / self.width_px

    def sigma_depth_m(self, sigma_px: float) -> float:
        """視差から求まる奥行き（＝高さ）の標準偏差。"""
        sigma_disp = sigma_px * math.sqrt(2)      # 2台ぶんの重心誤差
        return self.height_m ** 2 * sigma_disp / (self.f_px * self.baseline_m)

    def sigma_lateral_m(self, sigma_px: float) -> float:
        """画像面内（水平方向）の位置の標準偏差。奥行きよりずっと良い。"""
        return sigma_px * self.mm_per_px / 1000.0

    def n_frames(self, speed_ms: float, span_m: Optional[float] = None) -> int:
        span = self.fov_width_m if span_m is None else span_m
        return max(2, int(span / (speed_ms / self.fps)))


@dataclass
class Radar:
    """ドップラーレーダ1台。axis は感度が最大になる向きの単位ベクトル。

    座標系: x = 飛球線方向（前）, y = 上, z = 右
    """
    name: str
    elev_deg: float                 # 仰角。上向きが正
    azim_deg: float = 0.0
    sigma_v_ms: float = 0.15        # 視線方向速度の標準偏差

    @property
    def axis(self) -> np.ndarray:
        e = math.radians(self.elev_deg)
        a = math.radians(self.azim_deg)
        return np.array([math.cos(e) * math.cos(a),
                         math.sin(e),
                         math.cos(e) * math.sin(a)])


def velocity_vector(speed: float, launch_deg: float, azim_deg: float) -> np.ndarray:
    la, az = math.radians(launch_deg), math.radians(azim_deg)
    return speed * np.array([math.cos(la) * math.cos(az),
                             math.sin(la),
                             math.cos(la) * math.sin(az)])


# =============================================================================
# 推定器
# =============================================================================

@dataclass
class Estimate:
    speed_ms: float
    launch_deg: float
    azim_deg: float
    sigma_speed: float = float("nan")
    sigma_launch: float = float("nan")
    sigma_azim: float = float("nan")
    chi2: float = 0.0
    n_obs: int = 0
    flag: str = ""


def _camera_sigmas(rig: StereoRig, speed: float, launch_deg: float,
                   is_club: bool = False) -> tuple:
    """カメラ単体で得られる 速度・打ち出し角・方位角 の標準偏差。

    画像面内（水平）は精度が良く、奥行き（高さ）は視差に依存して悪い。
    その差がそのまま「水平の角度は得意、垂直の角度は苦手」になる。
    """
    s_px = rig.sigma_px_club if is_club else rig.sigma_px_ball
    n = rig.n_frames(speed, 0.25 if is_club else None)
    dt = 1.0 / rig.fps
    # 直線あてはめの傾きの誤差: sigma * sqrt(12/(N(N^2-1))) / dt
    k = math.sqrt(12.0 / (n * (n * n - 1))) / dt if n >= 2 else float("inf")
    sv_lat = rig.sigma_lateral_m(s_px) * k          # 水平方向の速度誤差
    sv_dep = rig.sigma_depth_m(s_px) * k            # 高さ方向の速度誤差
    v_h = speed * math.cos(math.radians(launch_deg))
    return (sv_lat,                                  # 速度（主に水平成分から）
            sv_dep / max(v_h, 1e-6),                 # 打ち出し角[rad]
            sv_lat / max(v_h, 1e-6),                 # 方位角[rad]
            n)


def fuse(rig: StereoRig, radars: Sequence[Radar],
         true_speed: float, true_launch: float, true_azim: float,
         rng: np.random.Generator, is_club: bool = False) -> Estimate:
    """カメラの観測とレーダーの観測を合わせて 速度・打ち出し角・方位角 を推定する。

    ガウス・ニュートンで重み付き最小二乗を解く。重みは各観測の分散の逆数。
    """
    sv, sla, saz, n = _camera_sigmas(rig, true_speed, true_launch, is_club)

    # --- 観測を作る（真値にノイズを乗せる） ---
    z_cam = np.array([true_speed + rng.normal(0, sv),
                      math.radians(true_launch) + rng.normal(0, sla),
                      math.radians(true_azim) + rng.normal(0, saz)])
    R_cam = np.array([sv, sla, saz])

    v_true = velocity_vector(true_speed, true_launch, true_azim)
    z_rad, R_rad = [], []
    for rd in radars:
        z_rad.append(float(v_true @ rd.axis) + rng.normal(0, rd.sigma_v_ms))
        R_rad.append(rd.sigma_v_ms)
    z_rad = np.array(z_rad); R_rad = np.array(R_rad)

    # --- 初期値はカメラの観測そのもの ---
    x = z_cam.copy()

    def predict(x):
        v = velocity_vector(x[0], math.degrees(x[1]), math.degrees(x[2]))
        return np.concatenate([x, [float(v @ rd.axis) for rd in radars]])

    z = np.concatenate([z_cam, z_rad])
    W = np.diag(1.0 / np.concatenate([R_cam, R_rad]) ** 2)

    for _ in range(8):
        h = predict(x)
        # 数値ヤコビアン
        J = np.zeros((len(z), 3))
        for j in range(3):
            d = np.zeros(3); d[j] = 1e-6 if j == 0 else 1e-8
            J[:, j] = (predict(x + d) - predict(x - d)) / (2 * d[j])
        r = z - h
        try:
            dx = np.linalg.solve(J.T @ W @ J, J.T @ W @ r)
        except np.linalg.LinAlgError:
            break
        x = x + dx
        if np.linalg.norm(dx) < 1e-10:
            break

    cov = np.linalg.inv(J.T @ W @ J)
    r = z - predict(x)
    chi2 = float(r @ W @ r)
    dof = max(1, len(z) - 3)

    flag = ""
    if len(radars) and chi2 / dof > 9.0:
        flag = "カメラとレーダーが食い違っています（較正ずれ／誤検出の疑い）"

    return Estimate(speed_ms=float(x[0]),
                    launch_deg=math.degrees(x[1]),
                    azim_deg=math.degrees(x[2]),
                    sigma_speed=float(math.sqrt(cov[0, 0])),
                    sigma_launch=math.degrees(math.sqrt(cov[1, 1])),
                    sigma_azim=math.degrees(math.sqrt(cov[2, 2])),
                    chi2=chi2 / dof, n_obs=len(z), flag=flag)


# =============================================================================
# 構成の比較（モンテカルロ）
# =============================================================================

CEILING = Radar("天井（打球方向へ 25°下向き）", elev_deg=-25.0, sigma_v_ms=0.15)
KIOSK   = Radar("キオスク下（12°上向き）",      elev_deg=+12.0, sigma_v_ms=0.15)

CONFIGS = [
    ("天井ステレオのみ",              []),
    ("＋ レーダー1台（キオスク）",     [KIOSK]),
    ("＋ レーダー1台（天井）",         [CEILING]),
    ("＋ レーダー2台（天井＋キオスク）", [CEILING, KIOSK]),
]


def compare(rig: StereoRig = None, speed=70.0, launch=11.0, azim=1.5,
            trials=4000, seed=1) -> str:
    rig = rig or StereoRig()
    rng = np.random.default_rng(seed)
    L = ["=" * 78,
         "  構成ごとの計測精度（ドライバー 初速70m/s・打ち出し11°）",
         "=" * 78,
         f"  天井高(ボールまで) {rig.height_m:.2f}m ／ 2台の間隔 {rig.baseline_m:.2f}m"
         f" ／ 視野幅 {rig.fov_width_m*100:.0f}cm ／ {rig.fps:.0f}fps",
         f"  分解能 {rig.mm_per_px:.2f} mm/px ／ ステレオ奥行き誤差 "
         f"±{rig.sigma_depth_m(rig.sigma_px_ball)*1000:.2f} mm",
         "-" * 78,
         f"  {'構成':<28}{'初速':>12}{'打ち出し角':>14}{'方位角':>12}"]
    out = {}
    for name, radars in CONFIGS:
        es, ls, az = [], [], []
        for _ in range(trials):
            e = fuse(rig, radars, speed, launch, azim, rng)
            es.append(e.speed_ms - speed); ls.append(e.launch_deg - launch)
            az.append(e.azim_deg - azim)
        sd = lambda a: float(np.std(a))
        out[name] = (sd(es), sd(ls), sd(az))
        L.append(f"  {name:<28}±{sd(es):>6.3f} m/s ±{sd(ls):>8.3f}° ±{sd(az):>8.3f}°")
    L.append("=" * 78)
    base = out["天井ステレオのみ"]
    best = out["＋ レーダー2台（天井＋キオスク）"]
    L += [f"  レーダー2台で、初速の誤差は {base[0]/best[0]:.1f}倍 改善、"
          f"打ち出し角は {base[1]/best[1]:.1f}倍 改善",
          "=" * 78]
    return "\n".join(L), out


def baseline_study(rig: StereoRig = None) -> str:
    """天井高と2台の間隔が打ち出し角の精度をどう決めるか。"""
    rig = rig or StereoRig()
    rng = np.random.default_rng(7)
    L = ["=" * 78,
         "  天井の条件が打ち出し角の精度に効く度合い（レーダー無し／2台あり）",
         "=" * 78,
         f"  {'天井高':>8}{'間隔':>8}{'奥行き誤差':>14}"
         f"{'打出角(カメラのみ)':>20}{'打出角(＋レーダー2台)':>22}"]
    for h in (2.0, 2.3, 2.8, 3.2):
        for b in (0.25, 0.40, 0.60):
            r = StereoRig(height_m=h, baseline_m=b, fov_width_m=rig.fov_width_m,
                          fps=rig.fps)
            a = [fuse(r, [], 70, 11, 1.5, rng).launch_deg - 11 for _ in range(1200)]
            c = [fuse(r, [CEILING, KIOSK], 70, 11, 1.5, rng).launch_deg - 11
                 for _ in range(1200)]
            L.append(f"  {h:>7.1f}m{b*100:>7.0f}cm"
                     f"{r.sigma_depth_m(r.sigma_px_ball)*1000:>12.2f}mm"
                     f"{np.std(a):>18.2f}°{np.std(c):>20.2f}°")
    L += ["-" * 78,
          "  カメラだけだと 天井高と間隔で精度が大きく振れる。",
          "  レーダーを足すと、現場の条件に左右されにくくなる。",
          "  → 設置環境がまちまちな外販では、ここが効く。",
          "=" * 78]
    return "\n".join(L)


def carry_impact(out: dict) -> str:
    """計測誤差が最終的な飛距離表示のブレになる量。お客様が見るのはこれ。"""
    import ball_flight as bf
    rng = np.random.default_rng(3)
    L = ["=" * 78,
         "  計測誤差 → キャリー表示のブレ（ドライバー・同じスイングを繰り返した場合）",
         "=" * 78,
         f"  {'構成':<28}{'キャリーのばらつき':>22}{'最大級のブレ':>16}"]
    base = bf.simulate(bf.Shot(70.0, 11.0, 1.5, 2600), keep_path=False).carry_yd
    for name, (sv, sl, sa) in out.items():
        cs = []
        for _ in range(3000):
            r = bf.simulate(bf.Shot(70 + rng.normal(0, sv), 11 + rng.normal(0, sl),
                                    1.5 + rng.normal(0, sa), 2600), keep_path=False)
            cs.append(r.carry_yd)
        sd = float(np.std(cs))
        L.append(f"  {name:<28}±{sd:>8.2f} yd{'':>8}{sd*3:>10.1f} yd")
    L += ["-" * 78,
          f"  基準のキャリー {base:.0f}yd。「最大級のブレ」は 3σ（ほぼ最悪値）。",
          "  同じスイングで表示が何ヤード動くか、が再現性の実感になる。",
          "=" * 78]
    return "\n".join(L)




def radar_angle_study() -> str:
    """レーダーの取り付け角度で、得られる情報がまったく変わる。"""
    rig = StereoRig(); rng = np.random.default_rng(11)
    L = ["=" * 78,
         "  レーダーの取り付け角度と、打ち出し角への寄与",
         "=" * 78,
         f"  ボールの飛球方向は 11°。レーダー1台をいろいろな仰角で置いた場合",
         "-" * 78,
         f"  {'レーダー仰角':>14}{'飛球方向との角度差':>22}{'打ち出し角の誤差':>20}{'改善':>10}"]
    base = np.std([fuse(rig, [], 70, 11, 1.5, rng).launch_deg - 11 for _ in range(2500)])
    L.append(f"  {'（レーダー無し）':>14}{'—':>20}{base:>18.3f}°{'—':>10}")
    for el in (11, 0, -10, -25, -40, -60):
        r = Radar(f"{el}", elev_deg=el)
        sd = np.std([fuse(rig, [r], 70, 11, 1.5, rng).launch_deg - 11 for _ in range(2500)])
        L.append(f"  {el:>13.0f}°{abs(11-el):>20.0f}°{sd:>18.3f}°{base/sd:>9.2f}x")
    L += ["-" * 78,
          "  飛球方向と同じ向き（11°）に置くと、ほとんど寄与しない。",
          "  cos が最大の点では、角度が少し変わっても視線速度がほぼ変化しないため。",
          "  **飛球線から大きく外して置くほど、打ち出し角の情報が増える。**",
          "  → キオスク下（やや上向き）は球速の裏取り用。",
          "     打ち出し角を取りにいくなら **天井から見下ろす向き** に置くこと。",
          "=" * 78]
    return "\n".join(L)


def club_study() -> str:
    """クラブ（入射角）は重心がぶれるので、ボールよりずっと難しい。

    レーダーはクラブヘッドも見えるが、シャフトや手・体からの反射が混ざるため
    ボールほど素直ではない。ここでは視線速度の誤差を ボールの4倍 と仮定している。
    """
    rig = StereoRig(); rng = np.random.default_rng(23)
    # クラブに対するレーダーは信頼度を落とす
    cl_ceiling = Radar("天井", elev_deg=-25.0, sigma_v_ms=0.60)
    cl_kiosk   = Radar("キオスク", elev_deg=12.0, sigma_v_ms=0.60)
    L = ["=" * 78,
         "  入射角（クラブ）— ここだけは天井2台では届かない",
         "=" * 78,
         f"  クラブ重心のノイズを ±{rig.sigma_px_club:.1f}px と仮定"
         f"（ボールは ±{rig.sigma_px_ball:.2f}px）。",
         "  丸くない・ブレる・シャフトと繋がって見えるため、ボールのようには決まらない。",
         "  レーダーもクラブに対しては誤差4倍と仮定（手や体の反射が混ざる）。",
         "-" * 78,
         f"  {'構成':<34}{'間隔':>7}{'入射角の誤差':>16}{'判定':>18}"]
    def judge(sd):
        return "実用範囲" if sd <= 0.6 else ("レッスンには厳しい" if sd <= 1.2 else "使えない")
    for label, b, radars in [
            ("天井ステレオのみ", 0.40, []),
            ("天井ステレオのみ", 0.80, []),
            ("天井 ＋ レーダー2台", 0.40, [cl_ceiling, cl_kiosk]),
            ("天井 ＋ レーダー2台", 0.80, [cl_ceiling, cl_kiosk]),
            ("天井（クラブ検出を4倍改善できた場合）", 0.40, [])]:
        r = StereoRig(baseline_m=b)
        if "4倍改善" in label:
            r.sigma_px_club = rig.sigma_px_club / 4
        sd = float(np.std([fuse(r, radars, 40, -3.0, 1.0, rng, is_club=True).launch_deg + 3.0
                           for _ in range(2500)]))
        L.append(f"  {label:<34}{b*100:>5.0f}cm ±{sd:>9.2f}°{judge(sd):>16}")
    L += ["-" * 78,
          "  **入射角を製品仕様に入れるなら、天井2台のままでは届きません。**",
          "  効くのは順に  ①クラブ検出アルゴリズムの改善  ②2台の間隔を広げる",
          "  ③側方カメラを1台足す。レーダーはここにはほとんど効きません。",
          "",
          "  現実的な判断: **初期出荷では入射角を仕様に入れない。**",
          "  ボール計測（初速・打ち出し角・方向）とクラブ軌道（水平）だけで",
          "  レッスンは十分成立します。入射角は v2 の目玉として残すほうが安全です。",
          "=" * 78]
    return "\n".join(L)


def drift_test() -> str:
    """カメラのスケールが狂ったとき、レーダーが気づけるか。"""
    rig = StereoRig(); rng = np.random.default_rng(31)
    L = ["=" * 78,
         "  カメラの較正ずれを検出できるか（レーダーの2番目の価値）",
         "=" * 78,
         "  カメラをぶつけた／温度でピントがずれた等で mm/px が狂った状況を模擬。",
         "  カメラだけでは『それらしい値』が出てしまい、誰も気づけない。",
         "-" * 78,
         f"  {'スケール誤差':>12}{'カメラが出す初速':>20}{'不一致の検定量':>18}{'検出':>12}"]
    for err in (0.0, 0.01, 0.02, 0.05, 0.10):
        chis, spd = [], []
        for _ in range(600):
            e = fuse(rig, [CEILING, KIOSK], 70 * (1 + err), 11, 1.5, rng)
            # レーダーは真値を見ているので、カメラだけがずれた状況を作る
            v = velocity_vector(70.0, 11, 1.5)
            zc = np.array([70 * (1 + err), math.radians(11), math.radians(1.5)])
            sv, sla, saz, _ = _camera_sigmas(rig, 70, 11)
            zr = np.array([float(v @ r.axis) + rng.normal(0, r.sigma_v_ms)
                           for r in (CEILING, KIOSK)])
            W = np.diag(1.0 / np.concatenate([[sv, sla, saz],
                                              [CEILING.sigma_v_ms, KIOSK.sigma_v_ms]]) ** 2)
            x = zc.copy()
            def pred(x):
                vv = velocity_vector(x[0], math.degrees(x[1]), math.degrees(x[2]))
                return np.concatenate([x, [float(vv @ r.axis) for r in (CEILING, KIOSK)]])
            z = np.concatenate([zc, zr])
            for _ in range(6):
                h = pred(x); J = np.zeros((5, 3))
                for j in range(3):
                    d = np.zeros(3); d[j] = 1e-6 if j == 0 else 1e-8
                    J[:, j] = (pred(x + d) - pred(x - d)) / (2 * d[j])
                x = x + np.linalg.solve(J.T @ W @ J, J.T @ W @ (z - pred(x)))
            r_ = z - pred(x); chis.append(float(r_ @ W @ r_) / 2)
            spd.append(70 * (1 + err))
        m = float(np.mean(chis))
        det = "検出" if m > 9 else ("境界" if m > 4 else "見逃す")
        L.append(f"  {err*100:>11.0f}%{np.mean(spd):>17.1f} m/s{m:>17.1f}{det:>12}")
    L += ["-" * 78,
          "  スケールが2%狂うと飛距離表示は約4%（ドライバーで10yd超）ずれる。",
          "  カメラ単体ではこれを検出できない。レーダーとの不一致で自動的に気づける。",
          "  **『おかしい』と言えるシステムかどうかは、製品の信頼性そのもの。**",
          "  ImpactVision は初速84m/s(189mph)を検証なしに出力していた。",
          "=" * 78]
    return "\n".join(L)


if __name__ == "__main__":
    rep, out = compare()
    print(rep); print()
    print(radar_angle_study()); print()
    print(carry_impact(out)); print()
    print(club_study()); print()
    print(drift_test()); print()
    print(baseline_study())
