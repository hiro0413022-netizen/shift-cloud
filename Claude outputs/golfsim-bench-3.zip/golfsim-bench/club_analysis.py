"""
club_analysis.py — クラブ軌道(Club Path)と入射角(Attack Angle)の計測

■ なぜ別モジュールなのか

ボールの計測とクラブの計測は、必要なものがまるで違う。

    ボール : インパクト「後」。丸い。背景から浮く。3〜4フレームあれば足りる
    クラブ : インパクト「前」。細長くブレる。手やシャフトと繋がって見える。
             しかも角度を出すには何フレームも要る

ImpactVision2 の実測ログ 40,615 球を調べたところ、次のことが分かっている。

    ・クラブ軌道(水平)は 補正前後で完全に同一 → 補正されていない実測値
    ・入射角(垂直)は そもそもログに存在しない → 計測していない

つまり「水平は取れていた、垂直は取れていなかった」。この差は偶然ではなく、
下の required_fps() が示すとおり **フレームレートの制約** から来ている。

■ 入射角が難しい理由

水平角(クラブ軌道)は ±10°以上の幅があるので、多少荒くても判別できる。
一方 入射角は ドライバーで -5°〜+5° の範囲に収まり、
1°の違いがそのまま弾道の違いになる。同じ計測精度では足りない。
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Sequence

import numpy as np


# --- 計測結果 ---------------------------------------------------------------

@dataclass
class ClubResult:
    club_path_deg: Optional[float]      # 水平。右が正（イン→アウトが正）
    attack_angle_deg: Optional[float]   # 垂直。アッパーが正
    club_speed_ms: Optional[float]
    n_frames: int
    path_sigma_deg: Optional[float]     # 推定誤差
    aoa_sigma_deg: Optional[float]
    warnings: list

    def ok(self, aoa_tol_deg: float = 1.0) -> bool:
        """入射角を表示してよい精度が出ているか。"""
        return (self.attack_angle_deg is not None
                and self.aoa_sigma_deg is not None
                and self.aoa_sigma_deg <= aoa_tol_deg)


# --- 角度のあてはめ ---------------------------------------------------------

def _fit_angle(t: np.ndarray, u: np.ndarray, v: np.ndarray):
    """(t,u,v) から進行方向に対する角度と、その標準誤差を返す。

    u = 主たる進行方向の座標[mm], v = 直交方向の座標[mm]
    直線 v = a·u + b をあてはめ、角度 = atan(a)。
    """
    n = len(u)
    if n < 3:
        return None, None
    A = np.vstack([u, np.ones(n)]).T
    coef, res, *_ = np.linalg.lstsq(A, v, rcond=None)
    a = float(coef[0])
    resid = v - A @ coef
    dof = n - 2
    if dof <= 0:
        return math.degrees(math.atan(a)), None
    s2 = float(resid @ resid) / dof
    sxx = float(((u - u.mean()) ** 2).sum())
    sa = math.sqrt(s2 / sxx) if sxx > 0 else None
    # d(atan(a))/da = 1/(1+a^2)
    sig = math.degrees(sa / (1 + a * a)) if sa is not None else None
    return math.degrees(math.atan(a)), sig


def analyze_club(centroids_mm: Sequence[tuple], times_s: Sequence[float],
                 aoa_tol_deg: float = 1.0) -> ClubResult:
    """クラブヘッド重心の3次元位置列から、軌道・入射角・ヘッドスピードを出す。

    centroids_mm : [(x, y, z), ...]  x=飛球線方向, y=上, z=右 [mm]
    times_s      : 各フレームの時刻[s]
    """
    warn = []
    P = np.asarray(centroids_mm, dtype=float)
    t = np.asarray(times_s, dtype=float)
    n = len(P)
    if n < 3:
        return ClubResult(None, None, None, n, None, None,
                          [f"クラブの検出フレームが {n} 枚しかない（最低3枚必要）"])

    x, y, z = P[:, 0], P[:, 1], P[:, 2]

    path, path_sig = _fit_angle(t, x, z)      # 水平: x に対する z の傾き
    aoa, aoa_sig = _fit_angle(t, x, y)        # 垂直: x に対する y の傾き

    # ヘッドスピード（最小二乗の速度）
    speed = None
    if n >= 2 and np.ptp(t) > 0:
        d = np.gradient(P, t, axis=0)
        speed = float(np.linalg.norm(d, axis=1).mean()) / 1000.0

    if n < 5:
        warn.append(f"検出 {n} フレーム。入射角の安定には5枚以上ほしい")
    if aoa_sig is not None and aoa_sig > aoa_tol_deg:
        warn.append(f"入射角の推定誤差 ±{aoa_sig:.2f}° が許容 {aoa_tol_deg:.1f}° を超える")
    if np.ptp(x) < 100:
        warn.append(f"クラブの追跡距離が {np.ptp(x):.0f}mm しかない。ROIを広げるべき")

    return ClubResult(path, aoa, speed, n, path_sig, aoa_sig, warn)


# --- カメラ選定のための逆算 -------------------------------------------------

def required_fps(club_speed_ms: float = 40.0,
                 roi_length_mm: float = 250.0,
                 mm_per_px: float = 1.7,
                 centroid_noise_px: float = 0.5,
                 target_sigma_deg: float = 0.5) -> dict:
    """目標精度から必要なフレームレートを逆算する。

    考え方:
      1フレームあたりのクラブ移動量  d = v / fps
      追跡区間 L の中で取れる枚数     N = L / d
      直線あてはめの傾き誤差          σ_a = σ_v / (Δu · sqrt(N/12))
      角度誤差                        σ_θ = σ_a （ラジアン, 小角近似）

    Δu は追跡区間の長さそのもの、σ_v は1点あたりの位置ノイズ。
    """
    sigma_v_mm = centroid_noise_px * mm_per_px
    out = {}
    for fps in (120, 240, 300, 500, 750, 1000, 1500, 2000):
        d_mm = club_speed_ms * 1000.0 / fps
        n = roi_length_mm / d_mm
        if n < 3:
            out[fps] = dict(frames=n, sigma_deg=None, ok=False)
            continue
        span = roi_length_mm
        sigma_a = sigma_v_mm / (span / math.sqrt(12.0) * math.sqrt(n))
        sigma_deg = math.degrees(sigma_a)
        out[fps] = dict(frames=n, sigma_deg=sigma_deg,
                        ok=(sigma_deg <= target_sigma_deg and n >= 5))
    need = next((f for f, r in out.items() if r["ok"]), None)
    return {"table": out, "required_fps": need,
            "assumptions": dict(club_speed_ms=club_speed_ms,
                                roi_length_mm=roi_length_mm,
                                mm_per_px=mm_per_px,
                                centroid_noise_px=centroid_noise_px,
                                target_sigma_deg=target_sigma_deg)}


def report(**kw) -> str:
    r = required_fps(**kw)
    a = r["assumptions"]
    L = ["=" * 68,
         "  入射角(Attack Angle)を測るのに必要なフレームレート",
         "=" * 68,
         f"  前提: ヘッドスピード {a['club_speed_ms']:.0f} m/s"
         f" ／ 追跡区間 {a['roi_length_mm']:.0f} mm"
         f" ／ 分解能 {a['mm_per_px']:.2f} mm/px",
         f"        重心ノイズ ±{a['centroid_noise_px']:.1f} px"
         f" ／ 目標精度 ±{a['target_sigma_deg']:.1f}°",
         "-" * 68,
         f"  {'fps':>6}{'取れる枚数':>12}{'角度誤差':>12}   判定"]
    for fps, v in r["table"].items():
        s = "—" if v["sigma_deg"] is None else f"±{v['sigma_deg']:.2f}°"
        mark = "○" if v["ok"] else ("×  枚数不足" if v["frames"] < 3 else "×")
        L.append(f"  {fps:>6}{v['frames']:>11.1f}枚{s:>12}   {mark}")
    L.append("-" * 68)
    L.append(f"  → 必要フレームレート: {r['required_fps']} fps 以上")
    L.append("=" * 68)
    return "\n".join(L)


if __name__ == "__main__":
    print(report())
    print()
    print("■ 結論")
    print("  効いているのは解像度ではなく **枚数** だった。")
    print("  500fps の時点で角度そのものの誤差は ±0.38° と十分だが、")
    print("  取れるのが3枚しかないため、1枚でも検出を外すと成立しない。")
    print("  余裕を持って5枚以上を確保できる 1000fps 以上が実用ライン。")
    print()
    print("  ImpactVision2 が ~300fps で クラブ軌道(水平)だけ取れて")
    print("  入射角(垂直)を取れなかったのは、これで説明がつく。")
    print("  300fps では 2枚。2点あれば直線は引けるので、")
    print("  ±10°以上ばらつく水平角なら粗くても判別できる。")
    print("  だが ±5°に収まる入射角には、外れ値を捨てる余地が無い。")
    print()

    # 動作確認: 入射角 -3.0°, クラブ軌道 +2.0° の合成データ
    import numpy as _np
    aoa_true, path_true, v = -3.0, 2.0, 40.0
    fps = 1000
    _np.random.seed(3)
    pts, ts = [], []
    for i in range(7):
        t = i / fps
        x = v * 1000 * t
        pts.append((x,
                    x * math.tan(math.radians(aoa_true)) + _np.random.normal(0, 0.85),
                    x * math.tan(math.radians(path_true)) + _np.random.normal(0, 0.85)))
        ts.append(t)
    r = analyze_club(pts, ts)
    print("■ 合成データでの動作確認（真値: 入射角 -3.0° / 軌道 +2.0°）")
    print(f"  クラブ軌道 {r.club_path_deg:+.2f}° (±{r.path_sigma_deg:.2f}°)")
    print(f"  入射角     {r.attack_angle_deg:+.2f}° (±{r.aoa_sigma_deg:.2f}°)")
    print(f"  ヘッドスピード {r.club_speed_ms:.1f} m/s ／ 検出 {r.n_frames} 枚")
    print(f"  表示可否(±1.0°基準): {'OK' if r.ok() else 'NG'}")
    for w in r.warnings:
        print("  警告:", w)
