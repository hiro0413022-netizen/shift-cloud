"""calib/lens.py — レンズの歪み補正

■ なぜ必要か

126°の広角レンズは、まっすぐな線が樽型に曲がって写る。
「歪みなし」と書かれていても、それは「少ない」であって「ゼロ」ではない。

これが姿勢推定に直接効く。**水平な肩が、画面の端では傾いて写る。**
補正しないと「肩が傾いています」という誤った指導をしてしまう。

■ やること

チェッカーボード（市松模様）を何枚か撮ると、そのレンズ固有の歪みが求まる。
以後は姿勢推定の前に補正をかけるので、**カメラごとに一度やれば済む。**

    1. A4にチェッカーボードを印刷して、板に貼る（たわむと精度が落ちる）
    2. 画面の中央・四隅・斜めに傾けた状態で 15〜25枚撮る
    3. 「計算する」を押す → 補正パラメータが保存される

■ 撮り方のコツ

  ・**四隅を必ず撮る。** 歪みは端で大きいので、中央だけだと求まらない
  ・板を傾けた画も入れる。正面からだけだと焦点距離と歪みが分離できない
  ・ボードが画面の1/3以上を占めるように近づく
  ・ピントを合わせる（ボケた角は検出精度が落ちる）
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

import cv2
import numpy as np

CALIB_DIR = Path(__file__).resolve().parent.parent.parent / "config" / "lens"


@dataclass
class LensModel:
    """1台ぶんの内部パラメータと歪み係数。"""
    key: str
    width: int
    height: int
    camera_matrix: np.ndarray            # 3x3
    dist_coeffs: np.ndarray              # (5,) or (8,)
    rms: float = 0.0                     # 再投影誤差[px]。0.5以下なら良好
    n_images: int = 0
    board: Tuple[int, int] = (9, 6)

    # --- 保存と読み込み ---
    def to_dict(self) -> dict:
        return dict(key=self.key, width=self.width, height=self.height,
                    camera_matrix=self.camera_matrix.tolist(),
                    dist_coeffs=self.dist_coeffs.ravel().tolist(),
                    rms=self.rms, n_images=self.n_images, board=list(self.board))

    @staticmethod
    def from_dict(d: dict) -> "LensModel":
        return LensModel(key=d["key"], width=d["width"], height=d["height"],
                         camera_matrix=np.array(d["camera_matrix"], np.float64),
                         dist_coeffs=np.array(d["dist_coeffs"], np.float64),
                         rms=float(d.get("rms", 0)), n_images=int(d.get("n_images", 0)),
                         board=tuple(d.get("board", (9, 6))))

    def save(self, path: Optional[Path] = None) -> Path:
        p = Path(path or (CALIB_DIR / f"{self.key}.json"))
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        return p

    @staticmethod
    def load(key: str) -> Optional["LensModel"]:
        p = CALIB_DIR / f"{key}.json"
        if not p.exists():
            return None
        try:
            return LensModel.from_dict(json.loads(p.read_text(encoding="utf-8")))
        except Exception:                             # noqa: BLE001
            return None

    # --- 実効画角（補正後）---
    @property
    def hfov_deg(self) -> float:
        fx = float(self.camera_matrix[0, 0])
        return 2 * np.degrees(np.arctan(self.width / 2 / fx))

    @property
    def vfov_deg(self) -> float:
        fy = float(self.camera_matrix[1, 1])
        return 2 * np.degrees(np.arctan(self.height / 2 / fy))


class Undistorter:
    """補正マップを一度だけ作って、毎フレーム使い回す。

    remap は毎回作り直すと重いので、マップを保持する。
    """

    def __init__(self, model: LensModel, alpha: float = 0.0):
        # alpha=0: 黒縁が出ないよう内側にトリミング（計測向き）
        # alpha=1: 元の画素を全部残す（周囲に黒が出る）
        self.model = model
        w, h = model.width, model.height
        newK, self.roi = cv2.getOptimalNewCameraMatrix(
            model.camera_matrix, model.dist_coeffs, (w, h), alpha, (w, h))
        self.newK = newK
        self.map1, self.map2 = cv2.initUndistortRectifyMap(
            model.camera_matrix, model.dist_coeffs, None, newK, (w, h), cv2.CV_16SC2)

    def __call__(self, img: np.ndarray) -> np.ndarray:
        if img.shape[1] != self.model.width or img.shape[0] != self.model.height:
            return img                                # 解像度が変わったら素通し
        return cv2.remap(img, self.map1, self.map2, cv2.INTER_LINEAR)


# =============================================================================
# 較正セッション
# =============================================================================

@dataclass
class CalibSession:
    """1台ぶんの較正作業。UIから1枚ずつ足していく。"""
    key: str
    board: Tuple[int, int] = (9, 6)      # 内側の交点の数（マス目の数−1）
    square_mm: float = 25.0
    size: Optional[Tuple[int, int]] = None
    img_points: List[np.ndarray] = field(default_factory=list)
    coverage: List[Tuple[float, float]] = field(default_factory=list)

    @property
    def n(self) -> int:
        return len(self.img_points)

    def _obj(self) -> np.ndarray:
        c, r = self.board
        p = np.zeros((c * r, 3), np.float32)
        p[:, :2] = np.mgrid[0:c, 0:r].T.reshape(-1, 2)
        return p * self.square_mm

    def add(self, img: np.ndarray) -> dict:
        """1枚足す。見つからなければ理由を返す。"""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
        h, w = gray.shape[:2]
        if self.size is None:
            self.size = (w, h)
        elif self.size != (w, h):
            return {"ok": False, "message": "解像度が途中で変わりました。やり直してください"}

        flags = cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE
        found, corners = cv2.findChessboardCorners(gray, self.board, flags)
        if not found:
            return {"ok": False, "n": self.n,
                    "message": "チェッカーボードが見つかりません。"
                               "全体が写るように・ピントを合わせて・明るくしてください"}
        corners = cv2.cornerSubPix(
            gray, corners, (11, 11), (-1, -1),
            (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001))
        self.img_points.append(corners)
        c = corners.reshape(-1, 2).mean(0)
        self.coverage.append((float(c[0] / w), float(c[1] / h)))
        return {"ok": True, "n": self.n, "center": self.coverage[-1],
                "message": f"{self.n}枚目を取り込みました"}

    def coverage_report(self) -> dict:
        """画面のどこを撮れているか。**端が埋まっていないと歪みが求まらない。**"""
        cells = {f"{r}{c}": 0 for r in "上中下" for c in "左中右"}
        for x, y in self.coverage:
            r = "上" if y < 1 / 3 else ("中" if y < 2 / 3 else "下")
            c = "左" if x < 1 / 3 else ("中" if x < 2 / 3 else "右")
            cells[f"{r}{c}"] += 1
        empty = [k for k, v in cells.items() if v == 0]
        corners = ["上左", "上右", "下左", "下右"]
        missing_corners = [k for k in corners if cells[k] == 0]
        return {"cells": cells, "empty": empty, "missing_corners": missing_corners,
                "ready": self.n >= 12 and not missing_corners}

    def compute(self) -> Tuple[Optional[LensModel], str]:
        if self.n < 8:
            return None, f"枚数が足りません（{self.n}枚。最低8枚、推奨15〜25枚）"
        rep = self.coverage_report()
        warn = ""
        if rep["missing_corners"]:
            warn = ("（注意: " + "・".join(rep["missing_corners"])
                    + " の隅を撮れていません。端の歪みが正しく求まらない可能性があります）")
        objp = [self._obj()] * self.n
        w, h = self.size
        rms, K, D, _, _ = cv2.calibrateCamera(objp, self.img_points, (w, h), None, None)
        m = LensModel(key=self.key, width=w, height=h, camera_matrix=K,
                      dist_coeffs=D, rms=float(rms), n_images=self.n, board=self.board)
        judge = ("良好" if rms < 0.5 else "許容" if rms < 1.0 else "要り直し")
        return m, (f"再投影誤差 {rms:.3f}px（{judge}）／"
                   f"補正後の水平画角 {m.hfov_deg:.1f}° {warn}")


def make_board_png(path: str, cols: int = 10, rows: int = 7,
                   square_px: int = 120, margin: int = 60) -> str:
    """印刷用のチェッカーボードを作る。内側交点は (cols-1, rows-1)。"""
    w, h = cols * square_px + margin * 2, rows * square_px + margin * 2
    img = np.full((h, w), 255, np.uint8)
    for r in range(rows):
        for c in range(cols):
            if (r + c) % 2 == 0:
                y0, x0 = margin + r * square_px, margin + c * square_px
                img[y0:y0 + square_px, x0:x0 + square_px] = 0
    cv2.putText(img, f"{cols}x{rows} squares / inner corners {cols-1}x{rows-1}",
                (margin, h - margin // 3), cv2.FONT_HERSHEY_SIMPLEX, 0.8, 0, 2)
    cv2.imwrite(path, img)
    return path
