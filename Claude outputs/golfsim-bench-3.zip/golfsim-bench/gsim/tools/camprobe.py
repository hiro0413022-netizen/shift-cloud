"""tools/camprobe.py — カメラを触る作業を『別プロセス』で行う

なぜ別プロセスなのか。

OpenCV の DirectShow / Media Foundation は、こちらの管理外にある
ネイティブのコードである。カメラを何十回も開き直すと、環境によっては
プロセスごと落ちる。同じプロセスの中で走らせていると、そのとき
**サーバーまで道連れになる**。画面には「Failed to fetch」としか出ず、
何が起きたのか分からなくなる（実際そうなった）。

別プロセスに出しておけば、落ちるのは子だけである。親は終了コードを見て
「探索中に落ちました」と報告できる。原因が分からなくても、
分からないなりに前へ進める状態を保てる。これが本題である。

使い方:
    python -m gsim.tools.camprobe discover --max-index 8
    python -m gsim.tools.camprobe modes --index 1
    python -m gsim.tools.camprobe bandwidth --entries <json>
    python -m gsim.tools.camprobe search   --entries <json>

結果は **標準出力に JSON 1個**。進み具合は **標準エラーに1行1件の JSON**
（{"progress": "..."}）で流す。親はそれを読んで画面に出す。
"""

from __future__ import annotations

import argparse
import base64
import json
import sys

import cv2

from ..capture.uvc import (bandwidth_test, boost_for_view, find_working_mode,
                           probe_indices, probe_modes)


def say(msg: str) -> None:
    sys.stderr.write(json.dumps({"progress": msg}, ensure_ascii=False) + "\n")
    sys.stderr.flush()


def _jpg(img, quality: int = 70):
    ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    return buf.tobytes() if ok else b""


def do_discover(max_index: int) -> dict:
    def step(i, n, api):
        say(f"番号 {i} を調べています（{i + 1}/{n}・{api}）")

    found = probe_indices(max_index=max_index, on_step=step)
    out = []
    for f in found:
        img = f.get("thumb")
        thumb = None
        if img is not None:
            view = boost_for_view(img)
            th = cv2.resize(view, (320, int(320 * view.shape[0] / view.shape[1])))
            thumb = "data:image/jpeg;base64," + base64.b64encode(_jpg(th)).decode()
        out.append(dict(index=f["index"], backend=f["backend"],
                        width=f["width"], height=f["height"],
                        fps=round(f["fps"], 1) if f["fps"] and f["fps"] > 0 else None,
                        brightness=f.get("brightness", 0.0),
                        frames=f.get("frames", 0), note=f.get("note", ""),
                        thumb=thumb))
    dark = [d["index"] for d in out if d["brightness"] < 8]
    if not out:
        note = ("1台も見つかりません。ケーブルと、他のアプリ（Zoom・カメラアプリなど）が"
                "掴んでいないかを確認してください")
    elif dark:
        note = (f"番号 {', '.join(map(str, dark))} がほぼ真っ暗です。"
                "部屋を明るくするか、レンズキャップを外して、もう一度探してください")
    else:
        note = "映っている絵を見て、どれがどの位置のカメラか決めてください"
    return {"devices": out, "note": note}


def do_modes(index: int) -> dict:
    def step(w, h, f, i, n, api="", asked=""):
        say(f"{i}/{n} 番号{index} を {api} / {asked} で {w}x{h}@{int(f)} …")

    return {"index": index, "modes": probe_modes(index, on_step=step)}


def do_one(index: int, w: int, h: int, f: float, backend: str, fourcc: str,
           warmup_sec: float = 0.8, measure_sec: float = 1.2) -> dict:
    """解像度×fps×経路×形式 の **1組だけ** を試す。

    MSMF は開けないときに失敗せず固まることがある。1組ごとに別プロセスに
    しておけば、固まっても親が時間切れで切り捨てて次に進める。
    """
    from ..capture.uvc import _backends, _fourcc_of, RAW_FOURCC
    api = dict(_backends()).get(backend)
    if api is None:
        return dict(ok=False, why=f"経路 {backend} がありません")
    cap = cv2.VideoCapture(index, api)
    if not cap.isOpened():
        cap.release()
        return dict(ok=False, why="開けません")
    try:
        code = cv2.VideoWriter_fourcc(*fourcc) if fourcc else None
        if code is not None:
            cap.set(cv2.CAP_PROP_FOURCC, code)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, w)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, h)
        if code is not None:
            cap.set(cv2.CAP_PROP_FOURCC, code)
        cap.set(cv2.CAP_PROP_FPS, f)
        try:
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:                            # noqa: BLE001
            pass
        import time as _t
        img, t0 = None, _t.perf_counter()
        while _t.perf_counter() - t0 < warmup_sec:
            ok, fr = cap.read()
            if ok and fr is not None:
                img = fr
        if img is None:
            return dict(ok=False, why="絵が出ません")
        gh, gw = img.shape[:2]
        if (gw, gh) != (w, h):
            return dict(ok=False, why=f"{gw}x{gh} しか出ません")
        n, t0 = 0, _t.perf_counter()
        while _t.perf_counter() - t0 < measure_sec:
            ok, fr = cap.read()
            if ok and fr is not None:
                n += 1
        real = n / (_t.perf_counter() - t0)
        fc = _fourcc_of(cap)
        raw_mbps = gw * gh * 2 * real / 1e6
        if fc.upper().startswith("MJP"):
            kind = "MJPG"
        elif fc.upper() in RAW_FOURCC:
            kind = "RAW"
        elif raw_mbps > 380:
            kind = "MJPG?"
        else:
            kind = "?"
        return dict(ok=True, width=gw, height=gh, requested_fps=f, backend=backend,
                    asked=fourcc or "指定なし", fourcc=fc or "(読めず)", kind=kind,
                    mjpg=kind.startswith("MJPG"), measured_fps=round(real, 1),
                    mbps=round(raw_mbps if kind == "RAW" else raw_mbps * 0.15, 0))
    finally:
        cap.release()


def do_discover_one(index: int, backend: str = "") -> dict:
    """番号1つだけを開いて静止画を取る（固まっても親が切り捨てられる）。"""
    found = probe_indices(max_index=index + 1, on_step=None, only=index,
                          backend=backend)
    if not found:
        return dict(found=False, index=index)
    f = found[0]
    img = f.get("thumb")
    thumb = None
    if img is not None:
        view = boost_for_view(img)
        th = cv2.resize(view, (320, int(320 * view.shape[0] / view.shape[1])))
        thumb = "data:image/jpeg;base64," + base64.b64encode(_jpg(th)).decode()
    return dict(found=True, index=f["index"], backend=f["backend"],
                width=f["width"], height=f["height"],
                fps=round(f["fps"], 1) if f["fps"] and f["fps"] > 0 else None,
                brightness=f.get("brightness", 0.0), frames=f.get("frames", 0),
                note=f.get("note", ""), thumb=thumb)


def do_bandwidth(entries: list) -> dict:
    say("1台ずつ測っています…")
    return bandwidth_test(entries)


def do_search(entries: list) -> dict:
    def step(w, h, f, i, n):
        say(f"{i}/{n} {w}x{h}@{int(f)} を全台同時で試しています…")

    return find_working_mode(entries, on_step=step)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["discover", "discover1", "modes", "mode1",
                                    "bandwidth", "search"])
    ap.add_argument("--index", type=int, default=0)
    ap.add_argument("--max-index", type=int, default=8)
    ap.add_argument("--entries", default="[]")
    ap.add_argument("--width", type=int, default=1280)
    ap.add_argument("--height", type=int, default=720)
    ap.add_argument("--fps", type=float, default=60)
    ap.add_argument("--backend", default="MSMF")
    ap.add_argument("--fourcc", default="MJPG")
    a = ap.parse_args(argv)

    if a.cmd == "discover":
        res = do_discover(a.max_index)
    elif a.cmd == "discover1":
        res = do_discover_one(a.index, a.backend if a.backend != "MSMF" else "")
    elif a.cmd == "mode1":
        res = do_one(a.index, a.width, a.height, a.fps, a.backend, a.fourcc)
    elif a.cmd == "modes":
        res = do_modes(a.index)
    elif a.cmd == "bandwidth":
        res = do_bandwidth(json.loads(a.entries))
    else:
        res = do_search(json.loads(a.entries))

    sys.stdout.write(json.dumps(res, ensure_ascii=False))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
