"""tools/check.py — ブラウザもサーバーも使わない、カメラの健康診断

ダブルクリック（check.bat）で走り、結果を『診断結果.txt』に書いてメモ帳で開く。

なぜこれが要るか。
ブラウザ経由の探索は、接続本数の上限・サーバーの停止・ドライバの固まりなど、
カメラ以外の理由で止まることがあり、そのたびに「カメラが悪いのか、
ソフトが悪いのか」が分からなくなった。ここではカメラの調査だけを、
1手順ずつ**別プロセス**で走らせる。どこかが落ちても、その手順が
「落ちた」と記録されて次へ進む。最後まで必ず結果が残る。
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "診断結果.txt"

LINES: list = []


def w(s: str = "") -> None:
    LINES.append(s)
    print(s)


def run(args: list, timeout: float):
    """camprobe を別プロセスで走らせる。落ちても結果を返す。"""
    cmd = [sys.executable, "-m", "gsim.tools.camprobe"] + args
    prev = os.environ.get("PYTHONPATH", "")
    env = dict(os.environ, PYTHONIOENCODING="utf-8",
               PYTHONPATH=(str(ROOT) + os.pathsep + prev) if prev else str(ROOT))
    t0 = time.perf_counter()
    try:
        p = subprocess.run(cmd, cwd=str(ROOT), env=env, capture_output=True,
                           text=True, encoding="utf-8", timeout=timeout)
    except subprocess.TimeoutExpired:
        return None, f"{int(timeout)}秒たっても終わりませんでした（ドライバが固まっています）"
    dt = time.perf_counter() - t0
    if p.returncode != 0 or not p.stdout.strip():
        last = ""
        for line in (p.stderr or "").splitlines()[::-1]:
            try:
                last = json.loads(line).get("progress", "")
                if last:
                    break
            except Exception:                        # noqa: BLE001
                continue
        return None, (f"異常終了しました（終了コード {p.returncode}、{dt:.0f}秒）"
                      + (f" 落ちた場所: {last}" if last else ""))
    try:
        return json.loads(p.stdout), ""
    except Exception as e:                            # noqa: BLE001
        return None, f"結果が読めません: {e}"


def main() -> int:
    w("=" * 60)
    w("  スイング計測ベンチ  カメラ診断")
    w("  " + time.strftime("%Y-%m-%d %H:%M:%S"))
    w("=" * 60)
    w()
    w("※ 先に Windows の「カメラ」アプリや Zoom などを閉じてください。")
    w("   開いたままだと、そのカメラは「使用中」で見つかりません。")
    w()

    # ---- 1. 見つかるか（番号ごとに別プロセス。固まっても20秒で次へ）
    w("■ 1. つながっているカメラ")
    w("   （番号 0 はノートPC内蔵カメラのことが多い）")
    devices = []
    for i in range(8):
        print(f"   番号 {i} を確認中…", end="\r")
        res, err = run(["discover1", "--index", str(i)], timeout=25)
        if res is None:
            # MSMF で固まったなら DSHOW で見る（存在の確認だけならこれで足りる）
            res2, err2 = run(["discover1", "--index", str(i), "--backend", "DSHOW"], timeout=25)
            if res2 is None:
                w(f"   番号 {i}  × {err}")
                continue
            if res2.get("found"):
                res2["note"] = (res2.get("note", "") + " MSMFでは固まりました").strip()
            res = res2
        if not res.get("found"):
            continue
        d = res
        devices.append(d)
        b = d.get("brightness", 0)
        mark = "真っ暗" if b < 8 else ("暗い" if b < 25 else "OK")
        w(f"   番号 {d['index']}  {d['width']}x{d['height']}  "
          f"明るさ {b:.0f}（{mark}）  経路 {d['backend']}"
          + (f"  ※{d['note']}" if d.get("note") else ""))
    if not devices:
        w("   × 1台も見つかりません")
    w()

    idx = [d["index"] for d in devices]

    # ---- 2. 各カメラで MJPEG が使えるか（1組ごとに別プロセス、25秒で打ち切り）
    w("■ 2. 各カメラの圧縮形式と実測fps")
    w("   （MJPG なら圧縮あり＝軽い。YUY2 は無圧縮＝1台でUSBを埋める）")
    w("   （固まった組は「時間切れ」と出て次へ進みます）")
    cands = [(1920, 1200, 120), (1280, 720, 120), (1280, 720, 60)]
    plan = [("MSMF", "MJPG"), ("DSHOW", "MJPG")]
    mjpg_ok = {}
    cap1920 = {}
    for i in idx:
        w(f"   ── 番号 {i}")
        modes = []
        for backend, fc in plan:
            for (cw, ch, cf) in cands:
                print(f"      番号{i} {backend}/{fc or '指定なし'} {cw}x{ch}@{cf} …      ", end="\r")
                res, err = run(["mode1", "--index", str(i), "--width", str(cw),
                                "--height", str(ch), "--fps", str(cf),
                                "--backend", backend, "--fourcc", fc], timeout=25)
                if res is None:
                    tag = "時間切れ（固まりました）" if "終わりません" in err else f"落ちました"
                    w(f"      {cw}x{ch}@{cf:<4} {backend:<6} 要求 {fc or '指定なし':<6} → {tag}")
                    continue
                if not res.get("ok"):
                    w(f"      {cw}x{ch}@{cf:<4} {backend:<6} 要求 {fc or '指定なし':<6} → × {res.get('why','')}")
                    continue
                m = res
                modes.append(m)
                k = m.get("kind", "?")
                flag = {"MJPG": "MJPG（圧縮）", "MJPG?": "圧縮（速度から判断）",
                        "RAW": f"{m.get('fourcc','?')}（無圧縮）"}.get(k, "形式読めず")
                w(f"      {cw}x{ch}@{cf:<4} {backend:<6} 要求 {fc or '指定なし':<6} → {flag:<16} "
                  f"実測 {m['measured_fps']:>6.1f}fps")
        best = max([m["measured_fps"] for m in modes if m["width"] >= 1920] or [0])
        good = sorted({m["backend"] for m in modes if m.get("mjpg")})
        mjpg_ok[i] = good
        cap1920[i] = best
        w("      → 圧縮あり: " + (f"{' / '.join(good)}" if good else "確認できず"))
    w()

    # ---- 3. 本命の設定で、ELP だけを同時に開く
    # 1920x1200 が出る番号 = ELP。出ない番号（内蔵カメラ）は混ぜない。
    elp = [i for i in idx if cap1920.get(i, 0) >= 30]
    if not elp:
        elp = [i for i in idx if i != 0][:3] or idx[:3]
    elp = elp[:3]
    w(f"■ 3. スイングカメラ {len(elp)}台（番号 {elp}）を同時に開く")
    w("   （重い設定から順に。全台が要求の75%以上出た最初の設定が答え）")
    if len(elp) < 2:
        w("   2台以上見つからないので省略")
        found = None
    else:
        ents = [dict(index=i, width=1920, height=1200, fps=120, fourcc="MJPG",
                     label=f"番号{i}") for i in elp]
        res, err = run(["search", "--entries", json.dumps(ents, ensure_ascii=False)],
                       timeout=400)
        found = None
        if res is None:
            w(f"   × 測れませんでした: {err}")
        else:
            for t in res.get("tried", []):
                if t["ok"]:
                    w(f"   {t['width']}x{t['height']}@{t['fps']:<4} ○ "
                      + " / ".join(f"{k} {v}fps" for k, v in t["got"].items()))
                else:
                    w(f"   {t['width']}x{t['height']}@{t['fps']:<4} × "
                      + (" / ".join(f"{k} {v}fps" for k, v in t["got"].items())
                         if t.get("got") else t.get("detail", "")))
            found = res.get("found")
            w(f"   → {res.get('verdict','')}")
    w()

    # ---- 4. 結論
    w("■ 4. 結論")
    if not idx:
        w("   カメラが見つかりません。カメラアプリを閉じてから、もう一度 check.bat を実行してください。")
    else:
        unknown = [i for i in idx if i not in mjpg_ok]
        if unknown and len(unknown) == len(idx):
            w("   カメラは見つかりますが、詳しく調べる段階で全部落ちました。")
            w("   ドライバ側の問題です。カメラを全部抜いて再起動し、もう一度 check.bat を実行してください。")
        else:
            w(f"   スイングカメラ（ELP）は番号 {elp}。それ以外は内蔵カメラです。")
            for i in elp:
                g = mjpg_ok.get(i, [])
                w(f"   番号 {i}: 圧縮で使える経路 = {' / '.join(g) if g else 'なし'}"
                  f"（1920x1200 で最大 {cap1920.get(i,0):.0f}fps）")
            if found:
                w(f"   → 設定は {found['width']}x{found['height']}@{int(found['fps'])} で{len(elp)}台同時OK。"
                  "start.bat の設定パネルで番号を割り当て、この設定にしてください。")
            else:
                w("   → 同時に開く試験が通りませんでした。上の ■3 を送ってください。")
        if unknown and len(unknown) != len(idx):
            w(f"   番号 {unknown} は調べる途中で落ちました（■2 参照）。")
    w("   このファイルをそのまま送ってください。")
    w()

    OUT.write_text("\n".join(LINES), encoding="utf-8")
    return 0


if __name__ == "__main__":
    try:
        code = main()
    except Exception as e:                            # noqa: BLE001
        w(f"診断プログラム自体が失敗しました: {type(e).__name__}: {e}")
        OUT.write_text("\n".join(LINES), encoding="utf-8")
        code = 1
    try:
        if os.name == "nt":
            os.startfile(str(OUT))                    # メモ帳で開く
    except Exception:                                 # noqa: BLE001
        pass
    raise SystemExit(code)
