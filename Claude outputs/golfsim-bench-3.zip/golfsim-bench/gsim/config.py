"""config.py — 設定の読み書き

設定はYAML1枚。**現場で開いて直せること**を優先する。
UIから変更したものもここに書き戻すので、次回起動時にそのまま復元される。
"""

from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any, Dict

import yaml

DEFAULT_PATH = Path(os.environ.get(
    "GSIM_CONFIG", Path(__file__).resolve().parent.parent / "config" / "swing.yaml"))

DEFAULT: Dict[str, Any] = {
    "site": {"name": "開発ベンチ", "bay": "1"},
    "pose": {"enabled": True, "target_fps": 25, "model_complexity": 1},
    "recording": {"seconds": 8, "dir": "recordings"},
    "server": {"host": "127.0.0.1", "port": 8770},
    "cameras": [
        {"key": "front", "label": "正面", "role": "front", "kind": "synthetic",
         "index": 0, "width": 1280, "height": 720, "fps": 120, "fourcc": "MJPG",
         "enabled": True, "note": "打席の正面。肩の傾き・頭の動き・腰の横移動"},
        {"key": "side", "label": "側面", "role": "side", "kind": "synthetic",
         "index": 1, "width": 1280, "height": 720, "fps": 120, "fourcc": "MJPG",
         "enabled": True, "note": "飛球線と直交。前傾角・起き上がり"},
        {"key": "diag", "label": "右斜め", "role": "diag", "kind": "synthetic",
         "index": 2, "width": 1280, "height": 720, "fps": 120, "fourcc": "MJPG",
         "enabled": True, "note": "45°。肩と腰の回転差（Xファクター）"},
    ],
}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load(path: Path | None = None) -> dict:
    p = Path(path or DEFAULT_PATH)
    if not p.exists():
        save(DEFAULT, p)
        return copy.deepcopy(DEFAULT)
    with p.open(encoding="utf-8") as f:
        return _merge(DEFAULT, yaml.safe_load(f) or {})


def save(cfg: dict, path: Path | None = None) -> None:
    p = Path(path or DEFAULT_PATH)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, allow_unicode=True, sort_keys=False)
