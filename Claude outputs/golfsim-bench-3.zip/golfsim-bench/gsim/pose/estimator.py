"""pose/estimator.py — 姿勢推定（MediaPipe Pose）

計測カメラとは役割が違う。ここは **体の動き** を取る。
33点のランドマークから、肩・腰・頭・手の位置を追いかける。

■ 設計方針

  ・フレーム全部に掛けない。CPU が持たない。**指定した頻度だけ推論する。**
    120fps で撮っても姿勢推定は 20〜30fps で十分（人体はそこまで速くない）。
  ・**推論は取り込みスレッドと分ける。** 推論が遅れても映像は止まらないこと。
  ・結果には必ず「いつのフレームか」を持たせる。3方向を突き合わせるのに要る。
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

# MediaPipe には2系統ある。どちらでも動くようにしておく。
#   旧 (mp.solutions.pose)      : pip install mediapipe の多くのビルドに入っている
#   新 (tasks.vision.PoseLandmarker) : .task モデルファイルが別途要る
_MP_LEGACY = _MP_TASKS = False
try:
    import mediapipe as mp
    _MP_LEGACY = hasattr(mp, "solutions") and hasattr(mp.solutions, "pose")
    try:
        from mediapipe.tasks import python as mp_python
        from mediapipe.tasks.python import vision as mp_vision
        _MP_TASKS = True
    except Exception:                                 # noqa: BLE001
        _MP_TASKS = False
except Exception:                                     # noqa: BLE001
    mp = None
_MP_OK = _MP_LEGACY or _MP_TASKS

MODEL_URL = ("https://storage.googleapis.com/mediapipe-models/pose_landmarker/"
             "pose_landmarker_lite/float16/latest/pose_landmarker_lite.task")
MODEL_DIR = Path(__file__).resolve().parent.parent.parent / "models"
MODEL_FILE = MODEL_DIR / "pose_landmarker_lite.task"


def ensure_model(verbose: bool = True) -> Optional[Path]:
    """新APIで要る .task モデルを用意する。無ければ落としてくる。"""
    if MODEL_FILE.exists() and MODEL_FILE.stat().st_size > 1_000_000:
        return MODEL_FILE
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    try:
        import urllib.request
        if verbose:
            print(f"[pose] 姿勢推定モデルを取得します: {MODEL_FILE.name}")
        urllib.request.urlretrieve(MODEL_URL, MODEL_FILE)
        return MODEL_FILE
    except Exception as e:                            # noqa: BLE001
        if verbose:
            print(f"[pose] モデルを取得できません ({e})。"
                  f"\n       手動で {MODEL_URL}\n       を {MODEL_FILE} に置いてください。")
        return None

# MediaPipe Pose の主要ランドマーク番号
L = dict(nose=0,
         l_shoulder=11, r_shoulder=12, l_elbow=13, r_elbow=14,
         l_wrist=15, r_wrist=16, l_hip=23, r_hip=24,
         l_knee=25, r_knee=26, l_ankle=27, r_ankle=28,
         l_heel=29, r_heel=30, l_foot=31, r_foot=32)


@dataclass
class PoseResult:
    key: str
    t_mono: float
    frame_index: int
    landmarks: Optional[np.ndarray] = None      # (33, 4) x,y,z,visibility（正規化）
    ok: bool = False
    infer_ms: float = 0.0

    def pt(self, name: str) -> Optional[np.ndarray]:
        if self.landmarks is None or name not in L:
            return None
        p = self.landmarks[L[name]]
        return p[:2] if p[3] > 0.35 else None


class PoseEstimator:
    """1台ぶんの姿勢推定を、専用スレッドで回す。"""

    def __init__(self, key: str, target_fps: float = 25.0,
                 model_complexity: int = 1, smooth: bool = True):
        self.key = key
        self.target_fps = target_fps
        self._pose = None
        self._cfg = dict(model_complexity=model_complexity,
                         smooth_landmarks=smooth,
                         min_detection_confidence=0.5,
                         min_tracking_confidence=0.5)
        self._latest: Optional[PoseResult] = None
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._src = None
        self.available = _MP_OK
        self.backend = ""
        self.error = ""

    def bind(self, source) -> None:
        self._src = source

    def start(self) -> None:
        if not _MP_OK or self._src is None:
            return
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name=f"pose:{self.key}")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2.0)
        self._thread = None

    def _make(self):
        """使えるほうの API で推論器を作る。"""
        if _MP_LEGACY:
            self.backend = "legacy"
            return mp.solutions.pose.Pose(**self._cfg)
        path = ensure_model()
        if path is None:
            raise RuntimeError("姿勢推定モデルがありません")
        self.backend = "tasks"
        opts = mp_vision.PoseLandmarkerOptions(
            base_options=mp_python.BaseOptions(model_asset_path=str(path)),
            running_mode=mp_vision.RunningMode.VIDEO,
            num_poses=1,
            min_pose_detection_confidence=self._cfg["min_detection_confidence"],
            min_tracking_confidence=self._cfg["min_tracking_confidence"])
        return mp_vision.PoseLandmarker.create_from_options(opts)

    def _infer(self, bgr, t_ms: int):
        import cv2
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        if self.backend == "legacy":
            rgb.flags.writeable = False
            res = self._pose.process(rgb)
            if not res.pose_landmarks:
                return None
            return np.array([[p.x, p.y, p.z, p.visibility]
                             for p in res.pose_landmarks.landmark], np.float32)
        img = mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb))
        res = self._pose.detect_for_video(img, t_ms)
        if not res.pose_landmarks:
            return None
        return np.array([[p.x, p.y, p.z, getattr(p, "visibility", 1.0)]
                         for p in res.pose_landmarks[0]], np.float32)

    def _loop(self) -> None:
        try:
            self._pose = self._make()
        except Exception as e:                        # noqa: BLE001
            self.error = f"{type(e).__name__}: {e}"
            self.available = False
            print(f"[pose:{self.key}] {self.error}")
            return
        interval = 1.0 / max(1.0, self.target_fps)
        last_idx, t_ms = -1, 0
        try:
            while not self._stop.is_set():
                t0 = time.perf_counter()
                fr = self._src.latest()
                if fr is None or fr.index == last_idx:
                    time.sleep(0.005)
                    continue
                last_idx = fr.index
                t_ms += max(1, int(interval * 1000))
                try:
                    arr = self._infer(fr.image, t_ms)
                except Exception as e:                # noqa: BLE001
                    self.error = f"{type(e).__name__}: {e}"
                    arr = None
                ms = (time.perf_counter() - t0) * 1000
                out = PoseResult(self.key, fr.t_mono, fr.index, arr, arr is not None, ms)
                with self._lock:
                    self._latest = out
                rest = interval - (time.perf_counter() - t0)
                if rest > 0:
                    time.sleep(rest)
        finally:
            try:
                if self._pose is not None:
                    self._pose.close()
            except Exception:                         # noqa: BLE001
                pass
            self._pose = None

    def latest(self) -> Optional[PoseResult]:
        with self._lock:
            return self._latest


def draw_overlay(img: np.ndarray, res: Optional[PoseResult]) -> np.ndarray:
    """骨格を描く。調整中はこれが見えることが何より大事。"""
    import cv2
    if res is None or not res.ok or res.landmarks is None:
        return img
    h, w = img.shape[:2]
    lm = res.landmarks
    bones = [("l_shoulder", "r_shoulder"), ("l_hip", "r_hip"),
             ("l_shoulder", "l_hip"), ("r_shoulder", "r_hip"),
             ("l_shoulder", "l_elbow"), ("l_elbow", "l_wrist"),
             ("r_shoulder", "r_elbow"), ("r_elbow", "r_wrist"),
             ("l_hip", "l_knee"), ("l_knee", "l_ankle"),
             ("r_hip", "r_knee"), ("r_knee", "r_ankle")]
    for a, b in bones:
        pa, pb = lm[L[a]], lm[L[b]]
        if pa[3] < .35 or pb[3] < .35:
            continue
        cv2.line(img, (int(pa[0] * w), int(pa[1] * h)),
                 (int(pb[0] * w), int(pb[1] * h)), (240, 168, 60), 2, cv2.LINE_AA)
    for name in ("nose", "l_shoulder", "r_shoulder", "l_hip", "r_hip",
                 "l_wrist", "r_wrist"):
        p = lm[L[name]]
        if p[3] < .35:
            continue
        cv2.circle(img, (int(p[0] * w), int(p[1] * h)), 4, (86, 200, 220), -1, cv2.LINE_AA)
    return img
