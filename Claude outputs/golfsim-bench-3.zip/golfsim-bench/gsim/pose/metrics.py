"""pose/metrics.py — 姿勢から、ゴルフで意味のある数字を出す

■ カメラの向きごとに、取れる指標が違う

ここも計測カメラと同じ話で、**見る向きが測れる量を決める**。

    正面（前方から）  : 肩の傾き・腰の左右移動・頭の上下左右・体重移動の目安
    側面（飛球線と直交）: 前傾角・背骨の角度・手元の高さ・アドレス姿勢
    右斜め（45°）     : 肩と腰の回転差（Xファクター）が一番よく見える

回転角は正面や側面からだと「奥行き方向の回転」になって潰れるが、
斜めから見ると肩幅・腰幅の**見かけの縮み**として現れる。
だから斜めのカメラが回転量に効く。3方向の役割分担はこれで決まる。

■ 数字の性質について

ここで出るのは **1台のカメラから見た2次元の量** である。
絶対角度としては正確でないが、**同じ人の同じセットアップでの変化**は
きちんと追える。レッスンで必要なのはそちらなので、これで成立する。
（3台を較正して3次元復元するのは次の段階。ハード同期が要る）
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from .estimator import L, PoseResult


def _mid(a, b):
    if a is None or b is None:
        return None
    return (a + b) / 2.0


def _angle_deg(v) -> Optional[float]:
    if v is None:
        return None
    return math.degrees(math.atan2(v[1], v[0]))


@dataclass
class Metric:
    key: str
    label: str
    value: Optional[float]
    unit: str
    hint: str = ""


def _shoulder_tilt(r: PoseResult) -> Optional[float]:
    ls, rs = r.pt("l_shoulder"), r.pt("r_shoulder")
    if ls is None or rs is None:
        return None
    a = _angle_deg(rs - ls)
    return -(a if abs(a) < 90 else a - math.copysign(180, a))


def _hip_tilt(r: PoseResult) -> Optional[float]:
    lh, rh = r.pt("l_hip"), r.pt("r_hip")
    if lh is None or rh is None:
        return None
    a = _angle_deg(rh - lh)
    return -(a if abs(a) < 90 else a - math.copysign(180, a))


def _spine_angle(r: PoseResult) -> Optional[float]:
    sh = _mid(r.pt("l_shoulder"), r.pt("r_shoulder"))
    hp = _mid(r.pt("l_hip"), r.pt("r_hip"))
    if sh is None or hp is None:
        return None
    v = sh - hp
    return abs(math.degrees(math.atan2(v[0], -v[1])))


def _width_ratio(r: PoseResult, a: str, b: str) -> Optional[float]:
    pa, pb = r.pt(a), r.pt(b)
    if pa is None or pb is None:
        return None
    return float(abs(pa[0] - pb[0]))


# 立っている人として、ありえない値。ここを超えたら検出が崩れている
PLAUSIBLE = {
    "shoulder_tilt": 40.0, "hip_tilt": 40.0, "spine_angle": 75.0,
    "shoulder_turn": 130.0, "hip_turn": 130.0, "x_factor": 90.0,
    "head_sway": 40.0, "head_lift": 40.0, "hip_slide": 40.0,
    "posture_change": 40.0,
}

KEY_LANDMARKS = ("l_shoulder", "r_shoulder", "l_hip", "r_hip", "nose")


def quality(r: Optional[PoseResult]) -> float:
    """主要な関節がどれだけ確からしく取れているか（0〜1）。

    **信用できない姿勢から出した数字は表示しない。**
    レッスンで「肩が56°傾いています」と出てしまうほうが、
    「検出できていません」と出るよりずっと悪い。
    """
    if r is None or not r.ok or r.landmarks is None:
        return 0.0
    vs = [float(r.landmarks[L[n]][3]) for n in KEY_LANDMARKS if n in L]
    return float(sum(vs) / len(vs)) if vs else 0.0


MIN_QUALITY = 0.55


def compute(role: str, r: Optional[PoseResult],
            ref: Optional[Dict[str, float]] = None) -> List[Metric]:
    """role は 'front'（正面）/ 'side'（側面）/ 'diag'（斜め）。"""
    if r is None or not r.ok or quality(r) < MIN_QUALITY:
        return []
    ref = ref or {}
    m: List[Metric] = []

    sh = _mid(r.pt("l_shoulder"), r.pt("r_shoulder"))
    hp = _mid(r.pt("l_hip"), r.pt("r_hip"))
    nose = r.pt("nose")

    if role == "front":
        m.append(Metric("shoulder_tilt", "肩の傾き", _shoulder_tilt(r), "°",
                        "右肩が下がるとプラス"))
        m.append(Metric("hip_tilt", "腰の傾き", _hip_tilt(r), "°"))
        if nose is not None and "nose_x0" in ref:
            m.append(Metric("head_sway", "頭の左右", (nose[0] - ref["nose_x0"]) * 100, "%幅",
                            "アドレス位置からのズレ"))
            m.append(Metric("head_lift", "頭の上下", (ref["nose_y0"] - nose[1]) * 100, "%高",
                            "プラスで伸び上がり"))
        if hp is not None and "hip_x0" in ref:
            m.append(Metric("hip_slide", "腰の横移動", (hp[0] - ref["hip_x0"]) * 100, "%幅"))
    elif role == "side":
        m.append(Metric("spine_angle", "前傾角", _spine_angle(r), "°",
                        "アドレスからの変化を見る"))
        if sh is not None and "sh_y0" in ref:
            m.append(Metric("posture_change", "起き上がり", (ref["sh_y0"] - sh[1]) * 100, "%高",
                            "プラスで伸び上がり"))
        w = r.pt("r_wrist")
        if w is not None:
            m.append(Metric("hand_height", "手元の高さ", (1.0 - w[1]) * 100, "%高"))
    else:                                             # diag
        sw = _width_ratio(r, "l_shoulder", "r_shoulder")
        hw = _width_ratio(r, "l_hip", "r_hip")
        if sw is not None and "sh_w0" in ref and ref["sh_w0"] > 1e-6:
            c = max(-1.0, min(1.0, sw / ref["sh_w0"]))
            m.append(Metric("shoulder_turn", "肩の回転", math.degrees(math.acos(c)), "°",
                            "アドレスの肩幅からの縮みで推定"))
        if hw is not None and "hip_w0" in ref and ref["hip_w0"] > 1e-6:
            c = max(-1.0, min(1.0, hw / ref["hip_w0"]))
            m.append(Metric("hip_turn", "腰の回転", math.degrees(math.acos(c)), "°"))
        st = next((x.value for x in m if x.key == "shoulder_turn"), None)
        ht = next((x.value for x in m if x.key == "hip_turn"), None)
        if st is not None and ht is not None:
            m.append(Metric("x_factor", "Xファクター", st - ht, "°",
                            "肩と腰の回転差。捻転の大きさ"))
    out = []
    for x in m:
        if x.value is None:
            continue
        lim = PLAUSIBLE.get(x.key)
        if lim is not None and abs(x.value) > lim:
            continue                      # ありえない値は出さない
        out.append(x)
    return out


def make_reference(r: Optional[PoseResult]) -> Dict[str, float]:
    """アドレス姿勢を基準として記録する。

    多くの指標は『アドレスからどれだけ動いたか』でしか意味を持たない。
    構えたところでこれを押してもらう。
    """
    if r is None or not r.ok:
        return {}
    out: Dict[str, float] = {}
    nose = r.pt("nose")
    if nose is not None:
        out["nose_x0"], out["nose_y0"] = float(nose[0]), float(nose[1])
    hp = _mid(r.pt("l_hip"), r.pt("r_hip"))
    if hp is not None:
        out["hip_x0"], out["hip_y0"] = float(hp[0]), float(hp[1])
    sh = _mid(r.pt("l_shoulder"), r.pt("r_shoulder"))
    if sh is not None:
        out["sh_x0"], out["sh_y0"] = float(sh[0]), float(sh[1])
    sw = _width_ratio(r, "l_shoulder", "r_shoulder")
    if sw:
        out["sh_w0"] = float(sw)
    hw = _width_ratio(r, "l_hip", "r_hip")
    if hw:
        out["hip_w0"] = float(hw)
    sa = _spine_angle(r)
    if sa is not None:
        out["spine0"] = float(sa)
    return out
