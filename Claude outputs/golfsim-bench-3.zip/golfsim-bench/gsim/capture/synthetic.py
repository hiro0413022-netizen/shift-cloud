"""capture/synthetic.py — 機器が無いときの代役

カメラが届く前でも、UI・姿勢推定・指標計算・記録まで全部通して確認できる。
実機が来たら設定ファイルの kind を uvc に変えるだけで差し替わる。
"""

from __future__ import annotations

import math
import time
from typing import Optional

import cv2
import numpy as np

from .base import CaptureSource, SourceInfo


class SyntheticCamera(CaptureSource):
    """歩く人型を描いて流す。姿勢推定が反応するので配線の確認になる。"""

    def __init__(self, key: str, label: str, width: int = 1280, height: int = 720,
                 fps: float = 60.0, ring_seconds: float = 8.0):
        super().__init__(SourceInfo(key=key, label=label, kind="synthetic",
                                    width=width, height=height, fps=fps,
                                    fourcc="RAW", device="ダミー"),
                         ring_seconds=ring_seconds)
        self.w, self.h, self.fps = width, height, fps
        self._t0 = time.perf_counter()

    def _open(self) -> None:
        self._t0 = time.perf_counter()

    def _grab(self) -> Optional[np.ndarray]:
        time.sleep(max(0.0, 1.0 / self.fps))
        t = time.perf_counter() - self._t0
        img = np.full((self.h, self.w, 3), 42, np.uint8)
        cv2.rectangle(img, (0, int(self.h * 0.86)), (self.w, self.h), (52, 74, 50), -1)

        # 姿勢推定が反応するよう、棒ではなく「肉付きのある人型」を描く
        s = self.h / 6.2                       # 頭ひとつぶんの目安
        cx = int(self.w * 0.5 + math.sin(t * 0.7) * self.w * 0.02)
        top = int(self.h * 0.13)
        sw = math.sin(t * 1.8)                 # スイングの位相
        skin, wear = (168, 186, 205), (188, 192, 196)

        def L(a, b, w_, c):
            cv2.line(img, (int(a[0]), int(a[1])), (int(b[0]), int(b[1])), c, int(w_),
                     cv2.LINE_AA)

        head = (cx, top + s * 0.5)
        neck = (cx, top + s * 1.05)
        hip = (cx, top + s * 3.05)
        shL = (cx - s * 0.46, top + s * 1.28); shR = (cx + s * 0.46, top + s * 1.28)
        hpL = (cx - s * 0.30, hip[1]);         hpR = (cx + s * 0.30, hip[1])
        # 胴
        cv2.fillPoly(img, [np.array([shL, shR, hpR, hpL], np.int32)], wear)
        L(neck, hip, s * 0.62, wear)
        cv2.ellipse(img, (int(head[0]), int(head[1])), (int(s * 0.30), int(s * 0.40)),
                    0, 0, 360, skin, -1, cv2.LINE_AA)
        L(neck, (head[0], head[1] + s * 0.30), s * 0.24, skin)
        # 腕（スイングで動かす）
        # 腕は胴を横切らせない。横切ると姿勢推定が左右を取り違える
        a1 = sw * 0.9
        hnd = (cx + s * (0.55 + 0.35 * math.cos(a1)), hip[1] - s * 0.20 + s * 0.45 * math.sin(a1))
        elL = ((shL[0] + hnd[0]) / 2 - s * 0.16, (shL[1] + hnd[1]) / 2 + s * 0.10)
        elR = ((shR[0] + hnd[0]) / 2 + s * 0.14, (shR[1] + hnd[1]) / 2 + s * 0.10)
        L(shL, elL, s * 0.20, wear); L(elL, hnd, s * 0.17, skin)
        L(shR, elR, s * 0.20, wear); L(elR, hnd, s * 0.17, skin)
        cv2.circle(img, (int(hnd[0]), int(hnd[1])), int(s * 0.11), skin, -1, cv2.LINE_AA)
        # クラブ
        L(hnd, (hnd[0] + (hnd[0] - cx) * 1.9, hnd[1] + (hnd[1] - hip[1]) * 1.9),
          s * 0.05, (240, 240, 230))
        # 脚
        for hp_, sgn in ((hpL, -1), (hpR, 1)):
            kn = (hp_[0] + sgn * s * 0.10, hp_[1] + s * 1.10)
            an = (hp_[0] + sgn * s * 0.16, hp_[1] + s * 2.15)
            L(hp_, kn, s * 0.26, wear); L(kn, an, s * 0.20, wear)
            cv2.ellipse(img, (int(an[0]), int(an[1] + s * .08)),
                        (int(s * .22), int(s * .10)), 0, 0, 360, (60, 60, 64), -1, cv2.LINE_AA)
        # OpenCV は日本語を描けないので、映像内は ASCII のみ。名前はUI側で出す
        cv2.putText(img, f"{self.info.key.upper()}  SYNTHETIC  {t:5.1f}s",
                    (16, 30), cv2.FONT_HERSHEY_SIMPLEX, .62, (170, 185, 175), 2, cv2.LINE_AA)
        return img

    def _close(self) -> None:
        pass
