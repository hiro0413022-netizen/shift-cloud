"""capture/genicam.py — 計測カメラ（Basler acA640-750um など）

■ なぜベンダーSDKを直接使わないのか

ImpactVision が更新できなくなった原因は、ZWO の独自SDKに縛られていたことだった。
ドライバが古くなった時点で、カメラを替えることも新しいPCで動かすこともできなくなった。

**同じ轍を踏まない。** ここでは GenICam / GenTL という業界標準経由で開く。
これなら Basler でも IDS でも Hikrobot でも、**同じコードのまま差し替えられる。**
「USB 3.0」ではなく「USB3 Vision」を必須条件にしたのはこのためである。

■ 必要なもの

    pip install harvesters
    + カメラメーカーの GenTL プロデューサ（.cti ファイル）

    Basler の場合: pylon をインストールすると入る
      Windows: C:\\Program Files\\Basler\\pylon 8\\Runtime\\x64\\ProducerU3V.cti
      Linux:   /opt/pylon/lib/gentl_producers/ProducerU3V-*.cti

    設定の cti に上のパスを書く。空なら自動で探す。

■ 計測カメラで必ず設定すること

    ExposureTime  : 露光。ボールを止めるには 10〜25µs。ここが命
    TriggerMode   : 赤外ストロボと同期させるので On（外部トリガ）
    PixelFormat   : Mono8
    Width/Height/OffsetX/OffsetY : ROI。狭めるほど fps が上がる
"""

from __future__ import annotations

import glob
import os
import platform
from typing import List, Optional

import numpy as np

from .base import CaptureSource, SourceInfo

DEFAULT_CTI_GLOBS = [
    r"C:\Program Files\Basler\pylon *\Runtime\x64\ProducerU3V.cti",
    r"C:\Program Files\Basler\pylon *\Runtime\x64\ProducerGEV.cti",
    "/opt/pylon/lib/gentl_producers/ProducerU3V*.cti",
    "/opt/ids-peak*/lib/ids/cti/ids_u3vgentl.cti",
    "/usr/lib/ids/cti/*.cti",
]


def find_cti() -> List[str]:
    """GenTL プロデューサ(.cti)を探す。見つからなければ空。"""
    hits: List[str] = []
    env = os.environ.get("GENICAM_GENTL64_PATH", "")
    for d in filter(None, env.split(os.pathsep)):
        hits += sorted(glob.glob(os.path.join(d, "*.cti")))
    for pat in DEFAULT_CTI_GLOBS:
        hits += sorted(glob.glob(pat))
    seen, out = set(), []
    for h in hits:
        if h not in seen and os.path.exists(h):
            seen.add(h)
            out.append(h)
    return out


class GenICamCamera(CaptureSource):
    """GenTL 経由の産業用カメラ。Harvester を使う。"""

    def __init__(self, key: str, label: str, serial: str = "", cti: str = "",
                 width: int = 640, height: int = 480, offset_x: int = 0,
                 offset_y: int = 0, exposure_us: float = 20.0,
                 gain: float = 0.0, trigger: str = "off",
                 pixel_format: str = "Mono8", fps: float = 751.0,
                 ring_seconds: float = 3.0):
        super().__init__(SourceInfo(key=key, label=label, kind="genicam",
                                    width=width, height=height, fps=fps,
                                    fourcc=pixel_format,
                                    device=serial or "(最初の1台)"),
                         ring_seconds=ring_seconds)
        self.serial, self.cti = serial, cti
        self.roi = (width, height, offset_x, offset_y)
        self.exposure_us, self.gain = exposure_us, gain
        self.trigger, self.pixel_format = trigger, pixel_format
        self._h = None
        self._ia = None

    def _open(self) -> None:
        try:
            from harvesters.core import Harvester
        except ImportError as e:
            raise RuntimeError(
                "harvesters が入っていません。 pip install harvesters") from e

        ctis = [self.cti] if self.cti else find_cti()
        if not ctis:
            raise RuntimeError(
                "GenTL プロデューサ(.cti)が見つかりません。"
                "pylon など、カメラメーカーのランタイムを入れてください")

        h = Harvester()
        for c in ctis:
            try:
                h.add_file(c)
            except Exception:                         # noqa: BLE001
                pass
        h.update()
        if not h.device_info_list:
            h.reset()
            raise RuntimeError("GenTL でカメラが見つかりません（接続と電源を確認）")

        idx = 0
        if self.serial:
            for i, d in enumerate(h.device_info_list):
                if getattr(d, "serial_number", "") == self.serial:
                    idx = i
                    break
            else:
                h.reset()
                raise RuntimeError(f"シリアル {self.serial} のカメラが見つかりません")

        ia = h.create(idx)
        n = ia.remote_device.node_map
        w, ht, ox, oy = self.roi

        def setn(name, value):
            try:
                getattr(n, name).value = value
                return True
            except Exception:                         # noqa: BLE001
                return False

        setn("OffsetX", 0); setn("OffsetY", 0)
        setn("Width", int(w)); setn("Height", int(ht))
        setn("OffsetX", int(ox)); setn("OffsetY", int(oy))
        setn("PixelFormat", self.pixel_format)
        setn("ExposureAuto", "Off"); setn("GainAuto", "Off")
        setn("ExposureTime", float(self.exposure_us))
        setn("Gain", float(self.gain))
        if self.trigger and self.trigger.lower() != "off":
            setn("TriggerSelector", "FrameStart")
            setn("TriggerMode", "On")
            setn("TriggerSource", self.trigger)       # 例: "Line1"
            setn("TriggerActivation", "RisingEdge")
        else:
            setn("TriggerMode", "Off")
            setn("AcquisitionFrameRateEnable", True)
            setn("AcquisitionFrameRate", float(self.info.fps))

        ia.start()
        self._h, self._ia = h, ia

        # 実際に入った値を読み戻す。**要求値ではなく実値を信用する**
        for name, attr in (("Width", "width"), ("Height", "height")):
            try:
                setattr(self.info, attr, int(getattr(n, name).value))
            except Exception:                         # noqa: BLE001
                pass
        try:
            self.exposure_us = float(n.ExposureTime.value)
        except Exception:                             # noqa: BLE001
            pass
        try:
            d = h.device_info_list[idx]
            self.info.device = (f"{getattr(d,'model',' ')} "
                                f"SN{getattr(d,'serial_number','?')} / 露光{self.exposure_us:.0f}µs")
        except Exception:                             # noqa: BLE001
            pass

    def _grab(self) -> Optional[np.ndarray]:
        if self._ia is None:
            return None
        try:
            with self._ia.fetch(timeout=1.0) as buf:
                c = buf.payload.components[0]
                img = c.data.reshape(c.height, c.width).copy()
            return img
        except Exception:                             # noqa: BLE001
            return None

    def _close(self) -> None:
        try:
            if self._ia is not None:
                self._ia.stop(); self._ia.destroy()
        finally:
            self._ia = None
            if self._h is not None:
                self._h.reset()
                self._h = None

    # 調整用（露光はライブで動かしたい）
    def apply_setting(self, key: str, value: float) -> bool:
        if self._ia is None:
            return False
        name = {"exposure": "ExposureTime", "gain": "Gain"}.get(key)
        if not name:
            return False
        try:
            getattr(self._ia.remote_device.node_map, name).value = float(value)
            if key == "exposure":
                self.exposure_us = float(value)
            return True
        except Exception:                             # noqa: BLE001
            return False

    def read_settings(self) -> dict:
        if self._ia is None:
            return {}
        n = self._ia.remote_device.node_map
        out = {}
        for k, name in (("exposure", "ExposureTime"), ("gain", "Gain")):
            try:
                out[k] = float(getattr(n, name).value)
            except Exception:                         # noqa: BLE001
                pass
        return out


def list_devices() -> list:
    """つながっている GenICam カメラを列挙する。"""
    try:
        from harvesters.core import Harvester
    except ImportError:
        return [{"error": "harvesters が入っていません（pip install harvesters）"}]
    ctis = find_cti()
    if not ctis:
        return [{"error": "GenTL プロデューサ(.cti)が見つかりません"}]
    h = Harvester()
    for c in ctis:
        try:
            h.add_file(c)
        except Exception:                             # noqa: BLE001
            pass
    h.update()
    out = [dict(index=i, model=getattr(d, "model", ""),
                serial=getattr(d, "serial_number", ""),
                vendor=getattr(d, "vendor", ""),
                tl_type=getattr(d, "tl_type", ""))
           for i, d in enumerate(h.device_info_list)]
    h.reset()
    return out or [{"error": "カメラが見つかりません"}]
