"""capture/videofile.py — 動画ファイルを入力にする

■ 何のためにあるか

iPhone で撮ったスイング動画を、そのまま計測ベンチに流せるようにする。
**実機のカメラが届く前に、本物の人の動きで姿勢推定と指標を詰められる。**
ダミーの人型では検出が不安定で、指標が信用できなかった。ここが解決する。

iPhone は計測カメラの代わりにはならないが（ローリングシャッター・
露光下限・赤外が写らない・同期できない）、**姿勢推定の開発素材としては十分**。

■ 使い方

    config/swing.yaml で

      - key: front
        kind: video
        path: samples/front_240fps.mov
        speed: 1.0        # 1.0 で撮影時の速度、0.25 でスロー再生
        loop: true

    240fps で撮った動画なら、メタデータの fps がそのまま入るので
    実時間の指標（角速度など）も正しく出る。
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

from .base import CaptureSource, SourceInfo


class VideoFileCamera(CaptureSource):
    def __init__(self, key: str, label: str, path: str, speed: float = 1.0,
                 loop: bool = True, max_width: int = 0, ring_seconds: float = 8.0):
        p = Path(path)
        super().__init__(SourceInfo(key=key, label=label, kind="video",
                                    device=p.name, fourcc="FILE"),
                         ring_seconds=ring_seconds)
        self.path = p
        self.speed = max(0.05, float(speed))
        self.loop = loop
        self.max_width = int(max_width)
        self._cap: Optional[cv2.VideoCapture] = None
        self._src_fps = 30.0
        self._next = 0.0

    def _open(self) -> None:
        if not self.path.exists():
            raise FileNotFoundError(f"動画が見つかりません: {self.path}")
        cap = cv2.VideoCapture(str(self.path))
        if not cap.isOpened():
            raise RuntimeError(f"動画を開けません: {self.path}")
        self._src_fps = float(cap.get(cv2.CAP_PROP_FPS)) or 30.0
        self.info.width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.info.height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.info.fps = self._src_fps * self.speed
        n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.info.device = (f"{self.path.name} / 撮影{self._src_fps:.0f}fps"
                            f" / {n}フレーム / ×{self.speed:g}")
        self._cap = cap
        self._next = time.perf_counter()

    def _grab(self) -> Optional[np.ndarray]:
        if self._cap is None:
            return None
        # 撮影時の時間軸を保って流す。ここを守らないと指標の時間軸が狂う
        now = time.perf_counter()
        if now < self._next:
            time.sleep(min(0.01, self._next - now))
            return None
        self._next += 1.0 / max(1e-3, self._src_fps * self.speed)
        ok, img = self._cap.read()
        if not ok:
            if not self.loop:
                return None
            self._cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ok, img = self._cap.read()
            if not ok:
                return None
        if self.max_width and img.shape[1] > self.max_width:
            h = int(img.shape[0] * self.max_width / img.shape[1])
            img = cv2.resize(img, (self.max_width, h), interpolation=cv2.INTER_AREA)
        return img

    def _close(self) -> None:
        if self._cap is not None:
            self._cap.release()
            self._cap = None
