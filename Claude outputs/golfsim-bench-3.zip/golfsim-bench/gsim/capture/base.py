"""capture/base.py — カメラ抽象化

UVCカメラ（スイング撮影）も GenICam カメラ（計測）もレーダーも、
この共通の形で扱う。あとから機器を差し替えても上位のコードを触らずに済む。
"""

from __future__ import annotations

import threading
import time
from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass, field
from typing import Optional

import cv2
import numpy as np


@dataclass
class Frame:
    image: np.ndarray
    t_mono: float          # 受信時刻（time.perf_counter）
    index: int             # 通し番号


@dataclass
class SourceInfo:
    key: str               # 役割の識別子 例: "front" / "side" / "diag_r"
    label: str             # 画面に出す名前 例: "前方"
    kind: str              # "uvc" / "genicam" / "radar" / "synthetic"
    width: int = 0
    height: int = 0
    fps: float = 0.0
    fourcc: str = ""
    device: str = ""       # 実際に開いたデバイスの識別
    connected: bool = False
    error: str = ""
    note: str = ""         # 要求どおりに開けず妥協したときの説明


class CaptureSource(ABC):
    """1台ぶんの取り込み。バックグラウンドで回し、常に最新フレームを持つ。

    ライブ表示では『溜めずに最新を見る』のが正しい。キューに積むと
    調整中に遅延が増えていき、何を触っているのか分からなくなる。
    録画したいときだけリングバッファから取り出す。
    """

    def __init__(self, info: SourceInfo, ring_seconds: float = 8.0):
        self.info = info
        self._latest: Optional[Frame] = None
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._count = 0
        self._ring_seconds = ring_seconds
        self._ring: deque = deque()
        self._recording = False
        self._fps_win: deque = deque(maxlen=90)
        # 歪み補正。ここで掛けると、ライブ映像も姿勢推定も同じ補正後の絵を見る
        self._undistort = None
        self.undistort_enabled = True
        # 映像の持ち上げ（ソフト側の増幅）。センサーに入る光は増えないが、
        # 受け取った信号を伸ばすことで骨格の検出が通るようになることが多い。
        # 暗部を伸ばすほどノイズも伸びるので、上げれば良いというものではない。
        self._lut = None
        self.enhance_level = 0

    # --- 実装するのはこの3つだけ ---
    @abstractmethod
    def _open(self) -> None: ...
    @abstractmethod
    def _grab(self) -> Optional[np.ndarray]: ...
    @abstractmethod
    def _close(self) -> None: ...

    # --- 共通の動作 ---
    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name=f"cap:{self.info.key}")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2.0)
        self._thread = None

    def _loop(self) -> None:
        # 開くのに時間がかかっているとき、黙って待たせない。
        # ドライバが固まると例外も出ずに止まるので、外から時間で見張る。
        opened = threading.Event()

        def watch():
            t0 = time.perf_counter()
            while not opened.wait(1.0):
                if self._stop.is_set():
                    return
                el = time.perf_counter() - t0
                if el > 8:
                    self.info.error = (f"開いています…（{int(el)}秒）。他のカメラの順番待ちか、"
                                       "ドライバが固まっています")
        threading.Thread(target=watch, daemon=True, name=f"open-watch:{self.info.key}").start()
        try:
            self._open()
            opened.set()
            self.info.connected = True
            self.info.error = ""
        except Exception as e:                      # noqa: BLE001
            opened.set()
            self.info.connected = False
            self.info.error = f"{type(e).__name__}: {e}"
            return
        last = time.perf_counter()
        misses = 0
        try:
            while not self._stop.is_set():
                img = self._grab()
                if img is None:
                    misses += 1
                    if misses > 60:
                        self.info.error = "フレームが取れません（ケーブル／帯域を確認）"
                        self.info.connected = False
                        break
                    time.sleep(0.002)
                    continue
                misses = 0
                u = self._undistort
                if u is not None and self.undistort_enabled:
                    try:
                        img = u(img)
                    except Exception:                 # noqa: BLE001
                        pass
                lut = self._lut
                if lut is not None:
                    try:
                        img = cv2.LUT(img, lut)
                    except Exception:                 # noqa: BLE001
                        pass
                now = time.perf_counter()
                self._fps_win.append(now - last)
                last = now
                self._count += 1
                fr = Frame(img, now, self._count)
                with self._lock:
                    self._latest = fr
                    if self._recording:
                        self._ring.append(fr)
                        cutoff = now - self._ring_seconds
                        while self._ring and self._ring[0].t_mono < cutoff:
                            self._ring.popleft()
        finally:
            try:
                self._close()
            except Exception:                        # noqa: BLE001
                pass
            self.info.connected = False

    # --- 取り出し ---
    def latest(self) -> Optional[Frame]:
        with self._lock:
            return self._latest

    @property
    def measured_fps(self) -> float:
        if len(self._fps_win) < 5:
            return 0.0
        dt = sum(self._fps_win) / len(self._fps_win)
        return 1.0 / dt if dt > 0 else 0.0

    def set_enhance(self, level: int) -> None:
        """0=そのまま / 1=弱 / 2=中 / 3=強。

        変換表（LUT）を1回作って使い回す。1画素ずつ計算すると
        120fps×3台では間に合わないが、表引きなら十分に速い。
        暗い側を大きく持ち上げ、明るい側は飽和させない形にする。
        """
        level = max(0, min(3, int(level)))
        self.enhance_level = level
        if level == 0:
            self._lut = None
            return
        gamma, gain = {1: (1.6, 1.15), 2: (2.4, 1.35), 3: (3.4, 1.6)}[level]
        x = np.arange(256, dtype=np.float32) / 255.0
        y = np.power(x, 1.0 / gamma) * gain
        self._lut = np.clip(y * 255.0, 0, 255).astype(np.uint8)

    def set_undistorter(self, u) -> None:
        """歪み補正器を差す。None で無効。"""
        self._undistort = u

    @property
    def has_undistort(self) -> bool:
        return self._undistort is not None

    def set_recording(self, on: bool) -> None:
        with self._lock:
            self._recording = on
            if not on:
                self._ring.clear()

    def take_clip(self) -> list:
        with self._lock:
            return list(self._ring)
