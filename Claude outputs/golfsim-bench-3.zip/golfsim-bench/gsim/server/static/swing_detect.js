// swing_detect.js — アドレス → トップ → インパクト を骨格から見つける
//
// ■ 何を手がかりにするか
//
// 手元（両手首の中点）の位置だけを見る。クラブは骨格に写らないし、
// 体の回転は見る向きに依存するが、**手元はどのカメラからでも動く**。
//
//   アドレス : 手元が基準位置の近くで静止している
//   テイクバック: 基準から離れていく
//   トップ   : 離れる向きから戻る向きへ変わる瞬間（速度の符号が反転）
//   インパクト: 戻ってきて基準位置を通過する瞬間（そこが最速）
//
// ■ インパクトの決め方
//
// 「基準位置に最も近づいたコマ」ではなく、**基準の高さを横切る瞬間**を
// 前後のコマから線形に補間して出す。骨格は毎秒30回しか取れないので、
// コマ単位だと±33msの誤差になる。補間すれば数msまで詰められる。
// ダウンスイングは0.25秒ほどなので、この差は小さくない。
//
// ■ 誤検出について
//
// 素振り・アドレスの入り直し・手を上げただけ、をスイングと呼ばないために
// 「一定以上離れてから戻ってくる」ことを条件にする。往復の振幅が
// 小さいものは弾く。厳しすぎると拾えないので、閾値は調整できるようにする。

export const PHASE = {
  IDLE:'idle', ADDRESS:'address', BACK:'backswing', TOP:'top',
  DOWN:'downswing', IMPACT:'impact', FOLLOW:'follow',
};

export const DEFAULTS = {
  stillFrames: 8,      // アドレスと認めるのに必要な静止コマ数
  stillSpeed: 0.004,   // 静止とみなす速さ（画面比/コマ）
  stillNear: 0.10,     // 基準位置からこの範囲にいればアドレス
  startAway: 0.05,     // これ以上離れたらテイクバック開始
  minTopAway: 0.13,    // トップがこれ未満ならスイングとみなさない
  impactNear: 0.035,   // 基準の高さをこの範囲で横切ったらインパクト
  followFrames: 12,    // インパクト後、これだけ経ったら1スイング終了
  maxSwingMs: 4000,    // これを超えたら取りやめ（構え直しなど）
};

const L_WRIST = 15, R_WRIST = 16;

// 手元＝両手首の中点。片方しか見えないときはその片方を使う。
// 打つ人の利き手を問わずに済むので、左右の想定を持たなくてよい。
export function handPoint(lm, visMin = 0.35){
  if(!lm) return null;
  const ok = i => lm[i] && (lm[i].visibility ?? 1) > visMin;
  const a = ok(L_WRIST) ? lm[L_WRIST] : null;
  const b = ok(R_WRIST) ? lm[R_WRIST] : null;
  if(a && b) return {x:(a.x+b.x)/2, y:(a.y+b.y)/2};
  return a ? {x:a.x, y:a.y} : (b ? {x:b.x, y:b.y} : null);
}

export class SwingDetector {
  constructor(opt){
    this.o = Object.assign({}, DEFAULTS, opt||{});
    this.reset();
  }
  reset(){
    this.phase = PHASE.IDLE;
    this.base = null;          // アドレスでの手元位置
    this.still = 0;
    this.hist = [];            // {t, x, y, away, v}
    this.tAddress = null; this.tTop = null; this.tImpact = null;
    this.topAway = 0;
    this.lastAway = 0;
    this.events = [];
  }

  // 基準を外から与える（アドレスを手動で押した場合）
  setBase(p){ if(p) this.base = {x:p.x, y:p.y}; }

  /** 1コマぶん入れる。戻り値は、そのコマで起きた出来事（無ければ null）。 */
  push(t, lm){
    const p = handPoint(lm);
    if(!p){ return this._maybeAbort(t); }

    const prev = this.hist.length ? this.hist[this.hist.length-1] : null;
    const v = prev ? Math.hypot(p.x-prev.x, p.y-prev.y) : 0;
    const away = this.base ? Math.hypot(p.x-this.base.x, p.y-this.base.y) : 0;
    const rec = {t, x:p.x, y:p.y, away, v};
    this.hist.push(rec);
    if(this.hist.length > 600) this.hist.shift();

    const o = this.o;
    let ev = null;

    switch(this.phase){
      case PHASE.IDLE: {
        // 静止が続いたらそこをアドレスとみなす。基準が未設定ならその場所を基準にする。
        if(v < o.stillSpeed) this.still++; else this.still = 0;
        if(this.still >= o.stillFrames){
          if(!this.base) this.base = {x:p.x, y:p.y};
          const near = Math.hypot(p.x-this.base.x, p.y-this.base.y) < o.stillNear;
          if(near){
            this.phase = PHASE.ADDRESS;
            this.tAddress = t;
            ev = {type:'address', t};
          }
        }
        break;
      }
      case PHASE.ADDRESS: {
        if(away > o.startAway){
          this.phase = PHASE.BACK;
          this.topAway = away;
          ev = {type:'takeaway', t};
        }
        break;
      }
      case PHASE.BACK: {
        if(away > this.topAway){ this.topAway = away; this.tTop = t; }
        // 離れる向きから戻る向きへ変わった＝トップ
        else if(this.topAway - away > 0.012 && this.topAway >= o.minTopAway){
          this.phase = PHASE.DOWN;
          ev = {type:'top', t:this.tTop, away:this.topAway};
        }
        if(t - this.tAddress > o.maxSwingMs){ this.reset(); }
        break;
      }
      case PHASE.DOWN: {
        // 基準の「高さ」を下向きに横切る瞬間を、前後のコマから補間で出す
        if(prev && this.base){
          const y0 = prev.y - this.base.y, y1 = p.y - this.base.y;
          const crossed = (y0 < 0 && y1 >= 0) || (y0 > 0 && y1 <= 0);
          const near = Math.abs(y1) < o.impactNear || Math.abs(y0) < o.impactNear;
          if(crossed && near){
            const f = (y1 === y0) ? 0 : (0 - y0) / (y1 - y0);   // 0〜1
            const tImp = prev.t + (t - prev.t) * Math.max(0, Math.min(1, f));
            this.tImpact = tImp;
            this.phase = PHASE.IMPACT;
            this.followCount = 0;
            ev = {type:'impact', t:tImp, speed:v,
                  between:[prev.t, t], frac:f};
          }
        }
        if(this.tTop!=null && t - this.tTop > o.maxSwingMs){ this.reset(); }
        break;
      }
      case PHASE.IMPACT:
      case PHASE.FOLLOW: {
        this.phase = PHASE.FOLLOW;
        this.followCount++;
        if(this.followCount >= o.followFrames){
          ev = {type:'complete', t,
                address:this.tAddress, top:this.tTop, impact:this.tImpact,
                topAway:this.topAway};
          const base = this.base;
          this.reset();
          this.base = base;           // 基準は持ち越す
        }
        break;
      }
    }
    if(ev) this.events.push(ev);
    return ev;
  }

  _maybeAbort(t){
    // 人が見えなくなったら、途中の状態は捨てる（誤検出のもとになる）
    if(this.phase !== PHASE.IDLE && this.tAddress!=null && t - this.tAddress > this.o.maxSwingMs){
      const base = this.base; this.reset(); this.base = base;
    }
    return null;
  }
}
