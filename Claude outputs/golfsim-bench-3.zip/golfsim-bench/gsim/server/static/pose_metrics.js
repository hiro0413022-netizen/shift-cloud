// pose_metrics.js — 骨格から、ゴルフで意味のある数字を出す
//
// Python版（gsim/pose/metrics.py）をそのまま移したもの。
// **同じ式で同じ数字が出ること**を守る。片方だけ直すと、
// どちらが正しいのか分からなくなる。
//
// ■ カメラの向きごとに、取れる指標が違う
//   正面   : 肩の傾き・腰の傾き・頭の左右上下・腰の横移動
//   側面   : 前傾角・起き上がり・手元の高さ
//   右斜め : 肩と腰の回転差（Xファクター）
//
// 回転角は正面や側面からだと奥行き方向に潰れるが、斜めから見ると
// 肩幅・腰幅の「見かけの縮み」として現れる。だから斜めが回転量に効く。

export const L = {
  nose:0, l_shoulder:11, r_shoulder:12, l_elbow:13, r_elbow:14,
  l_wrist:15, r_wrist:16, l_hip:23, r_hip:24,
  l_knee:25, r_knee:26, l_ankle:27, r_ankle:28,
  l_heel:29, r_heel:30, l_foot:31, r_foot:32,
};

// 立っている人としてありえない値。ここを超えたら検出が崩れている
const PLAUSIBLE = {
  shoulder_tilt:40, hip_tilt:40, spine_angle:75,
  shoulder_turn:130, hip_turn:130, x_factor:90,
  head_sway:40, head_lift:40, hip_slide:40, posture_change:40,
};

const KEY_LANDMARKS = ['l_shoulder','r_shoulder','l_hip','r_hip','nose'];
export const MIN_QUALITY = 0.55;
const VIS_MIN = 0.35;

const deg = r => r*180/Math.PI;

// 可視性が低い点は「無い」ものとして扱う。見えていない点から角度を出さない。
function pt(lm, name){
  const i = L[name];
  if(lm==null || i===undefined) return null;
  const p = lm[i];
  if(!p) return null;
  const v = (p.visibility!==undefined) ? p.visibility : 1;
  return v > VIS_MIN ? [p.x, p.y] : null;
}
function mid(a,b){ return (a&&b) ? [(a[0]+b[0])/2, (a[1]+b[1])/2] : null; }
function angleDeg(v){ return v ? deg(Math.atan2(v[1], v[0])) : null; }
function sub(a,b){ return (a&&b) ? [a[0]-b[0], a[1]-b[1]] : null; }

function tilt(a, b){
  const v = sub(b, a);
  if(!v) return null;
  const x = angleDeg(v);
  return -(Math.abs(x) < 90 ? x : x - Math.sign(x)*180);
}
function shoulderTilt(lm){ return tilt(pt(lm,'l_shoulder'), pt(lm,'r_shoulder')); }
function hipTilt(lm){ return tilt(pt(lm,'l_hip'), pt(lm,'r_hip')); }

function spineAngle(lm){
  const sh = mid(pt(lm,'l_shoulder'), pt(lm,'r_shoulder'));
  const hp = mid(pt(lm,'l_hip'), pt(lm,'r_hip'));
  if(!sh || !hp) return null;
  const v = sub(sh, hp);
  return Math.abs(deg(Math.atan2(v[0], -v[1])));
}
function widthRatio(lm, a, b){
  const pa=pt(lm,a), pb=pt(lm,b);
  return (pa&&pb) ? Math.abs(pa[0]-pb[0]) : null;
}

export function quality(lm){
  if(!lm) return 0;
  const vs = KEY_LANDMARKS.map(n=>{
    const p = lm[L[n]];
    return p ? ((p.visibility!==undefined)?p.visibility:1) : 0;
  });
  return vs.reduce((a,b)=>a+b,0)/vs.length;
}

export function makeReference(lm){
  if(!lm) return {};
  const out = {};
  const nose = pt(lm,'nose');
  if(nose){ out.nose_x0=nose[0]; out.nose_y0=nose[1]; }
  const hp = mid(pt(lm,'l_hip'), pt(lm,'r_hip'));
  if(hp){ out.hip_x0=hp[0]; out.hip_y0=hp[1]; }
  const sh = mid(pt(lm,'l_shoulder'), pt(lm,'r_shoulder'));
  if(sh){ out.sh_x0=sh[0]; out.sh_y0=sh[1]; }
  const sw = widthRatio(lm,'l_shoulder','r_shoulder');
  if(sw) out.sh_w0=sw;
  const hw = widthRatio(lm,'l_hip','r_hip');
  if(hw) out.hip_w0=hw;
  const sa = spineAngle(lm);
  if(sa!=null) out.spine0=sa;
  return out;
}

export function compute(role, lm, ref){
  if(!lm || quality(lm) < MIN_QUALITY) return [];
  ref = ref || {};
  const m = [];
  const add=(key,label,value,unit,hint)=>m.push({key,label,value,unit,hint:hint||''});

  const sh = mid(pt(lm,'l_shoulder'), pt(lm,'r_shoulder'));
  const hp = mid(pt(lm,'l_hip'), pt(lm,'r_hip'));
  const nose = pt(lm,'nose');

  if(role==='front'){
    add('shoulder_tilt','肩の傾き', shoulderTilt(lm), '°','右肩が下がるとプラス');
    add('hip_tilt','腰の傾き', hipTilt(lm), '°');
    if(nose && ref.nose_x0!==undefined){
      add('head_sway','頭の左右', (nose[0]-ref.nose_x0)*100, '%幅','アドレス位置からのズレ');
      add('head_lift','頭の上下', (ref.nose_y0-nose[1])*100, '%高','プラスで伸び上がり');
    }
    if(hp && ref.hip_x0!==undefined)
      add('hip_slide','腰の横移動', (hp[0]-ref.hip_x0)*100, '%幅');
  } else if(role==='side'){
    add('spine_angle','前傾角', spineAngle(lm), '°','アドレスからの変化を見る');
    if(sh && ref.sh_y0!==undefined)
      add('posture_change','起き上がり', (ref.sh_y0-sh[1])*100, '%高','プラスで伸び上がり');
    const w = pt(lm,'r_wrist');
    if(w) add('hand_height','手元の高さ', (1-w[1])*100, '%高');
  } else {
    const sw = widthRatio(lm,'l_shoulder','r_shoulder');
    const hw = widthRatio(lm,'l_hip','r_hip');
    if(sw!=null && ref.sh_w0>1e-6)
      add('shoulder_turn','肩の回転',
          deg(Math.acos(Math.max(-1,Math.min(1, sw/ref.sh_w0)))), '°',
          'アドレスの肩幅からの縮みで推定');
    if(hw!=null && ref.hip_w0>1e-6)
      add('hip_turn','腰の回転',
          deg(Math.acos(Math.max(-1,Math.min(1, hw/ref.hip_w0)))), '°');
    const st = m.find(x=>x.key==='shoulder_turn');
    const ht = m.find(x=>x.key==='hip_turn');
    if(st && ht) add('x_factor','Xファクター', st.value-ht.value, '°',
                     '肩と腰の回転差。捻転の大きさ');
  }
  // ありえない値は出さない。間違った数字を出すより、出さないほうがよい
  return m.filter(x=>{
    if(x.value==null || !isFinite(x.value)) return false;
    const lim = PLAUSIBLE[x.key];
    return lim===undefined || Math.abs(x.value) <= lim;
  });
}

// 骨格の線。描画に使う
export const BONES = [
  [11,12],[11,23],[12,24],[23,24],
  [11,13],[13,15],[12,14],[14,16],
  [23,25],[25,27],[24,26],[26,28],
  [27,29],[29,31],[28,30],[30,32],
];
