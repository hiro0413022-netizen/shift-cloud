#!/usr/bin/env python3
"""run_bench.py — スイング計測ベンチを起動する

    python run_bench.py                 既定の設定で起動
    python run_bench.py --port 8770
    python run_bench.py --config config/swing.yaml

起動したらブラウザで http://127.0.0.1:8770 を開く。
"""
import argparse
import os
import sys
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=None)
    ap.add_argument("--host", default=None)
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()

    if a.config:
        os.environ["GSIM_CONFIG"] = str(Path(a.config).resolve())

    from gsim import config as cfgmod
    cfg = cfgmod.load()
    host = a.host or cfg["server"].get("host", "127.0.0.1")
    port = a.port or int(cfg["server"].get("port", 8770))

    print("=" * 64)
    print("  スイング計測ベンチ")
    print("=" * 64)
    print(f"  設定ファイル : {cfgmod.DEFAULT_PATH}")
    print(f"  画面         : http://{host}:{port}")
    print(f"  カメラ       : " + ", ".join(
        f"{c['key']}({c['kind']})" for c in cfg["cameras"] if c.get("enabled", True)))
    print("=" * 64)
    print("  終了は Ctrl+C")
    print()

    if not a.no_browser:
        try:
            webbrowser.open(f"http://{host if host != '0.0.0.0' else '127.0.0.1'}:{port}")
        except Exception:
            pass

    import uvicorn
    uvicorn.run("gsim.server.app:app", host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()
