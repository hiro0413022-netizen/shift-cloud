"""
lm_validate.py — 計測器(TrackMan / FlightScope Mevo)の実測データで弾道エンジンを検証・較正する

■ なぜこれが重要か

弾道エンジン(ball_flight.py)は TrackMan 公表の PGAツアー平均に合わせて較正してある。
出典は明確だが、それは **ツアープロが、屋外で、高級球を打った** ときの数字である。

自社の店舗で使うのは レンジボール で、屋内で、打つのは一般のお客様。
飛距離の絶対値がずれる可能性が高い。ここを埋めるには自分たちの実測が要る。

もうひとつ決定的な理由がある。ImpactVision の 40,615 球には
**スピンの実測値が1つも無い**（生値は全球 0.00）。
弾道計算でスピンは飛距離を左右する最大の要因なのに、そこだけデータが無かった。
Mevo はスピンをレーダーで実測する。**欠けていた唯一の入力がこれで埋まる。**

■ 正直に書いておく限界

屋内で使う限り、計測器が出す「Carry」も、初速・打ち出し角・スピンから
その計測器自身の弾道モデルで計算した値である。実際に落ちた場所を測った数字ではない。
TrackMan であっても、屋内モードならこれは同じ。

    → 我々の carry と計測器の carry を比べるのは「モデル同士の比較」であって、
      真値との比較ではない。

ただし verify_multi() で キャリー・最高到達点・滞空時間・落下角 を同時に見れば、
「たまたま飛距離が合った」のか「弾道の形そのものが合っている」のかを区別できる。

それでも意味はある。独立に作られた2つのモデルが広い範囲で一致するなら、
どちらも現実から大きく外れてはいない可能性が高い。
そして何より、**初速・打ち出し角・スピンは実測値**なので、
そこを入力に使うぶんには何の問題も無い。

■ 使い方

    myflightscope.com/sessions → Data → Export To CSV でCSVを取得し、

    python lm_validate.py session.csv           # 検証だけ
    python lm_validate.py session.csv --fit     # 自社の球・自社の環境に合わせて再較正

    TrackMan / Mevo どちらの書き出しでも、列名を自動で判別する。
"""

from __future__ import annotations

import argparse
import csv
import math
import sys
from dataclasses import dataclass
from typing import Optional

import ball_flight as bf

YARD = 0.9144
MPH = 0.44704


# --- 列の対応づけ -----------------------------------------------------------
# FlightScope の書き出し列名はアプリのバージョンや言語で変わる。
# 完全一致ではなく「含んでいるか」で拾う。

FIELDS = {
    # ボール（Mevo / TrackMan 共通）
    "ball_speed": ["ball speed", "ballspeed", "ボール初速", "球速"],
    "club_speed": ["club speed", "clubspeed", "ヘッドスピード"],
    "launch_v":   ["launch angle", "vertical launch", "vert. launch", "launch_v",
                   "打ち出し角", "打出角"],
    "launch_h":   ["launch direction", "horizontal launch", "horiz. launch", "launch_h",
                   "打ち出し方向"],
    "spin":       ["spin rate", "total spin", "backspin", "スピンレート", "スピン量"],
    "spin_axis":  ["spin axis", "スピン軸"],
    "carry":      ["carry"],
    "total":      ["total distance", "total"],
    "apex":       ["apex", "max height", "height", "最高到達点"],
    "flight_time":["hang time", "flight time", "滞空"],
    "land_angle": ["land angle", "landing angle", "落下角"],
    "side":       ["side total", "side", "左右"],
    "club":       ["club name", "club type", "club", "クラブ"],
    # クラブ（TrackMan / Mevo+ Pro のみ）
    "club_path":  ["club path", "クラブ軌道"],
    "aoa":        ["attack angle", "angle of attack", "入射角"],
    "face_angle": ["face angle", "フェース角"],
    "face_to_path":["face to path", "フェーストゥパス"],
    "dyn_loft":   ["dynamic loft", "dyn. loft", "dyn loft"],
}


def _match(header):
    """CSVヘッダから、こちらの項目名 → 列インデックス の対応を作る。"""
    low = [h.strip().lower() for h in header]
    out = {}
    for key, pats in FIELDS.items():
        best = None
        for i, h in enumerate(low):
            for rank, pat in enumerate(pats):
                if pat in h:
                    # 先に書いたパターンほど優先。'spin axis' を 'spin' に取られないように
                    if key == "spin" and ("axis" in h or "loft" in h):
                        continue
                    if key == "club_speed" and "profile" in h:
                        continue
                    if key == "side" and "spin" in h:
                        continue
                    if key == "total" and "spin" in h:
                        continue
                    if best is None or rank < best[0]:
                        best = (rank, i)
        if best:
            out[key] = best[1]
    return out


def _num(row, idx) -> Optional[float]:
    if idx is None or idx >= len(row):
        return None
    v = row[idx].strip().replace(",", "")
    if not v or v in ("-", "--", "N/A", "n/a"):
        return None
    try:
        return float(v)
    except ValueError:
        return None


@dataclass
class Shot:  # 計測器1球ぶんの実測値
    club: str
    ball_speed_ms: float
    launch_deg: float
    spin_rpm: float
    carry_yd: Optional[float]
    launch_h_deg: float = 0.0
    spin_axis_deg: float = 0.0
    apex_yd: Optional[float] = None
    flight_time_s: Optional[float] = None
    club_path_deg: Optional[float] = None
    aoa_deg: Optional[float] = None
    face_angle_deg: Optional[float] = None
    face_to_path_deg: Optional[float] = None
    land_angle_deg: Optional[float] = None
    side_yd: Optional[float] = None

    @property
    def backspin(self) -> float:
        return self.spin_rpm * math.cos(math.radians(self.spin_axis_deg))

    @property
    def sidespin(self) -> float:
        return self.spin_rpm * math.sin(math.radians(self.spin_axis_deg))


def load(path: str, units: str = "auto") -> list:
    """FlightScope の CSV を読み込む。単位は自動判定。"""
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    if not rows:
        raise SystemExit("CSVが空です")

    # ヘッダ行を探す（先頭に説明行が入ることがある）
    hdr_i, cols = 0, {}
    for i, r in enumerate(rows[:12]):
        c = _match(r)
        if "ball_speed" in c and ("launch_v" in c or "carry" in c):
            hdr_i, cols = i, c
            break
    if not cols:
        raise SystemExit(
            "列を認識できませんでした。ヘッダ行はこれです:\n  " + " | ".join(rows[0]))

    header_text = " ".join(rows[hdr_i]).lower()
    if units == "auto":
        if "m/s" in header_text or "meter" in header_text:
            units = "metric"
        elif "mph" in header_text or "yd" in header_text or "yard" in header_text:
            units = "imperial"
        else:
            # 単位表記が無いときは値の大きさで判断する
            sp = [_num(r, cols["ball_speed"]) for r in rows[hdr_i + 1:]]
            sp = [x for x in sp if x]
            units = "imperial" if sp and sum(sp) / len(sp) > 90 else "metric"

    v_k = MPH if units == "imperial" else 1.0
    d_k = 1.0 if units == "imperial" else 1.0 / YARD   # 距離は yd に揃える

    shots = []
    for r in rows[hdr_i + 1:]:
        bs = _num(r, cols.get("ball_speed"))
        la = _num(r, cols.get("launch_v"))
        sp = _num(r, cols.get("spin"))
        if bs is None or la is None or sp is None:
            continue
        if bs * v_k < 5 or sp <= 0:
            continue
        carry = _num(r, cols.get("carry"))
        apex = _num(r, cols.get("apex"))
        club = r[cols["club"]].strip() if "club" in cols and cols["club"] < len(r) else "?"
        shots.append(Shot(
            club=club or "?",
            ball_speed_ms=bs * v_k,
            launch_deg=la,
            spin_rpm=sp,
            carry_yd=carry * d_k if carry is not None else None,
            launch_h_deg=_num(r, cols.get("launch_h")) or 0.0,
            spin_axis_deg=_num(r, cols.get("spin_axis")) or 0.0,
            apex_yd=apex * d_k if apex is not None else None,
            flight_time_s=_num(r, cols.get("flight_time")),
            club_path_deg=_num(r, cols.get("club_path")),
            aoa_deg=_num(r, cols.get("aoa")),
            face_angle_deg=_num(r, cols.get("face_angle")),
            face_to_path_deg=_num(r, cols.get("face_to_path")),
            land_angle_deg=_num(r, cols.get("land_angle")),
            side_yd=(lambda v: v * d_k if v is not None else None)(_num(r, cols.get("side"))),
        ))
    if not shots:
        raise SystemExit("有効なショットが1つも読めませんでした")
    return shots, units, sorted(cols)


def predict(s: "Shot", temp_c: float = 20.0, altitude_m: float = 0.0):
    return bf.simulate(bf.Shot(
        ball_speed_ms=s.ball_speed_ms, launch_deg=s.launch_deg,
        azimuth_deg=s.launch_h_deg, backspin_rpm=s.backspin,
        sidespin_rpm=s.sidespin, temp_c=temp_c, altitude_m=altitude_m),
        keep_path=False)


# --- 検証 -------------------------------------------------------------------

def verify(shots, temp_c=20.0, altitude_m=0.0) -> str:
    have = [s for s in shots if s.carry_yd]
    if not have:
        return "CSVに Carry の列が無いため比較できません（初速・打出角・スピンは使えます）"

    L = ["=" * 74,
         "  弾道エンジン vs 計測器（クラブ別）",
         "=" * 74,
         f"  {'クラブ':<14}{'球数':>5}{'初速':>9}{'スピン':>9}"
         f"{'計測器':>10}{'計算':>10}{'差':>9}"]

    by = {}
    for s in have:
        by.setdefault(s.club, []).append(s)

    all_err = []
    for club, g in sorted(by.items(), key=lambda kv: -sum(x.ball_speed_ms for x in kv[1]) / len(kv[1])):
        errs, mev, ours = [], [], []
        for s in g:
            r = predict(s, temp_c, altitude_m)
            errs.append(r.carry_yd - s.carry_yd)
            mev.append(s.carry_yd); ours.append(r.carry_yd)
        m = lambda a: sum(a) / len(a)
        all_err += errs
        L.append(f"  {club[:13]:<14}{len(g):>5}"
                 f"{m([x.ball_speed_ms for x in g]):>8.1f}"
                 f"{m([x.spin_rpm for x in g]):>9.0f}"
                 f"{m(mev):>9.1f}y{m(ours):>9.1f}y{m(errs):>+8.1f}y")

    m = sum(all_err) / len(all_err)
    sd = math.sqrt(sum((e - m) ** 2 for e in all_err) / len(all_err))
    mae = sum(abs(e) for e in all_err) / len(all_err)
    L += ["-" * 74,
          f"  全体 {len(all_err)}球   平均のズレ {m:+.1f}yd   "
          f"ばらつき ±{sd:.1f}yd   平均絶対誤差 {mae:.1f}yd",
          "=" * 74]

    if abs(m) < 4:
        L.append("  → 系統的なズレはほぼ無い。いまの較正のままで使える")
    elif m > 0:
        L.append(f"  → 計算のほうが平均 {m:.1f}yd 飛んでいる。")
        L.append("     レンジボールや屋内条件のぶんだけ落として較正すべき（--fit）")
    else:
        L.append(f"  → 計算のほうが平均 {-m:.1f}yd 飛んでいない。--fit で合わせ込める")
    return "\n".join(L)


# --- 自社の球に合わせた再較正 -----------------------------------------------

def fit(shots, temp_c=20.0, altitude_m=0.0) -> str:
    from scipy.optimize import least_squares

    have = [s for s in shots if s.carry_yd]
    if len(have) < 8:
        return f"再較正には8球以上ほしい（いま {len(have)}球）"

    base = (bf.CD0, bf.CL_MAX)

    def resid(p):
        bf.CD0, bf.CL_MAX = float(p[0]), float(p[1])
        return [predict(s, temp_c, altitude_m).carry_yd - s.carry_yd for s in have]

    try:
        r = least_squares(resid, [base[0], base[1]],
                          bounds=([0.10, 0.10], [0.40, 0.40]), xtol=1e-10)
    finally:
        pass
    cd0, cl = float(r.x[0]), float(r.x[1])
    bf.CD0, bf.CL_MAX = cd0, cl
    errs = [predict(s, temp_c, altitude_m).carry_yd - s.carry_yd for s in have]
    m = sum(errs) / len(errs)
    mae = sum(abs(e) for e in errs) / len(errs)
    bf.CD0, bf.CL_MAX = base

    return "\n".join([
        "=" * 74,
        "  自社の球・自社の環境に合わせた再較正",
        "=" * 74,
        f"  対象 {len(have)}球",
        f"  CD0    {base[0]:.4f}  →  {cd0:.4f}   （抗力。大きいほど飛ばない）",
        f"  CL_MAX {base[1]:.4f}  →  {cl:.4f}   （揚力。大きいほど浮く）",
        f"  再較正後の 平均のズレ {m:+.2f}yd ／ 平均絶対誤差 {mae:.2f}yd",
        "-" * 74,
        "  ball_flight.py の該当行を書き換えれば反映される:",
        f"      CD0 = {cd0:.4f}",
        f"      CL_MAX = {cl:.4f}",
        "",
        "  ※ TrackMan較正(ツアープロ・屋外・高級球)との差が、",
        "     そのまま『自社のボールと環境の差』を表している。",
        "=" * 74])


def spin_model(shots) -> str:
    """クラブごとのスピン実測値をまとめる。カメラでスピンが取れるまでの代用になる。"""
    by = {}
    for s in shots:
        by.setdefault(s.club, []).append(s)
    L = ["=" * 74,
         "  クラブ別スピン実測（ImpactVision に欠けていた唯一のデータ）",
         "=" * 74,
         f"  {'クラブ':<14}{'球数':>5}{'初速m/s':>10}{'打出°':>8}"
         f"{'スピンrpm':>11}{'±':>7}{'スピン/初速':>12}"]
    for club, g in sorted(by.items(), key=lambda kv: -sum(x.ball_speed_ms for x in kv[1]) / len(kv[1])):
        m = lambda a: sum(a) / len(a)
        sp = [x.spin_rpm for x in g]
        mu = m(sp)
        sd = math.sqrt(m([(x - mu) ** 2 for x in sp]))
        L.append(f"  {club[:13]:<14}{len(g):>5}{m([x.ball_speed_ms for x in g]):>10.1f}"
                 f"{m([x.launch_deg for x in g]):>8.1f}{mu:>11.0f}{sd:>7.0f}"
                 f"{mu / m([x.ball_speed_ms for x in g]):>12.1f}")
    L += ["-" * 74,
          "  一番右の『スピン/初速』が使える。カメラでスピンを直接測れるまでは、",
          "  クラブ種別と初速からこの比率でスピンを推定できる。",
          "=" * 74]
    return "\n".join(L)




# --- 多項目での検証（TrackMan があるときはこちらが本命） --------------------

def verify_multi(shots, temp_c=20.0, altitude_m=0.0) -> str:
    """キャリーだけでなく、最高到達点・滞空・落下角も同時に突き合わせる。

    キャリーだけ合わせるのは実は簡単で、抗力と揚力を打ち消し合うように
    いじれば数字は合ってしまう。だが **弾道の形** までは合わない。
    最高到達点・滞空時間・落下角が同時に合って初めて、
    「飛距離がたまたま合った」ではなく「弾道そのものが正しい」と言える。
    """
    metrics = [
        ("キャリー",   "carry_yd",       lambda r: r.carry_yd,           "yd", 1),
        ("最高到達点", "apex_yd",        lambda r: r.apex_yd,            "yd", 1),
        ("滞空時間",   "flight_time_s",  lambda r: r.flight_time_s,      "s",  2),
        ("落下角",     "land_angle_deg", lambda r: r.landing_angle_deg,  "°",  1),
    ]
    preds = [(s, predict(s, temp_c, altitude_m)) for s in shots]

    L = ["=" * 74,
         "  弾道エンジン vs 計測器（多項目）",
         "=" * 74,
         f"  {'項目':<12}{'球数':>6}{'計測器':>12}{'計算':>12}{'平均のズレ':>13}{'ばらつき':>11}"]
    ok = []
    for name, attr, get, unit, dp in metrics:
        pairs = [(getattr(s, attr), get(r)) for s, r in preds if getattr(s, attr) is not None]
        if not pairs:
            L.append(f"  {name:<12}{'—':>6}   （この列が書き出しに含まれていません）")
            continue
        errs = [b - a for a, b in pairs]
        m = sum(errs) / len(errs)
        sd = math.sqrt(sum((e - m) ** 2 for e in errs) / len(errs))
        ref = sum(a for a, _ in pairs) / len(pairs)
        our = sum(b for _, b in pairs) / len(pairs)
        rel = abs(m) / ref * 100 if ref else 0
        ok.append((name, rel))
        L.append(f"  {name:<12}{len(pairs):>6}{ref:>11.{dp}f}{unit}"
                 f"{our:>11.{dp}f}{unit}{m:>+12.{dp}f}{unit}{sd:>10.{dp}f}{unit}")
    L.append("-" * 74)
    bad = [n for n, r in ok if r > 5]
    if not ok:
        L.append("  比較できる列がありませんでした")
    elif not bad:
        L.append("  → 4項目すべて 5% 以内で一致。**弾道の形そのものが合っている**")
        L.append("     飛距離がたまたま合っているのではない、という強い証拠になる")
    else:
        L.append(f"  → ズレが5%を超えた項目: {', '.join(bad)}")
        L.append("     キャリーだけ合っていて他がずれる場合、抗力と揚力の配分が違う。")
        L.append("     --fit で両方を同時に合わせ直せる")
    L.append("=" * 74)
    return "\n".join(L)


# --- フェース角の推定を実測値で検証（TrackMan のみ） ------------------------

def verify_face(shots) -> str:
    """練習画面で表示している『フェース角』は D-plane からの逆算値。
    TrackMan は実測してくれるので、その推定が当たっているか確かめられる。
    """
    have = [s for s in shots
            if s.face_angle_deg is not None and s.club_path_deg is not None]
    if len(have) < 5:
        return ""

    errs = []
    for s in have:
        # 練習画面と同じ式: 打ち出し方向 ≒ 0.15×軌道 + 0.85×フェース
        est = (s.launch_h_deg - 0.15 * s.club_path_deg) / 0.85
        errs.append(est - s.face_angle_deg)
    m = sum(errs) / len(errs)
    sd = math.sqrt(sum((e - m) ** 2 for e in errs) / len(errs))
    mae = sum(abs(e) for e in errs) / len(errs)

    # 実測から係数そのものを求め直す:  launch_h = a×path + (1-a)×face
    num = den = 0.0
    for s in have:
        x = s.club_path_deg - s.face_angle_deg
        y = s.launch_h_deg - s.face_angle_deg
        num += x * y; den += x * x
    a = num / den if den else float("nan")

    L = ["=" * 74,
         "  フェース角の推定 vs 実測（練習画面の表示が正しいかの検証）",
         "=" * 74,
         f"  対象 {len(have)}球",
         f"  推定のズレ  平均 {m:+.2f}°  ／ ばらつき ±{sd:.2f}°  ／ 平均絶対誤差 {mae:.2f}°",
         "-" * 74,
         f"  実測から求め直した係数:  打ち出し方向 = {a:.3f}×軌道 + {1-a:.3f}×フェース",
         f"  いま画面で使っている係数: 0.150×軌道 + 0.850×フェース"]
    if abs(a - 0.15) > 0.05:
        L.append(f"  → ずれている。画面の式を {a:.2f} / {1-a:.2f} に直すべき")
    else:
        L.append("  → 教科書どおりの値。画面の式はこのままでよい")
    L.append("=" * 74)
    return "\n".join(L)


# --- クラブ計測の実測分布 → カメラ要求仕様の答え合わせ ----------------------

def club_spec(shots) -> str:
    """入射角とクラブ軌道が実際どれくらいの範囲に散らばるかを見る。

    これが分かると『何度の精度で測れば意味があるのか』が決まり、
    club_analysis.py の必要フレームレートの前提を実データで確かめられる。
    """
    aoa = [s.aoa_deg for s in shots if s.aoa_deg is not None]
    path = [s.club_path_deg for s in shots if s.club_path_deg is not None]
    if not aoa and not path:
        return ""

    def stat(v):
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / len(v))
        return m, sd, min(v), max(v)

    L = ["=" * 74,
         "  クラブ計測の実測分布 → 必要な計測精度",
         "=" * 74,
         f"  {'項目':<14}{'球数':>6}{'平均':>9}{'ばらつき':>10}{'最小':>9}{'最大':>9}{'必要精度':>12}"]
    for name, v in (("入射角", aoa), ("クラブ軌道", path)):
        if not v:
            continue
        m, sd, lo, hi = stat(v)
        # ばらつきの 1/5 が見分けられれば、上達の変化を追える
        need = sd / 5
        L.append(f"  {name:<14}{len(v):>6}{m:>+8.1f}°{sd:>9.2f}°"
                 f"{lo:>+8.1f}°{hi:>+8.1f}°{need:>11.2f}°")
    L += ["-" * 74,
          "  『必要精度』= 実測のばらつきの 1/5。",
          "  お客様の上達やクラブの違いを数字で見せるには、この程度の分解能が要る。",
          "  club_analysis.py の required_fps() にこの値を渡せば、",
          "  必要なカメラのフレームレートが確定する。",
          "=" * 74]
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser(
        description="TrackMan / Mevo の実測CSVで弾道エンジンを検証・較正する")
    ap.add_argument("csv", help="TrackMan または myflightscope.com から書き出したCSV")
    ap.add_argument("--fit", action="store_true", help="自社の球に合わせて再較正する")
    ap.add_argument("--temp", type=float, default=20.0, help="気温[℃]")
    ap.add_argument("--alt", type=float, default=0.0, help="標高[m]")
    a = ap.parse_args()

    shots, units, cols = load(a.csv)
    print(f"読み込み {len(shots)}球 ／ 単位 {units} ／ 認識した列: {', '.join(cols)}")
    n_path = sum(1 for s in shots if s.club_path_deg is not None)
    n_aoa = sum(1 for s in shots if s.aoa_deg is not None)
    n_face = sum(1 for s in shots if s.face_angle_deg is not None)
    if n_path or n_aoa or n_face:
        print(f"クラブ計測あり: 軌道 {n_path}球 ／ 入射角 {n_aoa}球 ／ フェース角 {n_face}球")
    print()
    for block in (club_spec(shots), verify_face(shots)):
        if block:
            print(block); print()
    print(spin_model(shots)); print()
    print(verify(shots, a.temp, a.alt)); print()
    print(verify_multi(shots, a.temp, a.alt))
    if a.fit:
        print(); print(fit(shots, a.temp, a.alt))


if __name__ == "__main__":
    main()
