@echo off
chcp 65001 > nul
cd /d "%~dp0"
title スイング計測ベンチ
echo ================================================================
echo   スイング計測ベンチ
echo ================================================================
echo.

rem === 使える Python を探す =========================================
rem  姿勢推定に使う MediaPipe は Python 3.9〜3.12 のみ対応。
rem  3.13 が入っていても使えないので、3.12 以下を優先して探す。
setlocal enabledelayedexpansion
set PYEXE=
for %%V in (3.12 3.11 3.10 3.9) do (
  if "!PYEXE!"=="" (
    py -%%V -c "import sys" >nul 2>&1
    if not errorlevel 1 set "PYEXE=py -%%V"
  )
)
if "!PYEXE!"=="" (
  python -c "import sys; raise SystemExit(0 if (3,9)<=sys.version_info[:2]<=(3,12) else 1)" >nul 2>&1
  if not errorlevel 1 set "PYEXE=python"
)
if "!PYEXE!"=="" goto NOPYTHON

for /f "delims=" %%v in ('!PYEXE! -c "import sys;print(sys.version.split()[0])"') do set "PYVER=%%v"
echo   Python !PYVER! を使います
echo.

rem === 既存の環境が使えるか確認 =====================================
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -c "import sys; raise SystemExit(0 if (3,9)<=sys.version_info[:2]<=(3,12) else 1)" >nul 2>&1
  if errorlevel 1 (
    echo   前に作った環境が使えない Python でした。作り直します...
    rmdir /s /q ".venv"
  )
)

rem === 専用の環境を作る（1回目だけ）=================================
if not exist ".venv\Scripts\python.exe" (
  echo   初回準備をしています。5分ほどかかります。そのままお待ちください...
  echo.
  !PYEXE! -m venv .venv
  if errorlevel 1 goto VENVFAIL
  ".venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
  echo   必要なものを取得しています...
  ".venv\Scripts\python.exe" -m pip install -r requirements-bench.txt
  if errorlevel 1 goto PIPFAIL
  echo.
  echo   準備ができました。
  echo.
)

rem === 足りない部品がないか毎回確かめる =============================
rem  新しい機能を足すと必要な部品が増える。環境を作り直さないと入らない、
rem  という作りだと「昨日まで動いていたのに起動しない」ことになる。
rem  すでに入っていれば数秒で終わるので、毎回確かめる。
".venv\Scripts\python.exe" -c "import fastapi,uvicorn,cv2,mediapipe,yaml;import importlib;importlib.import_module('python_multipart')" >nul 2>&1
if errorlevel 1 (
  echo   足りない部品があるので取得します。少しお待ちください...
  ".venv\Scripts\python.exe" -m pip install -r requirements-bench.txt --quiet
  if errorlevel 1 goto PIPFAIL
  echo   取得しました。
  echo.
)

echo   起動します。ブラウザが自動で開きます。
echo   開かないときは  http://127.0.0.1:8770  を手で入力してください。
echo.
echo   終了するには、この黒い画面で Ctrl+C を押すか、閉じてください。
echo ----------------------------------------------------------------
echo.
".venv\Scripts\python.exe" run_bench.py
goto END

:NOPYTHON
echo ----------------------------------------------------------------
echo   使える Python が見つかりません
echo ----------------------------------------------------------------
echo.
py -0 2>nul
echo.
echo   姿勢推定に使う MediaPipe は Python 3.9〜3.12 にしか対応していません。
echo   3.13 が入っていても使えないので、3.12 を追加で入れてください。
echo   （3.13 はそのままで大丈夫です。消す必要はありません）
echo.
echo   1. https://www.python.org/downloads/release/python-3129/
echo   2. ページ下の "Windows installer (64-bit)" をダウンロード
echo   3. インストーラの最初の画面で
echo.
echo        [x] Add python.exe to PATH      ← チェックを入れる
echo.
echo   4. "Install Now" を押す
echo   5. この画面を閉じて start.bat をもう一度ダブルクリック
echo.
goto END

:VENVFAIL
echo.
echo   環境の作成に失敗しました。Python を入れ直すと直ることが多いです。
goto END

:PIPFAIL
echo.
echo   必要なものの取得に失敗しました。
echo   ・ネットワークにつながっているか
echo   ・上に赤い文字でどのパッケージが失敗したか出ていないか
echo   を確認して、その部分をコピーして送ってください。
goto END

:END
echo.
endlocal
pause
