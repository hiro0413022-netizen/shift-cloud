"use client";

import { useActionState, useRef, useState } from "react";
import { submitWebSignup, type WebSignupState } from "./actions";
import { yen } from "@/lib/frunk";
import { joinEstimate, validCoupon, JOIN_CAMPAIGN } from "@/lib/frank-billing-pure";
import { FRANK_TERMS_TEXT, FRANK_PRIVACY_URL } from "@/lib/frank-terms";
import { AddressFields } from "@/components/address-fields";
import { BirthDateInput } from "@/components/birth-date-input";
import { NameFields } from "@/components/name-fields";
import { corporateSpec } from "@yozan/core/frank-corporate";
import { jpPhoneError } from "@yozan/core/jp-phone";
import { SignaturePad } from "@/components/signature-pad";

type Plan = {
  id: string;
  name: string;
  monthly_price: number | null;
  joining_fee: number | null;
  max_bookings_per_day: number | null;
  note: string | null;
  is_corporate?: boolean | null;
  max_users?: number | null;
  max_open_slots?: number | null;
  companion_free?: boolean | null;
};

const field =
  "w-full rounded-xl border border-(--color-line) bg-(--color-panel-2) px-4 py-3 text-base text-(--color-txt) placeholder:text-(--color-dim)/60 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/15";
const label = "mb-1 block text-sm font-medium text-(--color-dim)";
const cardCls = "rounded-2xl border border-(--color-line) bg-(--color-panel) p-5";

/** 「2026-09-11」→ その月から4か月分の「9月」「10月」「11月」「12月」表記 */
function monthLabels(baseYmd: string): [string, string, string, string] {
  const d = new Date(`${baseYmd}T12:00:00+09:00`);
  const names: string[] = [];
  for (let i = 0; i < 4; i++) {
    const m = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + i, 1));
    names.push(`${m.getUTCMonth() + 1}月`);
  }
  return names as [string, string, string, string];
}

export function WebJoinForm({ plans }: { plans: Plan[] }) {
  const [state, action, pending] = useActionState<WebSignupState, FormData>(submitWebSignup, {});
  const [planId, setPlanId] = useState(plans.find((p) => p.name.includes("レギュラー"))?.id ?? plans[0]?.id ?? "");
  const [signature, setSignature] = useState("");
  const [coupon, setCoupon] = useState("");
  // 電話番号はその場で桁数を見る（#208）。
  // 打ち間違い（携帯なのに10桁など）に気づかないまま送られると、Squareが決済リンクの
  // 発行を拒否して「決済ページに行けないのに申込は済んでいる」状態になってしまう。
  // 会員ページのログインも電話番号の下4桁なので、間違ったままだと後でご本人が入れない。
  const [phone, setPhone] = useState("");
  const [phoneTouched, setPhoneTouched] = useState(false);
  const phoneMsg = phone.trim() === "" ? null : jpPhoneError(phone);
  const [step, setStep] = useState<"input" | "estimate">("input");
  const formRef = useRef<HTMLFormElement | null>(null);

  const todayYmd = new Date(Date.now() + 9 * 3600_000).toISOString().slice(0, 10);
  const plan = plans.find((p) => p.id === planId) ?? null;
  // 法人プラン（#195）。判定は @yozan/core/frank-corporate に寄せる（サーバーも同じ関数を通す）
  const spec = corporateSpec(plan);

  const toEstimate = () => {
    const form = formRef.current;
    if (!form) return;
    if (!form.reportValidity()) return;
    if (jpPhoneError(phone)) {
      setPhoneTouched(true);
      form.querySelector<HTMLInputElement>('input[name="phone"]')?.focus();
      return;
    }
    if (!signature) {
      alert("ご署名（電子サイン）をお願いします");
      return;
    }
    setStep("estimate");
    setTimeout(() => document.getElementById("join-estimate")?.scrollIntoView({ behavior: "smooth" }), 50);
  };

  if (state.ok) {
    // 決済ページを出せなかったときのフォールバック（Square未設定・発行失敗）。
    // ⚠ この画面はお支払いが済んでいない。前は成功と見分けが付かなかったので明記する（#208）
    return (
      <div className="rounded-2xl border border-amber-500/40 bg-(--color-panel) p-8 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-amber-500/10 text-3xl text-amber-400">✓</div>
        <p className="mt-3 text-lg font-semibold">入会のお申し込みを承りました</p>
        <p className="mt-2 text-sm text-(--color-dim)">
          ただいま決済ページをご用意できませんでした。<span className="font-medium text-(--color-txt)">お支払いはまだ完了していません。</span>
          <br />内容をスタッフが確認し、折り返しご連絡のうえお手続きいたします。
        </p>
      </div>
    );
  }

  return (
    <form ref={formRef} action={action} className="space-y-4">
      {/* プラン選択 */}
      <div className={`${cardCls} space-y-3`}>
        <p className="text-sm font-semibold text-(--color-txt)">ご希望のプラン <span className="text-rose-400">*</span></p>
        {plans.length === 0 ? (
          <p className="text-sm text-(--color-dim)">現在ご案内できるプランがありません。お手数ですが店舗にお問い合わせください。</p>
        ) : (
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {plans.map((p) => (
              <label
                key={p.id}
                className={`cursor-pointer rounded-xl border p-3 transition-colors ${
                  planId === p.id ? "border-accent bg-accent/10" : "border-(--color-line) bg-(--color-panel-2)"
                }`}
              >
                <input type="radio" name="plan_id" value={p.id} className="sr-only" required
                  checked={planId === p.id} onChange={() => setPlanId(p.id)} />
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-(--color-txt)">{p.name}</span>
                  {p.monthly_price != null && (
                    <span className="text-sm font-bold text-accent">{yen(p.monthly_price)}<span className="text-xs font-normal text-(--color-dim)">/月</span></span>
                  )}
                </div>
                <div className="mt-1 space-y-0.5 text-xs text-(--color-dim)">
                  {p.joining_fee != null && <div>入会金 {yen(p.joining_fee)}</div>}
                  {p.note && <div>{p.note}</div>}
                </div>
              </label>
            ))}
          </div>
        )}
        <p className="text-xs text-(--color-dim)">※ 表示金額はすべて税抜（月額）です。</p>
      </div>

      {/* ===== 法人プランのご契約情報（#195・2026-09-01） =====
          法人は「会社が契約して、社員の方が使う」形。月会費のお支払いは1本だけ、
          ご利用者はおひとりずつ会員番号を出す（誰が来たかが記録に残り、カルテも分けられる）。
          ご利用者は申込のときに全員ぶんご登録いただく（ユーザー確定）。 */}
      {spec.isCorporate && (
        <div className={`${cardCls} space-y-4`}>
          <div>
            <p className="text-sm font-semibold text-(--color-txt)">ご契約の法人について</p>
            <p className="mt-1 text-xs text-(--color-dim)">
              このプランは<span className="font-medium text-(--color-txt)">最大{spec.maxUsers}名様</span>までご登録いただけます。
              打席のご予約は御社合計で<span className="font-medium text-(--color-txt)">{spec.maxOpenSlots}コマ（1コマ＝1時間）</span>まで先にお取りいただけ、
              ご利用が済むとまた次のご予約をお取りいただけます。
              {spec.companionFree ? "同伴のビジター様は無料でご一緒いただけます。" : ""}
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <label className={label}>会社名・団体名 <span className="text-rose-400">*</span></label>
              <input name="company_name" required placeholder="株式会社ヨザン" className={field} />
            </div>
            <div className="col-span-2">
              <p className="text-xs text-(--color-dim)">
                このあとの「お客様情報」は<span className="font-medium text-(--color-txt)">ご担当者様（ご契約者）</span>のご入力をお願いします。
                月会費のご請求とご連絡は、ご担当者様宛にお送りします。
              </p>
            </div>
            <div className="col-span-2">
              <label className={label}>請求先メールアドレス（経理ご担当が別の場合）</label>
              <input name="billing_email" type="email" placeholder="keiri@example.co.jp" className={field} />
            </div>
            <div>
              <label className={label}>請求先 郵便番号</label>
              <input name="billing_postal_code" inputMode="numeric" placeholder="670-0000" className={field} />
            </div>
            <div>
              <label className={label}>請求先 住所</label>
              <input name="billing_address1" placeholder="兵庫県姫路市…" className={field} />
            </div>
            <p className="col-span-2 text-xs text-(--color-dim)">
              ※ 請求先が空欄のときは、ご担当者様のご連絡先へお送りします。
            </p>
          </div>

          {/* ご利用者は入会後に会員ページからご登録いただく（#206・無記名で申し込める）
              ここで全員のお名前を required にしていたため、
              「まだ誰が使うか決まっていない」会社はお申し込みできなかった。 */}
          <div className="space-y-2 border-t border-(--color-line) pt-4">
            <p className="text-sm font-semibold text-(--color-txt)">ご利用者のご登録について</p>
            <div className="rounded-xl border border-(--color-line) bg-(--color-panel-2) p-3 text-xs leading-relaxed text-(--color-dim)">
              <p>
                お申し込みの時点では、ご利用になる方のご入力は不要です。
                ご入会後、<span className="font-medium text-(--color-txt)">会員ページの【ご利用者の管理】</span>から、
                ご担当者様がいつでもご登録・入れ替えいただけます。
              </p>
              <p className="mt-2">
                ご登録いただける人数は
                <span className="font-medium text-(--color-txt)">
                  {spec.usersUnlimited ? "制限がありません" : `${spec.maxUsers}名様まで`}
                </span>
                です。ご担当者様ご自身がご利用になる場合も、同じ画面からご登録ください。
              </p>
              <p className="mt-2">
                ※ 打席をご利用になる方は、ご登録が必要です（おひとりずつ会員番号を発行し、
                会員証QRとレッスンカルテを分けてお作りするため）。
                ご予約は御社の合計{spec.maxOpenSlots}コマ（1コマ=1時間）まで、ご登録者で分け合ってお取りいただけます。
              </p>
            </div>
          </div>
        </div>
      )}

      {/* お客様情報 */}
      <div className={`${cardCls} space-y-4`}>
        <p className="text-sm font-semibold text-(--color-txt)">お客様情報</p>
        <div className="grid grid-cols-2 gap-3">
          <NameFields
            inputClassName={field}
            labelClassName={label}
            requiredMark={<span className="text-rose-400"> *</span>}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <BirthDateInput inputClassName={field} labelClassName={label} className="col-span-2" />
          <div className="col-span-2">
            <label className={label}>性別</label>
            <select name="gender" defaultValue="" className={field}>
              <option value="">選択</option>
              <option value="male">男</option>
              <option value="female">女</option>
              <option value="other">その他</option>
              <option value="unknown">無回答</option>
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={label}>電話番号 <span className="text-rose-400">*</span></label>
            <input
              name="phone" type="tel" required inputMode="tel" autoComplete="tel" placeholder="090-1234-5678"
              className={`${field} ${phoneTouched && phoneMsg ? "border-rose-400" : ""}`}
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              onBlur={() => setPhoneTouched(true)}
            />
            {phoneTouched && phoneMsg && <p className="mt-1 text-xs text-rose-400">{phoneMsg}</p>}
          </div>
          <div><label className={label}>メールアドレス <span className="text-rose-400">*</span></label><input name="email" type="email" required placeholder="example@mail.com" className={field} /></div>
        </div>
        <p className="text-xs text-(--color-dim)">※ 会員ページのログインに電話番号下4桁を、入会の控え（PDF）の送付にメールアドレスを使用します</p>
        <div className="grid grid-cols-2 gap-3">
          <AddressFields inputClassName={field} labelClassName={label} wideClassName="col-span-2" />
        </div>
        <div>
          <label className={label}>ご利用開始希望日</label>
          <input type="date" name="start_date" className={field} />
        </div>
        <div className="rounded-xl border border-(--color-line) bg-(--color-panel-2) px-4 py-3 text-sm text-(--color-dim)">
          <span className="font-medium text-(--color-txt)">お支払いはクレジットカードのみ</span>
          <br />
          このあと安全な決済ページ（Square）に進み、<span className="font-medium text-(--color-txt)">入会時のお支払い（入会金＋前取りの月会費）を1回で</span>
          お済ませいただきます。同時にカードが登録され、
          <span className="font-medium text-(--color-txt)">決済完了と同時にご入会が確定し、会員番号を発行</span>
          します（入会の控えPDFをメールでお送りします）。前取り期間のあとは、毎月自動でのお支払いになります。
        </div>
        <div>
          <label className={label}>クーポンコード（お持ちの方のみ）</label>
          <input name="coupon" autoCapitalize="none" autoCorrect="off" placeholder="例: FRANKGOLF2026" className={field}
            value={coupon} onChange={(e) => setCoupon(e.target.value)} />
          <p className="mt-1 text-xs text-(--color-dim)">ご紹介などのクーポンコードをお持ちの方はご入力ください（入会金が無料になります）</p>
        </div>
      </div>

      {/* 規約・同意・電子サイン */}
      <div className={`${cardCls} space-y-3`}>
        <p className="text-sm font-semibold text-(--color-txt)">会員規約のご確認・同意 <span className="text-rose-400">*</span></p>
        <div className="max-h-64 overflow-y-auto whitespace-pre-wrap rounded-xl border border-(--color-line) bg-(--color-panel-2) p-4 text-xs leading-relaxed text-(--color-dim)">
          {FRANK_TERMS_TEXT}
        </div>
        <label className="flex items-start gap-3 text-sm text-(--color-dim)">
          <input type="checkbox" name="consent_privacy" value="1" required className="mt-0.5 h-5 w-5 accent-(--color-accent)" />
          <span>
            <a href={FRANK_PRIVACY_URL} target="_blank" rel="noopener" className="font-medium text-(--color-gold) underline">プライバシーポリシー</a>
            に同意し、個人情報を入会手続き・サービス提供の目的で利用することに同意します。<span className="text-rose-400">*</span>
          </span>
        </label>
        <label className="flex items-start gap-3 text-sm text-(--color-dim)">
          <input type="checkbox" name="consent_terms" value="1" required className="mt-0.5 h-5 w-5 accent-(--color-accent)" />
          <span>上記の会員規約（休会・退会の規定を含む）を確認し、同意します。<span className="text-rose-400">*</span></span>
        </label>
        {/* 決済に関する同意は他の同意とまとめない（構想 §2-2・規約_モバイルオーダー同意条項_案）。
            まとめると「同意を取った」と言いにくくなるため、独立のチェックボックスにしている */}
        <label className="flex items-start gap-3 text-sm text-(--color-dim)">
          <input type="checkbox" name="consent_mobile_order" value="1" required className="mt-0.5 h-5 w-5 accent-(--color-accent)" />
          <span>
            <span className="font-medium text-(--color-txt)">会員ポータルからのご注文について同意します。</span>
            スマホからドリンク等をご注文いただいた場合、ご注文の時点で、月会費のお支払いにご登録いただいたクレジットカードに代金を請求します（注文ごとのカード操作はありません）。
            カードのご登録がない場合は、退店時に店頭でのお会計となります。<span className="text-rose-400">*</span>
          </span>
        </label>
        <div>
          <p className="mb-1 text-sm font-medium text-(--color-dim)">ご署名（電子サイン） <span className="text-rose-400">*</span></p>
          <SignaturePad value={signature} onChange={setSignature} />
          <input type="hidden" name="signature" value={signature} />
        </div>
      </div>

      {/* ===== お見積り（#131）: 入力内容の確認と、その場でお支払いいただく金額 ===== */}
      {step === "estimate" && plan && (() => {
        const est = joinEstimate({
          monthlyExTax: Number(plan.monthly_price ?? 0),
          joiningFeeExTax: Number(plan.joining_fee ?? 0),
          applyDateYmd: todayYmd,
          // クーポン入力を見積に反映（#136。実決済側と同じ分岐。キャンペーン終了後にズレていた）
          couponWaivesJoiningFee: !!validCoupon(coupon),
        });
        const [m0, m1, m2, m3] = monthLabels(todayYmd);
        const row = "flex items-baseline justify-between gap-3 py-2 border-b border-(--color-line)/60";
        return (
          <div id="join-estimate" className={`${cardCls} space-y-3 border-(--color-gold)/60`}>
            <p className="text-base font-bold text-(--color-txt)">お見積り（{plan.name}）</p>
            {spec.isCorporate && (
              <p className="rounded-lg bg-(--color-panel-2) p-3 text-xs text-(--color-dim)">
                法人プランのお支払いは<span className="font-medium text-(--color-txt)">御社で1本</span>です（ご利用者ごとの追加費用はありません）。
                ご入会が確定すると、ご登録いただいたご利用者お一人ずつに会員番号を発行し、ご担当者様宛にまとめてお送りします。
              </p>
            )}
            <div className="text-sm">
              <div className={row}>
                <span>入会金</span>
                <span>
                  {est.campaign ? (
                    <>
                      <s className="text-(--color-dim)">{est.joiningFeeTaxIncluded.toLocaleString()}円</s>
                      <span className="ml-2 font-bold text-emerald-500">→ 0円（年内入会キャンペーン）</span>
                    </>
                  ) : (
                    <span className="font-bold">{est.joiningFeeCharged.toLocaleString()}円（税込）</span>
                  )}
                </span>
              </div>
              {est.campaign && (
                <div className={row}>
                  <span>月会費（{m0}分・入会月）</span>
                  <span>
                    <s className="text-(--color-dim)">{est.monthlyTaxIncluded.toLocaleString()}円</s>
                    <span className="ml-2 font-bold text-emerald-500">→ 0円（キャンペーン）</span>
                  </span>
                </div>
              )}
              <div className={row}>
                <span>月会費 前取り（{m1}分＋{m2}分）</span>
                <span className="font-bold">{est.monthlyTaxIncluded.toLocaleString()}円 × {est.prepaidMonths} ＝ {(est.monthlyTaxIncluded * est.prepaidMonths).toLocaleString()}円（税込）</span>
              </div>
              <div className="flex items-baseline justify-between gap-3 pt-3">
                <span className="font-bold">本日のお支払い合計</span>
                <span className="text-2xl font-bold text-(--color-gold)">{est.totalDueNow.toLocaleString()}円<span className="text-xs font-normal">（税込）</span></span>
              </div>
            </div>
            <ul className="space-y-1 rounded-xl bg-(--color-panel-2) p-3 text-xs text-(--color-dim)">
              {/* 前取りした{m1}{m2}分の自動課金はスキップされるため、カードへの自動請求は{m3}分から（#137） */}
              <li>・{m3}以降の月会費は、毎月「入会日と同じ日」にご登録カードへ自動でお支払いになります（{m1}分・{m2}分は本日お支払い済みのため請求されません）。</li>
              <li>・キャンペーンでのご入会は、<span className="font-semibold text-(--color-txt)">{JOIN_CAMPAIGN.minMonths}か月間の継続</span>をお願いしています。</li>
              <li>・上記の合計を、決済ページで<span className="font-semibold text-(--color-txt)">1回でお支払い</span>いただきます（分割されません）。</li>
              <li>・決済は安全な決済ページ（Square）で行います。決済完了と同時に会員番号を発行します。</li>
            </ul>
          </div>
        );
      })()}

      {state.error && (
        <p className="rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-center text-sm text-rose-300">{state.error}</p>
      )}

      {step === "input" ? (
        <button type="button" onClick={toEstimate} className="w-full rounded-xl bg-accent py-4 text-lg font-semibold text-white transition-colors hover:bg-accent/90">
          お見積りを確認する
        </button>
      ) : (
        <div className="space-y-2">
          <button disabled={pending || !signature} className="w-full rounded-xl bg-accent py-4 text-lg font-semibold text-white transition-colors hover:bg-accent/90 disabled:opacity-50">
            {pending ? "決済ページへ移動中..." : "この内容で決済に進む"}
          </button>
          <button type="button" onClick={() => setStep("input")} className="w-full rounded-xl border border-(--color-line) py-3 text-sm text-(--color-dim) hover:text-(--color-txt)">
            ← 入力内容を修正する
          </button>
        </div>
      )}
      <p className="text-center text-xs text-(--color-dim)">
        決済ページ（Square）でのお支払い完了と同時にご入会が確定し、会員番号と入会の控え（PDF）をメールでお送りします。
      </p>
    </form>
  );
}
