"use client";

import { useActionState, useState } from "react";
import { submitSignup, type SignupState } from "./actions";
import { yen } from "@/lib/frunk";
import { OCCUPATIONS, CONTACT_METHODS } from "@/lib/walkin";
import { AddressFields } from "@/components/address-fields";
import { BirthDateInput } from "@/components/birth-date-input";
import { NameFields } from "@/components/name-fields";
import { SignaturePad } from "@/components/signature-pad";

type Plan = {
  id: string;
  name: string;
  monthly_price: number | null;
  joining_fee: number | null;
  max_bookings_per_day: number | null;
  note: string | null;
};

const field =
  "w-full rounded-xl border border-(--color-line) bg-white px-4 py-3 text-base text-(--color-txt) placeholder:text-(--color-dim)/60 focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/15";
const labelCls = "mb-1 block text-sm font-medium text-(--color-dim)";
const cardCls = "rounded-2xl border border-(--color-line) bg-(--color-panel) p-5 shadow-sm";

export function JoinForm({ token, plans }: { token: string; plans: Plan[] }) {
  const [state, action, pending] = useActionState<SignupState, FormData>(submitSignup, {});
  const [signature, setSignature] = useState("");
  const [planId, setPlanId] = useState(plans[0]?.id ?? "");

  if (state.ok) {
    return (
      <div className="rounded-2xl border border-emerald-200 bg-white p-8 text-center shadow-sm">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-50 text-3xl text-emerald-600">✓</div>
        <p className="mt-3 text-lg font-semibold">入会申込ありがとうございました</p>
        <p className="mt-2 text-sm text-(--color-dim)">内容をスタッフが確認し、手続きを進めます。タブレットをスタッフにお渡しください。</p>
      </div>
    );
  }

  return (
    <form action={action} className="space-y-4 pb-10">
      <input type="hidden" name="token" value={token} />
      <input type="hidden" name="signature" value={signature} />

      {/* プラン選択 */}
      <div className={`${cardCls} space-y-3`}>
        <p className="text-sm font-semibold text-(--color-txt)">ご希望のプラン <span className="text-rose-500">*</span></p>
        {plans.length === 0 ? (
          <p className="text-sm text-(--color-dim)">現在ご案内できるプランがありません。スタッフにお声がけください。</p>
        ) : (
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {plans.map((p) => (
              <label
                key={p.id}
                className={`cursor-pointer rounded-xl border p-3 transition-colors ${
                  planId === p.id ? "border-accent bg-accent/5" : "border-(--color-line) bg-white"
                }`}
              >
                <input
                  type="radio" name="plan_id" value={p.id} className="sr-only" required
                  checked={planId === p.id} onChange={() => setPlanId(p.id)}
                />
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-(--color-txt)">{p.name}</span>
                  {p.monthly_price != null && <span className="text-sm font-bold text-accent">{yen(p.monthly_price)}<span className="text-xs font-normal text-(--color-dim)">/月</span></span>}
                </div>
                <div className="mt-1 space-y-0.5 text-xs text-(--color-dim)">
                  {p.joining_fee != null && <div>入会金 {yen(p.joining_fee)}</div>}
                  {p.max_bookings_per_day != null && <div>1日の予約 {p.max_bookings_per_day}コマまで</div>}
                  {p.note && <div>{p.note}</div>}
                </div>
              </label>
            ))}
          </div>
        )}
      </div>

      {/* お客様情報 */}
      <div className={`${cardCls} space-y-4`}>
        <p className="text-sm font-semibold text-(--color-txt)">お客様情報</p>
        <div className="grid grid-cols-2 gap-3">
          <NameFields inputClassName={field} labelClassName={labelCls} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <BirthDateInput inputClassName={field} labelClassName={labelCls} className="col-span-2" />
          <div className="col-span-2">
            <label className={labelCls}>性別</label>
            <select name="gender" defaultValue="" className={field}>
              <option value="">選択</option>
              <option value="male">男</option>
              <option value="female">女</option>
              <option value="other">その他</option>
              <option value="unknown">無回答</option>
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>電話番号 <span className="text-rose-500">*</span></label>
            <input name="phone" type="tel" required placeholder="090-1234-5678" className={field} />
          </div>
          <div>
            <label className={labelCls}>メールアドレス</label>
            <input name="email" type="email" placeholder="example@mail.com" className={field} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <AddressFields inputClassName={field} labelClassName={labelCls} wideClassName="col-span-2" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className={labelCls}>ご職業</label>
            <select name="occupation" defaultValue="" className={field}>
              <option value="">選択</option>
              {OCCUPATIONS.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>
          <div>
            <label className={labelCls}>ご希望の連絡方法</label>
            <select name="contact_method" defaultValue="" className={field}>
              <option value="">選択</option>
              {CONTACT_METHODS.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>
        </div>
        <div>
          <label className={labelCls}>ご利用開始希望日</label>
          <input type="date" name="start_date" className={field} />
        </div>
        <div className="rounded-xl border border-(--color-line) bg-(--color-panel-2) px-4 py-3 text-sm text-(--color-dim)">
          <span className="font-medium text-(--color-txt)">お支払いはクレジットカードのみ</span>
          <br />
          月会費は毎月カードで自動お支払いになります。カードのご登録は、この申込のあと
          <span className="font-medium text-(--color-txt)">会員番号が発行されてから</span>
          （会員ページ）となります。この画面でカード情報を入力する必要はありません。
        </div>
      </div>

      {/* 同意・署名 */}
      <div className={`${cardCls} space-y-3`}>
        <p className="text-sm font-semibold text-(--color-txt)">ご確認・同意</p>
        <label className="flex items-start gap-3 text-sm">
          <input type="checkbox" name="consent_privacy" value="1" required className="mt-0.5 h-5 w-5 accent-(--color-accent)" />
          <span>個人情報を入会手続き・サービス提供の目的で利用することに同意します。<span className="text-rose-500">*</span></span>
        </label>
        <label className="flex items-start gap-3 text-sm">
          <input type="checkbox" name="consent_terms" value="1" required className="mt-0.5 h-5 w-5 accent-(--color-accent)" />
          <span>会員規約（<span className="font-medium text-(--color-txt)">休会・退会の規定</span>を含む）を確認し、同意します。<span className="text-rose-500">*</span></span>
        </label>
        <div>
          <label className={labelCls}>ご署名（指でご記入ください）<span className="text-rose-500">*</span></label>
          <SignaturePad value={signature} onChange={setSignature} />
        </div>
      </div>

      {state.error && <p className="text-center text-sm text-rose-600">{state.error}</p>}

      <button
        disabled={pending}
        className="w-full rounded-xl bg-accent py-4 text-lg font-semibold text-white shadow-sm transition-colors hover:bg-accent/90 disabled:opacity-50"
      >
        {pending ? "送信中..." : "この内容で入会を申し込む"}
      </button>
    </form>
  );
}
