# DECISIONS（決定事項ログ）

形式: `#N (日付) 決定内容 — 理由`。同じ議論を繰り返さない。

- #65 (2026-07-17) **cad_*/dms_* の「全員読める」ポリシーを書き換えではなく削除した**（migration 0066適用済、#64残件1）。発見: cad_availability/cad_clients/cad_dispatches/cad_invoices/cad_partners と dms_activities/dms_demos/dms_documents/dms_options/dms_plans/dms_projects/dms_prospects/dms_quote_settings/dms_quotes の14テーブルに `FOR SELECT TO authenticated USING (true)` が付いており、**ログインさえすれば会社・ロール無視でキャディ派遣の取引先/請求・営業先リスト/見積/活動履歴を全件読めた**（実測: authenticated で dms_prospects 13件・cad_clients 7件）。決定: **テナント条件への書き換え（`company_id = app.current_company_id()`）ではなく削除**。理由: 到達経路を全ファイル走査した結果 **アクセスは100% service_role（createAdmin）経由**で、RLSが効く `createClient()` からの `.from('cad_*'/'dms_*')` は **0件**（caddy-os 6ファイル・demo-sales 8ファイル）＝このポリシーは一度も使われていない死んだコードだった。書き換えても誰も通らない経路が残るだけで、**意図を偽って表明するポリシーは誤読のもと**。RLS有効＋ポリシー0 ＝ anon/authenticated 全拒否・service_roleのみ（BYPASSRLS）は gn_directives/vault_systems/ai_action_queue など既存13テーブルと同じ本リポジトリの標準形で、認可はアプリ層（use_caddy/use_demo_sales|view_hq、#3）が持つ。将来 authenticated から直接読む画面を作る時に `create policy <t>_tenant_read ... using (company_id = app.current_company_id())` を足す（company_id列は14テーブル全てに存在済み）。検証: ポリシー14→0・RLSは14テーブルとも有効のまま・他268ポリシーは無傷、authenticated ロールで dms_prospects/cad_clients/cad_invoices すべて0行（遮断）、service_role では 13件/7件（アプリ経路は無事）。巻き戻しSQLは 0066 ファイル末尾のコメント。**#64の残件は (2)vault平文パスワード (3)漏洩パスワード保護OFF (4)search_path・pg_net の3件**。

- #64 (2026-07-17) **DB権限監査 — anon から業務データへの到達経路を全部塞いだ**（migration 0064・0065適用済）。監査の発見: **(a) gnv_* 16ビューは SECURITY DEFINER（owner=postgres）で実体テーブルのRLSを迂回する**のに anon/authenticated に ALL が付いていた。防御は WHERE 句の `gn_ctx_company()`＝`current_setting('gn.company_id')` だけ、つまり「呼び出し側が自分で名乗る値」。実証: anon ロールで GUC を偽装して **gnv_members 243行・gnv_bank_txn 698行・gnv_staff 10行が読めた**。現時点では PostgREST が request.* 以外の GUC を設定できず未到達だったが、**set_config を呼ぶRPCを1本 anon に生やすだけで会員・財務・給与が全開**になる状態だった。**(b) public スキーマ約140テーブルに anon が ALL（TRUNCATE含む）**。これは Supabase の既定ACL（RLSで止める設計）で実害は無かったが、**TRUNCATE は RLS を無視する**うえ、新テーブルを作るたびに同じ穴が自動で開き「ポリシー付け忘れ＝即全開」だった。決定: **①0064** gnv_* を public/anon/authenticated から revoke し、**SELECT は gn_chat_reader のみ**（読み手は `gn_chat_query`(SECURITY DEFINER, owner=gn_chat_reader) 経由の1本だけ＝`ask-data.ts` は service_role から rpc 呼び出し）。**`security_invoker=true` にはしない** — gn_chat_reader は実体テーブルへのGRANTを持たないため invoker 化すると Ask Data が全滅する。**「RLS迂回=ビュー / テナント境界=gn_chat_queryの引数 / アクセス制御=GRANT」の三層**を維持し、入口の権限だけ締める。**②0065** anon のテーブル権限987件を剥奪＋`ALTER DEFAULT PRIVILEGES` で今後も付かないようにし、**関数の PUBLIC 既定 EXECUTE も停止**（#54/#55 は「anonからrevokeしたのにPUBLIC経由で実行できた」事故＝個別対応では再発する）。⚠️**運用ルール追加**: 今後 public/golfwing に関数を作る migration は末尾に `grant execute on function ... to service_role;` が必須（README §採番ルール）。既定付与は遡及しないので既存関数・現行アプリは無影響。検証: anon権限 987→0、authenticated 1014→902（差分112 = gnv_16本×7権限のみ＝業務テーブルは無傷）、攻撃再現は `permission denied for view gnv_members` で遮断、Ask Data 疎通OK。巻き戻しは `supabase/migrations/rollback_0064_0065.sql`。**残（未対応の監査所見）**: (1) `cad_*`/`dms_*` の SELECT ポリシーが `USING (true)`＝ログインさえすれば会社・ロール無視で全件読める（現状 authユーザー10名・1社なので実害ゼロだがテナント/権限モデルが壊れている）、(2) `vault_systems.password` が平文（2件。RLS拒否でservice_role専用だがDBダンプには平文で乗る）、(3) Auth の漏洩パスワード保護がOFF、(4) `gn_ctx_*`/`app.gen_secret` の search_path 未固定・pg_net が public スキーマ（軽微）。

- #63 (2026-07-16) **生成側を executor に配線＝各AIが自動で enqueue するようにした**（migration 0063適用済）。#62で器はできたが「生成側から enqueueAction を呼ぶ配線」が無く自動発火していなかった。決定（外部送信は**承認ゲートで試運転**＝ユーザー選択）: **(a) CEO AI日次**（`ceo-ai.ts runDailyCeoReport`）が終わりに**スタッフ朝連絡**を `staff_directive` で投入（`dedupe=staff-brief-YYYY-MM-DD`・1日1件）。試運転ポリシーで staff_directive=approval なので /executions に承認待ちで並び、承認するとハンドラが `gn_line_outbox` へ入れて公式LINE配信。**(b) CEO AIの各指示**（`saveInstructions`）を `agent_directive`（auto・内部）で配布＝承認待ちにせずAI社員へ流し監査に残す。**(c) 成果物承認**（`/deliverables reviewDeliverable`）で承認時に `internal_notify`（auto）を投入＝SNS/顧客の送信チャネルが未接続のため当面は「承認済み・手動対応」の記録/可視化、チャネル接続後に `sns_post` 等の実送信へ差し替える。**(d) 試運転ポリシー(0063)**: staff_directive/line_broadcast/sns_post を auto_undo→**approval** に退避（信頼できたら `ai_execution_policies` で auto_undo に戻す）、`agent_directive`=auto を追加。ハンドラ整理: 壊れていた `deliverable_generate`（引数不整合）を撤去し `agent_directive` を追加。**残**: 実チャネル接続時に (c) を実送信化、staff系を auto_undo に緩めるかの判断、prod_deployのVercel MCP接続。
- #62 (2026-07-16) **#61のexecutorを実装＝リスク階層が実際に動くようにした**（migration 0062適用済）。#61はスキーマ（ai_execution_policies）だけで「どこも読んでいない」状態だった。決定: 全AIアクションを1つの関所 `ai_action_queue` に通す。**(a) `lib/ai-execution.ts`**＝`enqueueAction()`（`resolveMode`でポリシー解決→ auto は scheduled_at=now / auto_undo は now+undo_minutes / approval は status='awaiting_approval'）、`runDueActions()`（scheduled_atを過ぎたqueuedを楽観ロックで拾いハンドラ実行→done/failed、**audit_logs(actor_type='ai')に必ず記録**）、`cancelAction`（取消枠内のqueuedのみ）、`approveAction/rejectAction`。**(b) ハンドラ登録**: test_notify（無害）/ internal_notify / report_generate / deliverable_generate / staff_directive・line_broadcast（gn_line_outboxへ実送信は取消枠経過後）。未登録は失敗扱い＝安全。**(c) `ai_action_queue`（0062）** status機械（queued/running/done/cancelled/failed/awaiting_approval）＋dedupe一意index、service_role専用。**(d) 実行tick**: `/api/cron/execute`（vercel.json 10分ごと）＋日次cronのついで。**(e) UI `/executions`**: 一覧・状態バッジ・取消枠カウントダウン・取消/承認/却下・「テスト実行」「今すぐ回す」。取消枠は"送ってから取消"ではなく**猶予中は実行を遅らせる**方式で安全。検証: test_notify=auto_undo/2分でenqueue→scheduled_at>now＝executor未取得を確認。**残（NEXT_TASKS C-0）**: 生成側（suggestions/agent-runner/staff-notice）からenqueueAction呼び出しの配線＝実運用の自動発火はまだ。prod_deployのVercel MCP接続も残。
- #61 (2026-07-16) **AI自律度をリスク階層モデルに移行＋Vault秘密のAI自動保存＋開発速度ルール緩和**（migration 0061適用済）。背景: 「AIは提案を保存するだけ・全部承認待ち」（旧AI_RULES原則1）が、承認者＝古川さん自身を律速にし、VISION の「現場から抜けても回る」と構造的に矛盾していた。決定: **(a) 実行を3階層に**＝`ai_execution_policies`（action_typeごと・DB編集可）で **auto（承認不要・監査ログのみ）/ auto_undo（自動実行＋取消枠 undo_deadline）/ approval（承認必須）** に振り分け。緑=report_generate/kpi_refresh/draft_create/deliverable_generate/internal_notify/issue_create/pr_open/test_run/data_analysis/order_candidate、黄=staff_directive(15分)/line_broadcast(15分)/sns_post(30分)、赤=prod_deploy/db_change/payment/customer_message/personal_info/contract/hiring/price_change/policy_change（VISION §7の赤リスト維持）。`ai_suggestions` に `execution_mode`/`undo_deadline` 追加、既定=approval（安全側）。**全実行を audit_logs(actor_type='ai') に記録**。⚠️実際に自動実行が走るのは executor が execution_mode/policies を読むよう配線してから（NEXT_TASKS）＝適用時点は挙動不変。**(b) Vaultのパスワードを「ユーザーが/vault手入力」から「AIがMCPで生成・保存」へ**（#26更新）。`vault_systems` に `secret_source(generated/external/manual)`/`managed_by(user/ai)` 追加、`app.gen_secret()` で強い秘密を自動生成。AI発行のログインは generated、外部プロバイダ発行値は渡せば external で直接保存（値はチャットに残るトレードオフを許容）。**(c) 開発速度ルール緩和**（DEVELOPMENT_RULES 7・8）＝複数機能まとめ実装可・影響範囲は横断的に読む。**(d) 新アプリのデプロイはVercel MCPでClaudeが実行**（prod_deployはapproval）。据え置き: 給与単一計算式・git切れ検査・Vault二重ゲート・DB権限RLS。
- #60 (2026-07-15) **AI社員の「指示書止まり」を解消し、成果物を生成→レビュー→承認できるようにした**。発見: CEO AIは毎朝、各AI社員宛ての指示書（prompts, status=draft）までは自動生成していたが、その指示を受けて実際の成果物（SNS投稿案・広告見出し等）を作る一段が無く、「AI社員は working なのに成果物がどこにも無い」状態だった（実行ログ0件）。
  対策: ①**migration 0060** で `ai_execution_logs` に `prompt_id / review_status(pending|approved|rejected) / reviewed_at / reviewed_by` を追加（成果物は既存 `output/tokens_used/cost_estimate_yen` 列に保存）。②`lib/agent-runner.ts`（`generateDeliverables`）を新設 — 指示書を入力にClaude API（AGENT_AI_MODEL→CEO_AI_MODEL→haiku）で成果物本文を生成し ai_execution_logs へ review_status='pending' で保存。宛先AIごとに成果物の型を指定（sns_ai=投稿3案＋Google広告＋ターゲ＋予算配分、他は汎用テンプレ）。③`ceo-ai.ts` の日次実行(`runDailyCeoReport`)に連結＝**毎朝、指示書と同時に成果物まで自動生成**（ANTHROPIC_API_KEY未設定ならスキップ、指示書は残る。1回の上限5件でコスト暴発防止）。④**新ページ `/deliverables`（成果物レビュー）** ＋承認/却下 server action＋サイドバー導線。承認しても配信・課金はしない（下書き確定のみ、VISION §7維持）。第一弾としてSNS AIの「初心者向けゴルフ体験キャンペーン」成果物を1件シード投入。
- #53 (2026-07-14) **労働時間・人件費の計算は1本に集約する（画面ごとの独自集計を禁止）**。発見: 本部ダッシュボード(/hq)が独自集計しており給与画面(/admin/payroll)とズレていた — (a) **15分丸め（companies.settings.rounding_minutes=15）を掛けていない**（102時間36分→正 100時間45分）、(b) **月給者(wage_type='monthly')を時給0円扱い**＝月給が人件費に入らない、(c) 交通費・手当・残業割増(overtime_rate)が未反映、(d) 期間が `${ym}-31` 固定（AUDIT D-1と同じ日付バグ）。**同じ穴がGENESISのKPI関数 `refresh_shift_cloud_kpis`(0008) にもあった**（KPI「人件費」が同じく過小）。
  対策（再発防止まで込み）: ①集計の正典を `lib/labor-summary.ts`（`summarizeLabor`）に新設し、金額は `payroll-calc.ts` の `calcMonthlyPayroll` に委譲。/hq はこれを呼ぶだけにした。②**migration 0046** で `refresh_shift_cloud_kpis` を給与と同じ式（日次丸め＋月給＋交通費）に修正。③**tests/labor-summary.test.ts**（2026-07実データで丸め・月給・交通費・按分・休憩の二重控除を1円/1分単位で固定）。④**scripts/check-labor-logic.mjs をCIに追加** — `work_minutes` の直接集計 / `hourly_wage`・`monthly_salary` の直接乗除算 / `${ym}-31` の決め打ち を禁止（正典ファイルのみ許可）。⑤DEVELOPMENT_RULES.md に「給与・労働時間の計算」節。
  **④のガードが導入直後に既存バグを4件検出**: スタッフ画面(/home)の今月労働時間が丸めなし（給与見込みと分数が食い違う）、`${ym}-31` 決め打ちが 勤怠管理・月末照合・スタッフ画面・caddy-os の計4箇所 → すべて修正。
  実測（2026年7月）: 総労働時間 102時間36分 → **100時間45分**、人件費 ¥256,203 → **¥883,982**（時給者253,982＋月給者4名630,000＝古川80,000/小川80,000/山本200,000/林270,000）。**月給者が消えていた影響は古川さん1人ではなかった**。休憩は attendance_days.work_minutes の時点で控除済み（recalcAttendance = 拘束 − 休憩）＝二重控除も未控除も無いことを確認。

> ⚠採番注意: #28と#29は歴史的に重複採番（各2件）。参照を壊さないため振り直さず【#28a/#28b】【#29a/#29b】の注記で区別する（AUDIT_2026-07-11）。**次に使う番号は #228**。

- #1 (2026-07-02) リポジトリは軽量モノレポ（npm workspaces、単一Next.jsアプリ＋packages分離）。Turborepoはアプリ2つ目から — MVP速度優先、構造だけ将来対応
- #2 (2026-07-02) 認証はメール＋パスワード基本、メールなしスタッフはログインID＋パスワード（擬似メール方式）— アルバイトがメール非保持の可能性
- #3 (2026-07-02) RLSはテナント分離に限定し、ロール別権限はアプリ層で制御。例外として給与系テーブル（staff_wages, payroll_items）のみRLSでも保護 — RLSに全権限ロジックを持たせると保守不能
- #4 (2026-07-02) 金額はinteger円、時間はinteger分。浮動小数禁止 — 丸め誤差防止
- #5 (2026-07-02) 論理削除（deleted_at）を標準。物理削除禁止 — 監査・復元要件
- #6 (2026-07-02) 打刻は修正レコード積み上げ方式（元レコード不変）— 改ざん防止・労基対応
- #7 (2026-07-02) AI提案はMVPでは保存のみ。実行は人間承認後 — 安全性
- #8 (2026-07-02) Supabaseは新規プロジェクト作成（ユーザー承認済み）
- #9 (2026-07-02) 実働は1分単位で記録。給与計算時の丸めは会社設定（デフォルト: 丸めなし）— 後日ユーザー確認で変更可
- #10 (2026-07-02) MVP期間中はpackages/分離を保留し、apps/shift-cloud/src/lib配下に集約。UIはshadcn/ui相当の自作プリミティブ（src/components/ui.tsx）— ファイル数・複雑性削減。2アプリ目でpackages化
- #11 (2026-07-02) 管理系の書き込みはservice_roleクライアント＋requireActor権限チェック＋監査ログ。読み取りはスタッフ画面=RLSクライアント、管理画面=service_role — RLSはテナント分離専任（#3の具体化）
- #12 (2026-07-02) キオスクは端末トークン（sha256ハッシュ保存）認証。URLは発行時のみ表示
- #13 (2026-07-02) シフトはスタッフ主導: 提出→自動ドラフト（主店舗）→管理者確認で確定。人員不足時は「出勤募集」（応募→採用で確定・人数充足で自動クローズ）— ユーザー要望による運用転換
- #14 (2026-07-04) リポジトリはPublic運用。旧Vercelプロジェクト`shift-cloud`は削除（稼働は`shift-cloud-shift-cloud`）— ※ファイル破損によりCHANGELOG 2026-07-04から復元
- #15 (2026-07-04) （前半欠損のため一部復元不能）…クレジット節約。共通化はGenesis安定後に実施
- #16 (2026-07-04) Kernelテーブルは同一Supabaseプロジェクト(qrgpblnnhdudigarrtuz)に追加（migration 0004、追加のみ・既存テーブル変更なし）。audit_logs / approval_requests / notifications / ai_suggestions / integration_configs は既存を再利用
- #17 (2026-07-04) Kernelテーブルも既存標準準拠: company_id + RLSテナント分離（app.current_company_id()）、書き込みはservice_role+requireActor、論理削除、updated_atトリガー
- #18 (2026-07-04) Genesis UIのアクセスは `view_hq` 権限保持者のみ（本部/オーナー向けコックピット）。Webhook受信はconnectorごとのトークン（sha256ハッシュ保存、#12と同方式）
- #19 (2026-07-04) GolfOrder移行は方式B（DB先行: Hono維持でD1→Supabase差し替え、UIは後続でNext.js化）。移行中の新規開発凍結はユーザー許容済み
- #20 (2026-07-04) GolfOrderのテナント: 実店舗はGOLF WING宝塚のみ → tenants/usersテーブル廃止、companies/stores/staff+Supabase Authに統合。デモテナントは移行後廃止
- #21 (2026-07-06) 財務管理は自作financeモジュール（fin_segments/fin_categories/fin_entries、事業別月次PL）。データは税理士資料の手入力＋CSV取込を正とし、会計ソフトAPI連携・資金繰り予測・予実管理は後続フェーズ
- #22 (2026-07-06) 会員・体験予約・入会/退会KPIはGOLF WINGの会員管理「Smart Hello」（システムディ、公開API無し）からCSV手動エクスポート→Genesis取込で接続（#21の財務と同型）。API連携は提供され次第切替
- #23 (2026-07-06) 体験予約受付はGenesisに自作（member-osモジュール、migration 0011: mbr_guests/mbr_trial_bookings/mbr_intake_tokens）。紙+Excel運用を廃止し、スタッフWeb入力（/members）＋お客様タブレット自己入力（公開ルート /intake/[token]、トークン#12方式）＋電子サインで受付。体験予約数・入会率は refresh_member_kpis で自動集計（0010の手動更新を置換）。設計: docs/modules/member-os/TRIAL_INTAKE.md
- #24 (2026-07-06) 予約システムの棲み分け: 当面GOLF WING(宝塚)の予約はSmart Hello継続。姫路FRUNK GOLFはGenesis自作の予約システムを新規導入 → member-osは体験受付から予約・会員名簿へ拡張する前提でマルチストア設計（company_id/store_id分離）。会員名簿本体も将来Genesisへ移管
- #25 (2026-07-06) CEO AIの頭脳はアプリ内蔵のClaude API呼び出し（ANTHROPIC_API_KEY設定時、モデルはCEO_AI_MODELで変更可・既定claude-haiku-4-5）。キー未設定/失敗時はルールベースに自動フォールバックし日次レポートは必ず生成。毎朝6時(JST)にVercel Cronで自動実行（/api/cron/daily、CRON_SECRET認証）。指示案はprompts下書きとして保存し実行はしない（VISION §7）
- #26 (2026-07-06) システム台帳（Vault）はGenesis内ページ `/vault` ＋ `vault_systems` テーブルで一元管理。RLSポリシーを作らずservice_role専用（給与系と同等保護、#3の例外扱い）。アクセスは view_hq ログイン＋Vaultパスワードの二重ゲート（sha256照合、`VAULT_PASSWORD` envで変更可・平文はコードに置かない）。秘密情報はDBのみに保存しPublicリポジトリ（#14）には一切書かない。新システムはページ上のフォーム or AI経由でDB行追加＝ページは常に自動反映
- #28【a】(2026-07-08) 経営ダッシュボード（Genesisトップ）は「全体スコア→経営KPI→事業別→店舗ドリルダウン」構成に刷新（旧レーダー司令室を廃止）。事業別=fin_segmentsの当月PL、店舗別の会員数・今月入会/退会=会員名簿(mbr_members)から集計。**店舗紐付けはスキーマ変更なしのアプリ層マッピング**（mbr_members.store_nameテキスト→store名称、fin_segments→store 1:1で売上按分）＝getBusinessBreakdown()に集約。store_id列追加やSmart Hello取込側の店舗付与は、姫路開業でstore_nameが複数化する時点で対応（それまで全会員は宝塚に集約）
- #29【a】(2026-07-07) 書類・証憑管理は**経理系と法務系で分離**。経理系（請求書・見積・領収書・レシート＝金額突合と電帳法保存）はMoney OSの `mon_receipts` が担当（後続）、法務系（契約書・覚書・規約・NDA＝期限管理と法的リスク）は独立アプリ **Legal OS** が担当。両者はDB共有のため `leg_document_id` の相互リンク1本のみで連携（二重管理回避）
- #30 (2026-07-07) Legal OSは**GENESIS内モジュールではなく独立アプリ `apps/legal-os`**（別Vercel・DB共有・`/api/v1`）。理由: GENESISは古川さん専用の司令室にするため、他者がアップロード等で触る面はGENESIS外に出す（member-os #27・Money OSと同型の勝ちパターン）。GENESIS本体はLegal OSデータの閲覧＋承認のみで入力面を持たない。締結・更新・解約の正式承認はGENESIS側approval_requestsで古川さんが実施（VISION §7）。migration 0024適用済（leg_*・Storage `legal-docs`）。稼働時にvault_systems登録（#26/Vaultルール）
- #27 (2026-07-06) 体験受付（member-os）をGenesis内ページから独立アプリへ分離（Shift Cloudと同型）。`apps/member-os` を新Vercelプロジェクト（member-os）として別URL・別ログインで運用。Genesisのサイドバー項目とルート（/members・/intake）は撤去。DBは同一Supabase(qrgpblnnhdudigarrtuz)を共有し mbr_* と refresh_member_kpis はそのまま → 体験予約数・入会率KPIは従来どおりGenesisへ自動流入（Shift Cloudの労務KPIと同じ関係）。認可は新権限 `use_reception` または `view_hq`（#18の経営層）で入れる二段構え。#23の「Genesisに自作」を分離運用へ更新
- #31 (2026-07-08) ゴルフ事業の月次売上 = **店頭決済（売上台帳=物販/利用料/スポット、税抜「金額」列合計）＋ 月会費予測（口座振替の定額会費。ファイン実績が届くまでの暫定、会員種別×単価）**。単価(税抜): レギュラー17,500/マスター22,500/プラチナレギュラー17,500/ライト9,800/法人55,000(1契約=法人会員、法人会員2枚目は0)/レギュラー家族割12,250/チケット・モニター・トライアル・スタッフ0。課金対象=在籍(退会は退会月末まで課金=leave_date>=当月初)かつ休会でない(suspend_start〜suspend_end, "YYYY/MM"月単位)。fin_entriesは(company,segment,category,month)がUNIQUEで売上高は月×事業1行のみ→店頭+月会費を**合算1行**、source='ledger+forecast'、memoに内訳。裏付け: 5月実績売上高4,720,335=台帳1,242,185+月会費3,478,150。6月取込済=5,046,856(台帳1,487,906+月会費3,558,950)。**注意: 6月ゴルフ経費は未入力→利益過大（Money OSで別途取込要）。7月以降と自動化(アプリ化)は未実装**
- #32 (2026-07-08) 月会費予測を自動化（#31の実装）。migration 0028: fin_categories `membership_forecast`（月会費（予測）/revenue）＋関数 `refresh_golfwing_membership_forecast`（会員種別×単価で当月を算出しfin_entriesへupsert、source='forecast'。**実績優先**＝mon_salesに当月の'月会費'があれば予測を論理削除）。日次cron(runDailyCeoReport)に組込。6月は売上高=店頭1,487,906＋月会費（予測）3,558,950に分離、7月予測3,526,650を生成。migration 0029: **KPI/ダッシュボードのヘッドラインは「最新の完了月」**に変更（refresh_finance_kpisは当月除外、getBusinessBreakdownもtarget_month<当月初でPL表示＋当月はforecastTotalを「見込み」バナー表示）＝進行中の当月(予測のみ)で数字が急落して見える問題を回避。DB適用済・アプリ側はデプロイ要
- #28【b】(2026-07-06) member-osの体験受付を「一時利用者名簿」方式に再定義（GOLF WING宝塚）。予約起点をやめ、店頭常設タブレットの予約なし自己入力＋スタッフ追記で紙/手入力Excelを廃止（設計: docs/modules/member-os/WALKIN_LEDGER.md）。決定: (1)利用区分は体験利用/フィッティング/打席利用/ビジター打席/その他の5固定 (2)Excel出力は「一時利用顧客名簿」シートのみ現行同一・会員集計タブは作らない (3)会員数/会費等はSmart HelloのCSV/Excel取込で自動化（#22、別系統） (4)既存約2,415行を移行。新テーブル mbr_walkin_visits（+既存mbr_guests再利用）。姫路FRUNK GOLFの予約システム（#24）は別途
- #29【b】(2026-07-06) LINE公式アカウント連携は n8n を統合ハブに置く（ネイティブMCPを増やさず、SNS/LINE/将来の会計もn8n経由でSupabaseに集約する方針）。受信は n8n Webhook で受け、LINE署名（channel secret）で検証（#18のconnectorトークン方式に準拠）。4フェーズで段階導入: **A.顧客対応集約** = LINE受信→n8n→`sec_inquiries`に `source='line'`・`external_id`=LINEメッセージIDで重複排除insert（既存CEO Inbox #17がそのまま受け皿＝スキーマ変更ゼロ、`handled_by_agent='customer_ai'`）。返信は既存の承認フロー（status=approved後にn8nがLINE reply/push＝外部送信は承認必須 VISION §7）。**B.体験予約取込** = 自由文パースはせず、LINEリッチメニュー「体験予約」から member-os 公開 `/intake`（#23の既存導線）へ誘導し、体験予約数・入会率KPIは既存 `refresh_member_kpis` で自動。**C.配信** = SNS AI生成文を承認→n8nが LINE broadcast/narrowcast で配信（承認必須）。**D.Instagram** = Meta Graph API を n8n で（後続）。LINE公式アカウントとMessaging APIチャネルは `vault_systems` に登録（#26）。channel access token / secret は Vault(DB) と n8n credential に保存し、Publicリポジトリ（#14）には置かない
- #34 (2026-07-09) GOLF WINGビジター向けのシャフトフィッティング予約は独立アプリ **Reserve OS**（`apps/reserve-os`・別Vercel `reserve-os`・DB共有・ポート3004）。member-os/survey-os等と同型（入力面は独立、GENESISは閲覧/承認）。**既存 res_bookings（0020, 姫路FRUNK=即時枠予約）とは別概念の「申込型」**＝お客様は日時を即確定できず、**候補日時を第3希望まで（必須）＋事前ヒアリング**を送信し、スタッフが対応可能なスタッフ有無・フィッティング枠重複を**目視で確認して確定**する（ユーザー指定の運用）。migration `0032_reserve_os.sql` 適用済（res_services/res_requests、RLS標準準拠）。サービスは `res_services.slug/category` で駆動し**他サービス（クラブFT/体験レッスン）へ行追加のみで流用**可。メール（`src/lib/mail.ts`, Resend汎用レイヤ）: 申込→**YOZANアドレスからGOLF WINGアドレスへ通知**（reply_to=お客様、スタッフは返信でお客様対応）＋お客様受付確認＋確定連絡。**LINE通知は notifyLine() フックのみで後続**（#29 の n8n 統合ハブ経由）。Googleスプレッドシート自動同期は当面CSV書き出しで代替（後回し）。vault_systems登録済（#26）。正典 docs/modules/reserve-os/SYSTEM.md
- #33 (2026-07-09) アンケート/情報収集は独立アプリ **Survey OS**（`apps/survey-os`・別Vercel `survey-os`・DB共有）。member-os/legal-os/money-osと同型（入力面は独立、GENESISは閲覧/承認）。**公開回答は匿名・トークンレス**（slug + status='open' を検証し service_role で書き込み）、管理は `view_hq`/`use_survey`。汎用スキーマ `svy_surveys/svy_questions/svy_answers/svy_responses`（migration 0030適用済）で単一/複数/自由記述/**順位付け(ドラッグ&ドロップ)**/スケールに対応。順位付けは **ボルダ平均(正規化0-100)＋平均順位の両方**で集計しコーチ強み弱みヒートマップを自動生成。GOLF WING会員アンケート（コーチ評価13順位＋WING NOTE、対象コーチ5名/小川うらら除外）を 0031 で投入（slug=`golfwing-2026`、公開中）。回答10件ごとに company_events へ記録。**アンケートビルダー（項目編集GUI）はフェーズ2**（現状はseed/AI経由で作成）。正典 docs/modules/survey-os/SYSTEM.md
- #35 (2026-07-11) **packages化を履行（#10を更新）**: `packages/core`（auth/kernel/supabase/middleware）を新設し、**新規アプリのみ**が使用。既存11アプリの `src/lib` コピーは全て内容が分岐済みのため一括移行せず、1アプリずつ・Vercelビルド確認付きで段階移行（バックログB-6）。新規アプリは `npm run new-app`（scripts/new-app.mjs + templates/app-template）で雛形生成 — ログイン・認可・レイアウト・/api/v1・独立アプリ方式（#30/#33/#34の勝ちパターン）を型として固定化
- #36 (2026-07-11) **金額ロジックはテスト必須**: 給与計算・CSV取込・月会費単価の純粋ロジックを `payroll-calc.ts` / `money-util.ts` 等に抽出し `tests/`（node --test）で固定。CI（.github/workflows/ci.yml）が push/PR ごとに テスト＋tsc＋next build を全Nextアプリで実行。ローカル（サンドボックス）のtsc/buildは信頼せずCI・Vercelビルドを正とする。※buildPayrollの「月末日を-31固定」バグ（30日以下の月で給与計算失敗）を本決定と同時に修正
- #37 (2026-07-11) **KPI整合性チェッカー**を日次cron（runDailyCeoReport）に組込（apps/genesis/src/lib/kpi-checks.ts、Claude API不要のルールベース）。完了月の経費0円（利益過大）／forecast残存（実績未入力）／売上前月比±50%超／5大KPI目標未設定 を検知し「今日、古川さんが判断すべきこと」の先頭に表示 — 間違った数字でCEO AIが判断する事故を止める
- #38 (2026-07-11) **migration採番ルール**: 過去の番号重複6ペア（0020/0022/0023/0024/0027/0031、全て適用済）はリネームせず凍結し、supabase/migrations/README.md を適用台帳とする。次番号は0034〜、作成時に台帳を更新。追加のみの原則は不変
- #39 (2026-07-11) **時給の月中変更は日付按分**（監査D-3の解消）: 給与計算は日ごとに「その日に有効な賃金（staff_wages.effective_from <= 勤務日の最新）」を適用し、レート別に集計して合算（calcMonthlyPayroll）。交通費/日も同様。賃金開始日より前の勤務日は**最古の賃金行へフォールバック**（登録遅れで0円になる事故を防ぐ）。単一時給のスタッフは従来計算と完全一致（テストで固定）。レート別内訳は payroll_items.detail.wage_periods に保存（説明可能性）。旧実装（月末時点の賃金を月全体へ遡及）を置換
- #40 (2026-07-11) **Legal OS フェーズ2（legal_ai接続）**: (a) 日次チェック=ルールベース（apps/genesis/src/lib/legal-checks.ts）— 解約判断期日90日以内/契約満了60日以内/高リスク/確認待ち14日滞留 を「今日、古川さんが判断すべきこと」へ合流。 (b) 自動抽出=Claude API（legal-ai.ts）— 日次cronで未抽出の契約書を**1件/日**、PDF/画像を読み相手方・契約期間・自動更新・解約通知日数・リスク・要点を抽出し**提案として保存**（人の入力は上書きしない・提案全文はdetail.ai_extracted・status=under_review・確定は人=VISION §7）。next_action_date自動計算とリマインダー自動生成つき。APIキー未設定なら何もしない（日次レポートに影響なし）。モデルはLEGAL_AI_MODEL envで変更可（既定claude-haiku-4-5）
- #41 (2026-07-11) **Money OS mon_receipts（経理証憑）フェーズ1**: migration 0034適用済 — mon_receipts（種別invoice/quote/receipt/delivery/other・発行日・発行元・金額・突合状態unmatched/matched/archived・mon_expense_id/mon_bank_txn_id/leg_document_idリンク #29a）＋プライベートバケット mon-receipts（legal-docsと同方式）。money-golfwingに /receipts（アップロード・一覧・編集・論理削除。署名付きURL閲覧、Server Actions bodySizeLimit 8MB）。**「まず撮って登録→後で整える」運用**。OCR自動読取・経費自動起票は経理AIフェーズ（後続）。削除は論理削除のみでStorage実体は残す（電帳法配慮）
- #42 (2026-07-11) **経理AI フェーズ1（証憑OCR自動読取）**: 日次cronで未読取（ocr_text null）のmon_receiptsを最大3件、Claude APIで読取り（apps/genesis/src/lib/receipt-ai.ts）。発行日・金額（税込整数円）・発行元・種別を**空欄の項目のみ**補完（人の入力は上書きしない）。読取ダイジェストをocr_textへ保存（再処理防止の目印兼用）。**mon_expenseへの自動起票はフェーズ2**（読取精度を実運用で確認してから、VISION §7の段階導入）。モデルはRECEIPT_AI_MODEL envで変更可（既定claude-haiku-4-5）
- #44 (2026-07-11) **給与に「月給制」と「手当」を実装**（migration 0035）。実際の給与明細（260625/260724支給）を解析し、支給式を確定＝**時給者: 時給×実労働 + 交通費(日額)×出勤日数 + Σ手当 / 月給者: 月給(固定) + 交通費(実費) + Σ手当**。手当= パーソナル(単価×件数)/フィッティング紹介料/コンペ/ラウンドレッスン。新テーブル `payroll_allowances`（月次実績）・`staff_allowance_rates`（単価マスタ）、`staff_wages.wage_type`（hourly|monthly）。**勤怠0日の月給者（役員）は includeStaffIds に入れないと給与が消える**ためbuildPayrollで明示。tests/payroll-allowances.test.ts が明細金額を1円単位で固定（9人全員一致を確認）。付随: staffの店舗名ゴミ3件（在籍KPIが10人→7人の水増しだった）を削除、春馬凡夫→卜部凡夫に名寄せ、林和希/山本公嗣/小川うららを追加
- #45 (2026-07-11) **Caddy OS（キャディ派遣のアプリ化）**: 独立アプリ `apps/caddy-os`（別Vercel・DB共有・port 3005・権限 use_caddy|view_hq）。migration 0036（cad_clients/cad_partners/cad_dispatches＋`refresh_caddy_finance`）。**1派遣=1行**に売上と原価を持ち行単位で粗利が出る。**社員の派遣は原価0**（人件費は給与側 #44）＝ Excel運用で起きていた「林さんの交通費を委託料台帳と給与の両方で計上」する二重計上をCHECK制約で構造的に禁止。財務へは `refresh_caddy_finance` が fin_entries へ自動集約（source='caddy_os'、人件費は触らない）。Excel全6ヶ月（272派遣）を移行済・合計は台帳と全月一致。**事業の実態: 半年で売上433万・粗利211万・自社人件費164万＝事業利益48万（薄利）。林さんの固定給27万が固定費のため月商80万を切ると赤字**（ダッシュボードに常時警告）。移行時に「委託先マスタ未登録のまま台帳に出ていた委託先（日高真里子さん）」を検出。正典 docs/modules/caddy-os/SYSTEM.md
- #46 (2026-07-12) **Caddy OS フェーズ2 — 一括入力・請求書・出勤可否**（migration 0037/0038）。(a) **一括入力**: 派遣は月40〜60件あり1件ずつのフォームでは運用に耐えないため、スプレッドシート風グリッド（Enterで次行・日付/取引先を引き継ぐ・取引先選択で単価自動・委託先選択で委託料自動）に置換。登録後 `renumber_caddy_seq` で採番を日付順に振り直す（Excelの採番コピペ事故を構造で防ぐ）。(b) **請求書**: 実物PDF（2026年6月・加古川）を解析し仕様確定＝明細は「キャディ業務料（YYYY年M月D日 分）」×その日の人工数×単価、小計→税10%(floor)→合計（外税）。締切日は取引先マスタの締め日（月末/20日、全角表記も吸収）。画面表示＋ブラウザ印刷でPDF保存（`@media print`）。差出人・振込先は companies.settings.invoice に保持。tests/caddy-invoice.test.ts が実物と1円一致で固定（小計96,000/税9,600/合計105,600）。(c) **出勤可否**: `cad_availability`（○可/△要相談/×不可・空欄=未回答）をクリックで即保存するカレンダー。**委託先は社員ではないため Shift Cloud の勤怠・給与には載せない**（載せると人件費として計上され委託料と二重計上になる＝0036の設計思想）。2ヶ月後の運用開始を想定。(d) 移行時に発見: 2026-06-07 加古川の「担当キャディ不在・売上16,000」の行はExcelの入力ミス（実物請求書は6人工96,000）→ 論理削除して請求書と一致させた
- #43 (2026-07-11) **全体スコアは外部チェック（KPI整合性#37・法務#40）も減点対象にする**。発見: 判断リストに「6月経費未入力」「予測値残存」「KPI目標未設定5件」が出ているのに全体スコアは**100点・減点要因なし**と表示されていた（computeGenesisScoreがCockpitDataしか見ないため）。朝これを見た古川さんは「満点」と誤認する＝KPIチェッカー(#37)を作った意味が消える。対策: `JudgmentItem` に `weight`/`scoreLabel` を追加し、判断項目が自分の減点を申告 → `applyJudgmentPenalties()` が集計してスコアへ反映。重み: **数字の整合性違反 -12/件**（ブロッカー-10より重い＝経営判断の土台が嘘だから）／KPI目標未設定 -4/KPI／契約の期日超過 -10・判断期日接近/満了接近 -5・高リスク契約 -6・確認滞留 -2。**ダッシュボード(トップ)も日次レポートと同じ判断リスト・スコアを表示**（従来はトップだけ整合性/法務の警告が出ず、レポートと数字が食い違っていた）。tests/genesis-score.test.ts で固定（実データ再現ケース＝56点/danger）
- #47 (2026-07-13) **システムネットワークマップ（GENESIS /network）**: 全システムの接続グラフを可視化するタブを追加（目的=どれが何とつながるか・どこでエラーか・新システムが何とつながるかの状況確認）。**トポロジの正典は `apps/genesis/src/app/(main)/network/topology.ts`** — 新アプリ/システムを作ったら (a) topology.tsへノード＋エッジ追記 (b) `apps/genesis/public/flows/` へフロー図SVG追加 をセットで行う（AIの作業ルール）。vault_systemsに登録されただけの未マッピングシステムは画面が自動で点線ノード表示（Vault登録ルール#26系と接続）。死活監視は `/api/network/health`（view_hq必須）が確認済みURLへHTTP到達性チェック＝**5xx/接続不可のみ赤**（ログインリダイレクト/401は稼働扱い）、60秒ごと自動更新。未デプロイ/移行中=黄・スクリプト/外部=灰。フロー図12枚（全体マップ＋各OS）を「フロー図一覧」タブで閲覧可
- #48 (2026-07-13) **スタッフポータル拡張（Shift Cloudを「スタッフOS」に）**（migration 0039）。仕様変更3本柱のC（優先度C→A→B）。(a) **月間カレンダー /calendar**: シフト・店舗イベント・本人メモ（sp_calendar_memos、RLSで本人のみ）・やることを月グリッド表示、日タップで詳細＋メモ書込み。**予約連携は疎結合設計**＝「dateキーの日別フィード」(lib/day-feed.ts) にReserve OS/体験予約/Smart Halloを後からアダプタ合流（FK結合しない）。(b) **本日のやること sp_tasks**: 本人追加＋完了チェック。source=manager/genesis/ai でGenesis判断リスト・店長からの配信を後続接続。(c) **日報・週報 /reports（sp_reports）**: daily=当日/weekly=月曜キーで1人1件upsert、社内で相互閲覧（情報共有）。CEO AI日次レポートへの要約流入は後続（ai_summary列は準備済）。(d) **給与見込みの精緻化**: homeの概算を本計算と同じ calcMonthlyPayroll に置換＝月給制・手当・時給按分(#39,#44)対応。「確定額は給与明細が正」を明記。(e) **クイックリンク sp_links**: 店舗別リンク集（GOLF WINGはSmart Hallo等）。**URLのみ保持、ID/PWはVault(#26)**＝自動ログインはしない。残るA（全アプリのモバイル対応）とB（各ログイン画面にマニュアルDL）はNEXT_TASKSで管理。正典 docs/modules/workforce-os/STAFF_PORTAL.md
- #49 (2026-07-13) **Lesson OS（WING NOTE代替: スイング動画・コーチコメント・Trackman受け口）**（migration 0041適用済）。lsn_students（生徒台帳、**Smart Hello会員番号member_codeで会員名簿と疎結合**）/ lsn_videos（動画、バケットlesson-videos private）/ lsn_comments / lsn_measurements（Trackman等、JSONB受け口）。独立アプリapps/lesson-os（P1で実装）。**動画・大容量アップロードは署名付きURLでブラウザ→Storage直PUT**が標準（Server Action経由はVercel約4.5MB上限で失敗＝資料室の不具合で発覚）。**Storageキーは日本語不可**（"Invalid key"）→ base64urlエンコードで持ち表示時に復号（genesis lib/libkey.ts、資料室・Lesson OS共通ルール）。正典 docs/modules/lesson-os/SYSTEM.md
- #50 (2026-07-13) **Lesson OS P2 — PGA NOTE準拠の大型アップデート**（migration 0043適用済）。ユーザー要望「PGA NOTEの機能を参考に大幅アップデート・UIも真似る」。公式サイト機能ページを実機調査し全機能を実装: 顔写真つき生徒情報・基本/詳細情報（JSONB、項目はPGA NOTE準拠=学習スタイル/HS/球筋/スコア等）・**カリキュラム進捗9項目スライダー%＋レーダーチャート**（依存なしSVG）・**動画描画ツール**（直線/円/フリーハンド4色、正規化座標でannotations JSONBに保存）・**ガイド線プリセット**（スイングプレーン/前傾）・コマ送り/スロー再生・**比較再生**（過去vs現在/生徒vsお手本の同時再生）・**お手本スイング**（lsn_model_videos）・**生徒共有リンク**（lsn_share_tokens→/s/[token]、アプリ不要=PGA NOTEユーザーアプリ相当をURL1本で）・**CSVエクスポート**。UI=コーチ側:紺ヘッダ×ダーク×金／生徒側:青ヘッダ×白（PGA NOTE両アプリ準拠）。PGA NOTEとの差別化: アプリ不要・名前だけ登録・データ持ち出し自由・Trackman受け口・GENESIS連携
- #51 (2026-07-13) **Lesson OS P2c — 撮影モジュールとスイングフェーズ移動**（migration 0044）。ユーザー要望「撮影用モジュール＋動画確認時にアドレス/トップ/インパクト/フィニッシュへ移動」。(a) **撮影モジュール**（アプリ内カメラ録画・ガイド線・3秒カウントダウン・自動停止5/8/12秒・カメラ切替）。**音声を必ず録る**＝打球音がインパクト自動検出の基準になるため。MediaRecorder非対応端末はファイル選択へフォールバック。(b) **フェーズは7点**（アドレス/テークバック/トップ/切り返し/インパクト/フォロー/フィニッシュ）を秒数で `lsn_videos.phases` JSONBに保持し、再生画面からワンタップ移動（◀▶で前後移動、タイムライン上にマーカー）。(c) **決め方＝自動推定＋手動微調整**: 打球音の鋭いピーク（WebAudioで5msごとのエネルギー比＝立ち上がりの鋭さ×音量が最大の点）をインパクトとし、残り6点はテンポ3:1（バックスイング約0.8秒・切り返し〜インパクト約0.28秒）の相対時間で導出。**人の手動設定が常に優先**（_method=manual）＝AIの推定は下書き（VISION §7）。音声なし/デコード不可は尺比率で仮置き（_method=ratio）。(d) 生徒共有ページ /s/[token] でもフェーズ移動・スロー・コマ送りを開放（閲覧のみ）。正典 docs/modules/lesson-os/SYSTEM.md §5

- #52 (2026-07-14) **Genesisの「報告→提案→承認→実行指示」を通す**（migration 0045）。診断: (a) 日次レポートが止まっていた原因は**Vercel Cronの `/api/cron/daily` が middleware に /login へ307リダイレクトされていた**こと（PUBLIC_PREFIXESに /api/cron を追加して解消。ログには手動生成分しか無かった）。(b) LINEのリッチメニュー押下（「プロの出勤情報」等）が sec_inquiries に message イベントとして入り、未対応15件中10件を占拠していた。(c) ai_suggestions / approval_requests / gn_directives 相当の「提案・指示」の器が空で機能していなかった。決定: **①受信フィルタ sec_filter_rules**（文言・一致条件をDBで持ち /inbox から追加削除。該当は自動で対応不要＝inquiry_type=noise）。**②返信の起案と承認送信**: 未対応の問い合わせに日次で ai_draft_reply を自動生成し、/inbox で承認＝送信（メール=秘書タスク、LINE=n8n『LINE返信送信 (承認済み→Push)』が status=approved を5分おきにPush送信、失敗時は reply_error に理由を残す）。外部送信は承認済みのみ（VISION §7）。**③改善提案 ai_suggestions を実装**（ルールベース＋Claudeのハイブリッド、dedupe_keyで重複防止、severityはenum critical/warning/info、suggested_actionはjsonb→textへ変更）。Cockpit一等地と /suggestions に常時表示。**④実行指示台帳 gn_directives**（/directives）: 宛先=スタッフ（sp_tasks＋通知に配信）/ AI社員（prompts指示書）/ 外部送信（approval_requests）。改善提案から1クリックで指示化できる（提案が見て終わりにならない導線）。

- #53 (2026-07-14) **Report OS（月次資料AI）を「手動スクリプト」から「毎月自動」へ**（migration 0047適用済）。診断: 資料作成AIは generate.js（JSON→pptx）が動くだけで、①数値の入れ物が未整備（物販・会員推移）②build-data がDB未接続 ③スケジュール未登録、の3点で自動化されていなかった。決定: **(a) DB整備 0047** — `rpt_retail_sales`（物販売上の月次・税込。売上データxlsxの品目「販売」から2022-06〜2026-06をバックフィル）、`rpt_member_snapshots`（正会員数の月次スナップショット）、`report_member_counts()`（正会員ルール §4-Aの**正典実装**＝除外4区分・当月末退会者を除く）、`snapshot_member_count()`、集計ビュー **`v_rpt_monthly`**（members/new_joins/leavers/retail_sales/fittings/trials）。**`rpt_fittings` は作らない**＝一時利用者名簿(`mbr_walkin_visits`)が正ソースとして取込済みのため二重管理を避ける。**(b) build-data.mjs を v_rpt_monthly 読みに全面書き換え**（`--no-ai` で数値のみ生成可）。**(c) scheduled-task `report-os-monthly`（毎月1日8:00）** が前月分を生成し「承認待ち下書き」として提示。**DBアクセスはSupabase MCP経由**にしたため service_role キーを持たずに回る（CLI利用時のみbuild-data.mjsがservice_roleを使う）。既知の限界: 会員推移・退会率は名簿再構成のため過去の退会者を含まない参考値（過去月の退会率が0になる）→ 今後はスナップショットの積み上げで解消。検証: 2026-06で 会員210 / 体験7 / フィッティング7 / 入会率128.6% / 物販¥1,174,200（前月比+50.1%）が全てDBから一致。

- #54 (2026-07-14) **AI DEMO SALES（クリニック・動物病院向けHP制作の営業デモ高速生成）**（migration 0048適用済）。独立アプリ `apps/demo-sales`（勝ちパターン: 別Vercel・DB共有・port 3009・権限 use_demo_sales|view_hq・new-app雛形から生成）。中心価値は営業管理ではなく**「営業先専用デモの事前生成」**＝完成イメージを見せて「必要かどうか画面で判断してもらう」営業。決定: (a) **デモ生成はルールベースで即時**（Claude API不要）— 業種別テンプレート10種（配色・語彙・構成を業種ごとに変える）× DemoBrief（実データ＋修正指示）→ 単一HTML。ユーザー指示「AI診断よりも先にHPを高速で作れるように」に対応し、分析・スコアは後からClaude/人が埋める。(b) **デモは非公開**: /d/[token]（乱数トークン・X-Robots-Tag noindex・HTML内metaと二重化・既定60日失効・任意パスコード・DEMOリボン常時表示）。既存サイトの写真/ロゴは使わず仮素材（※仮ラベル）＝契約後差し替え。(c) **現サイトを批判しない営業設計**: good_points/caution_points を提案書・電話/訪問トーク・比較画面に構造的に差し込む。(d) **面談中修正**: briefを引き継いで再生成（version+1・指示履歴はbrief.instructionsとdms_activities.edit_requestに残る）。(e) **成約→dms_projectsへワンクリック移行**（handover jsonbに顧客情報・分析・デモ・要望・履歴・未確認事項を再入力なしで引継ぎ）＝将来のWEB DEVELOPMENT COMMAND CENTERの受け皿。(f) 営業指示（自然言語）は dms_activities kind=directive に保存しClaudeが次セッションで実行（自動実行は後続）。初期シード: 営業先13件＋料金プラン2種（basic 298,000/月16,500・growth 498,000/月29,800）。正典 docs/modules/demo-sales/SYSTEM.md。付随: templates/app-template/src/middleware.ts が壊れていた（349バイトで途切れ・matcher export欠落）のを修正

- #55 (2026-07-14) **予約申込の一次導線を「メール」から「スタッフのやることリスト」へ**（migration 0050適用済）。背景: Reserve OSは公開済みだが `RESERVE_STAFF_EMAIL`/Resend が未設定、LINE通知も `notifyLine()` が no-op のままで、**申込がスタッフに届かない状態**だった。ユーザー判断で「メール送信・LINE送信の設定は次回。今回は申込がシフトアプリのやることリストに入るようにし、そこから日程を確認してGOLF WINGのメールアドレスから人が返信する」。決定: **(a) sp_tasks を「店舗共通タスク」対応に拡張**（`staff_id` をNULL許容化。`staff_id is null` ＋ `store_id` ＝その店の全員のやることリストに出る。両方nullは `sp_tasks_target_check` で禁止）。予約対応は特定個人の宿題ではなく「店の誰かが折り返す」仕事のため。**誰か1人が完了にすれば全員から消える**が、`done_by`/`done_at` に誰が対応したかを残す。**(b) Reserve OS → sp_tasks は疎結合**（FKを張らず `ref_type='reserve_request'`/`ref_id`。day-feedと同じ思想）。`idx_sp_tasks_ref` のユニーク制約で二重作成を防止。source に `'reserve'` を追加。タスクの `note` に第1〜3希望・電話・メール・詳細URLを載せ、スタッフはシフトアプリ上で日程確認まで完結できる。確定/見送り/完了/キャンセルの操作で `closeStaffTask()` が自動でdone化。**(c) Genesisに `/reserve`（閲覧専用）を新設** — 申込累計/確認待ち/確定/来店完了、**24時間以上未対応の申込**（折り返し滞留の検知）、申込一覧。**(d) Reserve OS 一覧トップに公開URLのコピー導線**（公式LINEのリッチメニューに貼る用。`res_services` から動的生成）。付随: seedの `res_services.store_id` が null だったため GOLF WING 宝塚 を設定（これが無いと店舗共通タスクの宛先が決まらない）。**次回**: Resend env設定でメール自動送信、n8n Webhook経由のLINE通知（`notifyLine()` 実装）、フォーム項目のGOLF WING実サービス準拠への作り直し

- #56 (2026-07-14) **Ask Data（データに聞くチャット）— LLMには「答え」ではなく「SQL」だけを書かせる**（migration 0053適用済）。背景: 日次レポートは押し出しで、聞きたいことを聞けない。とくに**店長・スタッフはCoworkを使えない**ため、数字を知るには本部に聞くしかなかった。汎用チャットは作らない（古川さんはCoworkで同じことができるので劣化版になる）。**実データに接地した質問応答だけが価値**という判断。決定: **(a) ハルシネーション対策＝LLMは数字を書かない**。LLMの出力はSQL1本のみで、数値はPostgresが計算する。画面には**生成SQLと結果件数を必ず出す（出典表示）**。0件なら「データがありません」と答え、推測は禁止。答えられない質問は `CANNOT_ANSWER:` を返させる。**(b) 権限はアプリではなくDBが強制する（多層防御）**。①LLMが触れるのは公開ビュー `gnv_*` 16本のみ。②実行は**実体テーブルへの権限を一切持たないロール `gn_chat_reader`** 所有の SECURITY DEFINER 関数 `gn_chat_query()`＝文字列ガードを抜けられても実体テーブルに到達できない。③会社・店舗・hq/storeスコープは GUC（`gn.company_id`/`gn.store_id`/`gn.scope`）でビュー側が強制。**給与・経理・銀行・契約・問い合わせ・キャディは `scope='store'` では0行**になる（`gn_ctx_is_hq()`）。④ガード: SELECT/WITHのみ・単文のみ・書込/DDL/システム関数の語を禁止・FROM/JOINは `gnv_` 以外を拒否・statement_timeout 8秒・LIMIT強制。検証済み（DELETE/複文/実体テーブル/CTE経由/pg_sleep をすべて遮断）。**(c) 置き場所は2つ**: Genesis `/chat`（view_hq＝全社・給与含む）と shift-cloud `/chat`（自店舗のみ。**店舗未割当のスタッフは利用不可**＝全店が見える事故を防ぐ）。エンジンは `@yozan/core/ask-data` に一本化。**(d) 全質問を `gn_chat_messages` に記録**（質問・生成SQL・回答・件数・実行時間）＝出典と監査。モデルは `ASK_DATA_MODEL`（既定 haiku-4-5）。**注意**: ビューを追加したら `ask-data.ts` のカタログにも必ず追記する（カタログに無い列はLLMにとって存在しない）。正典 docs/modules/ask-data/SYSTEM.md

- #57 (2026-07-14) **売上台帳の取込を「毎月の手作業」から1コマンドへ**（migration 0052適用済）。診断: 売上データ.xlsx → `mon_sales_lines`（明細）は6月まで入っているのに、月次サマリ `mon_sales` は5月で止まっており、6月の売上は `fin_entries` に **source='sales_ledger' で手入力**されていた（1,487,906円）。つまり毎月ここで人が止まる。決定: **(a) 関数 `refresh_mon_sales_from_lines(company_id, month)`** — 台帳明細を品目別・税抜で月次サマリへ集計し（`source='ledger'`・べき等）、そのまま `refresh_money_to_finance()` を呼んで fin_entries まで反映する。**(b) 落とし穴＝月会費のカテゴリ**: 0028の予測は「その月の `mon_sales` に `category='月会費'` があれば実績が来たとみなして予測を削除」する。台帳の月会費は**窓口・SB決済の入会金や日割り**であって口座振替の実績ではないので、これを '月会費' として入れると月会費予測（約356万）が消えて売上が激減する。→ 台帳由来は **`'月会費(窓口)'`** として保存し、`'月会費'` はファインの口座振替実績専用に温存。**(c) `mon_category_map` に不足マッピングを追加**（月会費(窓口)/工賃/参加料/参加費/送料/返金）— 未マッピングの品目は fin_entries に流れず**売上から消える**ため。**(d) 取込スクリプト `scripts/import-sales-ledger.mjs`**（`npm run import:sales -- --month=YYYY-MM [--apply]`。既定はdry-run）。台帳は期別シートで列構成が違うので**ヘッダ名で列を引く**。31期以降は「金額」(税抜)が空の行が多いため、**空なら 税込/1.1 を四捨五入**する規則にした。検証: 2026-06を再現して 166件・**1,487,906円**（DB実測と1円一致、品目別件数も一致）。6月ロールアップ後も月会費予測3,558,950は生存・5月4,720,335は不変を確認。**残**: ファインの口座振替実績が届いたら `mon_sales` に `category='月会費'` で入力→予測は自動停止（この導線はまだ手入力）

- #58 (2026-07-14) **Money OSに「売上分析」を新設**（`/analysis`・DBスキーマ変更なし）。これまで Money OS は入力（売上・現金・取込）中心で、**事業別・カテゴリ別に売上を見る画面が無かった**。決定: **(a) 新しい集計ルールを作らない** — 事業別は `fin_entries`（財務の正典。月会費予測もキャディ派遣もここに集まる）、カテゴリ・品目・支払方法別は台帳（`mon_sales` / `mon_sales_lines`）を読むだけ。独自集計を持たせると #53 と同じ「画面ごとに数字が割れる」事故になる。**(b) 画面構成**: 事業別売上（前月比・構成比・予測バッジ）／全社12か月推移／カテゴリ別（前月比・構成比）／物販の種類別・利用料の内訳・支払方法別。チャートは依存ライブラリ無しのCSSバー。**(c) 権限**: 事業別は全社の数字なので `canManageAll`（view_hq / manage_money_all）のみ。現場スタッフは自店舗のカテゴリ内訳だけ見える。**(d) 「予測」バッジ**を明示 — 月会費予測は暫定値であることを画面上で区別できないと、実績と取り違える。検証（2026-06）: ゴルフ事業 5,046,856（売上高1,487,906＋月会費予測3,558,950）＋キャディ派遣 645,000 ＝ 5,691,856 でDBと一致

- #59 (2026-07-15) **改善提案を「工程（誰が・何を・どの順で）」に分解して配れるようにした**（migration 0059）。背景: `/suggestions` の提案は文面を直せず、宛先を1つ選ぶ単一指示にしかできなかった（「案は出るが現場が回らない」）。実際の打ち手は *体験不足→SNS広告→台本作成→撮影→編集→AIがアップ* のように担当がスタッフとAIに分かれる連鎖。決定: **(a) 提案カードを編集可能に**（`suggestion-card.tsx`・クライアント）— 施策名・背景をその場で書き換え、工程エディタで各工程に「担当（スタッフ/AI社員）・やり方/台本・期限」を設定、並べ替え/追加/削除できる。**(b) AI自動下書き**（`lib/step-planner.ts`）— 「AIに工程を下書きさせる」で Claude が実行手順を工程に分解し、**スタッフ名簿とAI社員コードから担当まで割り当てて**下書き（撮影・台本・配布=staff、文面・配信案・分析・アップ=ai_agent のヒューリスティックも併用）。APIキー無し/失敗時は ①②③/改行/→ で分割するルールベースにフォールバック。下書きは保存せず画面で確定（VISION §7）。**(c) 発行=キャンペーン**（`issueCampaign`）— 親 `gn_directives(target_kind='campaign

- #66 (2026-07-18) **FRANK GOLF（姫路）の公式ホームページを新設**（`sites/frank-golf/`・静的マルチページHTML12枚）＋**ブランド表記を「FRANK GOLF」に確定**（migration 0067）。背景: 計画書フォルダは `FRANK`、稼働中のmember-osの画面・DBは `FRUNK`、依頼時の口頭は `FRANCK` と**3種類に割れていた**。決定: **(a) 正式表記は FRANK GOLF**。stores.name を 'FRUNK GOLF 姫路'→'FRANK GOLF 姫路' に改名（0067）。**改名しないもの**＝`stores.code='frunk_himeji'`・`frunk_members/frunk_plans/frunk_signup_tokens`・`/frunk` ルート・`FRUNK_STORE_CODE`（いずれも識別子で画面に出ない。改名は影響範囲が広く益が薄い）。安全性: kernel.ts の `storesForSegment('himeji')` は「姫路」でも一致するため改名後も動作（本コミットで FRANK も明示対応）。0028の月会費予測が使う `not ilike '%FRUNK%'` は **mbr_members.store_name（Smart Hello由来の外部テキスト）** に対する条件で stores.name とは別物 → 影響なし。**(b) サイトの中心メッセージは「ただの練習場ではなく、ゴルフが上手くなり、仲間ができる場所」** — バー・ラウンジは補足設備ではなく独立セクションの中心価値。PLAY/LEARN/CONNECTの3体験。ただし**交流を強制しない**（「一人で集中したい日も歓迎」を全ページで併記）。**(c) 対顧客サイトでは「省人モデル」「無人店舗」を禁止語**とし、スマート入退室／完全予約制／待ち時間なし／落ち着いた少人数制に置換（経営者目線の語を客に見せない）。**(d) 未確定情報を勝手に埋めない** — 料金・住所・営業時間・シミュレーター・レッスン内容・駐車場・特典は全て `assets/site-data.js` に集約し、値が null なら画面に自動で「近日公開」を表示。確定時はJSONの1行差し替えのみで再ビルド不要。**(e) 予約・会員ログイン・Web入会は作り直さず member-os へリンク**（`/member/login`・`/member/register`・`/member/book`・`/book/[token]`）。体験予約は member-os の発行トークンURLを `links.trialBooking` に貼る運用。未設定の間は自動で公式LINEにフォールバックする。**未解決**: `/member/register` は「Web予約を使うための登録」であって**プラン契約・決済を伴う入会ではない** → 真のWeb入会の要否は別途判断が必要。プレオープンは **2026年9月2日**


- #67 (2026-07-18) **FRANK GOLF サイトに画像サンプル投入＋SEO/MEO強化**（#66の続き）。決定: **(a) 実写を捏造しない** — 未開業の施設の実写風画像を作るのは誤認・MEO上のリスク。代わりに `_build_images.py`（PIL）で**ブランドトーンの抽象アトモスフィア画像6枚**（hero/concept/play/lesson/lounge/community）を生成し、`assets/img/` に配置。**本番は同名で実写に上書き**するだけ（`site-data.js` の `images` でパス変更も可）。JS無効でも見えるよう各`<img>`に初期src、`data-img-src`でJSが差し替え、heroは`--hero-img`のinline varで背景指定。**(b) SEO**: 全ページに`BreadcrumbList` JSON-LD（head()が`PAGE_LABEL`から自動付与）、トップに`GolfCourse`＋`SportsActivityLocation`、FAQに`FAQPage`。ページ別`description`、`keywords`（姫路 インドアゴルフ 等）、`og:image:alt`、`robots`、`canonical`（SITE_URL設定時）。全画像altにローカルKW。**(c) MEO**: `jsonld_business()`に`areaServed`（姫路市/たつの市/太子町/揖保郡/高砂市/加古川市）・`knowsAbout`・`alternateName`。アクセスページに可視の「対応エリア」節。**telephone/geo/openingHours/priceRange/sameApは未確定のため意図的に出力せず**、確定後に追記するTODOをコード内に明記（嘘の構造化データはペナルティ対象）。**(d) 未整備の追加ブロッカー**（NEXT_TASKS A-0c/d に反映済）: ①ドメイン確定→`_build.py`の`SITE_URL`設定→再ビルド（未設定だとLINE共有で画像が出ない・sitemap/canonical未生成）②特商法/プライバシーは草案（法務未確認）③Googleビジネスプロフィール登録（NAP一致）。生成物: `sites/frank-golf/`（HTML15枚＋assets/img6枚＋ogp/favicon）。`__pycache__`は.gitignore追加済


- #68 (2026-07-18) **FRANK GOLFサイトに告知バナー＋施設イメージ強化**（#66/#67の続き）。決定: **(a) プレオープン告知バナー3種**を`_build_ogp.py`で生成（`banner-wide.jpg`1200x420=トップ告知帯／`banner-square.jpg`1080x1080=Instagram／`banner-line.jpg`2500x843=LINEリッチメニュー）。トップのヒーロー直後にCTA付きバナー帯を設置。`site-data.js`の`images.banner*`で差し替え可。**(b) フロア見取り図（イメージ図）** — `_build.py`の`floorplan()`がインラインSVGで「エントランス→打席×4→バー・ラウンジ」の動線を描画。施設ページとトップに設置。**"施設のイメージが湧く"施策として写真より効く**（動線が伝わる）。画面に「イメージ図」バッジを明示し、確定レイアウトで更新する前提。**(c) 施設ページに設備アイコン5種**（スマート入退室/シミュレーター/ラウンジ/レッスン/駐車場、インラインSVG）**＋ギャラリー6枠**（実写差し替え前提、既存サンプル画像を流用）。**(d) 実写を捏造しない方針は継続**（#67）。すべてサンプル/イメージと明示。検証: 15ページ全てで画像alt欠落0・JSON-LD妥当・リンク切れ0・禁止語0。生成物追加: banner-wide/square/line.jpg。`_fp_preview.png`（SVG確認用の一時ファイル・0バイト化済）は.gitignore追加


- #69 (2026-07-18) **FRANK GOLFサイトに出資提案資料の確定情報を反映＋フロア図を実間取り化**（#66〜#68の続き）。出資ご提案資料（22p・宛先小林電工）とBP-70C45図面から抽出。決定: **(a) 顧客向け確定情報を公開**（ユーザー承認・料金含む全公開）— 営業時間(平日11-22/土日祝9-20・火曜定休)、駐車場20台無料、全4打席(1打席レフティ左右対応)、シミュレーター計4台(OKONGOLF他)、所在地=兵庫県姫路市土山、バーカウンター併設、プレ9/2・**グランドオープン9/5**。すべて`site-data.js`に集約(番地/電話/入会金/体験料は未確定=近日公開のまま)。**(b) 料金プランを実プランに再構成** — 個人3カード(ライト9,800/レギュラー13,800★一番人気/マスター19,800)＋スペックに法人2プラン(39,800/59,800)＋レッスン料金(25分2,500/4回9,000/8回16,000)。`price.corporate[]`/`price.lessonPrice`を追加、旧REGULAR/LESSON/CORPORATE参照を全修正。**(c) フロア見取り図を実間取りに描き直し** — `floorplan()`を「スロープ入口→打席1-2→中央バーカウンター＆ラウンジ→打席3-4(4はレフティ)→階段2F(個室・スタッフ)」に。**(d) MEO強化** — JSON-LDに実営業時間`openingHoursSpecification`(火曜除く)・`priceRange`・`amenityFeature`(駐車場/バー/シミュ/レフティ)を追加。**(e) 投資家情報(出資1,500万・利益分配・会員数目標・営業利益・商圏・スタッフ実名)は公開サイトに載せない**。**(f) ブランドはFRANKで確定**（出資資料はFRUNK表記だがユーザー再確認済でサイト/DBはFRANK維持）。抽出メモ: `FRANK_GOLF_出店計画/10_出資提案資料_抽出メモ.md`。検証: 15ページ 料金表示・店舗情報・JSON-LD営業時間・alt・リンク・禁止語すべてOK


- #70 (2026-07-18) **FRANK GOLFサイト 4項目の確定情報を反映**（#69の追補）。ユーザー回答により: **(a) 住所確定=兵庫県姫路市土山6-6-1** → `store.address`更新＋**Googleマップ埋め込み**(`store.mapEmbed`=maps.google.com/maps?q=...&output=embed／APIキー不要方式)を設定し、アクセスページ・トップの地図枠が実描画されるように。JSON-LDに`streetAddress`追加。**(b) 図面の「階段使用不可」は誤り＝2Fも客用に使う** → フロア図の2F表記を「2階も練習フロア（個室）」に、注記を「1F・2Fの2フロア」に修正。**(c) 料金は税抜** → `price.note`を「表示金額はすべて税抜（月額）」に。**(d) 常駐コーチ=藤田晃規プロを公開** → レッスンページにコーチ紹介カード新設（JGTOツアーメンバー・兵庫県出身・大阪学院大卒・2009年プロ転向・日本アマベスト16、JGTO選手ページへ外部リンク）、`lesson.coaches`更新、JSON-LDに`employee`(sameAs=JGTO)追加。抽出メモ`10_出資提案資料_抽出メモ.md`も更新。検証: 15ページ 料金/住所/地図/コーチ/JSON-LD・リンク・alt・禁止語すべてOK

- #71 (2026-07-18) **FRANK GOLFサイトに「ご予約の流れ」＋体験申込フォームを新設**。背景: member-osの`/book/[token]`は打席のWeb予約であって体験(初回・プロのワンポイント付き)の申込ではない＝**体験は人が対応する申込型**。決定: **(a) 体験ページに「ご予約の流れ」**を可視化（体験4STEP：申込→来店→体験&ワンポイント→フランクに入会案内／会員3STEP：ログイン→Web予約→スマート入退室、member-osへリンク）。**(b) 体験申込フォームを新設**（氏名/フリガナ/電話/メール/第1〜3希望日/ゴルフ経験/要望/プライバシー同意）。送信先は`links.trialForm`で差し替え式・**Formspree互換**(fetch POST)。未設定時は`trialForm`空→フォーム自動非表示＋公式LINE受付案内にフォールバック(公開しても壊れない)。**(c) 会員の打席予約はmember-osで完成済み**＝サイトは作り直さずリンクのみ。**(d) 推奨バックエンド=Reserve OS**（既存の申込型・DECISIONS #34で「体験レッスンへ行追加のみで流用可」と設計済）に体験サービスを足す案をNEXT_TASKS A-0eに記載。**(e) Web入会(決済)は存在しない**＝`/member/register`はWeb予約用登録、実入会は来店時スタッフ対応（#66未解決の再確認）。検証: 15ページ フォーム表示切替(設定時/未設定時)・必須項目・リンク・alt・禁止語すべてOK

- #72 (2026-07-18) **体験予約・Web入会を member-os に実装し公式サイトに接続**（migration 0068）。決定: **(a) 体験予約=申込型を新規実装** — `mbr_trial_requests`（氏名/連絡先/第1〜3希望日時/経験/要望/同意、status: pending→confirmed→done→canceled）＋**公開ページ `/trial`**（トークン不要・`resolveHimeji`で姫路店解決・service_role経由insert）＋**スタッフ `/trials`**（ナビ「体験申込」・日程確定/来店済/キャンセル/メモ）。打席予約(`/book/[token]`)とは別概念。**(b) Web入会=既存frunk申込フローの公開版** — **公開ページ `/join-web`**（プラン選択＋顧客情報＋同意、署名なし）→`frunk_members`にstatus='pending'でinsert→**既存の `/frunk`（FRANK会員）承認フローに合流**（承認で会員番号発行・在籍化）。オンライン決済なし（来店/後日確定）。**(c) 料金プランをDB投入** — `frunk_plans`に実5プラン（ライト9,800/レギュラー13,800/マスター19,800/法人ライト39,800/法人プレミアム59,800・税抜）。これでWeb入会のプラン選択が機能。**(d) 公式サイト接続** — `site-data.links.trialBooking=/trial`・`joinWeb=/join-web`。trial.htmlのオンサイトFormspreeフォームは撤去しmember-osに集約（予約系はmember-os一元管理の原則を維持）。plan.htmlに「Webで入会」CTA追加。**(e) 残作業=member-osのデプロイのみ**（DB適用済・コード実装済・env追加不要、NEXT_TASKS A-0e）。RLSは既存frunk_*同様enableのみ(service_role専用)。検証: 新規9ファイルtsc通過(自分の範囲)、DBへの模擬insert成功(テスト行は削除済)、HP全15ページ検証OK

- #73 (2026-07-19) **サーバー日付をJST基準に統一＋現場RUNBOOK整備＋ネットワークマップ実態同期**。発見: 日次cronは6:00 JST＝**前日21:00 UTC**に走るため、`new Date()`のUTC日付を使う箇所が全て「前日」にズレていた（7/19朝生成のレポートが「日次レポート 2026/7/18」、スタッフ朝連絡のsp_tasks日付・提案dedupeキーも同様。毎月1日朝はKPI整合性チェックの「当月」も1か月ズレる）。決定: **(a) `apps/genesis/src/lib/jst.ts`** を新設（jstDateJa/jstYmd/jstMonthStart）し、ceo-ai・directives・staff-notice・suggestions・kpi-checks のサーバー側「今日」を全てJSTへ。**tests/jst-dates.test.ts** がcron実時刻(21:00 UTC)で日付・月初のズレを固定。**今後サーバーコードで「今日」を扱うときは必ずjst.tsを使う**。**(b) RUNBOOK 4本を新規作成**（C-1完了）: money-os / survey-os / reserve-os / caddy-os → 各アプリの `public/manual.md` にコピーし `/manual`（ログイン不要）で配信、ログイン画面に「📖 使い方マニュアル」リンク追加（middleware publicPrefixesに/manual追加）。**(c) ネットワークマップ(#47)を実態に同期**: survey-os / caddy-os / demo-sales / reserve-os のURL・本番状態を反映（Vault照合。survey/caddyは「未デプロイ」表示のまま実は本番稼働だった）、**FRANK GOLF公式サイトをノード追加**（frank-golf.svgフロー図つき・体験申込→member-os /trial→mbr_trial_requestsの導線を図示）。**(d) B-1判定**: 日次レポートは7/15朝以降、7/16朝を除き毎朝生成＝復旧済（欠落3日はタイムアウト事故 #62系→f2b0190で解消済）。mbr_trial_requests(0068)の権限姿勢も点検済（RLS有効・ポリシー無し=service_role専用でOK）

- #74 (2026-07-18) **FRANK GOLF公式サイトの本番ドメインを frankgolf.jp に確定・公開準備完了**。決定: **(a) SITE_URL=https://frankgolf.jp** を `sites/frank-golf/_build.py` に設定し再ビルド → canonical/OGP を絶対URL化、sitemap.xml/robots.txt を生成（未設定時は出力しない仕様だったため）。**(b) frankgolf.jp は取得可能（未登録）だがVercelは.jp非対応** → お名前.com等の日本のレジストラで取得しDNSをVercelへ向ける必要あり。**(c) 公開方式=git＋Vercelインポート**（画像約750KBで直接ファイルデプロイは非現実的・sandboxにpush権限なし＝他アプリと同じ方式）。Root Directory=`sites/frank-golf`・Framework=Other（静的）・ビルド不要。`vercel.json`追加（キャッシュ・セキュリティヘッダ）。手順書 `sites/frank-golf/DEPLOY_本番公開手順.md`。**(d) 公開後**: member-os `lib/site.ts` の SITE_URL に frankgolf.jp を入れて再デプロイすると同意リンク有効化（NEXT_TASKS/タスク#42）。画像実写化・LINE URL・法務確認は公開後の仕上げ（サイトは草案・サンプルのまま本番化＝プレオープン告知用として許容）

- #75 (2026-07-24) **店舗ダッシュボード /store/[token] を Shift Cloud に新設**（migration不要）。背景: 店頭タブレットで「出勤・やること・KPI・業務リンク」を1画面で見たい（ユーザー要望）。決定: **(a) 置き場所=Shift Cloud内**（day-feed/sp_tasks/sp_linksの既存資産を流用・新アプリは立てない）。**(b) 認証=kiosk_devicesデバイストークン**（打刻キオスクと同一トークンで開ける・スタッフログイン不要＝店頭共有表示。middleware PUBLIC_PREFIXESに/store追加）。**(c) 画面構成**: 店舗切替タブ（GOLF WING宝塚/FRANK GOLF姫路）→ 今月KPIカード4種 → 月間カレンダー（店舗全員の出勤者名チップ＋イベント/体験予約/やること●・日タップ詳細・店舗共通タスクの追加/完了）→ 業務リンク集。5分ごと自動refresh。**(d) KPIは既存テーブルから直接集計＝DB変更なし**: 体験=mbr_trial_bookings(GW)/mbr_trial_requests(FRANK #72)、物販=mon_sales category='販売'（当月未取込は最新実績月をフォールバック表示・6月実績1,067,456で検証）、会員=mbr_members(kernel.tsと同ロジック・本会員223人で検証)/frunk_members(FRANK)、売上見込=mon_sales当月＋fin_entries forecast(0028・7月予測3,674,150で検証)。**(e) sp_linksに業務リンク7件を投入**（Member OS/ワークスWebEDI発注/Money OS/Lesson OS/Reserve OS/Survey OS/SWING CORTEX。既存のSmart Hello/GolfOrder/コーポレートと合わせて10件）。タスク操作はトークン検証＋会社一致チェック（店舗共通タスクのみ操作可）。正典: apps/shift-cloud/src/lib/store-dash.ts・docs/modules/workforce-os/STAFF_PORTAL.md §5。検証: tsc通過・tests67件全通過。残: FRANK用kiosk_devices行の発行（現状は宝塚「入口IPAD」の1台のみ＝そのトークンで両店切替可）

- #76 (2026-07-24) **Genesis大改修P1: 「報告システム」→「自律実行OS」への画面再編**（正典 docs/genesis/REDESIGN_2026-07.md・ユーザーGO済・migration不要）。背景: サイドバー26画面・判断の入口が5か所以上に分散し「AIの活動を人間が読む」構造になっていた。決定: **(a) サイドバーを5＋管理に集約**（ホーム/チャット/AI社員/数字＋「管理」折りたたみに残り21画面。既存URLは全温存＝cron・通知リンクを壊さない。sidebar.tsx で PRIMARY_NAV/ADMIN_NAV 分離、mobile-nav も追随）。**(b) ホーム全面刷新＝判断フィード統合**（`lib/judgment-feed.ts` 新設）: approval_requests / ai_action_queue(awaiting_approval=承認・queued=取消枠) / ai_execution_logs(成果物) / sec_inquiries(new・awaiting_approval) / **mbr_trial_requests(体験申込)** / **frunk_members(Web入会)** / **res_requests(予約申込)** を1本のフィードにし、**その場でワンタップ承認**（既存server action再利用＋新 `feed-actions.ts` の decideTrialRequest）。他アプリ由来はDB共有なので新API不要（§5a）。ただし**Web入会と予約確定は深リンク**（会員番号発行・確定メールのロジックがmember-os/reserve-os内のため。共有関数化はP2）。**(c) UI指針適用**: 装飾（hud/blink/ネオン）をホームから撤去、1カード=1判断、ゼロ状態は「判断ゼロ—いい日です」、queuedは「実行予定・取り消す」チップ（§9）。**(d) 事実修正**: member-os `/trial` は**本番稼働済み**（A-0e記載は陳腐化）＝体験申込0件の原因は導線でなく集客→P2営業ループで対応。**(e) 判断フィードの sec_inquiries は new/awaiting_approval が正**（'pending'という状態は無い）。inquiryカードはAI下書きがある時だけ「承認して送信」を出す（空文送信事故防止はapproveInquiry側の既存ガード併用）。残: P2=ループ基盤(gn_loops/gn_loop_runs)＋営業AIループ＋prod_deployハンドラ＋ルール文書改訂、P3=測定学習・gn_events一元化・稼働化プログラム

- #77 (2026-07-25) **Genesis大改修P2前半: 自律ループ基盤＋営業AIループv1＋ルール改訂**（migration 0075適用済）。決定: **(a) ループ基盤** — `gn_loops`（定義・config=しきい値/クールダウン）＋`gn_loop_runs`（1日1回のサイクル記録: observed/decision/deliverable/action_queue_id/result。RLS enableのみ=service_role専用・関数なしのためEXECUTE付与は不要）。**(b) 営業AIループv1** `lib/sales-loop.ts`（sales_trial_recovery・日次cronに接続）: 当月体験実績（GW=mbr_trial_bookings.lesson_date＋FRANK=mbr_trial_requests）vs kpis.trial_bookings目標の**日割りペース**で不足を検知 → 不足≧min_shortfall(1) かつ cooldown_days(7)内に未実行なら、掘り起こし配信文を生成し **staff_directive(approval)** で起案 → ホーム判断フィードで承認 → 既存経路(gn_line_outbox→n8n)でスタッフへ「公式LINE配信依頼」。**顧客LINEへの直接配信はA-4のチャネル開通後に line_broadcast へ切替**（v1は依頼まで＝誤配信リスクなし）。目標未設定/順調/クールダウン中も必ず skip として記録（判断の透明性）。**(c) ルール改訂（全権付与に基づく）**: AI_RULES=承認UIをホーム判断フィードに一本化・自律ループの正典追記・デプロイ方針(prod_deploy approval維持＋ホームカード化＋CIゲート＋自動ロールバック)。DEVELOPMENT_RULES=mountクローン禁止(45秒タイムアウト)→GitHub直クローンでtsc/tests/push、**push後のVercelビルド結果確認を義務化**（#73→#76の5日間ビルド破損の再発防止）。**(d) 残（P2後半）**: prod_deployハンドラ実装（要Vercelトークン/デプロイフックのenv設定）、member-os/reserve-os承認ロジック共有関数化、/chat・/command統合、事業別を/financeへ、OPERATIONS全面改訂、朝の個人LINEダイジェスト・判断SLA

- #78 (2026-07-25) **Genesis大改修P2後半: 判断のホーム完結を拡大＋開発自律化の配線**（migration不要）。決定: **(a) Web入会承認をホームで完結** — `feed-actions.ts` に `decideJoinRequest`（member-os `approveSignup` と同一ロジック: FR####連番発行・status active・join_date=JST今日・audit/event記録）。member-osの画面はそのまま（同じテーブルを同じ遷移で更新するだけ＝二重実装だが式が単純なため許容。式が複雑化したら共通パッケージ化）。**予約確定は深リンクのまま**（確定メール送信がreserve-osのRESEND env依存のため。genesisにenvを足すより現状維持が安全）。**(b) 判断SLA** — フィードで24時間超の未判断に `stale` フラグ→琥珀枠＋「24時間経過」バッジ＋最上位昇格。**(c) /chat・/command をタブで統合**（`chat-tabs.tsx`。サイドバー「チャット」は両方でアクティブ。完全な1画面化はP3以降の判断）。**(d) 事業別パフォーマンスをホーム→/finance へ移設**（ホームは判断とKPIに専念）。**(e) prod_deployハンドラ実装** — 承認後に `VERCEL_DEPLOY_HOOKS`（プロジェクト名→Deploy Hook URLのJSON env）をPOST。**通常デプロイはgit push自動なので、これはenv反映・再デプロイ・ロールバック用**。env未設定時は明示エラー（安全側・設定は任意）。**(f) OPERATIONS改訂方針を明記** — ユーザー作業は原則AI実行、残るのは秘密情報の発行・実機確認・法務・物理作業の4種のみ

- #79 (2026-07-25) **demo-sales デモサイトv2＋管理フォーム改善**（migration不要・DBスキーマ変更なし）。決定: **(a) デモを6ページ構成に**（render-demo.ts全面改修）— 単一HTML＋ハッシュルーティングを採用し、dms_demos.html（1カラム）・/d/[token]配信・version管理は不変。ホーム/診療案内/初めての方へ(FAQ)/院長・院内紹介/アクセス/Web予約。**(b) Web予約はデモ動作のみ** — カレンダー（休診日=診療時間表の●/休から自動判定・過去日不可）→時間枠（決定的擬似乱数の仮○×）→入力→確認→完了。送信・保存は一切しない（面談で触らせる用途・個人情報リスクゼロ）。**(c) 写真未設定はSVGサンプルイラスト**（lib/sample-art.ts新規・テンプレート配色連動・全て「※仮画像」ラベル）— 素材ルール#54（既存サイト流用禁止）の範囲内で完成イメージの密度を上げる。実写真アップロードで常に上書き。**(d) 管理フォーム再編** — ①基本②文章③診療内容・時間④写真⑤修正指示のセクション化、業種標準値をプレースホルダーで可視化（「空=業種標準」の中身が見える）、news/recruit欄追加、webReserveチェックボックス廃止（予約デモ常時搭載のため。briefの旧値は無視されるだけで互換）。既存デモは再生成すればv2デザインになる（自動一括再生成はしない=営業先に見せた版が勝手に変わらないように）

- #80 (2026-07-25) **顧客LINE直接配信を開通（A-4解消・migration 0076）**。古川さんからLINE Messaging APIの長期アクセストークン3本を受領（YOZANスタッフ連絡用 / GWビジター用 / GW会員様用）。決定: **(a) トークンは `gn_line_channels`（0076・RLS enableのみ=service_role専用）にのみ保存**。**リポジトリは公開のため、トークンをコード・migration・env設定例・ドキュメントに書くことを禁止**（seedはMCP経由のSQL直実行）。**(b) `lib/line.ts`** — broadcast（全友だち一斉）/ push（グループ・個人）。**(c) `line_broadcast` ハンドラを実配信に差し替え** — payload.channel（gw_visitor/gw_member・audience=customerのみ許可）→ LINE API broadcast。送信履歴は gn_line_outbox に status='sent' で記録（n8nは拾わない）。スタッフ向け staff_directive は従来どおり outbox→n8n 経路を維持（二重送信防止）。**(d) 営業ループを顧客直接配信に切替** — sales-loop の起案を staff_directive（配信依頼）→ **line_broadcast（ビジター用OAへ直接配信・approval維持）** に変更。文面は顧客向けのみ（社内数字を含めない）。ホームの判断カードに**文面プレビュー（160字）**を表示してから承認できるようにした。**(e) 残**: channel secret／webhook受信（「体験希望」返信の自動取り込み）は次段。gw_member チャネルの用途（会員向け施策）はループ第二弾で設計

- #81 (2026-07-25) **LINE受信webhook＋デプロイフックのDB化（A-4完全解消）**。channel secret 3本と genesis用 Vercel Deploy Hook URL を受領。決定: **(a) webhook `/api/webhooks/line/[code]`**（middleware公開パス `/api/webhooks` 配下＝設定変更不要）— x-line-signature を channel_secret で HMAC-SHA256 検証（timingSafeEqual）。テキストメッセージを **sec_inquiries(source='line', status='new') に取り込み**、既存のCEO秘書パイプライン（AI下書き→ホーム判断フィード→承認）へ合流。送信者userIdは `proposed_event.line_user_id` に保持（返信pushは #80 の linePush で次段接続）。「体験」を含む返信は inquiry_type='trial'・priority='high'＋company_eventsに記録（営業ループの成果測定の源泉）。message.id で重複配送をdedupe。未知チャネルは200で握る（LINE再送ループ回避）、署名不一致は401。**(b) デプロイフックは gn_deploy_hooks（0077・RLS enableのみ）に保存**し prod_deploy ハンドラはDB参照優先・env フォールバック。**シークレット類は一貫してDBのみ・gitに書かない**（#80の原則）。**(c) 残るユーザー作業は LINE Developersコンソールへの Webhook URL 貼り付けのみ**（各チャネル1回・Claudeはコンソールにアクセス不可のため）→ 2026-07-25 設定完了報告あり

- #83 (2026-07-25) **P3後半＋財務修正＋朝連絡刷新**（migration 0078/0079適用済）。決定: **(a) キャディ6月支出の異常を修正** — 原因は 6/2 銀行振込1,100,000（小川うらら役員報酬）の labor/caddy 誤分類 → 本部・共通へ付替。調査の過程で**構造問題を発見**: refresh_money_to_finance が銀行明細をPLへ流すため、キャディでは台帳(caddy_os)集計と売掛回収・外注払いの銀行明細が**二重計上**されていた（1〜5月の売上が実際の約2倍に見えていた）。0078で **caddyセグメントの銀行明細を2026-01以降除外**（台帳=正典、2025年は銀行が唯一ソースなので従来通り）＋関数末尾で refresh_caddy_finance を必ず実行＋**林さん人件費は source='caddy_manual'**（wipe対象外）で1〜6月分を復元。検証: 6月=売上645,000/支出595,680(外注321,000＋林274,680)。**教訓: source='money' の行は refresh で全消去される。手動調整行を source='money' で入れてはならない**。**(b) スタッフ朝連絡を実務中心に刷新**（古川さん指示）— KPI・体験不足の話を廃止し、**本日の出勤（shifts）＋今日のやることリスト（sp_tasks）**に変更。予約状況はSmart Hello APIが無いため載せず店舗ダッシュボード参照を案内。**(c) 事業別カードの収支内訳** — kernel.getBusinessBreakdown に SegmentLine（カテゴリ別内訳）を追加し、カードの数字タップで ＋売上/−経費 の内訳と差引を表示。**(d) イベント一元化（0079）** — 体験申込/Web入会/予約申込/アンケート回答の到着をDBトリガーで company_events へ自動記録（アプリ改修ゼロ・例外は握って業務を止めない）。**(e) AI週次成績表** `ai-scorecard.ts`（毎週月曜）: AI別の成果物数・承認/却下・実行数・ループ打ち手を gn_loop_runs に記録しイベント化。**(f) 朝の個人LINEダイジェスト** `morning-digest.ts`（毎日）: 判断待ちの件数と先頭3件＋昨日のAIの動きを古川さんの個人LINEへpush（宛先はスタッフ用OAへの1:1メッセージから自動採用→gn_loops(morning_digest).config.line_user_id）。**残**: 集計正典の共通lib化（kernel⇔store-dashの重複解消）は別途

- #85 (2026-07-26) **FRANK GOLF 9/2計画GO＋LINEグループ配信（§3-5）**。決定: 実行計画`FRANK_GOLF_出店計画/10_プレオープン実行計画_0902.md`の全項承認（営業時間=平日10-21/土日祝8-20/火曜定休・ファウンダー会員特典・Stripe課金・SquarePOS・開発順序3-5→3-1→3-3→3-2→3-7→3-4）。§3-5実装: **(a) webhookグループ自動捕捉** — スタッフ用OAのグループjoin/発言で`gn_line_groups`へ自動登録（LINE API group/summaryで名前取得→FRANK/WINGを名前から店舗自動マッピング）。スタッフグループ内の雑談はsec_inquiries化しない（CEO Inbox汚染防止）。**(b) sendStaffLineをn8n経由→OAトークン直接pushへ**（outboxはstatus='sent'の履歴のみ）。**(c) 送信先選択**: payload.target='all'／store_id／group_id。朝連絡はtarget='all'（GW/FRANK両グループ）。**運用**: 古川さんがOAを両グループに招待するだけで配信先登録が完了する。Shift OSにFRANK5名登録済（林hayashikazuki/穴田anada/藤田fujita=contractor/小川ogawaurara/古川、初期PW=password、auth.users直insert）。**教訓: サンドボックス再起動でgit認証が消える→pushはユーザーPCのcommit-and-deploy.ps1方式**。**§3-1前半も同commitで実装**: (d) サイトCMS — migration 0080 `gn_site_content`（data=FRANKオーバーライド＋news、適用済）＋公開API `/api/public/site/frank-golf`（CORS・60秒キャッシュ）＋サイト側 `assets/cms.js`（fetch→window.FRANKへdeep-merge→FRANK_RENDER()再描画・API障害時は静的値で表示＝安全）を16ページ全部に注入＋Genesis `/site-admin`（基本情報・お知らせCRUD・上級者向けJSON、サイドバー「FRANKサイト管理」）。(e) index.htmlにギャラリーセクション（assets/imgの同名上書きで実写化）。dream house写真=TANOSU記事 https://tanosu.com/gourmet/207587 で発見（権利: 前運営者から元写真入手 or 許諾 or 撮り直しが必要・計画書§9）。**残（次セッション）: §3-3予約→§3-2 Stripe→§3-7 Square→§3-4レッスン管理、HP本番デプロイ（Vercel新プロジェクト root=sites/frank-golf）＋frankgolf.jp接続**

- #86 (2026-07-26) **FRANK §3-3 打席予約v1**（migration 0081適用済）。決定: **(a) 会員認証はパスワードレス**（会員番号＋電話下4桁・Web完結、frunk_membersと照合、active/approvedのみ）。**(b) 30分単位×5打席**（frunk_bays: 1F TrackMan4×2／2F OKONGOLF・DTECT×2）。二重予約は**DBのpartial unique index**が最終防衛（uq_frunk_booking_slot）。**(c) プラン上限をAPIでenforcement**: 1日上限=frunk_plans.max_bookings_per_day×60分、ライトは月8日。**(d) 営業時間は§8確定値をコードに内蔵**（平日10-21/土日祝8-20/火曜定休、businessHours()。祝日の土日扱いはv2）。API=/api/public/frank/booking（GET空き/my・POST book/cancel・CORS対応）、サイト=booking.html（空きグリッド→タップ予約→キャンセルまで完結）。予約/キャンセルはcompany_eventsに記録（ホームのフィード・朝連絡に自然合流）。**残: §3-2 Stripe・§3-7 SquareはアカウントID審査待ちでブロック（ユーザー申請後にwebhook実装）／§3-4レッスン管理（プロ別枠・カルテ連携）**

- #91 (2026-07-26) **FRANKサイト リニューアル: 白ベース×緑×ベージュ（ロゴ準拠）＋画像ファースト**。ユーザー指摘「黒×緑は見にくい・文字が多い・画像ベースに。SEOは維持」＋ロゴ画像受領。決定: **(a) テーマ**: style.css の :root を白基調に全面差し替え（--ink=#FFFDF8/--ink-2=ベージュ#F6F1E4/文字=緑チャコール#3A4237/--brass=ロゴイエロー#D99A2B・brass-2は白地用に濃く#A8771B）。CSS変数駆動のため全17ページ一括反映。個別修正: nav白すりガラス・ヒーロー明オーバーレイ＋l2を緑・カード白＋ソフトシャドウ・CTA明緑ワッシュ・**フッターのみディープグリーン#22301Fで締め**（スコープ内オーバーライド）・モバイルメニュー白。予約2ページのインラインrgba(255,255,255,*)も反転。**(b) 画像ファースト**: ロゴ実画像を配置（assets/img/logo.png・白透過logo-t.png、ヒーローに表示）、ギャラリーをコンセプト直後へ移動、PLAY/LEARN/CONNECTを写真カード化（play/lesson/lounge.jpg＋SEO alt付き）、hero/concept/WHY FRANK/note-soloの長文を短縮。**(c) SEO維持**: title/meta/OGP/JSON-LD/h1-h2/alt/canonical/sitemapは全温存。theme-color全ページ白へ、ogp.png・favicon.svg・favicon-32/apple-touch-iconをロゴベース白基調で再生成。文言のSEOテキストは下層ページに残存（トップのみ圧縮）

- #90 (2026-07-26) **緊急修正: /api/public がgenesis middlewareの公開パス未登録**。発見経緯: レッスン管理の本番E2Eテスト（pg_net→本番API）で405/HTML応答→調査で `/api/public` 全体が/loginへ307と判明。**影響: #85サイトCMS・#86打席予約・#88レッスン予約のAPIが本番で全て不通だった**（サイトはcms.jsの静的フォールバックで表示は無事・予約グリッドは「読み込みに失敗」）。修正: PUBLIC_PREFIXES に `/api/public` を追加。**教訓: 公開APIを新設したら本番への疎通確認（curl相当）までがDone**。tsc通過。E2E続き（枠予約→カルテ生成→クリーンアップ）はデプロイ後に実施。あわせて資料室（/library・FRANK GOLF分類）に「残タスク一覧」「Stripe/Square申請ガイド」「frankgolf.jpドメイン接続手順」の3点を保管（library-upload EdgeFnを一時再開→410で再閉鎖）

- #89 (2026-07-26) **FRANK 店頭運用の残タスク解消（§3-3残・A-8・祝日）**。決定: **(a) 店舗ダッシュボード /store にFRANK当日予約を表示** — getStoreMonthFeed に frunk_bookings（打席・時刻/会員名/打席名）＋frunk_lesson_bookings（レッスン・時刻/会員名/コーチ名）を予約欄へ合流（store_idフィルタのためGW側は影響なし）。予約は時刻順ソート（ラベル内HH:MM抽出）。**(b) FRANK端末のkiosk_devices発行**（「FRANK 店頭タブレット」・トークンはVault「FRANK 店頭タブレット」に登録済=URL式・DBはsha256ハッシュのみ）。**(c) 2026-27年の祝日をシード** — gn_site_content.data.booking.holiday_dates に11日分（9/21〜2027/3/22。火曜と重なる祝日は定休が優先=businessHoursの判定順。変更は/site-adminから）。検証: shift-cloud tsc通過。残: HP本番デプロイはユーザーPCからVercelインポート（#74手順書）＋frankgolf.jp取得

- #88 (2026-07-26) **FRANK §3-4 レッスン管理v1**（migration 0082適用済）。決定: **(a) スキーマ**: `frunk_lesson_slots`（プロが公開する枠・プロ別/打席別・open/closed）＋`frunk_lesson_bookings`（会員予約＋record_note=レッスン記録＋handover_note=申し送り＋student_id=カルテ）。1枠1人はpartial unique index（uq_frunk_lesson_booking, done も枠占有）。RLS enableのみ=service_role専用・関数なし。**(b) 会員側**: 公開API `/api/public/frank/lesson`（GET枠一覧30日先/my・POST book/cancel・CORS）＋サイト`lesson-booking.html`（打席予約と同じ会員番号＋電話下4桁認証）。同会員は同日1枠まで。予約/キャンセルはcompany_eventsへ記録（event_type=lesson.booked/cancelled）。**(c) カルテ自動生成**: 予約時に lsn_students を member_code（FR####）で find-or-create→booking.student_id 紐付け（Lesson OSのカルテと同一台帳）。**(d) 打席ブロック**: 打席指定のopen枠は frank-booking の getSlots/createBooking 両方で打席予約から自動除外（lessonBaySlots）。**(e) スタッフ側**: Lesson OS `/frank`（ナビ「FRANK」）— 枠の一括公開（開始〜終了をレッスン時間30/60/90分で分割・重複はunique indexでスキップ）・停止/再公開/削除（予約入りは削除不可）・スタッフによる予約取消・記録＋申し送り保存（保存=done・recorded_by記録）・**前回の申し送りを次回予約カードに自動表示**（琥珀枠）・カルテへ深リンク。**(f) 権限**: 藤田/穴田/林和希に「スタッフ」ロール（use_lesson）をSQL付与（小川はview_hqで従来通り）。コーチ候補=staff_store_assignmentsのFRANK配属activeのみ。検証: tsc（genesis/lesson-os）・tests72件全通過。残: §3-2 Stripe/§3-7 Square（アカウント審査待ち）・HP本番デプロイ

- #87 (2026-07-26) **予約設定の汎用化（ユーザー要望「設定で変更できるように」）**。決定: 営業時間・定休曜日・祝日・臨時休業・枠単位・予約可能日数を**gn_site_content.data.booking**で管理し、`/site-admin`の「予約設定」フォームから変更可能に（保存→即反映・デプロイ不要）。コードの既定値は DEFAULT_BOOKING_CFG（平日10-21/土日祝8-20/火曜定休/30分枠/14日先まで）で、**設定が無ければ既定値で動く安全設計**。祝日は「土日祝営業時間を適用する日付リスト」方式（自動祝日判定はv2）。index.htmlに予約CTA・sitemapにbooking.html追加

- #84 (2026-07-25) **財務訂正＋P3完結**。決定: **(a) 小川氏1,100,000の再訂正** — #83で「役員報酬」と推定したが、ユーザー確認により**貸付金の返済（借入金返済）**と判明。BS取引でありPL対象外 → mon_bank_txn.category='loan_repayment'（fin_categoriesに存在しないコード=refresh対象外）に変更。**ルール: 借入・返済・資金移動などBS取引はcategoryに'loan_repayment'等の非PLコードを付ける**。あわせて#83のwipeで消えていた6月役員報酬160,000（古川80,000＋小川80,000）を source='hr_manual' で復元。本部6月人件費=160,000が正。**(b) スタッフ指示の未完了再指示** — 朝連絡に「持ち越し」欄を追加（直近7日の未完了sp_tasksを済になるまで毎朝再掲）。**(c) 会員集計の正典を @yozan/core/members に集約** — スタッフ除外・トライアル区別・半開区間[月初,翌月初)・退会理由プレースホルダの定義を1箇所化し、genesis(kernel.ts)とshift-cloud(store-dash.ts)が共用。tests/members.test.ts 5件追加（計72件）。これでP3後半は完了、REDESIGNの残タスクなし

- #82 (2026-07-25) **Genesis大改修P3前半: 測定学習＋稼働化プログラム**（migration不要）。決定: **(a) 営業ループの測定** — `sales-loop.ts` に `measurePastRuns`: act から7日経過した run について「7日間の体験申込（GW bookings＋FRANK requests）」と「LINEの体験返信（sec_inquiries source=line, inquiry_type=trial）」を実測し `gn_loop_runs.result` に保存、company_events に「打ち手→結果」を記録（ホームのAIティッカー・CEO AI日次の観測に流れる）。日次cronで自動測定。**(b) 稼働化プログラム** — `activation-loop.ts`（毎週月曜・code=system_activation）: reserve/survey/lesson/legal の直近14日利用数を観測し、**0件のシステムは「稼働化 or 凍結」の改善提案を ai_suggestions に自動起票**（pending重複はdedupe）→ ホーム判断フィードに出る。提案文に具体的な稼働化手段（導線掲出・権限付与等）を含める。**(c) 残（P3後半）**: gn_eventsイベント一元化・集計正典の共通lib化・AI週次成績表・朝の個人LINEダイジェスト（古川さんの個人userId取得後=スタッフ用OAに1:1メッセージを送れば webhook経由で取得可能）
- #92 (2026-07-27) **FRANK 体験のセルフ予約 — 折り返し待ちを廃止**（migration 0083適用済）。ユーザー指摘「体験予約はスタッフからの折り返しで完成ではなく、直接カレンダーから日時と打席を選んだら確定できるように」。決定: **(a) 打席マスタを実店舗に合わせて作り直し** — 0081のシード5打席（bay-1f-l等）は実態と不一致だったため論理削除し、**A打席(1F)／B打席(2F・左右打席＝レフティ対応)／C打席(2F)／D打席(2F・未設営でclose)** の4打席に再構成。`frunk_bays.is_lefty`（レフティ可否）と `trial_priority`（体験の自動割当順 A=1/B=2/C=3、null＝体験に使わない）を追加。予約0件のため安全に差し替え。**(b) 打席は選ばせない** — 初めての方に打席の違いは判断できないため、お客様は日時だけ選び、サーバーが A→B→C の優先順で自動割当（レフティにチェックすると左右打席=Bのみ）。**(c) 会員予約と同じ台帳に入れる** — `frunk_bookings.member_id` を nullable にし `trial_request_id` を追加＋CHECK(どちらか必須)。これで既存の partial unique index `uq_frunk_booking_slot` がそのまま体験の二重予約も防ぐ（会員予約・レッスン枠との衝突も自動で回避）。**(d) 受付時間は営業時間内すべて**（ユーザー選択。プロが枠を開ける運用は不要にした）。ただし**当日ぶんは「今から2時間後以降」のみ**表示＝直前予約で準備が間に合わない事故を防ぐ。定休日はカレンダー上で最初からグレー（APIが closedDows/closedDates を返す）。**(e) キャンセルはトークンURL** — `mbr_trial_requests.cancel_token`。ログイン不要でお客様が自分でキャンセルでき、打席も同時に解放。同じ電話/メールで未来の体験が既にある場合は二重申込を拒否。**(f) 実装**: `lib/frank-trial.ts`＋公開API `/api/public/frank/trial`（GET空き/token・POST book/cancel・CORS）、サイトは `_build.py` 生成の **trial-booking.html**（1.日を選ぶ→2.時間を選ぶ→3.氏名連絡先→即確定）。`site-data.js` の `links.trialBooking` をこのページに変更したので**全19ページの体験CTASが自動で切り替わる**（旧 member-os `/trial` の折り返し申込フォームは残置）。確定画面に日時・打席・住所・持ち物・当日の流れ・キャンセルURL・（LINE設定後は）友だち追加を表示。**(g) スタッフ側**: member-os `/reservations`（予約（姫路））に「体験予約」パネルを追加し、来店/取消を1タップで。取消時は frunk_bookings も同期して打席を解放。**未解決（次セッション）**: member-osの予約管理は `res_bookings`、FRANKの打席予約は `frunk_bookings` と**台帳が二重化している**。体験は frunk_* 側に入るため、空き状況グリッド（res_*ベース）には出ない。どちらかに寄せる判断が必要。検証: genesis/member-os の tsc通過（既存エラーのみ）、DBで二重予約→unique violation・持ち主なし→check violation を実測、19ページをheadless Chromeで確認（JSエラー0・体験CTA全ページ trial-booking.html・定休日グレー2件）
- #93 (2026-07-27) **FRANK 予約システムの一本化 — 予約台帳が2つあった問題を解消**（migration 0084適用済）。ユーザー指示「1本化してください」。**発見**: 同じ「FRANK姫路の予約」を持つ台帳が2組あった。`res_resources`/`res_bookings`（0020/0024・member-osの予約管理／入金・未収金・店頭カレンダー・トークンURL式のお客様Web予約・`/member/book`）と、`frunk_bays`/`frunk_bookings`（0081-0083・公開API＋サイト／打席マスタ・プラン上限・レッスン枠連動・体験）。会員のWeb予約に至っては**入口が2つ**あった。両方とも予約データ0件だったため移行なしで統合できた。**決定した役割分担**: **お客様の予約＝公式サイト frankgolf.jp**（booking/lesson-booking/trial-booking）、**スタッフの管理＝member-os**（/reservations・/board）。**(a) 台帳は frunk_bookings に一本化**。res_bookings が持っていた会計（amount/paid_amount/payment_status/payment_method/paid_at）・来店実績（status に visited/no_show を追加）・電話店頭予約の情報（guest_name/guest_phone/party_size/customer_kind=member|trial|dropin）を frunk_bookings へ移植。owner の CHECK を「member_id か trial_request_id か guest_name のいずれか必須」に拡張。**枠の占有判定を `status='confirmed'` から `status<>'cancelled'` に変更**（unique index も張り替え）— 来店済みに変えた瞬間に枠が空いて二重予約が入る事故を防ぐため。既存コード（frank-booking/frank-trial/store-dash）の confirmed 決め打ちも全て修正。**(b) 共通ロジックを @yozan/core/frank-booking に集約** — 営業時間・定休日判定・枠生成・会計ラベル・BookingCfg をここに置き、genesis（お客様側API）と member-os（スタッフ側）が同じ定義を使う。スタッフ画面だけ別の時間割になる事故を防ぐ。genesis の frank-booking.ts は再exportで互換維持。**(c) 画面**: `/reservations` を frunk_* ベースに全面書き換え（会員・体験・都度・レッスン枠が**1つのグリッド**に色分けで出る／未収金サマリ／電話店頭予約の登録／来店・無断欠・取消／入金記録）。`/board`（ロビー掲示）も frunk_* に。会員マイページの予約一覧・キャンセルも frunk_* に。**(d) 重複入口を廃止**: `/member/book` と `/book/[token]` はサイトへリダイレクト（ブックマーク・QR対策で消さずに転送）、`bookAsMember` 削除、Web予約用トークン発行も廃止（掲示用 issueBoardToken のみ残す）。`lib/reservation.ts` は空にして誤用防止。**(e) 旧テーブルはDROPせず** `comment on table` で「【廃止】」と明示（res_services/res_requests は Reserve OS の別システムなので無関係）。検証: genesis/member-os/shift-cloud の tsc通過（@yozan/core を /tmp に実体化して解決。VMのnode_modules/@yozan/core symlinkが壊れているため）、tests80件通過、実DBで通し確認（サイト体験予約→来店に変更しても枠は空かない＝unique violation→電話予約＋入金→キャンセルで同じ枠が再取得できる）。**残**: Stripe/Square連携時に frunk_bookings.amount と突き合わせる設計が必要
- #95 (2026-07-27) **ホームページ営業の基盤化 その1: 配布リンクの閲覧計測を共通モジュール化**（migration 0085適用済・正典 `docs/modules/track/SYSTEM.md`）。背景: 「対象店舗のピックアップ→自動でHP作成→メール自動送信→来店商談→契約」を回したいというユーザー要望。既存の demo-sales（#54/#79）が「HP自動作成」と「商談」をすでに持っており、欠けているのは **①営業先の自動ピックアップ ②メール配信 ③閲覧トラッキング** の3つ。**着手順は ③→①→② と決定**（③は既存資産の小改修で効果が最大、②はドメイン・法務準備があるので最後が安全）。**モジュール化の方針もユーザー選択で確定＝3パッケージに分割**（`@yozan/track` / `@yozan/prospect` / `@yozan/outreach`。demo-sales専用にせず、他システムから必要なものだけ使えるようにする）。**(a) `packages/track`（@yozan/track）を新設** — `trk_links`（配ったURL1本＝1行。app/resource_type/resource_id/token で任意のシステムから使える）＋`trk_sessions`（閲覧1回＝1行・滞在秒・見たページ・端末）＋`trk_events`（open/page/click。heartbeatは保存せず秒数に畳む）。記録は**RPC `trk_record` 1本**に集約（トークン照合→セッション→イベント→集計→初回開封の company_events 記録を原子的に・service_roleにEXECUTE付与済）。**個人情報とIPは保存しない**（UAは300字で切って端末判定のみ）。RLS有効・ポリシーなし＝service_role専用（#65の標準形）。**(b) ビーコンは「配信時」に差し込む** — `injectTracking()` が `/d/[token]` の応答HTMLへ挿入する方式にしたので、**保存済みHTML（dms_demos.html）は書き換えず、既存デモも再生成なしで計測対象になる**。版管理にも影響しない。二重注入ガード・`</body>`が無いHTMLへのフォールバック・失敗時は全部握る（相手に見せているページを絶対に壊さない）。**(c) 社内プレビューの除外** — 営業担当が自分で開いた分を数えると「開封＝ホットリード」が嘘になるため、管理画面からのリンクは全て `?preview=1`（一覧・詳細・compareのiframe）＝`is_internal=true` として閲覧数・滞在秒・初回開封の**すべてから除外**。**(d) demo-sales 接続** — `/api/track`（middleware公開パスに登録。#90の再発防止）＋`/p/[id]` に閲覧状況パネル（初回/最終・回数・合計滞在・セッション別の端末/滞在/見たページ）。**(e) Genesisホームの判断フィードに `hotlead` を追加** — 開封済み かつ 未対応（`notified_at` null）を「デモ開封」カードとして表示し、**hotleadだけは新しい順で最上位グループ**（開封直後ほど架電が繋がるため、既存の「古い順」ソートでは沈んでしまう）。「対応した」で `notified_at` を立てて消す＋audit/event記録。初回開封自体も `company_events(track.first_view)` に入るのでティッカー・CEO AI・朝ダイジェストへ自動合流。**(f) 通知先はユーザー選択で Genesisホーム＋メール**。メールは `@yozan/outreach`（②）着手時に接続する。**(g) ついでの修正**: `/d/[token]` の有効期限判定が UTC 日付だったのを JST に（#73のルール）。検証: tests 89件全通過（track 8件追加）、本番DBで trk_record を通し確認。**残: ①`@yozan/prospect`（Web現況スコア＋リスト取得アダプタ）→②`@yozan/outreach`（配信停止・抑止リスト・法定表示・日次スロットル。特定電子メール法3条1項3号=サイトにアドレスを公表している営業者への送信は同意不要／4条の表示義務／送信専用ドメイン＋SPF/DKIM/DMARC＋ウォームアップ）**

- #94 (2026-07-27) **FRANKサイト トップページを「初心者向けスクール型」に全面再構成**。ユーザー指摘「文字が多すぎる」＋参考サイト（チキンゴルフ chicken-golf.com）提示。決定: **(a) 構成を参考サイトに合わせる** — ヒーロー（大キャッチ＋実績数字4つ）→ キャンペーンバナー2枚 → コンセプト短文 → レッスン紹介（写真＋3行）→ 魅力3カード → 料金（入会金＋3プラン名だけ）→ 黄色いCTA帯 → 施設 → こんな方へ（チェックリスト）→ 新着 → アクセス → FAQ3件。**各ブロック2〜4行に圧縮し、詳細は下層ページへ逃がす**。index.html は 47KB → 24KB（文字量ほぼ半減）。**(b) 配色もポップに寄せる**（ユーザー選択）— ロゴのイエロー #F7B32B を主役に、`--ink` を白、`--ink-2` をクリーム、見出しは明朝をやめて Zen Kaku Gothic New 900、ボタンは押し込み influenced な立体シャドウ、角丸22px。既存クラス名は全て残したので下層16ページは無改修で新テーマに追従。**(c) 「お客様の声」「コラム」「店舗一覧」「採用情報」は作らない**（ユーザー判断・1店舗かつオープン前で中身がないため）。**(d) 画像の割当を実態に合わせ直した** — `lesson.jpg` は実際には料理写真、`concept.jpg` は別店舗の外観だった。site-data.js の `images` に `exterior/bay/sim/lessonPic/lounge/food/community` を定義し、意味とファイルを対応づけ（差し替えは同名上書き）。**バグ修正: `img` に `height` 属性があると CSS の `aspect-ratio` に勝ってしまい、魅力カードの写真が1枚だけ縦に伸びていた** → リセットに `img { height: auto }` を追加。あわせて電話番号が未定の間はヘッダーの電話ブロックを出さない、公式LINE未開設の間はフッターのLINE帯を出さない、極小ラベル（9〜10px）を11px以上に底上げ。検証: 全19ページをスマホ幅で確認（はみ出し0・JSエラー0・画像404ゼロ）

- #96 (2026-07-30) **Inventory OS 新設 — 物販在庫のエクセル脱却（migration 0086適用済・正典 `docs/modules/inventory-os/SYSTEM.md`）**。背景: ユーザーから `202606_ゴルフウィング在庫リスト.xlsm`（VBA付き・362品番・最新棚卸1,259点・仕入単価ベース約277万円・2025-12〜2026-06の7ヶ月分）を受領。**このエクセルは「棚卸台帳」であって在庫台帳ではない**——月1回の実地カウントしか無く入荷・販売の増減が追えないため「なぜ減ったか」が分からない。加えて月ごとに4列（確認日/時間/担当/数量）が横に増える設計で7ヶ月43列、保管場所が95件（26%）空欄、数量ゼロのまま残る品番が58件。golfwing（発注・入荷）とも分断＝二重入力。着手範囲はユーザー選択で **P1+P2（棚卸のデジタル化＋入出庫台帳）／入力端末＝店舗のiPad／バーコードは当面なし（管理番号のみ）**。

  **(a) 設計は3層分離** — `inv_items`（品番マスタ）／`inv_movements`（入出庫1件＝1行。**エクセルに無かった層**）／`inv_count_sessions`＋`inv_counts`（棚卸。横持ちを縦持ちに変換）。補助に `inv_codes`（品目・メーカーの略号表＝エクセル「コード表」シート）。**理論在庫＝直近の"確定した"棚卸の数量＋その棚卸日より後の movements 合計**（ビュー `inv_stock`）。全期間のmovementsを積む方式にしないのは移行時点で過去の入出庫が存在しないため（積むと在庫が全部ゼロになる）。棚卸を確定すると実地と理論の差が `kind='adjust'` として自動起票され、**締めた瞬間から理論在庫が実地に一致する**（money-osの金種棚卸 `mon_cash_count` と同じ思想）。管理番号 `品目略号-メーカー略号-連番` の採番と重複チェックはエクセルVBAからDB関数 `inv_next_code()` ＋ unique index に移した（同時登録の衝突を防ぐ）。RLS有効・ポリシーなし＝service_role専用（#65標準形）、新関数は service_role に EXECUTE 付与済み。

  **(b) 移行は差分方式＋MD5で全件検証** — `scripts/inventory/excel-to-inv.py`（原本xlsmも同ディレクトリにアーカイブ）。品目・メーカーは管理番号から `inv_codes` への join で復元（原本362行すべて一致を確認）。棚卸は最古の2025-12だけ全量、以降は「前月コピー→消えた品番を削除→増えた品番を挿入→変わった数量をUPDATE」（月次の変化は30〜90品番＝全体の8〜25%しかない）。**教訓: 差分方式で「前月に無かった品番」をUPDATEだけで扱うと入らない。INSERTを別に用意すること**（3月以降でBL 3品番が欠落し、あとから補正した）。検証: 7セッション×全品番の `(管理番号,数量)` 連結MD5が原本と完全一致（2,259レコード）、品目略号ごとの件数・合計数量の突合も差分ゼロ。移行分のセッションは `inv_close_count` を通さず直接 closed で投入（当時は理論在庫が存在しないため `theoretical`/`diff` は null、過去にadjustを起票しない）。

  **(c) 棚卸シートはiPad前提** — 保管場所タブで絞り込み（`12 / 37 ✓` の進捗表示）→前回値を大きく出す→同じならタップ1回（「同じ」ボタン／＋−）→違うときだけ数字を打つ。入力のたびに400msデバウンスで自動保存（「保存ボタンを押し忘れて全部消えた」を起こさない）。タップ領域48px。締める前に「残りN件を『前回と同じ』で埋める」。**362行を上から舐める作業が、数の変わった品番だけ触る作業になる**。権限は `use_inventory`＝counter（入力のみ）／`view_hq`・`manage_inventory`＝manager（マスタ編集・確定・入出庫記録）。ロール「スタッフ」「受付」に use_inventory、「店舗責任者」に manage_inventory を付与済み。

  **(d) golfwing連携はAPI** — golfwingは**別DB**なのでトリガーでは繋がらない。`POST /api/v1/movements`（Bearer `INVENTORY_API_TOKEN`）に入荷確定側から投げてもらう。突き合わせキーは Inventory OS の管理番号。`source_id` を入れれば再送しても増えない（`uq_inv_mov_source`）。**見つからない品番はエラーにせず `unmatched` で返して残りは通す**（1品エラーで入荷全体を止めない）。middlewareの公開パスに `/api/v1` を登録済み（#90の再発防止）。**有効化には golfwing 側の商品コードマスタ整備が前提**（ワークス発注が止まっているのと同じ理由）。

  **(e) money-os / report-os へはビューで** — 同一DBなので `inv_monthly_valuation`（期首在庫・期末在庫・当月仕入・売上原価＝三分法・平均在庫）を用意。**棚卸が無い月は行を出さない＝推計しない**（嘘の数字をPLに流さない）。移行直後は `purchase_value` が全月ゼロなので `cogs` が実態とずれる（2026-02は −150,263）が、これは異常ではなく**入荷を記録していなかったという事実がそのまま出ている**。

  **(f) 検証** — tsc通過。実DBでE2E（入荷10→棚卸で片方だけ1つ少なく数える→確定→adjust −1 が起票され新しい起点になる）を通してからテストデータを物理削除。ダッシュボードに「直近の棚卸で数えられていない品番がN件」を明示（`inv_stock` は品番ごとに最後に数えた棚卸を起点にするため、6月合計1,259に対し理論在庫合計は1,283になる）。network topology.ts にノード＋エッジ4本を追記、vault_systems に登録済み。

  **残**: ①golfwingの商品コードマスタ整備→API連携の有効化 ②money-osに粗利画面 ③report-osの物販セクション（在庫回転日数・死蔵在庫） ④`inventory_ai` の配線（適正在庫割れ→`ai_suggestions`。migration 0006でplanned済） ⑤shift-cloud `/store` からの棚卸導線 ⑥Vercelデプロイ（新プロジェクト root=`apps/inventory-os`）＋`INVENTORY_API_TOKEN` ⑦`reorder_point` の初期設定（現在は全品番nullなので発注候補が出ない）

- #97 (2026-08-03) **FRANK GOLF 会員第1号の受入＋9/2オープンゲート＋月会費のStripe継続課金（migration 0087適用済）**。
  **(a) 会員第1号: 小川雄一様** — 8/1にWeb入会申込（レギュラー会員・口座振替希望）で pending だったのを、ユーザー指示で**「モニター会員」（月会費0円・新設プラン・active=false=Web入会フォームには出さない）へ変更して承認**。会員番号 **F0001**・status=active・join_date=2026-09-02。予約ページで F0001＋電話下4桁で打席予約が使える。
  **(b) 9/2 10:00 オープンゲート** — `BookingCfg` に `open_date`（2026-09-02）と `open_time`（10:00）を追加（`@yozan/core/frank-booking`・gn_site_contentにも書き込み済みで上書き可）。businessHours が open_date より前は null（＝体験・打席・レッスン共通で枠なし）。オープン当日は 10:00 開始。**先行予約**は `bookableRange()`＝「max(今日, open_date) から advance_days 分」で、オープン前の今日からでも 9/2〜9/16 が予約できる（従来の today+14 だと 8/19 まで 9/2 が選べなかった）。打席は frunk_bays.active で A/B/C のみ（Dは未設営 active=false のまま＝コード変更不要）。枠は従来どおり閉店時刻（平日21:00/土日祝20:00）を超えない。
  **(c) booking.html 会員UX改修**（_build.py 対象外の手書きページ）— ①会員番号・下4桁を localStorage に保存し次回入力不要 ②オープン前の日付を選ぶと理由を表示して 9/2 に自動切替（APIが closed に reason/min_date/max_date を返すようになった） ③枠選択時に「閉店までに収まらない利用時間」を無効化・自動調整（終了時刻も表示） ④手順を1〜3のステップ表記に ⑤trial-booking のカレンダーもオープン日始まりに（_build.py 修正＋再生成）。
  **(d) 月会費のStripe継続課金** — ユーザー選択でStripe。**SDKは使わずfetchでREST直**（依存追加なし）。`frunk_members` に stripe_customer_id / stripe_subscription_id / billing_status(none|checkout|active|past_due|canceled) / billing_registered_at（0087）。`POST /api/public/frank/billing`（会員番号＋下4桁で認証→Checkout mode=subscription・price_data 税込=税抜×1.1・ja）→ booking.html の「カードで継続課金を登録する」から遷移。Webhook `/api/public/frank/billing/webhook`（署名HMAC検証・5分許容）で active/past_due/canceled を反映、登録完了時は payment_method='card' に切替＋company_events（billing.registered 等）でホーム/朝ダイジェストに合流。月会費0円プランは弾く。**残: Stripeアカウントの `STRIPE_SECRET_KEY` / `STRIPE_WEBHOOK_SECRET` を Vercel(yozan-genesis) に設定＋StripeダッシュボードにWebhook登録**（未設定の間は「店頭でお手続きください」と案内するだけでエラーにはしない）。
  検証: tests 105件全通過（frank-booking-open 7件追加）、genesis/member-os の tsc 通過、実DBで小川様の F0001 化とプラン0円化・bays active 状態を確認。
- #98 (2026-08-03) **Money OS: 担当プロ＋品名の在庫ピッカー＋明細編集（migration 0088適用済）**。ユーザー要望4点（①売上に担当プロ ②設定画面で店舗ごとにスタッフ追加 ③入力後の明細を編集 ④品名を在庫リスト/発注管理から選択、ただし選択肢が多すぎて遅いのは嫌）。**(a) 担当プロは staff と独立した名簿 `mon_pros`（店舗別）** — プロはログインしない外部者もいるため。money-golfwing に `/settings` を新設し追加・並び順・有効/無効・削除（無効=退任。過去明細は残る）。売上側は `mon_sales.detail.pro` に**名前スナップショット**で保存（名簿を消しても明細が壊れない）。**(b) 品名ピッカーの設計＝「全件を見せない」** — 自由入力は維持しつつ、未入力時は品目チップ＋最近の入力8件だけ、文字を打った瞬間に 履歴(4)→在庫(12) を横断絞り込み（NFKC正規化＋カナ→かな。コード/メーカー/品名/仕様を対象）。在庫はチップで品目を絞ってから眺めることもできる。選択元は同一DBの `inv_stock`（362品番・理論在庫と定価を表示）。**「発注管理商品」からの選択は見送り（ユーザー選択）** — golfwingは別DBかつ商品コードマスタ未整備（#96残課題①と同一ブロッカー）。マスタ整備後にAPI連携で追加する。**(c) 在庫連動＝0086(e)の配線（ユーザー選択で自動減算ON）** — 在庫品番付きの売上保存で `inv_movements(kind='sale', qty=-(個数||1), unit_cost=仕入単価スナップショット, source_app='money-os', source_id=sale.id)` を起票。`uq_inv_mov_source` が二重起票を防ぐ。品名を手で書き換えるとリンクは外れる（実在しない紐付けを残さない）。存在しない品番は在庫連動だけ諦めて売上は通す。**(d) 明細編集 `updateSale`** — 一覧の行から全項目編集。連携先も同期: 現金→現金=出納行を更新／現金→他=行を削除／他→現金=行を新規。在庫は数量・日付を同期、品番が外れたら取り消し（在庫が戻る）。**(e) 現金出納の残高は「積み直し」方式 `rebalanceCashLedger`** — balance列は表示用スナップショットのため途中行の編集・削除で以降が全部ずれる。編集/削除のたびに店舗の全行を entry_date,created_at 順に走査し、変わった行だけUPDATE（通常は末尾数行）。**deleteSale も従来は出納の連携行を残したままだった（残高が実態とずれる既存バグ）のを、連携行削除＋積み直しに修正**。**(f) ついで修正**: 売上入力の「今日」初期値がUTCだった（朝9時まで前日になる）のをJSTに（#73）。検証: 全ファイルの構文チェック通過（VMのマウントIO不調でフルtscが完走せず。**push前にユーザーPCで `npx tsc --noEmit` を実行のこと**）、実DBで通し確認（sale起票で在庫16→15・二重起票はuq_inv_mov_sourceで阻止・取消で16に復元。テスト行は物理削除済み）。残: 発注管理（golfwing）からの品名選択はマスタ整備後、担当プロ別の売上集計を /analysis へ
- #99 (2026-08-04) **Caddy OS: 請求書の不備修正（migration 0089適用済）**。ユーザー要望5点。**(a) 差出人・振込先** — `companies.settings.invoice` に代表者(representative)を追加し、YOZAN実データ（代表取締役 古川博庸・宝塚市平井・尼崎信金 鴻池支店 普通4120589 ｶ.ﾖｳｻﾞﾝ）をDB登録。/masters に「請求書設定」エディタ新設（saveInvoiceSettings）＝以後スタッフが自分で変更可。**(b) キャディ→YOZAN請求書の振込先** — `cad_partners.bank_info`（自由記述・任意）を追加、/masters 委託先フォームに欄、支払請求書に印字（未設定なら従来どおり「別途連絡」表示）。旧方針「口座は保持しない」はユーザー要望で転換。**(c) 締め期間** — 従来は締め日に関係なく暦月集計だったのを `billingRange(ym, closing_day)`＝**20日締め（西宮高原）は前月21日〜当月20日**、月末締めは暦月に修正。請求プレビュー/発行スナップショット/一覧の3箇所を統一（一覧は前月1日から広めに取得しJS側で取引先ごとに絞る）。**(d) 請求月の上書き** — 研修者など請求が月をまたぐ場合用に `cad_dispatches.billing_ym`（YYYY-MM・CHECK付き）。台帳一覧に「請求月」セル（onBlur保存・setDispatchBillingYm）、指定行は期間外でもその月の請求書へ、指定月以外からは除外。**(e) manual.md** にPDF保存手順（PC/iPhone）・締め期間・請求月・振込先設定を追記。検証: tests 14件通過（billingRange 3件追加・2月/年またぎ/30日締め×3月の丸め）、caddy-os tsc 通過。
- #100 (2026-08-04) **判断フィード: 実行プラン表示＋修正指示ループ＋学習蓄積（migration 0090適用済）**。ユーザー指摘「詳細を押しても何がどう実行されるかわからず怖くて承認できない。修正も細かく指示したい。修正は学習してほしい。LINEは文面を添えてほしい」。**(a) 実行プラン** — ホームのAI実行カード（ai_action_queue）に`<details>`展開を追加（`QueueDetails`）。judgment-feed.ts の `buildPlan()` が action_type ごとに「実行内容/宛先/実行タイミング(承認後最大10分=10分cron)/取消可否」を言語化。line_broadcast は gn_line_channels からチャネル名（例:「ビジター用」の友だち全員）、staff_directive は対象グループを表示。**送信文は全文表示**（従来は160字プレビューのみ）。**(b) 修正指示（両方式）** — 承認待ちの line_broadcast / staff_directive のみ `revisable`。①AI修正: 指示文1つでClaude（CEO_AI_MODEL・haiku既定）が書き直し（`lib/feedback.ts reviseWithAi`・キー未設定なら明示エラー） ②直接編集: textarea差し替え（API消費ゼロ）。どちらも payload.body を更新し `payload.revisions` に履歴、audit_logs に `ai_action.revise`。**修正後も awaiting_approval のまま＝承認するまで送信されない**。**(c) 学習** — `gn_feedback`（0090・RLSポリシー無し=service_role専用）に指示/before/after/sourceを記録。次回から ①AI修正時のプロンプトに「過去の学習ルール」として注入 ②sales-loop の配信文生成時に `applyLearnedRules` でテンプレートへ反映（適用ルールは payload.applied_rules に記録）。ルール無し/キー無し/失敗時はテンプレートのまま＝安全側。直接編集は任意の「なぜ直したか」メモを書いた時だけ学習対象（無言編集は文面差分のみ記録）。検証: マウントIO不調でVMのtscが完走せず、**push前にユーザーPCで `npx tsc --noEmit`（apps/genesis）を実行のこと**。残: deliverables/inbox下書きへの同UI展開（今回スコープ外・ユーザー選択）、staff朝連絡の生成側への学習注入。
- #99補足 (2026-08-04) **Caddy OS: キャディ振込先を項目別に（migration 0090適用済）**。#99(b)の自由記述 `bank_info` をユーザー要望で**項目別**（bank_name/bank_branch/bank_account_type[普通|当座 CHECK]/bank_account_no[数字のみzod検証]/bank_holder）に置き換え（入力済み0/35件を確認して drop）。/masters 委託先フォームに「振込先口座」行（グレー背景で区分）、支払請求書には**YOZAN請求書と同じ枠形式**（銀行 支店/種別預金 番号/口座名義）で印字。未登録なら従来どおり「別途ご連絡」。番号#100は並行セッション（判断フィード強化）が使用のため補足番号とした。検証: caddy-os tsc 通過（@yozan/core解決ノイズのみ＝既知）。
- #101 (2026-08-04) **AI営業 SNSインバウンド @yozan/content＋AI営業司令室 /ai-sales（migration 0091適用済・正典 docs/modules/ai-sales/SYSTEM.md）**。設計書 docs/modules/ai-sales/DESIGN.md をユーザー承認（着手順=SNSインバウンド最優先／コールドDMは完全自動の合法ルート無し=半自動・コメント起点DMのみ全自動可／Instagram中心・Xは当面手動）。
  **(a) パイプライン** — 毎朝6時cron(content-loop)がSWING CORTEX知識資産(sc_symptoms→checkpoints→knowledge)から題材を選び（直近21日重複回避・商品は日替わり交互）、Claude生成（キー無しはテンプレfallback）＋0090学習ルール適用 → `cnt_posts`(0091・service_role専用#65標準形) → `ai_action_queue(sns_post, approval)` でホーム判断フィードへ（実行プラン・全文・AI/直接修正=既存#100のレールに乗せた。revisableにsns_post追加）。承認=予約確定（executorが修正文面をcnt_postsへ同期）→ 18:00に10分cron(publishDueContent)が Instagram Graph API（fetch REST直・SDK無し）で自動投稿。**IGは画像必須**のため hook を `/api/public/ai-sales/card/[id]`（next/og 1080×1080・日本語フォントは実行時サブセット取得）でカード化して配信。IG env未設定の間は scheduled のまま注記のみ＝設定した瞬間に自動開通。却下は翌朝 syncRejected で rejected に同期。ループ既定ONはYOZANのみ（gn_loops sns_content）。
  **(b) 集客LP×2** — `/lp/pganote`・`/lp/swing-cortex`（genesis内公開ページ・PUBLIC_PREFIXESに `/lp` と `/api/track` を追加=#90再発防止）。閲覧は@yozan/trackを genesis に横展開（route1本＋token `lp-*`）。**LPは匿名公開ページなので notified_at 即埋めでホットリード通知の対象外**（demo-salesと扱いが違う）。社内リンクは必ず `?preview=1`。
  **(c) リード自動投入（専用テーブルを作らない）** — `/api/public/ai-sales/lead`: pganote→sales_osスキーマ（companies+contacts+leads[問い合わせ]+tasks=福原氏の翌日期限タスク。project/stage/担当はcode・名前で解決しUUID直書きしない。チャネル「SNS/LP」自動作成）、swing-cortex→sec_inquiries（判断フィードの問い合わせカードに載る）。honeypot付き。台帳投入失敗でも受付は落とさず company_events(warning) に残す。
  **(d) AI営業司令室 /ai-sales（リアルタイム）** — ファネル（投稿30d→LP閲覧→リード→商談→導入＋デモ開封未対応）・投稿パイプライン（状態チップ・カード画像/承認導線）・活動フィード（生成/投稿/LP閲覧/デモ開封/リード/AI判断のunion 30件）を15秒ポーリング（サーバーアクション・タブ非表示中は停止）。「今日の投稿案をいま作る」ボタン＝cron待ちなしで動作確認可。月曜は週次ファネルレポートを company_events へ。
  **(e) 台帳・地図** — vault_systems 3件（LP×2・/ai-sales）登録済み、network topology に ext-instagram ノード＋エッジ3本＋flows/ai-sales.svg。
  検証: 新規/変更ファイルの構文チェック通過。**push前にユーザーPCで `npx tsc --noEmit`（apps/genesis）を実行のこと**（VMマウントIO不調のため）。残: ①IG接続（OPERATIONS §9・env 2つ）②Instagram Insights取得 ③コメント起点自動DM ④Phase2 prospect / Phase3 outreach / Phase4 DM半自動。
- #101補足 (2026-08-04) **Instagramアカウント2つ作成＋商品webdesign（HP制作）追加（migration 0092適用済）**。ユーザー要望「コーチ補助とHP作成の2アカウント」。
  **(a) アカウント作成の分担** — フォーム入力まではAI（Chrome操作）、**パスワード設定と送信・認証コード入力はユーザー本人**（アカウント作成/パスワード入力はAI禁止操作のため）。作成済: **@swingcortex_jp**「SWING CORTEX」(hiro0413022+swingcortex@gmail.com・bio+LPリンク設定済) / **@yozan_web_jp**「YOZAN WEB制作」(hiro0413022+yozanweb@gmail.com)。vault_systems 2件登録済（PW値は保存しない=ユーザーのみ保持）。
  **(b) 商品webdesign** — cnt_posts.product に 'webdesign' 追加(0092)。題材はsc_*でなく `WEB_TOPICS`（packages/content/generate.ts・HP集客の固定ネタ8本・使い切ったら一周）。生成プロンプトは商品別の読者像(AUDIENCE)に一般化。既定ローテは `["swing-cortex","webdesign"]` 日替わり（pganoteは専用アカウントが無いため既定外・config.productsで有効化可）。
  **(c) アカウント別Instagram** — `igConfigForProduct()`: webdesign→`IG_ACCESS_TOKEN_WEB`/`IG_BUSINESS_ID_WEB`、他→従来env。publishDueは投稿ごとにアカウント解決し、未設定アカウント分だけ待機注記（他方は投稿される）。/ai-sales の警告もアカウント別2本に分離。
  **(d) HP制作LP** — `/lp/webdesign`（訴求=demo-sales運用の「契約前に完成デモ」・3ステップ・無料デモ依頼フォーム）。トークン `lp-webdesign`・リードは sec_inquiries（件名「ホームページ制作の相談・デモ希望」）。カード画像に webdesign ブランド（青系）追加。
  残: ①@yozan_web_jp のbioへLPリンク設定（セッションがブラウザに無くログインが必要なためユーザー作業） ②IG env 2アカウント分 ③push前 `npx tsc --noEmit`。

- #102 (2026-08-05) **LINE返信の「承認したのに送られない」を解消＝承認と同時に直push（コード修正のみ・migrationなし）**。実障害: 8/5 10:50に承認したGOLF WING会員様への返信が `sec_inquiries.status='approved'` のまま滞留し、`reply_sent_at` が null のまま送られていなかった。
  **(a) 原因** — 設計は「approved を n8n『LINE返信送信』ワークフローが拾ってPush」だったが、その**拾い役がリポジトリにもn8nにも存在しなかった**。承認アクションは status を書き換えるだけで終わっていた。
  **(b) 対応** — `approveInquiry`（inbox/actions.ts・ホーム判断フィードと共用）で source='line' のとき `proposed_event.line_user_id` 宛に `linePush()` で即送信し `status='replied'` / `reply_sent_at` を記録。送信失敗は approved のまま残し理由を `reply_error` に保存して画面に出す（黙って消えるのを防ぐ）。**スタッフ配信が #85 で直push化済みなので、返信も同じ経路に統一＝n8nは使わない**。gmail は従来どおり秘書スケジュールタスクが送る。
  **(c) 滞留分の救済** — 「approved かつ source=line かつ reply_sent_at が null」は再送を許可し、/inbox の処理済み一覧に「今すぐ送信」ボタンを出す（送信済みは二重送信しない）。
  **(d) 表示時刻のUTCズレ** — `components/ui.tsx` の `fmtDate` ほか3箇所が `toLocaleString("ja-JP")` を timeZone 指定なしで呼んでおり、サーバー（VercelはUTC）レンダリングの画面が**9時間ずれて**表示されていた（出来事ログ /events の時刻が合わない実障害）。`timeZone:"Asia/Tokyo"` を付与。**[[jst-date-rule]] の表示側ルール: 日時表示は必ずJST明示**。
  **(e) 検証** — tsc 0エラー・tests 108件通過。なお型チェックは `tsconfig.tscheck.json`（.gitignore対象=各環境ローカル）に @yozan/track・@yozan/content の paths を足して実行した。Windowsのnode_modules symlinkがVMマウント越しに壊れるため、この2パッケージだけ解決できない環境がある。
- #103 (2026-08-05) **AI営業SNSインバウンドに X（旧Twitter）チャネルを追加（migration 0093適用済・正典 docs/modules/ai-sales/SYSTEM.md §4）**。#101では「XはAPI有料のため当面手動」としていたが、**2026年2月のX API従量課金化**（旧Basic $200/月・新規Free廃止 → PPU 投稿$0.015/件・リンク付き$0.20/件・最低$5）で月30本≒$6となり前提が変わったため撤回。
  **(a) アカウント設計** — Instagramは商品別2アカウント（@swingcortex_jp / @yozan_web_jp）だが、**Xは会社公式1アカウント @YOZAN_inc に全事業を集約**。理由は「Xは本文にリンクを直接置けるので、投稿ごとにLPへ飛ばせる＝アカウントを分ける必要がない」。IGは本文リンクが踏めずbio誘導になるため分ける必要がある。表示名「株式会社YOZAN｜ゴルフ×AI」＝現場（インドアゴルフ運営）を持つ開発会社という立ち位置で、HP制作にもSWING CORTEXにも効かせる。
  **(b) 実装** — `packages/content/src/x.ts`: **OAuth 1.0a を Web Crypto(HMAC-SHA1) で自前署名**＋`POST /2/tweets`（SDK無し・#97/instagram.tsと同方式）。OAuth 2.0 を採らないのは refresh token 運用の失効コストを避けるため（自アカウント投稿は固定4値で完結）。`buildTweetText()` が **280重み**に自動短縮（Xは全角=2＝日本語実質140字。IGの400字本文をそのまま送ると必ず落ちる／URLはt.co一律23）。LPは `/lp/*?src=x` で流入元を識別。
  **(c) 1投稿=2チャネル** — cnt_posts 1行をIGとXの両方へ配信し、**承認カードは1本のまま**（判断の回数を増やさない）。0093で `x_tweet_id` / `x_posted_at` / `x_error` を追加し、チャネルの成否を独立して持つ。状態は「1つでも成功→posted / 設定済みが全滅→failed / 全未設定→scheduledのまま」。**片方だけ接続済みでも安全**（未接続側はエラーにせず注記のみ＝env設定した瞬間に自動開通）。
  **(d) 画面** — /ai-sales の投稿カードに IG/X のチャネル別チップ（X投稿はツイートへの外部リンク付き）、警告に「X未接続」、活動フィードにX投稿行。判断フィードの実行プランも「Instagram（カード画像）とX（本文＋LPリンク）へ同時投稿」に更新。
  **(e) 接続とセキュリティ運用** — 開発者アカウント登録・アプリ作成・権限変更・キー生成はAIがブラウザ操作で実施、**キーのコピーとVercel envへの入力はユーザー本人**（APIキー/トークンを入力欄に打ち込むのはAI禁止操作。ユーザーが権限を渡すと言った場合も例外にしない）。vault_systems 2件登録（Xアカウント・開発者コンソール／秘密値は保存しない）。network topology に `ext-x` ノード＋エッジ2本。
  **(f) 検証** — `tests/x-post.test.ts` 8件（OAuth 1.0a署名をX公式ドキュメント記載の既知**署名ベース文字列**と一致させ、Node crypto と Web Crypto の突き合わせで固定／280重みの上限・タグ2つ・URL保持・短文素通し）。全体 **tests 116件通過**、変更ファイルの構文チェック通過。**push前にユーザーPCで `npx tsc --noEmit`（apps/genesis）**。
  残: ①Instagram側の接続（OPERATIONS §9・Meta開発者登録のSMS制限待ち） ②X/IGのInsights取得cron ③ハブLP `/lp`（X・IGのプロフィールリンク先を1本化）。
- #103補足 (2026-08-05) **X初回投稿の実地確認と、そこで見つかった文面の作り分け改善**。@YOZAN_inc へ実投稿成功（tweet 2084889689530790018・15:30 JST）＝OAuth 1.0a署名・権限・従量課金の疎通を本番で確認。承認は判断フィード、配信は10分tick（`runDueActions`→`publishDueContent`が同一リクエスト内なので、予定時刻を過ぎていれば承認と同じtickで投稿される）。
  **見つかった2点（どちらも読み手に見える品質問題）**: ①280重みの切り詰めが**文の途中で切れた**（「✓ 予約・問い合…」）②IG前提のCTA「プロフィールのリンクをチェック」が、本文にリンクが載るXでは案内として食い違う。
  **対応（`buildTweetText`）**: 切り方を **文末（。！？）優先 → 改行（「〜は：」の前振り行は捨てる）→ 字数切り＋…** の3段に。拾えた本文が上限の6割未満になる場合だけ字数切りへ落とす（本文が痩せるのを防ぐ）。CTAは url がある時だけ「プロフィールのリンク」→「下のリンク」へ言い換え（IG側の文面は変えない）。tests 4件追加＝**全120件通過**。
- #104 (2026-08-05) **Xは承認なしで自動投稿に切り替え＋拡散のための画像添付とプロフィール整備**（migrationなし・`gn_loops.config.x_auto` で制御）。
  **(a) 承認の線引きを変えた** — Xは会社公式1アカウント・テキスト主体で事故の幅が小さいので**承認を外して自動投稿**、Instagramは画像＋商品別アカウントに出るので**承認を維持**。実装は publishDue が `xAuto` のとき `awaiting_approval` の行も拾い、**Xだけ投稿してstatusは動かさない**（Instagramの承認カードを消さないため）。二重投稿の防止は `x_tweet_id` の有無で判定。判断フィードの実行プランも「この承認が決めるのはInstagramだけ／Xへは承認を待たず自動投稿」と明記した。既定ON（config.x_auto を false にすれば承認制に戻る）。
  **(b) 画像添付（拡散施策）** — Xは画像付きの方が伸びるため、IGと同じカード画像を添付。OAuth 1.0a では v2 の `/2/media/upload` が使えない（403の報告多数）ので **v1.1 `upload.twitter.com/1.1/media/upload.json`** を使う（multipartのボディは署名対象外）。**画像アップロードが落ちても本文だけで投稿する**＝投稿自体は守り、理由は `x_error` に注記。
  **(c) プロフィール整備（拡散施策）** — アイコン400×400・ヘッダー1500×500を生成して設定（`apps/genesis/public/brand/x-icon.png` / `x-header.png`。ヘッダーは**左下にプロフィール画像が重なる**ので本文は x=400 以降に配置）、ウェブサイト欄に `/lp/webdesign`、初回投稿を**固定ポスト**に。空のアカウントはフォローされないため、投稿を増やす前の前提条件として先に片付けた。
  **(d) 検証** — tests 120件通過（うちXアダプタ12件）。実投稿での疎通は #103補足で確認済み。**push前にユーザーPCで `npx tsc --noEmit`（apps/genesis）**。
  残: ①IG接続（OPERATIONS §9） ②X/IGの反応数取得cron → cnt_posts.metrics ③ハブLP `/lp` ④投稿頻度の最適化（リンク付き$0.20/件なので、リンク無しの知見投稿を増やすと安く伸ばせる）。
- #105 (2026-08-06) **パーソナルレッスン手当を Money OS の売上台帳から自動算出（migration 0094適用済・正典 docs/modules/workforce-os/BUSINESS.md §レッスン手当）**。要望「ゴルフウィングの給与計算で、パーソナルレッスン25分1回2,000円をレッスン手当として追加したい」。
  **(a) 何が足りなかったか** — 0035(#44)で `payroll_allowances`(kind='personal') の器は作ってあったが、**入力する画面が無く SQL 直打ち**だった（2026-06分は手作業投入）。一方、実績は既に money-os の売上台帳に入っている（`mon_sales_lines.product_name='パーソナルレッスン（25分）'`・単価2,000・`pro`=担当プロ）。**二重入力をやめ、売上台帳を唯一の入力元にする**。手当を直したいときは money-os の売上明細を直す。
  **(b) 名寄せ** — `mon_sales_lines.pro` は自由記述の姓で表記ゆれがある（「古川プロ」、通称「春馬」＝卜部さん）。`mon_pros` に `staff_id`（給与スタッフへの紐付け）と `aliases text[]`（表記ゆれ）を追加し、末尾の「プロ」は正規表現で落として突合。担当プロ ≠ 給与スタッフ（外部プロもいる・0088の設計）なので **staff_id は任意**、未紐付けは取り込まず給与画面に警告を出す（黙って0円にしない）。
  **(c) 支払区分は3通り** — `mon_pros.payout_mode`: `payroll`（給与の手当＝井殿・卜部・榎本・福原）/ `outsourcing`（**業務委託費に上乗せ・給与明細に載せない**＝安東さん 2026-06〜）/ `none`（対象外＝古川さん。月給・役員報酬なのでレッスンを担当しても手当を付けない）。ユーザー確認済み（2026-08-06）。「担当した＝手当が出る」ではないので、区分を名簿に持たせて画面で説明できる形にした。
  **(d) 実装** — DB関数 `personal_lesson_counts(company_id, from, to)`（担当プロ別の件数・返金はマイナス計上・未紐付けも返す。#0065のルールに従い service_role にのみ EXECUTE）。`lib/lesson-allowance.ts` に単価定数と仕分けロジック（純粋関数・DBアクセス無し）。`buildPayroll` が集計のたびに personal を**論理削除→入れ直し**（他の手当 compe/round_lesson/fitting_referral/commute_actual は手入力のまま触らない）。/admin/payroll に「レッスン手当」カード（担当プロ別の件数・手当額・区分バッジ、未紐付け警告、業務委託分は別枠合計）。
  **(e) 検証** — 2026-06の手入力（安東25 / 井殿1 / 卜部1 / 榎本1・古川は未計上）と自動集計が**完全一致**することを実データで確認＝移行しても支給額が変わらない。tests 7件追加で全 **127件通過**、shift-cloud tsc は既知の @yozan/core 解決ノイズ2件のみ。
  残: ①money-os 設定画面に「担当プロ」の staff_id/aliases/payout_mode 編集UI（現状はSQL） ②2026-07の担当プロ未設定1件の入力補完 ③業務委託分（安東さん7月144,000円）を money-os の外注費へ自動計上するか要判断（現状は給与画面に表示するだけ）。
- #106 (2026-08-06) **担当プロの給与連携をmoney-osの設定画面で編集できるようにし、業務委託分は外注費へ自動計上（migration 0095適用済）**。#105の残件①③をユーザー指示で実装。
  **(a) 編集UI（残件①）** — money-os「設定」に **「給与連携（パーソナルレッスン手当）」** パネルを追加。担当プロごとに **スタッフ紐付け（select）/ 支払区分（給与の手当・外注費に上乗せ・対象外）/ 別名・表記ゆれ（読点区切り）** を1行フォームで保存（`updateProPayroll`）。**手当の設定を money-os 側に置いたのは、算出元が売上台帳＝money-osの担当プロ欄だから**（給与画面に置くと「直したい対象」と「直す場所」が離れる）。payout_mode はUI外から不正値が来てもCHECK制約に落とさずpayrollへ丸める。
  **(b) 外注費の自動計上（残件③）** — DB関数 `sync_lesson_outsourcing_expense(company_id, from, to, unit_price=2000)`（0095・service_roleのみEXECUTE）。`payout_mode='outsourcing'` のプロの件数×単価を `mon_expense`（category='外注' / item='パーソナルレッスン手当' / payee=スタッフ名 / **source='lesson_allowance'**）へ1か月1名1行で入れる。`buildPayroll`（給与の「集計を実行」）から手当取込と同じトランザクション流れで呼ぶ＝**給与を締めれば経費側にも載る**。
    - **計上日は勤務月の月末**（支払は翌月だが人件費は勤務月に計上する既存運用に合わせた）
    - **冪等**: 再実行時は source='lesson_allowance' の既存行を論理削除してから入れ直す。**手入力の外注費（source<>'lesson_allowance'）には触らない**
    - segment_id / store_id は**その月のレッスン売上明細の最頻値から採る**（店舗→事業の対応表を新設しない＝実績が正）
    - ⚠**二重計上の口が開いた**: 通帳CSV/Excel取込で同じ支払を別行で入れると重複する。自動計上分は memo に「（レッスン手当 自動計上）」が入るので取込時はそちらを消す。BUSINESS.mdに明記した
  **(c) 検証** — 2026-07で `sync_lesson_outsourcing_expense` を2回実行し、安東茉優 72件=144,000円が**1行だけ生き残る**（前回分は deleted_at 済み）ことを実データで確認。money-golfwing tsc 0エラー、shift-cloud tsc は既知の @yozan/core ノイズ2件のみ、tests 127件通過。
  残: ①money-osの経費一覧で自動計上行を編集不可にするか（現状は手で消せる＝次の集計で復活する） ②2026-07の担当プロ未設定1件の入力補完。
- #107 (2026-08-07) **Xの連続投稿（スレッド）をサーバー側の仕組みにする（migration 0096適用済）**。要望「Xで連続投稿してみて／パソコンを開いていないときでも自動で動く仕組みに変えて」。
  **(a) 何が間違っていたか** — 会社紹介スレッドを「ブラウザ操作で投稿する」段取りで進めていた。これはPCが起動しAIセッションが動いている間しか成立せず、**仕組みではなく手作業**だった。既に #103/#104 で「cronが自前でX APIを叩く」完結型のレールがあるのに、そこへ載せていなかったのが誤り。以後、外部への発信は**必ず cnt_posts に予約して Vercel Cron に投げさせる**（ブラウザ操作は最終手段）。
  **(b) なぜ1行＝1スレッドか** — 9投稿を9行にすると承認カードが9枚になり、判断の粒度が壊れる（0093でIG/Xを1行にまとめたのと同じ理由）。`cnt_posts` に `thread_parts`（本文の並び）と `thread_tweet_ids`（投稿できたIDの並び）を追加し、1行＝1スレッドとした。
  **(c) 再開できることが要点** — 公開投稿は取り消せないので、途中失敗で全部やり直すと**前半が重複投稿される**。`thread_tweet_ids` の長さ＝進捗とし、次tickはその続きだけを、末尾IDを `in_reply_to_tweet_id` にして投げる。1tick最大12本（execute の maxDuration=60秒）・間隔1.2秒。進捗ゼロのtickは `source.thread_stalls` で数え、**一度も投稿できていなければ即failed／途中まで公開済みなら6tick（約1時間）まで粘る**（半端に公開されたスレッドを放置しないため）。
  **(d) platform列に意味を戻した** — 0093では「表示ラベル・判定は見ない」としたが、会社紹介のようにIGへ出す絵が無い投稿が出てきたので `platform='x'` をIGスキップの判定に使う。あわせて `product` に `'yozan'`（会社公式の発信＝売り込みではない）を追加。生成ループが回すのは従来の3商品のみなので、型を `SalesProduct`（生成対象）と `Product`（= SalesProduct | 'yozan'、cnt_postsの値）に分けた。
  **(e) 原稿→予約の導線** — `scripts/post-x-thread.mjs`（Markdownを `---` で分割し、X重み文字数を出してdry-run → `--apply` で予約）。会社は名前で引く（`companies` に FRANK GOLF もあるので `limit(1)` は別テナントを掴む事故になる）。同じ theme の未投稿が残っていれば何もしない＝何度実行しても増えない。
  **(f) 検証** — `tests/x-thread.test.ts` 6件（返信で繋がる／途中失敗でも投稿済みIDを返す／再開時に再投稿しない／全部済みならAPIを叩かない／1tick上限／上限超過の整形）＝全 **133件通過**。会社紹介スレッド9投稿は `status='draft'` で投入済み（デプロイ前は旧コードが拾わない）、デプロイ確認後に `scheduled` へ変更して公開する。
  残: ①スレッドの反応数取得（metrics） ②/ai-sales の投稿カードにスレッド進捗（n/9）を出す ③生成AIにスレッド起案をさせるか（現状は人が原稿を書いてscriptで予約）。
- #108 (2026-08-06) **経費の「発生」と「支払」を消込でつなぎ、二重計上を構造的に潰した（migration 0096・0097適用済・正典 docs/modules/money-os/SYSTEM.md §4-5）**。#106で「自動計上分は摘要を目印に手で消してください」と運用に逃がしたのをユーザーが「根本解決は？」と差し戻した。**運用の注意書きは対症療法で、忘れれば必ず破れる**という指摘は正しい。
  **(a) 何が根本原因だったか** — `refresh_money_to_finance` は経費を `mon_expense`（発生ベース）＋ `mon_bank_txn` の確定出金（支払ベース）の**単純な足し算**で作っており、**同じ経済事象が2つの入口から入るのに、両者を結ぶ鍵が無かった**。0095でレッスン手当の自動計上を入れたことで、この穴が実際に踏める状態になった（安東さんの業務委託費が「勤務月末の発生」と「通帳の出金」で2回入る）。
  **(b) 採った解 — 明細単位の消込** — `mon_expense.settled_txn_id`（**多対一**＝合算振込に対応）。集計(c)を「出金額 − その取引に紐付いた経費の合計（下限0）」に変更。**全額突合なら0になって消え、一部だけ突合なら残額だけ計上される**ので、合算振込の途中経過でも壊れない。発生側(b)は減らさない＝**人件費・外注費は勤務月に載る（発生主義を維持）**。突合を解除すれば元に戻る（片方向の破壊をしない）。既存データは settled_txn_id=null なので**金額は一切変わらない**（実測で全月一致）。
    採らなかった案: **事業まるごと除外**（キャディ 0078 と同じ方式。振込名義での機械判定になり取りこぼす）、**発生ベース一本化**（カード明細からの経費拾いが全部手入力になる）、**自動計上をやめる**（人件費が勤務月に載らず1か月ずれる）。消込は家賃・ロイヤリティなど「発生と支払が月をまたぐもの」全部に効くので選んだ。
  **(c) 画面と候補出し** — money-os「カード・口座取込」に **「支払の消込」パネル**。候補は `lib/settlement.ts`（純粋関数）で、金額一致＞支払先一致、日付は発生の−31日〜+75日（前払いは1か月まで許す）、摘要の空白は無視、支払先1文字は誤検知するので照合しない、**突合済みの取引は候補から外す**（1つの出金を二重に消込まない）。候補が0件の経費は行ごと隠す（押せない行を並べない）。
    0096でSQL版 `suggest_expense_settlements` も作ったが、**単体テストで固定できる方を正典にする**ため 0097 で削除した（使われないSQL関数を残すと正典が二重になる＝#65と同じ判断）。
  **(d) 検証** — 実データで疑似の出金（-144,000・確定・外注）を作り、突合前 外注合計 8,434,992 → 突合後 8,290,992 ＝**差分ちょうど144,000**（二重計上が消えることを金額で確認）。候補提示も「金額・支払先が一致」で1件だけ返ることを確認。テスト行と突合は後始末済み。tests **142件通過**（settlement 9件追加）、money-golfwing tsc 0エラー。
  **(e) 運用に残る判断** — 消込は人が押す。押し忘れると**発生と支払の二重計上ではなく「支払が余分に計上される」**（発生だけの状態より多い）。BUSINESS.md / SYSTEM.md に手順を明記した。**新しい自動計上を足すときは、その支払が銀行側からも入るかを必ず確認すること**をSYSTEM.md §4-5に恒久ルールとして書いた。
  残: ①未消込の出金・経費が一定期間残っていたらホームで警告 ②領収書(`mon_receipts`)の突合と消込の統合（今は別々の紐付け）。
- #109 (2026-08-07) **Xの反応数の取り込みと、スレッド進捗の可視化（migrationなし・cnt_posts.metrics を使う）**。#107の残件①②。（並行セッションが先に #108 を使ったため採番し直した）
  **(a) 取得方法は料金で決めた** — 反応数は取り方で単価が5倍変わる。`GET /2/tweets?ids=` は **Posts: Read $0.005/件**、`GET /2/users/{id}/tweets` は **Owned Reads $0.001/件**（自分のアプリで自分の投稿を読む場合・docs.x.com/x-api/getting-started/pricing 2026-08確認）。**自分のタイムラインを1回だけ読んでID突合する**方式にした。同じリソースはUTC日内で重複課金されないので、日1回なら月$1未満。ユーザーIDの取得は User: Read $0.010 と割高なので `gn_loops.config.x_user_id` に焼いて2回目以降は叩かない。
  **(b) 10分tickではなく日次cron** — publishDue と同じ10分tickに乗せると1日144回になり、取り方を安くした意味が消える。`/api/cron/daily` から `refreshContentMetrics` を1日1回だけ呼ぶ。取得に失敗しても投稿処理は巻き込まず、`ai.sns_metrics_failed` を出来事ログに残すだけにした。
  **(c) スレッドは「入口」と「合計」を分けて持つ** — `metrics.x` = 入口ツイートの数字、`metrics.x_thread` = 連投全体の合計。入口だけ見ると返信に付いたいいねが消え、合計だけ見ると入口の伸びが分からない。画面は合計を優先表示。表示回数(impression_count)は自分の投稿でのみ返るので、**取れなかった場合は0ではなくnull**にして「0回表示」と誤読させない。
  **(d) OAuth 1.0aのGETで踏んだ穴** — GETは**クエリ文字列も署名対象**だが、Authorizationヘッダに載せてよいのは `oauth_*` だけ。従来の `buildOAuthHeader` は extraParams をヘッダにも出しており、投稿(POST・クエリなし)では表面化しなかった。ヘッダ生成を `oauth_` で絞り、テストで固定した。
  **(e) 画面** — /ai-sales の投稿カードに **連投 n/9** チップ（未完了は琥珀色＋「続きを投稿中」）と、反応数（👁表示・♡いいね・↻リポスト・💬返信）。cronを待たずに確かめられるよう「反応数をいま取り込む」ボタンも置いた（X未接続時は押せない）。`PRODUCT_SHORT` に `yozan`（YOZAN公式）を追加。
  **(f) 検証** — `tests/x-metrics.test.ts` 5件（タイムラインを1回だけ叩く／public_metricsの変換／欠けた表示回数はnull／連投の合計／クエリをヘッダに載せない）＝全 **147件通過**。@yozan/content の tsc 0エラー、genesis tsc は既知の workspace 解決ノイズ(TS2307)と既存のTS7006 1件のみ。
  **(g) 実データで見つかった読み間違い** — 会社紹介スレッド（9本）の取り込み結果が **replies 合計8** になった。X は「自分の次の投稿」も返信として数えるので、**8件は全部が自作自演**。そのまま出すと「8人が反応してくれた」と読める。連投の合計からは **連結ぶん（本数-1）を引いて外部からの返信だけ**を出すようにした（入口ツイートの `metrics.x` は素の値のまま）。初回取り込み実測: 表示12・いいね0・返信0（外部）。
  残: ①Instagram側のInsights取得（IG未接続のため保留） ②反応数の推移をグラフ化するか（現状は最新値のみ・履歴は持たない）。
- #110 (2026-08-07) **営業先の自動ピックアップ `@yozan/prospect`（migration 0098適用済・正典 docs/modules/prospect/SYSTEM.md）**。要望「①から順に作成／パソコンを閉じてる状態でも自動でピックアップしてリスト化する仕組みに」。[[hp-sales-pipeline]] の①。
  **(a) 何が問題だったか** — 営業先13件はすべて `source='manual'` で、**古川が手を動かした日だけ増える**状態だった。③閲覧計測(#95)とインバウンド(#101〜#104)は動いていたのに、パイプラインの入口が人の稼働に縛られていた。デモの外部閲覧は0件＝作っても届ける経路が無く、上流も止まっていた。
  **(b) 動く場所を先に決めた** — demo-sales に `vercel.json` の crons を新設し `/api/cron/prospect` を **20:00 UTC（JST 5:00）と 23:00 UTC（JST 8:00）** に叩く。#107 で決めた「外部への発信・定期処理は必ずcronに載せる／ブラウザ操作は最終手段」をそのまま適用した。middleware の公開プレフィックスに `/api/cron` を追加（登録漏れは #90 の事故）。**1回で終わらせない前提**にし、`budgetMs` を超えたら止めて次tickが続きから進む（外部サイトの取得は遅く件数も読めないため）。
  **(c) 取得アダプタは差し替え可能に（ユーザー選択）** — `kind='directory'`（医師会等の公開名簿ページ巡回・無料・いま動く）と `kind='places'`（Google Places API）の2本。**Placesはキー未設定なら黙ってskip**するので、`GOOGLE_PLACES_API_KEY` をVercel envに入れた瞬間にコード変更なしで有効になる。サイトごとの専用スクレイパは書かず、「一覧からリンクを拾う→詳細から連絡先を拾う」の2段だけを汎用化し、サイト差は `prs_sources.link_pattern`（正規表現1つ）で吸収する。伊丹市医師会名簿（約200件）をシード済み。
  **(d) 巡回の作法** — User-Agentに会社名と連絡先を明記、`robots.txt` を読んでDisallowなら取りに行かない（`src/robots.ts`・純粋関数でテスト固定）、同一サイトへは1.2秒間隔、1回の上限は `max_per_run`。**「技術的に取れるか」ではなく「取ってよいと言われているか」で止める**。
  **(e) Web現況スコア** — 取得済みHTMLだけを見る純粋関数（`src/audit.ts`）。評価は1〜5で demo-sales の `ANALYSIS_ITEMS` と同じキーに入れ、画面でそのまま見え人が上書きできる。`score`(0-100) は**改善余地の大きさ**＝直したときの効果が大きい先が上に来る。`mobile` を最重(26点)にしたのは、スマホで見られないことが最も強い提案材料だから。⚠**文字コードを必ず見る**（`decodeHtml`）: 古いサイトほどShift_JISが残っており＝まさに営業対象。UTF-8決め打ちだと本文が化けて「情報量が少ない」と**誤って高得点**になる。取得できなかった先は0点にせず40点（中位）に置く＝消さずに人の目に触れさせる。
  **(f) 所見と観測値を分けた** — `analysis` は所見（AI・人が書き換える）、`audit` は観測値（上書きしない）。混ぜると人が直した所見を翌朝のcronが機械の値で潰す。
  **(g) 重複は構造で潰す** — 自動で拾い続ける仕組みで重複を許すと②outreachで**同じ医院に2通目**を送る。`prs_seen`（company_id, ref_key ユニーク・拾わなかった理由も残す）＋ `dedupe.ts`（電話一致/サイト一致は屋号が違っても同一、屋号だけの一致は同じ市のときに限る＝「たなか歯科」は全国にある。市が不明な側があれば安全側に倒す）。
  **(h) デモ作成まで自動（ユーザー選択）** — `score>=55` の上位3件まで自動生成。既にデモがある先は触らない（面談中に見せている画面が変わるため）。**「営業お断り」表示を検出した先はデモも作らない**（作れば送りたくなるので入口で止める）。中身は業種テンプレートの仮データで、**AIに文章を書かせていない**＝送る前に必ず人が見る前提なので、下書きの品質より作られていることが重要。生成は demo-sales 側の `createAutoDemo` を `onDemo` コールバックで呼ぶ（パッケージは `renderDemo` を知らない＝アプリ非依存）。
  **(i) 非医療の業種を追加（ユーザー選択）** — `salon`/`esthe`/`restaurant`。医療広告ガイドラインの対象外なので、お客さまの声・施術前後写真・価格を出せる＝勝ち筋が違う。あわせて `templates.ts` に**語彙層 `IndustryVocab`/`vocabOf`** を入れた（省略項目は医療系の既定値）。これが無いと美容室のデモに「院長あいさつ」「ご来院の流れ」、提案書に「院長先生」「診療時間」が出る。名簿は診療科が混在するので `guessIndustry()` がページの文言から寄せる（拾えなければ巡回元の設定のまま＝勝手にotherへ落とさない）。
  **(j) 判断は1回だけ** — Genesisの判断フィードに `source='prospect'` を追加。「〇〇（Web現況スコア78点）のデモができました／見つかった改善余地: …」→「デモを確認する」。demo-sales には `/sources` 画面（巡回元の追加編集・実行ログ・「いま1回だけ試す」）を新設し、SQL直打ちにしない。
  **(k) 検証** — `tests/prospect.test.ts` 22件（古いサイトの方がスコアが高いこと・十分なサイトが上位に来ないこと・営業お断りの検出・重複判定・robots最長一致・名簿からの抽出・業種推測）＝全 **169件通過**。demo-sales / genesis とも tsc 0エラー（paths を通した tsconfig.tscheck.json で確認）。
  残: ①**Vercelで demo-sales に `CRON_SECRET` を設定（これが無いとcronが401で動かない＝ユーザー作業）** ②`/p/[id]` に採点内訳の表示 ③②`@yozan/outreach`（送信）。「営業お断り」の検出は①で済ませてある。
- #111 (2026-08-07) **営業メールの自動送信 `@yozan/outreach`（migration 0099適用済・正典 docs/modules/outreach/SYSTEM.md）**。[[hp-sales-pipeline]] の②で最後の1本。これで ③計測→①ピックアップ→②送信 が一周し、人の稼働が要るのは「返信が来てからの商談」だけになった。
  **(a) ユーザー選択（2026-08-07）** — 送信基盤=Resend／送信元=`yozan-group.jp` のサブドメイン（本体のメール到達性を守る）／**承認なしの完全自動**／返信の受け口=既存の `info@yozan-group.jp`（Gmail転送済み・新しい受信経路を増やさない）。
  **(b) 送る仕組みと同時に「止める仕組み」を作った** — メールは取り消せないので、後から足すのでは間に合わない。**ウォームアップ**（初日10通・1日10通ずつ増・上限で頭打ち。新しい送信元から急に大量送信すると迷惑メール判定される）、**自動停止**（直近100通で宛先不明8%超 or 迷惑報告2件で停止。放置すると送信ドメインの信用が壊れ**会社の普段のメールまで届かなくなる**ので人が気づくのを待たない）、**手動停止**、**抑止リスト**（配信停止/バウンス/苦情を自動で積む・ドメイン単位可）、**1営業先1通**（`out_messages` の部分ユニーク索引で構造的に担保＝アプリの条件分岐に頼らない）、**記録が先・送信が後**（queued行を作ってから送る。逆だと記録前に落ちたとき二重送信）。
  **(c) 送信可否は純粋関数に閉じた（`policy.ts`）** — DBに触らずテストで固定し、`server.ts` を唯一の呼び出し元にした。判定は**「送ってよい理由が揃っているか」**で書いている（除外条件を並べる書き方は、条件を1つ足し忘れたときに「送れてしまう」方向に倒れるため）。
  **(d) 法的根拠を列で持たせた** — 特定電子メール法3条1項3号は「自己のアドレスを**公表している**営業者」への送信を同意なしで認める。名簿やPlacesのアドレスは公表主体が本人とは限らないので根拠にならない。①側の audit に **サイトからのメールアドレス抽出**を追加し、`dms_prospects.email_source`（site/directory/places/manual）と `email_page_url` を記録。**送信対象は email_source='site' のみ**。推測でアドレスを組み立てる（info@ドメイン等）ことは実装していない。
  **(e) 法定表示は文面から切り離した（`compose.ts`）** — 4条の表示義務（名称・住所・受信拒否の通知先）をテンプレート本文に書かせると**書き忘れた文面が1つ混ざった瞬間に違法**になる。`composeEmail` が `companies.settings.invoice`（#99で登録済み）から機械的に付け、テンプレート側で消せない。住所が未設定なら**送信そのものを中止**する。`List-Unsubscribe`/`List-Unsubscribe-Post`（RFC 8058）も付与＝停止導線が押しやすいほど迷惑報告が減る。
  **(f) 送るのはデモがある先だけ** — この営業の型は「完成イメージを見せる」ことが中身なので、デモが無いメールはただの売り込みになる。`hasDemo` を送信条件に入れた（①の自動デモ生成と噛み合う）。
  **(g) 配信結果を持ち帰る** — `/api/webhooks/resend`（Svix署名検証・5分のリプレイ防止）で delivered/opened/bounced/complained を `out_messages` に記録。**Webhookは順不同で届く**ので `isForwardTransition` で状態を後戻りさせない。バウンス・苦情は抑止リストへ自動追加し、営業先を unreachable/lost に落とす。これが無いと自動停止も効かない。
  **(h) 画面** — demo-sales `/outreach`（状態・送信ログ・文面編集・送らない先・「送らずに内容を確認」＝dryRunで判定と文面を見る・「いますぐ止める」）。送信元/返信先/上限/時刻は**envではなく out_settings**（運用で変えるものをenvに置くと再デプロイが要る）。cronは毎時叩き、`send_hour_jst` の回だけ送る＝時刻変更にデプロイ不要。
  **(i) 検証** — `tests/outreach.test.ts` 22件（公表アドレス以外を弾く/営業お断り/抑止/2通目なし/デモ無しは送らない/上限/ウォームアップの刻み/自動停止の閾値と母数/法定表示が必ず入る/改善余地は2つまで/既定テンプレに未置換差込とMarkdown装飾が残らない/Webhookの読み替えと後戻り防止/アドレス抽出）＝全 **192件通過**。demo-sales・genesis とも tsc 0エラー。
  残: ①**Resendのドメイン認証（send.yozan-group.jp のDNS登録＝ユーザー作業。OPERATIONS §12）と `RESEND_API_KEY` 設定** ②認証後に `/outreach` で送信をON ③返信の自動検知（replied_at）とフォローアップ2通目（現状は1営業先1通で固定）。
- #112 (2026-08-07) **Money OS 売上入力の刷新: お客様名の可視化・購入履歴・定価/割引額/決済金額・Excel出力（migration無し）**。要望「売上入力で顧客名も表記できるように／名前を押したら詳細／エクセル出力（添付と全く同じ形式で）／金額入力時に定価と割引額、決済金額を入力できるように」。
  **(a) お客様名が明細から消えていた** — 一覧は `品名 || お客様名` の1列で、品名が入っていると**お客様名が表示されない**。誰に売ったかが台帳Excelには残るのにアプリでは見えない状態だった。`お客様名` と `品名・内容` を独立した列に分けた（会員区分は名前の横に小さく併記）。
  **(b) 購入履歴は2系統を混ぜる** — 名前クリックで `CustomerHistoryDialog`（累計税抜・明細数・来店日数・初回/最終来店）。取得元は `mon_sales`(source='app') **＋ `mon_sales_lines`**（台帳Excel取込分）の両方。アプリ側だけ見ると、台帳にしか履歴が無い常連が「初めてのお客様」に見える。名簿は持たず**売上明細の名前で引く**ので、表記ゆれ（全角スペース有無等）は別人扱いになる＝既知の割り切り。
  **(c) 金額入力を台帳Excelと同じ計算の流れに** — `定価 + 割引額 = 売価 → ×個数 = 金額(税抜) → 切り捨て10% = 決済金額(税込)`。従来は「単価×個数」だけで、割引を打つと定価が消えて**いくら値引いたかが残らなかった**。下流を手で直したらそこから下の自動計算を止める（`unitManual`/`amountManual`/`taxManual`）＝端数調整を潰さない。「売価を先に入れてから割引額」を打つ人向けに、定価が空なら現在の売価を定価とみなす。在庫リストから品番を選ぶと定価は**売価ではなく定価欄**に入る。
  **(d) migrationを足さなかった** — 定価・割引額は `mon_sales.detail.list_price` / `.discount`（jsonb）へ。集計の正は従来どおり `amount`（税抜合計）なので、`refresh_money_to_finance` も既存レポートも触らずに済む。列を足すと 0022 以降の集約関数まで波及する。
  **(e) Excel出力 `/api/sales/export?month=YYYY-MM`（`lib/sales-excel.ts`・exceljs）** — 現場の「新ゴルフウィング売上データ.xlsx／◯◯期売上一覧」と**同じ29列・列幅・書式・テーマ色・オートフィルタ・ウィンドウ枠固定**で当月明細を書き出す。既存ブックへそのまま貼れることが要件。**J売価/L金額/M税込/W掛け率/Z金額/AA粗利は値ではなく数式**で書く（定価や割引を直したら追従する現場の運用を壊さないため）。シート名は `${fiscalTerm}期売上一覧`（6月始まり・2025-06〜=31期）。
  **(f) 日付はDateを渡さずExcelシリアル値で書く** — ExcelJSにJS Dateを渡すと実行環境のTZで1日ずれる（UTCのVercelで前日になる）。`excelSerial()` で 1899-12-30 起点の整数を直接書き込む。[[jst-date-rule]] と同じ穴。
  **(g) 二重計上を構造で避けた** — 出力対象は `mon_sales` の **source='app' のみ** ＋ `mon_sales_lines`。`ledger`/`migration`/`slack_import` は「月末日付・お客様名なしの月次まるめ」で中身は lines と同じものの合計。当初 `source<>'ledger'` で除外していたが、実データに migration/slack_import が居て明細に混ざるため `= 'app'` に倒した。
  **(h) 定価・割引額の埋め方** — H定価は `detail.list_price` → `inv_items.list_price` → 売価 の順で採用。**I割引額は保存値を使わず必ず「売価−定価」で出し直す**。金額を手で上書きした明細でも `定価+割引額=売価`・`売価×個数=金額` が崩れず、DBの `amount` とExcelの合計が必ず一致する。種類/メーカー名/仕入れ値は `detail.inv_item_id` → `inv_items` から補完（掛け率・粗利は仕入れ値が分かる行だけ）。販売者はDBに項目が無いので空欄。
  **(i) 検証** — 出力xlsxを openpyxl で添付ファイルと突き合わせ（値・数式・数値書式・フォント・塗り・罫線・列幅・固定・オートフィルタ）。残差は元ファイル側のばらつき（テキスト列に数値書式が残る等）のみで、出力は各列の最頻パターンに揃えた。計算ロジックは `SalesEntry.tsx` から実関数を抜き出して11ケース（値引き・個数複数・決済手入力後の個数変更・不変条件）全通過。2026-07の台帳155行で `定価+割引額=売価`・`売価×個数=金額` が**全行成立**することをSQLで確認（合計1,334,220＝月次まるめと一致）。tsc 0エラー。
  **(j) 定番ボタンを頻度順・最大10件に（2026-08-07 追記）** — 「一度しか入力していない商品が定番に並ぶ／10個までにして、同じ入力の多いものを順に自動で並び替え・入れ替え」。上限8→**10**、並びは**打った回数の多い順・同数なら直近に打った順**（直近500明細が母数）。使われなくなった組み合わせは上限の外へ自然に押し出されるので手入れ不要。
  あわせて**集計の金額を合計(amount)から単価に変えた**。合計で数えると同じ商品が個数ごとに別の定番へ割れ（個数2の「パーソナルレッスン２５分 4,000」が別枠になる）、押したときに**定価欄へ合計額が入る**バグになっていた。単価は `detail.list_price` → `amount/qty` の順。実データで「パーソナルレッスン２５分 2,000」が n=8 に統合されることを確認。`Preset.amount` → `Preset.unitPrice` に改名して意味を型で固定。
  残: ①`exceljs` を追加したのでデプロイ時 `npm install` が要る ②販売者欄を入力項目にするか ③お客様名の表記ゆれ統合（名簿と紐付けるか）。
- #112 (2026-08-07) **Vault（システム台帳）から16件が消えていた表示バグを修正（migrationなし・データ側のカテゴリも正規化）**。ユーザー指摘「demo-salesが台帳に乗っていない」から発覚。
  **(a) 原因** — `/vault` の画面が `CATEGORIES`（site/dev/mail/saas/other の5つ）**に列挙されたカテゴリだけ**を `filter` して表示する作りだった。台帳の登録自体はAIも人も自由な文字列でカテゴリを入れられるため、'社内システム' '開発' 'SNS' 'web' 'store' 'payment' 'サイト' 'システム' '仕入先サイト' の行が**1件も画面に出ないまま消えていた**（40件中**16件**）。AI DEMO SALES は #54 から一貫して登録されていたのに、category='社内システム' だったため一度も表示されていなかった。
  **(b) なぜ重大か** — 台帳は「そこに全部ある」ことが唯一の価値なので、**取りこぼしが静かに起きる**のは最悪の壊れ方。「登録したのに無い」と見えるため、同じシステムを二重登録する動機にもなる（実際 Instagram SWING CORTEX が2件重複していた）。
  **(c) 直し方 — 分類の網羅性に依存しない作りへ** — グループ化を `lib/vault-categories.ts` に純粋関数として切り出し、**未知のカテゴリは other に落として必ず表示する**（捨てない・throwしない）。表記ゆれは `ALIASES` で吸収（社内システム/サイト/システム/web/store→site、開発→dev、SNS→sns、仕入先サイト→other）。カテゴリは実態に合わせて **site/saas/sns/mail/payment/dev/other の7つ**に拡張し、追加フォームのselectと同じ定義を共有する。見出しに総件数を出して「全部で何件あるか」を画面で確認できるようにした。
  **(d) データ側も正規化** — 非対応カテゴリの16件を上記の対応表でUPDATE。結果 site 19 / saas 5 / sns 4 / mail 5 / dev 4 / payment 1 / other 2 ＝ **40件すべてが表示対象**になった。
  **(e) 検証** — `tests/vault-categories.test.ts` 6件。中心は「**グループ化の前後で件数が変わらない**」＝この事故そのものを落とすテスト。ほかに表記ゆれの吸収・未知カテゴリのother落ち・表示順・ラベル付与。全 **198件通過**、genesis tsc 0エラー。
  **(f) あわせて台帳の内容も最新化** — 「AI DEMO SALES（営業デモ生成）」→「**AI DEMO SALES（HP制作営業）**」に改称し、#110/#111 で足した画面（/sources・/outreach・/unsubscribe）・cron 2本・Webhook・DBスキーマ4系統・環境変数・止め方・送信元/返信先を記載。Reserve OS には「**Resend無料枠を空けるため yozan-inc.jp を削除したので、本稼働時は RESERVE_FROM_EMAIL の変更が必要**」という警告を追記（気づくべき場所に書く）。
  残: ①Instagram SWING CORTEX の重複2件の統合（どちらを残すかはユーザー判断） ②Vaultに「重複しそうな名前」の警告を出すか。
- #113 (2026-08-07) **User-Agentに日本語を入れていたため、①の巡回・採点が全滅していたのを修正（コードのみ）**。ユーザー報告「0件になります」から発覚。
  **(a) 症状と原因** — `/sources` の「いま1回だけ試す」が 新規0・重複0・採点8・デモ0 を返した。実行ログ(`prs_runs.detail`)を見ると全件が `TypeError: Cannot convert argument to a ByteString because the character at index 45 has a value of 26666`。26666=「株」。`packages/prospect/src/http.ts` の UA に **「株式会社YOZAN ホームページ制作の営業調査」と日本語を入れていた**のが原因。**HTTPヘッダは ByteString(Latin-1) しか受け付けない**ため、`fetch` が呼ばれた瞬間に例外になり、一覧ページの取得も現況スコアの取得も**1件残らず失敗**していた。
  **(b) なぜテストで捕まらなかったか** — #110 のテストは純粋関数（audit/dedupe/robots/parse）だけを固定しており、**ネットワーク層を1度も通していなかった**。「fetchはhttp.tsに隔離してテストしない」という方針自体は正しいが、*ヘッダの組み立てはfetchを呼ばなくても検証できる*ことを見落としていた。
  **(c) 見つけにくかった理由** — 画面には「採点8」と出て**一見動いたように見える**。`unreachableAudit` が例外を握って40点（中位）を返す設計にしていたため、全件が「サイトを取得できませんでした・40点」で正常終了扱いになっていた。**握りつぶさない設計にしていたおかげで `prs_runs.detail` に理由が残っており**、そこから即特定できた（ログを残す判断は正しかった）。
  **(d) 修正** — UAをASCIIのみに（会社URLも `yozan.co.jp` → 正しい `yozan-inc.jp`、連絡先を `info@yozan-group.jp` に）。`tests/prospect.test.ts` に**UAの文字種を固定するテスト**を追加（charCode>255 が無いこと＋`new Headers()` が実際に throw しないことの二重確認＋連絡先が入っていること）。全 **199件通過**。
  **(e) 誤った採点結果の後始末** — この不具合で 8件が「40点・取得失敗」として記録され、`audited_at` が入ったせいで**二度と再採点されない**状態になっていた（再採点しない設計のため）。`audit.reason` が TypeError で始まる行の採点結果を消して `status='unanalyzed'` に戻し、次のcronで採点し直されるようにした（13件すべて未採点＝初期状態）。
  **(f) 学び** — 「外部に出ていく値」はfetchを呼ばずとも検証できる部分がある（ヘッダ・URL・エンコーディング）。純粋関数だけをテストする方針は、**その手前の組み立て**まで含めて初めて意味を持つ。
- #114 (2026-08-07) **名簿の巡回を「詳細ページの見出し」から「一覧ページの行」へ変更（migrationなし）**。#113でUAを直したあとも新規0件だったのを追った結果。
  **(a) 何が起きていたか** — 巡回自体は成功して**候補10件を取れていた**のに、`picked=0`。`prs_seen` を見ると全件 `duplicate`。原因は `extractContact` が屋号を `h1 → h2 → <title>` の順で探す作りで、**伊丹市医師会DBの詳細ページには見出しが無く、title が全ページ共通**（「ITAMI med Database [データ詳細]」）だったこと。結果、10件すべてが同じ屋号になり、1件目だけ登録されて残り9件は「同名＝重複」で落ちていた。実際にDBには屋号「ITAMI med Database [データ詳細]」の営業先が1件だけ生まれていた。
  **(b) 直し方 — 一覧の表から読む** — 名簿は「一覧の表に 屋号・住所・電話・診療科 が揃っている」形が大半。`extractRows()` を新設し、**リンクの文字＝屋号**、同じ `<tr>`（または `<li>`）内のセル＝住所・電話・診療科として読む。詳細ページは**公式サイトのURLを取るためだけ**に開く（一覧で取れた値は上書きしない）。外部サイトへの往復も減る。
  **(c) 静かな失敗を止める安全弁** — `looksBroken()` を追加。**屋号が全件同じ／種類が極端に少ない**場合は「抽出に失敗している」と判定し、**中途半端に登録せず巡回元ごと中止**してエラーを残す。今回のように「1件だけ入って残りは重複扱い」という、画面上は正常に見える失敗を二度と起こさないため。
  **(d) 握りつぶしをやめた** — `dms_prospects` への insert で `error` を捨てていたため「なぜ0件か」が追えなかった。エラーを `prs_sources.last_result` に残すようにし、`prs_seen.note` に**拾った屋号と電話**を記録する（何を拾ったのかが見えないと抽出のおかしさに気づけない）。
  **(e) 後始末** — 屋号がページタイトルになっていたゴミ1件を論理削除し、`prs_seen` の伊丹市医師会分を消して拾い直せるようにした。
  **(f) 検証** — `tests/prospect.test.ts` に4件追加（実ページを模した一覧HTMLから屋号・電話・市を取れること／診療科名から業種を寄せること／**全件同じ屋号を異常と判定すること**／件数が少ないうちは判定しないこと）＝全 **202件通過**、demo-sales tsc 0エラー。
  **(g) 教訓** — 「h1が無ければtitle」は一般には妥当だが、**CGI型の名簿では全ページ同じ値になる**。汎用の抽出は必ず「同じ値ばかり返っていないか」を自分で疑う仕組みとセットにする。#113と合わせ、**外部サイト相手の処理は実データで1回通すまで完了と見なさない**。
- #115 (2026-08-07) **モジュール化 優先順位①〜④のpackages切り出し（コードのみ・migrationなし・既存アプリ変更なし）**。正典 `docs/genesis/MODULARIZATION_PLAN.md`（同日作成）の実行。重複はgrep実測: CSV系10アプリ／Stripe実体はgenesis1箇所／jst.tsはgenesis+inventory-osに同一コピー／cron認可はgenesis daily・demo-sales prospectが完全同型。
  **(a) 方針** — 実績コードの逐語切り出しに徹し、新規の汎用化はしない。DBを触る処理はアプリ側に残す（trackと同じ「クライアントは引数で受け取る」方式）。**既存アプリは1行も変更していない**（B-6: 移行は1アプリずつ・Vercelビルド確認付き。今回のpackagesは新規アプリと次の商品から使う）。
  **(b) `@yozan/import`（①）** — `csv`（parseCsv逐語＋toCsv新設・既定BOM付き）/ `decode`（cp932ラベル吸収）/ `normalize`（toNumber・parseDate逐語＋makeDedupKey）/ `table`（ヘッダ行マッピング）。切り出し元はMoney OSのbankCsv.ts。Excelは対象外（ExcelJS依存＋Smart Hello名前空間ハックはmember-os固有のため）。
  **(c) `@yozan/billing`（②）** — frank-billing.ts(#97)からStripe往復だけを抽出: stripePost / 顧客作成 / Checkout(subscription) / 署名検証（逐語）/ `createStripeWebhookHandler`。Checkoutパラメータは`buildSubscriptionCheckoutParams`として純粋関数化（#113の教訓:「外部に出ていく値の組み立て」をテストで固定するため）。1ファイル構成（パッケージ内の拡張子なし相対importはnode --testが解決できないため。prospectの内部importをテストが踏んでいないのと同じ制約）。
  **(d) `@yozan/core/jst`（③）** — genesisのjst.tsを逐語でcoreへ。テストは3コピー（core/genesis/inventory-os）の**出力一致を固定**し、片方だけ直して日付がズレる静かなドリフトを検知する形にした。
  **(e) `@yozan/cron`（④）** — requireCronAuth＋createCronHandler（会社ごとループ・1社の失敗は他社を巻き込まない=genesis daily方針）。maxDuration宣言とmiddleware公開プレフィックスは肩代わりできないのでREADMEに⚠明記。
  **(f) 検証** — tests 16件追加（import 6 / billing 5 / cron 4 / core-jst 1）＝全 **218件通過**。billingは「切り出し元と同一挙動」より強く、署名の改ざん・鍵違い・5分超過・503/400/500の応答コードまで固定。
  **(g) 使いどころ** — billingはFRANKのsk_live差替え時にこの経路へ。importは次に取込機能を触るアプリから。⑤承認フローは計画どおり外販確定まで着手しない。
- #116 (2026-08-07) **営業先を「まとめて拾う」形に変え、ホームページが無い先を最優先にした（migration 0100適用済）**。ユーザー指摘「あまりにも件数が少なすぎます、方法を変えるなども検討してください」。
  **(a) 何が遅かったか** — 候補1件ごとに詳細ページを開いて1.2秒待つ作りだったため、45秒の試し実行では**10件が限界**だった（伊丹市医師会だけで約200件ある）。しかし#114で一覧の行から屋号・住所・電話を取れるようにした時点で、**詳細ページを開く必要はもう無かった**（開くのは公式サイトURLを探すためだけ）。
  **(b) 詳細ページ訪問を任意にした** — `prs_sources.visit_detail`（**既定false**）。一覧ページ1枚の取得で数百件を候補化できる。上限も `max_per_run` 既定10→**100**、1回の新規上限 30→**300**に引き上げ。相手サーバーへのアクセスも「一覧1回」だけになり、むしろ礼儀正しくなった。
  **(c) ホームページが無い先を最優先にした（発想の転換）** — 従来は `website_url` が無い先を**採点対象から外していた**（`.not("website_url","is",null)`）。しかし**HP制作営業では、サイトが無い先こそ最良の見込み客**。`noWebsiteAudit()` を追加し、**95点（最優先）**として扱う。
    - **「サイトが無い」と「サイトを取得できなかった」（40点）は明確に分ける**。前者は作れば全部が改善する確かな観測、後者は調べ直しが要る保留。混ぜると「たまたま落ちていたサイト」を最優先で営業してしまう。
    - 外部への通信も不要なので採点が速い。
    - ⚠この先はメールアドレスも公表されていないことが多く、②outreachの送信条件（`email_source='site'`）を満たさない＝**電話営業のリスト**になる。スコア順に並ぶので上位から架電できる。
  **(d) 巡回元を追加** — 宝塚市医師会の名簿を追加（既存の福本クリニックと同じDB形式）。Google Places の3件は `GOOGLE_PLACES_API_KEY` 待ちのまま。
  **(e) 後始末** — #114以前の旧コードで登録された「屋号＝ページタイトル」の行を削除し、`prs_seen` の伊丹市医師会分を消して拾い直せるようにした。
  **(f) 検証** — tests 2件追加（サイト無しは95点で古いサイトより上位／「無い」と「取得失敗」を区別する）＝全 **220件通過**、demo-sales tsc 0エラー。
  残: ①`GOOGLE_PLACES_API_KEY`（美容室・エステ・飲食が一気に増える） ②他市の医師会・歯科医師会・獣医師会の名簿URL追加 ③サイト無しの先の架電リスト画面。
- #117 (2026-08-07) **営業リストの取得を Places主軸＋AI抽出 に組み直した（migration 0101適用済）**。ユーザーの問い「根本的にそれは他業種に応用できる形ですか？生成AI系のAPIなどを使ったほうがよくないですか？」に対して、**どちらも正しい指摘**だったため設計を変えた。
  **(a) 名簿方式は他業種に応用できなかった** — 医師会・歯科医師会のように**業界団体が名簿を公開している業種**にしか使えず、美容室・エステ・飲食には該当する名簿が無い。さらに一覧ページのHTML構造ごとに `link_pattern` を人が設定する必要があり、#114で全滅したのもその脆さが原因。→ **Google Places API を主軸に格上げ**し、名簿は「Placesに無い情報（診療科など）を補う」補助に降格した。
  **(b) AIの使いどころを工程で切り分けた（この判断がこの決定の核）**
    - **①見つける（列挙）＝AIに任せてはいけない**。LLMは検索エンジンではなく、「伊丹市の美容室を100件挙げて」と頼めば**実在しない店を作る**。営業リストに架空の宛先が混ざれば、メールは届かず電話も繋がらず、こちらの信用が損なわれる。ここは実在が保証される Places API。
    - **②読み取る（構造化）＝AIが効く**。任意のHTMLから項目を取り出すのは正規表現の限界であり、LLMの得意分野。今日2度失敗したのはまさにここ。
    - **③評価する（現況スコア）＝AI不要**。SSL・viewport・更新年は機械計測の方が正確・無料・速い。
  **(c) 実装** — `ai-extract.ts`。`prs_sources.parser`（**auto**=規則→ダメならAI／rules／ai）。AIには「渡したHTMLに書かれていることだけを写せ、書かれていない項目はnull、創作禁止」と指示し、さらに **`verifyAgainstSource()` で元HTMLに実在する屋号だけを残す**（AIが指示に反して補完しても営業先にしない最後の砦）。`compactHtml()` で script/style/svg/コメントを落としてから渡す（費用は入力長に比例＝削るほど安く正確になる）。既定モデルは Haiku、1ページ数円で数百件を処理。
  **(d) Places の扱い** — `maxResultCount` を上限20固定にし nextPageToken で継続（Places APIの仕様上60件が上限。件数を稼ぐならクエリを分ける）。費用は **Text Search が月5,000リクエストまで無料**（2025年3月に$200共有クレジットは廃止されSKUごとの無料枠へ変更）。1リクエスト最大20件なので通常の運用は無料枠に収まる。
  **(e) 検証** — tests 3件追加（**AIが書いた屋号が元ページに無ければ落とす**／AIに渡す前にHTMLを削る／コードブロック混じりの出力からJSONを読む・壊れた出力はnullで止める）＝全 **223件通過**、demo-sales tsc 0エラー。手順は OPERATIONS §13。
  残: ①`GOOGLE_PLACES_API_KEY`（ユーザー作業・これが入ると業種が一気に広がる） ②`ANTHROPIC_API_KEY`（任意・名簿のAI読み取り用） ③Places巡回元の一括登録UI（いまは1件ずつ）。
- #118 (2026-08-07) **FRANK GOLF 9/2オープンの運営自動化・残ギャップ一掃（migrationなし・コード＋docs）**。「今足りないものを全部」の実測から着手。実測結果: 予約（体験/打席/レッスン）・Stripe課金・CMS・LINEグループ配信・店頭タブレットは稼働済み、**未実装は §3-7 Square POS・月会費のMoney OS計上・お客様向けメール・内覧会の受け口**だった。
  **(a) Square POS連携（§3-7・未申請でも先に実装）** — `/api/public/frank/pos/webhook`＋`lib/frank-pos.ts`。payment/refund→`mon_sales`（source='square'・姫路セグメント・FRANK店舗）→`refresh_money_to_finance`で既存パイプへ。現金は`mon_cash_ledger`にも自動反映（Money OS売上入力と同じ動き）。返金はマイナス行（category=返金）＋company_events(notice)。**冪等はdetail->>square_payment_id/refund_idで担保**（Webhookは同一イベントが複数回届く）。署名検証はHMAC-SHA256(URL+body)のbase64。category一律「利用料」＝内訳はスタッフがMoney OSで直す割り切り（memoに手掛かり）。
  **(b) Stripe月会費のMoney OS自動計上** — `invoice.paid` を frank-billing に追加。mon_sales（category=月会費・source='stripe'・invoice idで冪等）→refresh。**税込→税抜は ceil(税込/1.1)**＝Checkout作成時 round(税抜×1.1) とMoney OSの floor(税抜×1.1) の両方と往復一致することをテストで固定。GW月会費予測(0028)はgolfセグメント限定なので干渉しない。⚠**Stripe側Webhook登録イベントに invoice.paid の追加が必要**（本番切替時にまとめて・OPERATIONS §14-1）。
  **(c) 体験の確認メール＋前日リマインダー** — 画面を閉じるとキャンセルURLを失う＝確認メールが唯一の控え。前日リマインダーはno-show対策（体験60件計画の歩留まりに直結）。`lib/frank-mail.ts`（Resend・未設定なら自動スキップで予約は通る）。リマインダーは日次cronの会社ループの外で1回（明日の体験＋会員打席予約でメールあり）。**Resendの frankgolf.jp ドメイン認証＝ユーザー作業**（OPERATIONS §14-3）。
  **(d) 特別営業日 `special_open_dates`** — 内覧会「実施しない/日程未定」の回答を受け、**日程が決まったら/site-adminから開けられる形**だけ作った。オープン前・定休曜日・臨時休業より優先して営業扱い。bookableRangeもその日まで前倒し（maxはopen_date基準のまま＝オープン後の範囲が狭まる事故を防ぐ）。あわせて saveBookingCfg が **open_date等フォームに無いキーを消していた**のを spread 保持に修正（保存するとオープンゲートがDEFAULT頼みになっていた）。
  **(e) 純粋部の分離** — frank-pos-pure.ts / frank-mail-pure.ts に隔離（#113の教訓: 外部とやり取りする値の組み立て・読み替えはネットワーク無しで固定する）。tests/frank-pos.test.ts 9件＋特別営業日3件＝全 **235件通過**、genesis tsc 0エラー。
  **(f) docs** — RESERVATION_SYSTEM.md に特別営業日/メール/POS/invoice.paidを追記、OPERATIONS.md **§14（FRANKオープンの残り設定4つ＋開店前チェック）** 新設、**運営マニュアルv2**（9/2運用版・Square後の会計は台帳廃止）、スタッフ周知文面 `12_オープン前スタッフ周知_0902.md`（配信はユーザー判断＝文面作成のみの指示）。
  残（すべてユーザー作業・OPERATIONS §14）: ①Stripe本番鍵＋Webhook再登録 ②Squareアカウント申請→署名キー設定 ③Resendでfrankgolf.jp認証＋env ④FRANKスタッフグループへOA追加・FRANK公式LINE開設 ⑤site-data.jsの「近日公開」埋め ⑥D打席設営後のactive化 ⑦法務3ページの確定。
- #119 (2026-08-07) **「ホームページが無い」と「まだ確認していない」を分けた（migration 0102適用済）**。`GOOGLE_PLACES_API_KEY` 投入後の初回実行で **277件を取得**（Places 177件・伊丹市医師会 100件）＝パイプラインが初めて実用量に到達。その結果として、#116の設計に埋まっていた欠陥が表に出た。
  **(a) 何が起きたか** — 名簿由来の100件は `visit_detail=false`（#116で既定OFFにした）ため**公式サイトを一度も探していない**。にもかかわらず `website_url is null` というだけで `noWebsiteAudit()` が走り、**全件95点＝最優先**になった。自動デモまで1件（いくしま内科クリニック）作られており、**ホームページを持っている医院に「見当たりません」と営業する寸前**だった。#114（屋号が全件同じ）と同じ型の事故＝**知らないことを、知っていることとして扱った**。
  **(b) 構造で直す** — `dms_prospects.website_checked`（既定 **false**＝未確認）。純粋関数 `websiteVerdict()` が `has` / `none` / `unknown` を返し、**採点に進めるのは has と none だけ**。埋め忘れても既定falseなので安全側に倒れる＝嘘の最優先が生まれない。列を足すだけでなく「未確認を採点対象から外す」ところまでやらないと再発する（採点キューの `.or("website_url.not.is.null,website_checked.is.true")`）。
  **(c) 未確認をPlacesで解消する** — 名簿由来の先は屋号＋市区町村で Places に1件だけ問い合わせ、`websiteUri` の有無で確認済みにする（`lookupWebsite()`・1回60件まで）。**返ってきた屋号が正規化一致しなければ捨てる**（別の店を掴んで営業する方がはるかに高くつく）。一致しなければ未確認のまま次回に回る。これで名簿も「診療科が取れる高品質な巡回元」として使い続けられる。
  **(d) 画面で見える化** — /sources に「うちN件はホームページの有無を確認中（確認できるまで採点しません）」を表示。ここが減らなければ採点が進んでいない合図になる。
  **(e) 後始末** — 誤って95点で採点された10件をリセット、そこから作られた自動デモ1件を削除、Places由来177件は確認済みに更新（APIが有無を答えているため）。
  **(f) 検証** — tests 2件追加（**探していない先を「HPが無い」と断定しない**／採点していいのは has か none だけ）＝全 **237件通過**、demo-sales tsc 0エラー。
  残: ①未確認100件の解消（cronが回れば自動・60件/回） ②他市の名簿追加 ③サイト無しの先の架電リスト画面。

- #120 (2026-08-07) **FRANK GOLF の会員システムが2つに割れていたのを入会申込に一本化＋バーガーメニュー無反応を修正（migrationなし・コード＋docs）**。ユーザーが自分でスマホから会員登録→予約を試して発覚。症状は「登録したのにメールが来ない」「会員番号が分からずログインできない」「もう一度登録しても駄目」「そもそも会員登録が見つけにくい」「予約画面で右上の三本線が反応しない」の5つ。
  **(a) 割れていた会員システム（本丸）** — 公式サイトのフッター「Web会員登録」は `links.memberRegister` → member-os `/member/register` で **`mbr_provisional_members`** に仮会員（`P########`・ログインは生年月日）を作っていた。一方 `booking.html` の打席予約は **`frunk_members`**（`F0001`・会員番号＋電話下4桁／`verifyMember`）を見る。**別テーブルなので、サイトから「会員登録」した人は100%予約できない**（実データ: 2026-08-07 14:27と14:30に同一人物の仮会員が2件、frunk_members側は0件）。決定: **FRANK の入会は Web入会申込（`/join-web` → スタッフ承認 → 会員番号発行）に一本化**。`/member/register` と `memberRegister` アクションは廃止し `/join-web` へ転送（ブックマーク対策で消さない）。`memberLogin` は **frunk_members を会員番号＋電話下4桁で照合**（booking.html と同じ鍵）に変更し、承認前は「承認手続き中」と明示。仮会員テーブルは GOLF WING 側の資産なので残置。
  **(b) 通知ゼロ** — member-os にはメール送信コードが1行も無く、申込受付も承認（会員番号発行）も無通知だった＝**申込者が自分の会員番号を知る手段が存在しなかった**。`apps/member-os/src/lib/frank-mail.ts`（Resend・`RESEND_API_KEY` 未設定なら送信スキップで申込は成立させる）を追加し、**/join-web に受付メール**を実装。文面で「会員番号は承認後に連絡する／それまで予約はできない」を明言＝承認前に予約ページで弾かれる問い合わせを潰す。あわせて**同一電話/メールで審査待ちが残っている間は行を増やさず受付済みとして返す**（受付メールが無かったせいで二重申込が実際に起きたため）。
  **(c) 入会導線が見つからない** — `links.joinWeb` へのリンクは **plan.html 本文の1か所だけ**で、ヘッダー・フッター・予約ページのどこにも無かった。ナビ（モバイルメニュー）とフッター MEMBER の先頭に「入会のお申し込み」を追加、`booking.html` の会員番号入力欄の直下にも案内を置いた。`memberBooking` は `booking.html` に向け直し（#93で member-os 側は転送のみ）、「会員番号と生年月日でログイン」の説明を全ページ「会員番号と電話番号下4桁」に修正。
  **(d) 三本線が反応しない** — `sites/frank-golf/assets/site.js` の `init()` が**2回走る**（DOMContentLoaded で1回＋`cms.js` が CMS 取得後に `FRANK_RENDER()` でもう1回）。`nav()` が毎回 `addEventListener` するのでハンドラが二重登録され、1タップで「開く→即閉じる」が連続実行されて**無反応に見えていた**。`trialForm()` も二重登録＝体験フォームが2回POSTされる状態だった。決定: **イベント登録（nav/trialForm/stickyCta）は初回のみ**、描画（fillValues/wireLinks/news等）は毎回、`reveal()` は要素に `data-rv` を付けて二重 observe を防ぐ。全ページ共通のバグ。
  **(e) 検証** — linkedom で booking.html に site.js を実際に読ませ、`FRANK_RENDER()` の2回目まで再現したうえで **修正前=1タップで開かない／修正後=1タップで開き2タップ目で閉じる**を確認。member-os 型チェック通過、tests 237件全通過。
  残（ユーザー作業）: ①Vercel(member-os) に `RESEND_API_KEY` / `FRANK_MAIL_FROM` を設定（未設定だとメールは飛ばない） ②Resend の frankgolf.jp ドメイン認証 ③テストで入った仮会員2件（P57932221 / P37571648）の扱い ④**承認時に会員番号を伝える手段は今回未実装**＝当面は電話・LINEで案内する運用。
- #121 (2026-08-09) **公式LINEの個人連絡先台帳＋個別push（migration 0103適用済）**。きっかけ: 小川うらら（役員）がYOZAN公式LINEへ1対1でメッセージを送ってくる予定→従来はInboxで「差出人不明」表示・こちらから個別に送る手段も無かった。
  **(a) gn_line_contacts（0103）** — 1対1の送信者を受信時に自動登録（LINEプロフィールAPIで表示名取得）。`person_name`（正式名）が入っていれば個別pushの宛先になる。**期待連絡先**: line_user_id空＋match_hint（カンマ区切り）で先に名前だけ登録でき、表示名がヒントに一致した初回受信で自動リンク（一致が複数なら安全側でリンクしない）。リンク時は company_events（line.contact_linked）に記録。小川うらら（hint: 小川,うらら,ウララ,urara,ogawa）をシード済み。
  **(b) webhook** — sec_inquiries.from_name に正式名>表示名を設定（従来null）。連絡先処理の失敗で受信全体は落とさない。純粋部は `line-contact-pure.ts`（誤リンク防止: 空表示名・空ヒントは絶対にリンクしない）。tests 3件追加＝全**240件通過**。
  **(c) 個別push** — executorに `line_push_contact`（payload: contact=宛名部分一致 or contact_id、body）。policy=**auto**（ユーザー指示で送る用途のため承認の二度手間にしない）。複数一致・未リンク宛はエラーで停止。送信履歴は gn_line_outbox に status='sent' で残す。
  運用: 「小川にメッセージ送って」→ ai_action_queue に line_push_contact を積む→ /api/cron/execute（10分毎）が送信。返信はこれまで通りInbox承認→linePush直送信（#102）。
- #122 (2026-08-10) **警告は「直せる場所」に置く — レッスン手当の担当プロ未紐付けを給与画面でその場で修正できるようにした（migration 0104適用済）**。きっかけはユーザーの「未割り当てがあると出ているのはどれのことですか？また、アラートを出すなら表示だけでなく修正できるようにしてください」。
  **(a) 何が悪かったか** — #105 で出した警告は `personal_lesson_counts` の**集計行**しか持っておらず「(未設定) — 1件」としか言えなかった。どの売上明細なのかを知るには money-os の売上一覧を目視で探すしかなく、**警告を見た人がその場では何もできない**＝直さないまま集計を実行してしまう。原因を名指しできない警告は、無視される警告になる。
  **(b) 明細まで返す（0104）** — `personal_lesson_unlinked_lines(company_id, from, to)` を追加。0094と**同じ正規化・別名解決**を使い、担当プロがスタッフに解決できない明細を line_id・日付・お客様名・金額・store_id 付きで返す。判定ロジックを2か所に書かない（集計版と明細版で結果がズレると、警告は出るのに直す対象が見つからない状態になる）。
  **(c) 給与画面で直す** — `admin/payroll/lesson-fix.tsx`＋actions `assignLessonPro` / `linkLessonPro`。原因の型ごとに操作を分けた: **①pro空欄** → 明細1行ずつプルダウンで担当プロを選び `mon_sales_lines.pro` を埋める／**②名簿に無い表記** → 既存プロの**別名**に追加（表記ゆれ）／**③名簿にあるがスタッフ未紐付け** → その場でスタッフ＋支払区分を設定。②③はプロ名でまとめて1回で直す。権限は manage_payroll＋給与再認証（15分）を必須にし、全操作を監査ログ（payroll.lesson_pro_*）に残す。閲覧のみの人には従来どおり警告文だけ出す。
  **(d) 今回の実データ** — 未紐付けは **2026-07-26 北浦一郎さん パーソナル25分 2,000円（担当プロ欄が空欄）1件**。ユーザー確認により担当は**古川**＝payout_mode 'none'（月給・役員報酬）のため手当額は変わらない。ほかに 2025-09/10 の吉川法生さん4件が同じ空欄のまま残っている（過去月なので当月の警告には出ない）。
  **(e) 検証** — shift-cloud tsc 0エラー（既存の @yozan/core 解決エラー2件を除く）、tests 240件全通過、0104 は本番DBに適用して実データで結果を確認（7月分が警告から消えることを確認）。
- #123 (2026-08-10) **FRANK GOLF 月会費を Stripe → Square に一本化＋ドリンクメニュー登録＋入会承認メール（migration 0105適用済）**。ユーザー指示「物販も飲食もやるのでSquare 1つにまとめる」。店頭POS（#118）・物販・ドリンク・月会費が Square 1社＝入金・手数料・管理画面が1本になる。
  **(a) 課金の乗り換え** — booking.html の「カードで継続課金を登録する」は `/api/public/frank/billing` のまま、中身を `frank-square-billing.ts`（Squareサブスク決済リンク・SDK不使用のfetch直）に差し替え。リンクは会員ごとに発行し、返ってきた**注文IDを frunk_members.square_checkout_order_id に控える＝Webhookで初回決済と会員を結ぶ唯一の鍵**（Squareのリンク決済は顧客IDを事前指定できない。Stripeの client_reference_id に相当するものが無い）。
  **(b) Webhookは1本に集約・自動振り分け（この決定の核）** — 月会費も店頭売上も同じ `/api/public/frank/pos/webhook` に届く。振り分けを間違えると**月会費が店頭「利用料」として二重計上**される。判定は純粋関数 `classifySquareMonthlyPayment`: ①注文ID一致=初回（active化・square_customer_id確保） ②顧客ID一致は**金額がプランの税込月額と一致するときだけ**継続課金（店頭で会員プロフィール付きの決済をしても400円のドリンクを月会費と誤記録しない） ③どちらでもない=店頭売上。月会費は mon_sales（category=月会費・source='square'・payment idで冪等）。FAILED＋プラン額一致→past_due、subscription.updated CANCELED/DEACTIVATED→canceled。
  **(c) Square側の初期設定をスクリプト化** — `scripts/frank-square-setup.mjs`（再実行安全・名前で既存判定）: 消費税10%内税／ドリンク3カテゴリ24品（**各商品「一般/会員」の2価格バリエーション・税込**。レジは会員にバリエーションを選ぶだけ）／サブスクプラン「FRANK GOLF 月会費」5種（税込=round(税抜×1.1)・exTaxと往復一致をテスト固定）／Webhook購読（payment/refund/subscription）。終わりに Vercel env と frunk_plans.square_variation_id のSQL を出力。
  **(d) 入会承認メール（#120の残課題④解消）** — member-os の approveSignup が承認と同時に**会員番号＋Web予約＋カード登録の案内**をメール（buildApprovalMail・Resend未設定ならスキップで承認は成立）。これで Web入会→承認→メールで会員番号→booking.html でカード登録、が**人手ゼロで一周する**。
  **(e) 後始末** — Stripe版 frank-billing.ts は廃止マーク（テストモードのみ・実課金ゼロ・Webhook受け皿として残置、本番鍵は設定しない）。privacy（_build.py含む）・運営マニュアル・RESERVATION_SYSTEM・OPERATIONS §14-1/14-2 をSquare前提に書き換え。NEXT_TASKS.md の87バイトのNULL文字混入（ファイル破損）を修復。
  **(f) 検証** — tests 3件追加（月会費税込とexTaxの往復一致全5プラン／E.164変換／**振り分け=初回・継続・会員のドリンク購入・非会員・モニター0円**）＝全 **243件通過**、genesis/member-os tsc 新規エラー0。
  残（ユーザー作業・OPERATIONS §14-1）: ①Square法人確認 ②Developerアプリ作成→Production Access Token ③setup実行→Vercel env 3つ＋frunk_plans更新 ④実カードテスト。
- #124 (2026-08-10) **入会金10,000円＋無料クーポン6種＋休会の課金停止＋プラン変更の週割差額（migration 0106適用済）**。ユーザー決定: 入会金は会員登録時徴収・クーポン（frankgolft/fujita/anada/ogawa/furukawa/hayashi）で無料／休会費2,000円（税抜）は店頭・手動徴収／プラン変更は「差額を4分割し変更した週から月末までの残り週数分をその場で請求」。金額はすべて税抜表示（請求は×1.1）。
  **(a) 入会金はプランのフェーズに乗せられなかった（設計の分岐点）** — Squareの決済リンクは**有料フェーズ1つのバリエーション限定**（Checkout APIの制約）。「初回だけ入会金込み」の2フェーズ案は成立しない。→ **初回の月会費入金を確認したWebhookが、いま保存されたカードへ続けて11,000円を自動請求**する方式に変更。note接頭辞「FRANK入会金」で自分の請求を見分け、mon_sales の category=入会金 に記録（利用料への誤記録を防ぐ）。二重請求ガードは joining_fee_charged_at。失敗は company_events(warning)＝店頭徴収へフォールバック。
  **(b) クーポンは申込時に検証して弾く** — /join-web に入力欄。無効なコードは受け付けず即エラーで返す（黙って無効化すると「無料のはずが11,000円請求された」という最悪のトラブルになる）。有効なら joining_fee_waived=true＝Webhookが入会金を請求しない。承認メールも「入会金11,000円を続けて請求」／「クーポン適用のため無料」を書き分ける。
  **(c) 休会=課金の一時停止＋店頭徴収** — member-os の setMemberStatus が Square Pause/Resume を追従実行（frank-square.ts・失敗してもステータス変更は成立させ画面で知らせる）。休会費2,200円税込はレジ商品「休会費（1か月）」で店頭徴収。**退会は自動解約しない**（日割り・当月末など人の判断が要る）＝画面がダッシュボードでの解約を必ず促す。
  **(d) プラン変更の週割** — planChangeProration（純粋関数）: 第1週=4週分・第4週=1週分、1週あたり round(差額税込/4)、ダウングレードは0円（返金しない）。member-os の会員一覧から1操作: plan_id更新→Square swap-plan（翌請求から新額・スワップ先は同バリエーション＝入会金を二重請求しない）→card-on-fileへ差額を即時請求（カード未登録なら店頭徴収の案内）。
  **(e) レジ側** — setup script に「会費・その他」カテゴリ＋入会金11,000円・休会費2,200円のレジ商品を追加。サイトは plan.html の入会金「近日公開」を10,000円に確定、booking.html に初回の入会金自動請求の説明を明記。
  **(f) 検証** — tests 4件追加（クーポン6種と紛らわしい綴りの拒否／週割の5境界日／ダウングレード0円／入会金noteの判定）＝全 **247件通過**、genesis/member-os tsc 新規エラー0。
  残: #123と同じ（Squareトークン取得→setup実行→env設定。SQUARE_ACCESS_TOKEN は **member-os にも**必要になった）。
- #125 (2026-08-10) **日報を廃止し「イレギュラー報告」へ置き換え＋再発防止のAI分析（migration 0107適用済）**。ユーザー指示「日報ではなく何かあった（イレギュラー）ときに記載する。カテゴリー別を選択してから、いつ・どこ・だれ・なにがあったかを記載し、それを分析して今後同じミスやトラブルがないようにする」。
  **(a) 日報をやめた判断** — sp_reports はフリーテキスト1枠・**運用実績0件**。毎日「今日やったこと」を書かせても読む側の判断材料が増えないため、置き換えのコストがゼロのうちに切り替えた。テーブルは残置（追加のみの原則 #2）、画面とタブからのみ外す。
  **(b) 5Wを列に分ける（この決定の核）** — `sp_incidents` は category / severity / occurred_at(いつ) / place(どこ) / involved(だれ) / body(なに) / action_taken(対応) を**別々の列**に持つ。フリーテキスト1枚だと人もAIも読めず、「同じことが繰り返されている」を機械的に見つけられない。1日1件ではなく起きた分だけ書く（日報のような (staff,date) ユニークを付けない）。
  **(c) カテゴリはCHECK制約にしない** — 9分類（お客様クレーム/設備・機器/予約・受付/会計・決済/商品・在庫/ケガ・事故/施設・清掃/スタッフ・シフト/その他）は運用で増える。CHECKにすると増やすたびにmigrationが要り、さらに**一覧に無い値の行が画面から静かに消える**事故（Vault 2026-08-07 / 40件中16件が消えていた）を招く。DBはtextで受け、`packages/core/src/incidents.ts` の `normalizeIncidentCategory()` が未知値をotherに寄せる＝**1件も落とさない**ことをテストで固定。定義を core に置いたのは書く側(shift-cloud)と読む側(genesis)で必ず同じラベルを使うため。
  **(d) 重大度highは即LINE、ただし届かない時は黙らない** — `notifySevereIncident()` が gn_line_contacts の person_name='古川博庸' へ1対1 push（0107でシード。line_user_id は本人が公式LINEへ1回送れば webhook が自動で埋める / 0103）。**未リンク・API失敗は理由を画面に返す**（「送ったつもりで届いていない」を作らない / #102の再発防止）。通知済みは notified_at で二重送信を防ぐ。
  **(e) 分析は別テーブル・AIが人の本文を書き換えない** — `sp_incident_insights`（title/pattern/cause/prevention/incident_ids/status）。毎朝6時の `runDailyAfterwork` steps に `incidents` を追加＋Genesis `/incidents` の「今すぐ分析」ボタン。**AIキーが無い・APIが落ちていてもルールベース（同一カテゴリ2件以上）で必ず結果を出す**＝「分析されませんでした」で空白にしない。AIが返した incident_ids は実在するものだけ採用（存在しないidを根拠に置かない）。対応中(open/doing)と同じ見出しは作り直さないので毎日回しても重複しない。
  **(f) 分析は読んで終わりにしない** — insight は 未着手→対応中→完了/見送り を人が進める。完了させた対策は次の分析で作り直されないため、「同じ提案が毎朝出続けて誰も読まなくなる」を防ぐ。
  **(g) 検証** — tests 8件追加（未知カテゴリでも全件が集計に入る／別名の正規化／重大度の不正値はmidに落ちhighを勝手に作らない／ルールベースで必ず対策が出る／1件だけならノイズを出さない）＝全 **255件通過**、shift-cloud・genesis とも tsc 新規エラー0（@yozan/core のパス解決はVM側symlink破損のため paths 指定で検証）。本番DBにダミー報告4件を入れて画面確認。
  残（ユーザー作業）: ①**YOZAN公式LINEへ一度メッセージを送る**（重大報告の通知先リンク） ②スタッフへ運用の周知（毎日の日報は不要・何かあった時だけ） ③ダミー報告4件の削除依頼。
- #126 (2026-08-10) **Xの自動投稿が8/8を最後に止まった — 原因は「承認されない行が配信の順番待ちを永久に占領する」設計**。症状: cnt_posts の8/9・8/10分が `x_posted_at` も `x_error` も NULL のまま＝**エラーではなく、そもそも試行すらされていなかった**。
  **(a) 原因** — `publishDue()` は予定時刻を過ぎた行を `scheduled_at` の古い順に **limit 3件だけ**取る実装だった。一方 #104 でXは承認を待たずに投稿する（`gn_loops.config.x_auto`）ようにしたため、**「Xは投稿済み・Instagramは承認待ちのまま」という行が status=awaiting_approval のまま永久に残る**（IG承認が来ないと status が動かない）。この残骸が 8/6・8/7・8/8 の3件たまった時点で3枠が埋まり、8/9以降は毎tick一度も選ばれなくなった。**「古い順にN件」と「終わらない行が存在しうる」の組み合わせは必ず詰まる**。
  **(b) 対策** — 取得後に `hasPendingWork()`（`packages/content/src/due.ts` 新設）で**やることが残っている行だけに絞ってから件数を切る**。承認済み(scheduled)は必ず対象（この関数内で posted/failed に確定するので溜まらない）、承認待ちはXが済んでいれば対象外、連投は未投稿ぶんが残っていれば対象・stall上限に達したものは枠を返す。DBからは `max(limit*10, 30)` 件を広めに取る（1件あたりの外部API呼び出し数は limit のままで増えない＝課金は不変）。
  **(c) limitを増やすだけにしなかった理由** — 残骸は運用のたびに増え続けるので、いくつに増やしても同じ日が来る。詰まりの原因は件数ではなく「終わらない行を数に含めていること」。
  **(d) 検証** — tests/content-publish-due.test.ts 6件追加（承認待ち×X投稿済みは対象外／承認済みは常に対象／x_auto=offなら承認待ちを拾わない／連投の途中と完了／stall上限）＝全 **261件通過**。修正後、滞留していた8/9・8/10分がXへ投稿されたことを確認。
  残: Instagram側の承認待ちが溜まり続ける件（自動期限切れにするか）は今回は触っていない。
- #127 (2026-08-11) **Instagramを一旦止めてX専用にした（コード変更のみ・migrationなし）**。理由: IG自動投稿に必要な Meta for Developers の登録が、Facebook側の端末チェック（メール認証）で進められない状態が続いており、**いつ繋がるか読めない**。一方で投稿案は毎日1件生成され、承認カードが承認されないまま溜まり続ける＝#126でXが止まった原因そのものを作り続けていた。
  **(a) 設定1つで切り替える** — `gn_loops.config.ig_enabled`（既定true）。false のとき `runContentLoop` は `platform='x'` かつ `status='scheduled'`（承認済み）で下書きを作り、**承認カード（ai_action_queue）を出さない**。Meta接続ができたら true に戻すだけでIG運用に復帰する（コード変更不要）。
  **(b) 承認カードを出さない判断** — Xは `x_auto` で承認を待たずに投稿する。つまりIGが無い状態のカードは「承認しても何も起きず、承認しないと永久に残る」だけの存在で、判断フィードのノイズかつ #126 の詰まりの原因だった。**押しても何も変わらないボタンは置かない**。投稿自体は /ai-sales に並ぶので確認・編集はできる。
  **(c) 未接続警告の抑止** — ig_enabled=false のときは「@swingcortex_jp 未接続」等を出さず、代わりに「Instagramは停止中（戻し方）」を1行出す。**直す気のない警告を出し続けると本当に直すべき警告が埋もれる**。
  **(d) 既存データの決着** — 滞留していた承認待ち5件は全てXへ投稿済みだったので `posted` に確定、未投稿の1件（8/11 18:00）はX専用・scheduled に変換して queue_id を外し、承認カード6件は cancelled。以後 awaiting_approval の残骸は生まれない。
  残: Meta接続（**普段Facebookを開いている端末で認証を1回通す**のが最短。ユーザー作業・急がない）。復帰時は ig_enabled を true に戻す＋OPERATIONS §9。
- #128 (2026-08-11) **店舗またぎの表示・切替を廃止＝各アカウントは自分の店舗しか見えない／触れない（オーナーのみ全店横断）**。理由: money-os や shift-cloud の店舗切替・member-os の全店表示は「宝塚のつもりで姫路に登録する」型の事故のもと（ユーザー指示）。
  **(a) オーナー判定の正典は `manage_company`**（会社オーナーロールだけが持つ）。**view_hq では跨げない**＝「本部」「役員（本部閲覧）」ロールは自店のみ。`packages/core/src/auth.ts` の Actor に `isOwner / storeIds / primaryStoreId` を追加（オーナー=会社の全active店舗、他=staff_store_assignments）。core を使う7アプリ（member-os/reserve-os/lesson-os/survey-os/swing-cortex/caddy-os/demo-sales）に一括で届く。
  **(b) money-golfwing** — 全店横断（canManageAll）を view_hq→manage_company に変更。店舗が1つの人は切替プルダウンではなく店名ラベル表示。事業別分析・カード/口座取込（requireManageAll）もオーナー限定に。cookieに他店IDが残っていても getCurrentStore が無視する既存実装で下流は無改修。
  **(c) shift-cloud** — `visibleStores(actor)`/`pickStore()` を auth.ts に新設。シフト作成・勤怠・月末照合・紙シフトの4画面の店舗タブと `?store=` 直打ちを封鎖（配属1店舗ならタブ自体が消える）。イベント・ヘルプ募集・キオスク・スタッフ管理の店舗選択肢も同様に絞る。
  **(d) member-os** — 受付台帳・今月KPI・店舗selectを配属店舗で絞り、server action は `scopedStoreId()` でフォームのstore_idを検証（配属外なら主店舗に差し替え）＝UI非表示だけに頼らない。
  **(e) データ** — frank@（FRANK店舗アカウント）に FRANK GOLF 姫路の配属が無かったので staff_store_assignments に追加（is_primary）。⚠現在 manage_company を持つのは古川さんと**小川うらら**の2名（両者とも会社オーナーロール）。小川さんを自店のみにするならロールを変えること。
  検証: tests 261件通過・shift-cloud/money-golfwing/member-os の tsc クリーン。
- #129 (2026-08-11) **FRANK Web入会を「承認レス・即決済」に全面改修＋店舗ダッシュボード＝予約カレンダー化**（migration 0108適用済）。
  **(a) 入会フロー** — /join-web: 規約全文のスクロール表示＋同意＋電子サイン（店頭タブレットのSignaturePadを共通化 `components/signature-pad.tsx`）→ Square決済リンク（月会費サブスク）へ即リダイレクト → 初回入金のWebhook（genesis frank-pos.ts）が `activateWebJoin`（`lib/frank-join.ts`）で **会員番号FR####採番・active化・入会金カード課金・Lesson OSカルテ作成・控えPDFメール** まで全自動。スタッフ承認は挟まない（/frunkの承認は店頭iPad入会と救済用に残置）。決済リンク作成はSquare envがyozan-genesisにしか無いため **公開API `/api/public/frank/join-checkout`**（member_id=UUIDが実質の認可・redirect先はmember-os/frankgolf.jpのみ許可）。完了画面 `/join-web/complete?sid=` は5秒自動更新で会員番号を表示。Squareが使えない環境は旧承認フローに自動フォールバック。
  **(b) 採番の安全化（0108）** — `uq_frunk_members_member_no`（company_id, member_no・partial unique）。count+1採番は衝突したらリトライ。
  **(c) 入会控えPDF** — `lib/frank-join-pdf.ts`（pdf-lib＋fontkit）。レイアウトはゴルフウィング紙申込書の見本に準拠（申込者情報/費用/コース/サイン画像/店舗情報）。⚠**pdf-libのsubset埋め込みはCJKでグリフ欠落する**（poppler/gs両方で実証）→ glyf版NotoSansJPをJIS第1+2水準にfonttoolsでサブセットした2.3MBを**フル埋め込み**（PDF約1.4MB）。フォントは `src/assets/`＋`outputFileTracingIncludes`。Resendの `attachments` 対応を genesis/member-os両方の sendFrankMail に追加。
  **(d) Lesson OS連携** — 入会確定時に `lsn_students`（member_code=会員番号）と `lsn_share_tokens` を自動作成。完了メールにカルテURL（lesson-os.vercel.app/s/…）を記載、member-os会員ページ（会員番号+電話下4桁ログイン）にも「レッスンカルテを見る」を追加＝お客様のID/PWは会員登録と同一。
  **(e) 店舗ダッシュボード** — FRANK姫路アカウントは /dashboard＝**予約カレンダー**（日/週切替・打席×時間・体験/会員/都度/レッスン色分け・iPad横スクロール対応）。会員の**重要説明事項 `alert_note`**（0108・/frunkで記入）があると予約セルに⚠＋hoverで内容。レッスン管理（lesson-os/frank）・予約管理・/boardへの導線ボタン。GOLF WING宝塚は従来の月次KPI（オーナーは?store=で行き来）。ログイン後の着地は/dashboardに変更。
  **(f) 体験メール** — member-os /trial（希望日時申込型）に受付メールを追加（サイトのカレンダー予約は#118で送信済み）。
  **(g) サイト文言** — plan/trialの「スタッフ確認後に確定・オンライン決済はありません」を即時決済の説明に差し替え（_build.py再生成）。
  ⚠残: 規約・特商法・プライバシーは草案のまま（NEXT_TASKS A-0d・専門家確認は決済開始前に必須）。Webhook未達時はpendingのまま＝/frunkの承認で救済。
- #130 (2026-08-11) **member-os に来店検索 /search を追加（migration 0110適用済）**。理由: 受付台帳は「期間で絞って一覧」しかできず、目の前のお客様が過去に来た人かどうかを確かめられなかった（＝再来なのに初回として扱う／既存会員に体験を案内する事故のもと）。
  **(a) 1つの入力欄で全部引く** — 氏名・フリガナ・電話・メール・会員番号のどれでもよい。電話はハイフン有無・全角混在を数字だけに正規化して比較（`app.digits`）、下4桁だけでも当たる。「どの欄で探すか」を受付に選ばせない。
  **(b) 横断先** — 一時利用者(mbr_guests/mbr_walkin_visits)・GOLF WING会員名簿(mbr_members)・FRANK会員(frunk_members/frunk_bookings)・FRANKビジター予約(frunk_bookings.guest_*)。DB関数 `search_visitors()` は候補と来店履歴を平らに返すだけにして、人物の名寄せはアプリ側(`visitor-search-pure.ts`)で行う。
  **(c) 名寄せの鍵は3つだけ** — ①電話の下10桁 ②メール ③（カナ or 氏名）＋生年月日。**氏名だけ・カナだけでは絶対にくっつけない**（同姓同名は実データに普通にいる）。下4桁のような短い番号も鍵にしない。実データで「体験で来た人がその日に入会して会員名簿にも載っている」ケース（大山様・山本様・平山様）と「同じ人が別々のguest行で2回来ている」ケース（土山様・横山様）が正しく1枚にまとまることを確認。
  **(d) 店舗またぎ防止(#128)を踏襲** — 配属店舗のみ・オーナーのみ全店横断。`mbr_members` は店舗列を持たないGOLF WINGの名簿なので、FRANK専任アカウントには `p_include_gw=false` で出さない（実測: FRANKスコープで「田中」0件）。
  **(e) 検証** — tests/visitor-search.test.ts 12件追加＝全 **273件通過**、member-os tsc クリーン。6,181件のguestに対し電話検索 約50ms。pg_trgm(gin)＋電話digitsの関数インデックスを追加。
  正典: docs/modules/member-os/WALKIN_LEDGER.md「来店検索 /search」。
- #131 (2026-08-11) **FRANK入会の料金体系を改定＝入会金5,500円税込（年内無料）・月会費3か月分前取り（入会月無料）・見積画面・6か月継続**（migration 0109適用済）。ユーザー指定（2026-08-11）。
  **(a) 週割の廃止確認** — 入会時の日割り/週割は行わない。代わりに**入会月の月会費が無料**（キャンペーン）で、初月の不公平感を吸収する。
  **(b) 入会金** — 全プラン 10,000→5,000円税抜（表示・請求は税込5,500円）。**2026-12-31申込分まではキャンペーンで自動無料**（`isJoinCampaignActive`・クーポン6種は併存）。
  **(c) 前取り** — /join-web の決済で翌月分（Square決済リンク・1か月分）→ Webhookが入会確定後に**翌々月分をカードon fileへ即時課金**（note=「FRANK月会費前取り」・prepay_charged_atで二重課金ガード）。subscription.created で**サブスクを1周期pause**（pause_cycle_duration=1・prepay_pause_done_at）＝翌月の自動課金と前取りが重ならない。以後は毎月「入会日と同じ日」に自動課金（ユーザー確認済み）。例: 9/11入会→9月分無料・その場で10月分+11月分・次回автоは11/11（12月分）。
  **(d) 見積画面** — お客様情報→**お見積り**（入会金5,500円→0円・入会月0円・2か月分前取り・合計・6か月継続の明記）→決済、の2ステップに。`joinEstimate()`（frank-billing-pure・tests付き）が見積/PDF/メールの共通計算。
  **(e) 6か月継続** — 表示・同意記録＋`min_term_until`（入会+6か月）。退会操作時にスタッフへ警告（ブロックはしない・ユーザー確認済み）。会員一覧に「継続◯◯まで」バッジ。
  **(f) ライト会員** — 表記を月8回→**月4回**に修正（DB note・HPは元から月4回）。※月次回数の上限はシステム強制ではなく表記のみ（従来どおり）。
  **(g) HP** — index/planに入会金5,000円税抜（税込5,500円）表記＋年内キャンペーン説明を追加。**体験予約の日付選択を横スクロール14日→月ごとカレンダー・60日先まで**（advance_days=60に変更・gn_site_content）。
  ⚠残: Squareレジ商品「入会金」（11,000円）の価格改定はSquareダッシュボードでの手作業。pause_cycle_durationの実挙動は実カードテストで要確認（失敗時はeventsに警告が出て手動対応可能）。
- #131b (2026-08-11) **入会の決済を「見積と同額の1回払い」に修正**（#131の実装バグ。migrationなし）。症状: 見積は「入会金＋前取り2か月」なのに、Squareの決済画面はプラン月額1か月分しか出ず、残りは決済後にカードへ別途請求していた＝**見積と決済額が一致しない**（ユーザー指摘）。
  **(a) 原因** — サブスク決済リンク（Checkout API + subscription_plan_id）は「price_money はプランのフェーズ価格と一致させる」のが前提で、月額1か月ぶんしか出せないと解釈していた。実際は**一致しない金額を渡すと price override として通る**（Square公式ドキュメント: Subscription Plan Checkout）。
  **(b) 対応** — 決済リンクの price_money を **入会金＋月会費×前取り月数（＝見積の合計）** に変更。お客様はSquareのページで**1回だけ**支払う。カードはSquareがそのまま customer に保存する（サブスク決済リンクの仕様）。
  **(c) 上書きの後始末（重要）** — Squareはこの金額を**サブスクの price_override_money として引き継ぐ**ため、放置すると毎月その総額を請求してしまう。subscription.created の Webhook で ①`UpdateSubscription {price_override_money: null}` でプラン価格へ戻し ②`PauseSubscription {pause_cycle_duration: 2}` で前取り月数ぶんスキップ、を1回だけ実行（prepay_pause_done_at）。どちらか失敗したら events に警告（金額が総額のままになる＝実害が大きいので severity=warning で必ず気づける）。
  **(d) 廃止** — 決済後の「2か月目のカード課金」と、Web入会での「入会金の後追い課金」（初回一括に含めたため）。店頭タブレット入会→booking.htmlでカード登録の経路は従来どおり後追い課金が動く。
  **(e) 記帳** — 初回一括は1行の「月会費」にせず、**入会金／月会費（前取りNか月分）に分割**して mon_sales に入れる（入会金が売上分類から消えないように）。金額が見積と一致しないときは分割せず従来どおり1行（安全側）。
  **(f) 見積と決済額の一致をテストで固定** — genesis `lib/frank-join-pure.ts`（joinInitialTotal）と member-os `lib/frank-billing-pure.ts`（joinEstimate）を全プラン×キャンペーン内外で突き合わせる（tests 278件通過）。**片方だけ直すと再発するので、料金ロジックを変えるときは必ず両方**。
- #132 (2026-08-12) **シフト提出の3点改善＝休み希望は募集期間に関係なくいつでも / 提出時間からの編集 / テンプレートの店舗別化**（migration 0111適用済）。ユーザー指定（2026-08-12）。
  **(a) 休み希望を期間から切り離した** — `shift_requests` は `period_id` 必須なので、募集がまだ開いていない先の月は入力できず、**長期休暇のように先に決まっている休みを運営が早く把握できなかった**。新テーブル `staff_time_off_requests`（期間に紐づけない・start_date/end_date/kind/reason/status）で受ける。スタッフは /requests の「休み希望」からいつでも提出・取り下げ。
  **(b) 承認したらシフトにも反映する** — 管理者は **/admin/time-off** で承認/却下（ユーザー選択）。承認するとその期間のドラフトシフトを `is_day_off=true` にupsert。**確定済み(published)は書き換えない**。承認しただけでシフト側が勤務のまま残るのが一番の事故なので、承認と反映を同じアクションで行う（[[alerts-must-be-fixable]]と同じ考え方）。提出時は create_shifts 保持者へ、承認/却下時は本人へ通知。シフト作成画面には未処理件数の警告バーとセルの桃色表示（🛌 休み確定 / 🛌 休み希望）。
  **(c) 希望をクリックで反映→時間を打ち替え** — セル下の「希望: 11:00-20:00」がボタンになり、押すと**時刻の入力欄に展開**される（テンプレ希望も時刻に展開＝そこから任意の時間に変えられる）。「希望を一括反映」は**空きセルだけ**に入れる（入力済み・確定済みは上書きしない）。
  **(d) テンプレートを店舗別に** — `shift_templates.scope_type/scope_id`（元から列はあったが未使用）を使い、0111で既存の勤務テンプレ（早番/遅番/終日/フロント＝11:00-20:00系）を **GOLF WING 宝塚専用**に変更。「休み」だけ全店共通のまま。FRANK GOLF は営業時間が違う（平日10-22 / 土日9-20）ので、FRANK用テンプレはユーザーが /admin/templates の「対象店舗」から登録する（ユーザー選択＝枠だけ作る）。テンプレ未設定の店舗では提出画面に「⌚ 時間を指定」を使う案内を出す。
  **(e) 出し分けは1か所に集約** — `apps/shift-cloud/src/lib/shift-scope.ts`（templatesForStore/templatesForStores/timeOffIndex/validateTimeOff）。画面ごとに絞り込みを書くと、どこか1画面だけ他店舗の時間が出る事故になる。tests/shift-scope.test.ts 9件追加＝全 **287件通過**、shift-cloud tsc クリーン。
  ⚠ FRANK GOLF のシフトテンプレート登録はユーザー作業（/admin/templates ＞ 対象店舗＝FRANK GOLF 姫路）。
- #133 (2026-08-12) **money-os の一覧に「探す・絞る・集計する」を追加**（migrationなし）。ユーザー指定（2026-08-12「エクセルみたいにソートを商品ごとや人ごとに絞れる、あと検索機能も」）。
  **(a) 期間を選べるようにした** — 売上・現金出納に 当月/3か月/6か月/今年/全期間/任意期間（`RangePicker`・URLに残る）。**1か月固定では「この商品が今年何個売れたか」が見られない**のが元の不満。読み込みは最新4,000件までで、超えたら画面で伝える（黙って切らない）。
  **(b) 検索は1つの入力欄** — 品名・お客様・担当・メーカー・備考・金額・日付を横断。スペース区切りはAND、`-語`で除外。**全角/半角・大文字小文字は NFKC で吸収**（「ＴＩＴＬＥＩＳＴ」でも「titleist」でも引ける）。売上台帳Excel由来の表記ゆれで引けないのを防ぐため。
  **(c) 絞り込みプルダウンは「他の条件を適用した結果」から作る** — 件数つき。選ぶと0件になる選択肢を出さない（Excelのオートフィルタと同じ挙動）。区分/品名/お客様/担当/メーカー/支払/会員区分。
  **(d) 集計（ピボット）** — 商品別/お客様別/担当別/区分別/メーカー別/支払別の 件数・個数・金額・構成比。**行クリックでその値に絞り込む**（見つける→深掘るが1画面で完結）。空欄は「（未設定）」として残す＝集計の合計が明細合計と必ず一致する。
  **(e) 現金出納** — 検索＋入金/出金・摘要の絞り込み＋列見出しで並び替え。既定は古い順。**残高は記録時の値をそのまま出し、並び替えでは再計算しない**（並べ替えた順の累計を出すと帳簿の残高と食い違う）。
  **(f) 証憑** — 発行元・メモ・ファイル名・金額の検索、種別/状態の絞り込み、「全期間」チェック（探すときは月をまたぎたい）。件数が少ないためサーバー側で絞る。
  **(g) 実装の置き場所** — `apps/money-golfwing/src/lib/table-filter.ts`（normalizeText/matchesQuery/optionCounts/summarize/resolveRange）。3画面で挙動を揃えるため画面ごとに書かない。tests/table-filter.test.ts 12件追加＝全**299件通過**、money-golfwing tsc クリーン。正典 docs/modules/money-os/SYSTEM.md §5。
- #134 (2026-08-12) **店舗またぎ廃止の全社展開＝GOLF WING と FRANK GOLF が混ざっていた残り全部を封鎖**（migration 0112・**未適用**）。ユーザー指定（2026-08-12「まだゴルフウィングとフランクゴルフが一緒になっているものはあるか」）。#128 で塞いだのは shift-cloud の admin 4画面と member-os の受付台帳・来店検索だけで、**残りの6アプリは手つかずだった**（監査で判明）。
  **(a) 原則を再掲** — 自店舗のデータしか見えない/触れない。オーナー判定は `manage_company` のみ（`view_hq` は「本部」「役員」も持つので全店横断には使わない）。**UI非表示だけに頼らず、サーバー側で必ず `store_id` を検証する**（id 直打ちで抜けるため）。
  **(b) member-os** — `src/lib/store-scope.ts` を新設（`scopedStoreId`/`canAccessStore`/`requireStoreAccess`/`storeFilterIds`/`visibleStores`/`canAccessFrank`/`canAccessGolfWing`/`golfWingStoreId`）＝「2回目で切り出す」ルール。**/reservations は `requireReceptionActor()` の戻り値を捨てており店舗判定がゼロ**で、GOLF WING スタッフに FRANK の予約グリッド・顧客名・電話・**未収金**が見え、来店/取消/入金記録まで実行できた（最重要の穴）。/frunk・/trials・/follow・/board も company_id のみ。/dashboard は `?store=gw` 直打ちでスコープを外せたうえ、**見出しが「GOLF WING 宝塚」なのに `mbr_walkin_visits` を店舗で絞っておらず姫路が混入**（体験数・入会率・フィッティング件数が全部合算）。ナビの「予約（姫路）」「FRANK会員」は全員に無条件表示だった。`updateVisit`/`updateGuest`/`deleteVisit` は対象行の store_id 未検証。/import は取込先が `code='takarazuka'` 固定＝FRANK 専任が使うと宝塚に書き込む。
  **(c) shift-cloud** — `assertStoreAccess()`/`scopedStoreIds()` を lib/auth.ts に追加。**/store 店舗ダッシュボードは全店タブが健在**で、姫路の店頭タブレットから宝塚のKPI・シフト・スタッフ名が見えた（#128 の目的そのものが機能していなかった）→ オーナー以外は認証で解決した1店舗に固定。/admin/staff の一覧が全社＋`staff_wages` 同梱＝**他店の時給が見えた**。/admin/events・/(staff)/reports・/admin/audit-logs・/admin/payroll も company_id のみ（audit-logs は「操作者の配属」で絞る判断＝店長が自店の履歴を追えないと運用が回らないため。副作用としてシステム/AI操作は非オーナーに出ない）。**/hq は `view_hq` だけで「店舗比較」テーブルに両店を並べていた**＝#128(a) 未適用。サーバーアクションは `saveDraft`/`publishShifts`/`createPeriod`/`closePeriod`/`deletePeriod`/`saveStaff`/`deactivateStaff` が全部クライアント引数の store_id / id を無検証で使っていた（**staff の配属更新は他店の配属まで delete していた**）。
  **(d) Genesis** — `GenesisActor` に **isOwner も storeIds も無く**（view_hq のみ判定）、全画面が会社丸ごとだった。core の `createActorResolver` からロジックを移植し `visibleStores`/`storeScope`/`assertStoreAccess` を追加。`getBusinessBreakdown`・`ceo-ai`・`morning-digest`・`judgment-feed`・/incidents を店舗スコープ化。**`storeIdForMemberStoreName()` は `mbr_members.store_name` の表記ゆれを既定で GOLF WING に寄せていた**（FRANK 会員が宝塚にカウントされる）→ 明示一致しない行は集計から除外し、除外件数を画面に出す（数字を静かに間違えるより見える化する）。⚠適用直後は宝塚の会員数が減って警告バナーが出ます＝名簿の店舗名を直せば戻ります。**ライブラリ関数は storeIds を引数で受け取る設計**にして cron（actor が無い）を壊さない。
  **(e) inventory-os / lesson-os / money-golfwing** — inventory は在庫総数・在庫金額が両店合算。加えて **`staff_store_assignments` に存在しない `status` 列で絞っていたためクエリが常に失敗し `storeIds` が必ず空**というバグ（`deleted_at is null` に修正）。`deleteMovement` は id だけで論理削除でき会社すら見ていなかった。lesson-os は `lsn_students` が全社＝GOLF WING のレッスン生と FRANK 会員が同じ名簿に並んでいた（**store_id 列は 0041 で存在した**ので実際に分離）。/frank のレッスンカレンダーは GOLF WING のコーチにも開いていた。money-golfwing は **`mon_bank_txn.store_id` が実データ全 null（/import が入れていない）＝店舗で絞ることが原理的に不可能**なため、ダッシュボードを /import と同じオーナー限定に揃え、現場には店舗で絞れる数字（自店の現金残高・今月の店頭売上）だけを出す。
  **(f) KPIの店舗次元（0112）** — `kpis` に **store_id 列が無く、Genesisホームの体験数・成約率は構造的に合算**だった。`store_id` を追加（NULL=全社行 / 非NULL=店舗行）、`unique(company_id, code)` を部分ユニークインデックス2本に置換、`refresh_member_kpis` が全社行に加えて店舗別行も upsert。画面は「店舗行があればそれ、無ければ全社行」（`pickKpisForScope`）で列追加前後どちらでも動く。**今後あるKPIコードで店舗別行を作ったら、その code を書く refresh_* 関数の update に必ず `and store_id is null` を足すこと**（忘れると全社行の値で店舗行が上書きされるサイレント破壊）。`lsn_students.store_id` の NULL も宝塚へバックフィル。
  **(g) 検証** — tests **299件通過**、6アプリ（genesis / member-os / shift-cloud / inventory-os / lesson-os / money-golfwing）の tsc クリーン。
  ⚠**残タスク**: ① migration 0112 の適用（NEXT_TASKS A-0g）② `mbr_members` は店舗列を持たない（`store_name` テキストのみ）ので GOLF WING 専用扱いのまま＝2号店が出たら要対応 ③ `mon_bank_txn` を店舗別に見たいなら「取込時に店舗を割り当てる」仕様が別途必要 ④ FRANK の店舗UUID が genesis / lesson-os / inventory-os / member-os にハードコード＝`@yozan/core` へ店舗定数を切り出すべき（4回目）⑤ **`companies` に「FRANK GOLF」という店舗を1つも持たない会社レコードが残っており、KPI が2行ぶら下がっている**（`edf84e8e-…`。FRANK は 株式会社YOZAN の1店舗という整理なので、この会社レコードは不要と思われる＝ユーザー判断）。
- #134b (2026-08-12) **監査ログをオーナー限定に変更**（#134の(c)を修正。ユーザー判断）。`audit_logs` は店舗次元を持たない（company_id と操作者しかない）ため、#134 では「操作者の配属で絞る」を採ったが、その方式では**システム/AIの操作（actor_staff_id が null）が誰にも紐づかず非オーナーには出ない＝履歴が欠けたものを見せる**ことになる。欠けた監査ログは役に立たないどころか誤解のもとなので、全件見せるか見せないかの二択にし、`isOwner` 以外は notFound()＋管理メニューからも非表示（`MENU` に `ownerOnly` を追加）。
- #134c (2026-08-12) **Genesisの自動処理は「店舗を持つ会社」だけ回す**（#134の調査で発覚。migrationなし）。`companies` に **SWING CORTEX（外販SaaS）のテナント**が入っており、cron は `companies` を丸ごとなめていたため、**店舗も売上も勤怠も無いテナントに毎朝の日次レポート・AIループ・朝のLINEダイジェストを生成していた**（会社「FRANK GOLF」= `edf84e8e-…`。2026-07-24〜08-12 の日次レポートが毎日でき、AI実行ログ76件・gn_loops 5本のうち4本が有効）。
  **(a) 判定** — `lib/operating-companies.ts` `listOperatingCompanyIds()` ＝ **active な店舗を1つ以上持つ会社のみ**。`api/cron/daily` と `api/cron/execute` の両方で使う。新しい外販テナントが増えても自動で除外され、店舗を登録した時点で対象に入る。
  **(b) 会社レコードは消さない（ユーザー一任 → 残す判断）** — このテナント分離は SWING CORTEX の仕様どおりで正しい。消すとコーチング用アカウント `frank`（login_id=frank・use_coaching のみ）のログインとデータ境界まで壊れる。**FRANK 店舗の実務アカウントは別**で、株式会社YOZAN 側の `frankgolf`（受付＋スタッフ・FRANK GOLF 姫路に配属）＝こちらが日々使われている。**「消してよい残骸」ではなかった**ので、消すのではなく回す対象を絞る形にした。
  **(c) ついでに確認** — #128 で足した「FRANK GOLF会社のスタッフを株式会社YOZANの店舗に配属する」会社をまたいだ `staff_store_assignments` の行は、既に論理削除済み（2026-08-11 01:03）で実害なし。現在 company_id が食い違う配属行は0件。
- #135 (2026-08-12) **シフト作成に「日/週/半月/月」の期間切替＋FRANK予約カレンダーを「縦＝時間・横＝打席」に転置**（migrationなし）。ユーザー指定（2026-08-12・Airシフトと Smart Hello の画面を提示）。
  **(a) シフトの期間切替** — `/admin/shifts` は月固定で、列が31日ぶん並んで横スクロールが延々と続くのが調整しづらさの元だった。`src/lib/shift-span.ts` `resolveSpan({span,d,ym,today})` に日付計算を集約（画面ごとに書かない＝#132 `shift-scope.ts` と同じ方針）。週の開始は月曜、**半月は 1〜15 / 16〜末**＝印刷画面(`print/page.tsx`)の half1/half2 と同じ区切りに揃えた。`?ym=` は旧URL互換で残し、パラメータ無しは従来どおり「翌月・1か月」。列が16日以下なら `w-full` で横幅いっぱいに広げて横スクロールを消す。tests/shift-span.test.ts 21件。
  **(b) ⚠一括操作の対象範囲を明示** — 「希望を一括反映」「ドラフトを確定・通知」は元から**表示中の範囲**が対象だったが、期間を切り替えられるようになると「日表示のつもりで押したら月全体が確定した」が起こりうる。**ボタンのラベルに範囲を書く**（例「9月前半のドラフトを確定・通知」）、confirm に「この範囲の外は変わりません」と明記、クライアント側でも `days` に無い日付をスキップ（サーバー絞り込みとの二重防御）。押す前に何が起きるか分かるようにする、が方針。
  **(c) localStorage のキーを店舗単位に** — `shiftdraft:{store}:{ym}` → `shiftdraft:{store}`。週が月をまたぐと年月キーでは1つに収まらず、**期間を切り替えた瞬間に未保存ドラフトが行方不明になる**ため。旧キーはマウント時に新キーへ寄せる移行処理つき。範囲外の未保存件数は「うちN件は表示範囲の外」と表示して、保存件数と画面の見え方が食い違わないようにした。
  **(d) 予約カレンダーの転置** — Smart Hello（GOLF WINGの現行システム）に合わせ**縦＝時間・横＝打席**に。1日の流れを上から下に読め、営業時間が長くても横スクロールが要らない。打席×時間のグリッドは**4か所に重複**していて色まで食い違っていた（会員が sky と indigo）ため、`lib/bay-timeline-pure.ts`（純関数・色定義も1か所）＋ `components/bay-timeline.tsx` に切り出し、`/dashboard` と `/reservations` を載せ替え。左に月ミニカレンダー＋月/週/日＋表示時刻（15/30/60分）。
  **(e) 予約ブロックは所要時間ぶんの高さを持つ** — 従来の `occupancy()` は「30分コマごとに同じ行を返す」形だったので、開始コマにだけ描いて `rowSpan` で伸ばす畳み込みに変更。**開始は切り下げ・終了は切り上げ**（10:15開始が11:00に見えない／10:00-10:55は10:30の枠も潰す＝従来の占有判定と一致）。営業時間外・打席指定なし・二重予約は**黙って消さず** `unplaced` として表の下に理由付きで出す。
  **(f) 週表示は「縦＝時間・横＝曜日」** — 打席3〜4面×7日＝21〜28列は iPad横向き1180pxで1列40pxを切って読めない。週に必要なのは「どの時間帯が埋まっているか」なので打席は合算し、コマごとに予定チップ2件＋「他N件」、全打席埋まっていれば「満席」。日付見出しを押すとその日の日表示へ。
  **(g) 月表示は件数だけ** — `loadMonthCounts()` は `loadDay` を35回まわさず**2クエリ**で件数を集計（100クエリ超を避ける）。月に時間軸は作らない（字が小さすぎて読めない）。
  **(h) 検証** — tests **344件通過**（shift-span 21・bay-timeline 23を追加）、shift-cloud / member-os の tsc クリーン。※`next build` はサンドボックスのマウント経由だと3分を超えて完走しないため未実施＝**Vercelのデプロイが実質のビルド検証**になります。
  ⚠ `/board`（ロビー掲示）と `sites/frank-golf/booking.html`（お客様向け）は今回スコープ外＝**まだ横＝時間のまま**。揃えるなら `components/bay-timeline.tsx` を使い回せます。

- #136 (2026-08-13) **FRANK入会フローの通しテスト環境＋入会・課金まわりの堅牢化＋集客LP2枚**（migration 0113・適用済）。ユーザー指定（2026-08-13「少額のテストプランを作って」「関連システムを見直して追加機能やバグ修正」「集客での改善・HP編集やLP作成」）。
  **(a) テスト会員プラン** — frunk_plans に「テスト会員」（月100円税抜＝110円税込・入会金0・active=false）。`/join-web?test=1` のときだけ画面に出す（actions側は「テスト会員」に限り非activeでも受理）。実カードで入会フロー全体（決済→Webhook→採番→PDF→カルテ）を220円で通しテストできる。手順の正典 OPERATIONS §14-1「入会フローの通しテスト」。後始末＝Squareでサブスク解約＋会員退会＋売上テスト行削除。
  **(b) Squareプラン同期API** — `/api/public/frank/admin/square-plan-sync`（POST）。square_variation_id 未設定のプランに Square バリエーションを自動作成して紐付け（setup.mjs のプラン部分と同じ・冪等）。認証は `gn_ops_tokens`（0113・sha256のみ保存・期限つき）＝SQUARE_ACCESS_TOKENを知らないAI/運用ツールがプラン追加を完結できる。
  **(c) 決済リンクの迷子入金対策** — `square_checkout_order_ids`（履歴）＋`square_checkout_breakdown`（発行時に確定した内訳）を0113で追加。再送信で古いリンクから支払われても履歴で会員特定。Webhookの売上分割・控えPDF・完了メールは**入金日で再計算せず breakdown を正とする**（年またぎ・キャンペーン境界のズレ根絶。frank-join.ts の独自計算も削除）。
  **(d) 二重計上の最終防衛** — mon_sales の square_payment_id / square_refund_id に部分ユニークインデックス（Web入会の分割2行があるため part 込み）。insertSale は23505を「既記録」として握り現金出納も追記しない。check-then-act のレースを DB で塞ぐ。
  **(e) 予約まわりのバグ修正** — ①ライト会員の月8日上限が31日の無い月で素通り（`lte -31`が不正dateでエラー→握り潰し→空集合。翌月1日 `lt` に修正・取得失敗は安全側で予約拒否）②打席codeでの予約作成に deleted_at 除外が無かった③booking.html 予約ボタンの二重送信ガード④レッスン枠に店舗・会社スコープ検証が無かった（他社/他店枠をid直打ちで取れた）＋FRANK店舗UUIDのハードコードを @yozan/core 定数へ。
  **(f) 認証の総当たり対策** — 公開API（打席/レッスン/課金）の「会員番号＋電話下4桁」に形式チェック＋15分10回失敗ロック（frunk_auth_attempts 0113。テーブル未適用環境では従来どおり通る）。
  **(g) member-os 修正** — ①会員マイページの氏名が旧台帳 mbr_members 参照で「FR0001様」表示→frunk_members 参照に修正＋退会/却下はセッション無効化 ②スタッフ操作日付が素のUTC→lib/jst.ts 新設（JST日付ルール） ③承認時の採番にエラー処理・23505リトライが無く番号の母数もgenesisと不一致（company単位に統一） ④タブレット入会が plan_id 無検証（存在・会社・active検証を追加） ⑤pending使い回しキーを電話→電話+メールに・maybeSingle複数行エラー回避 ⑥見積にクーポン未反映＋前取り月数ハードコード修正。
  **(h) HP/LP（集客）** — LP2枚を _build.py に追加: `lp-trial.html`（無料体験55分に一点集中・FAQ構造化データ付き）と `lp-campaign.html`（年内入会キャンペーン＝入会金0円+入会月0円→Web入会直行）。広告・SNS・LINEの飛び先用。NEWSにキャンペーン告知を追加、booking.html の入会金旧表記（11,000円）を5,500円+年内無料に修正、sitemapへLP追加。
  **(i) 検証** — tests 343件通過、genesis / member-os の tsc クリーン、_build.py 再生成18ページ。
  ⚠残: ①ライト会員「平日昼間（月4回）」はサイト表記のみでサーバー強制なし（#131fの決定どおり。強制するなら要実装＝ユーザー判断）②公開APIのIP単位レート制限は未実装（member_no単位のみ）③テスト入会の後始末はユーザー実施 or Claude依頼。
- #136b (2026-08-13) **ライト会員の利用上限＝「月4回」で確定・サーバー強制**（migrationなし）。ユーザー指定（2026-08-13「両方間違えています。月4回です」）。#136⚠残①の解消。旧実装は frank-booking.ts が「月8日」で、HP・DB note の「月4回」と食い違っていた → 予約APIの月次上限を **月4回（利用日数ベース・同一日の追加予約は数えない）** に修正。「平日昼間の利用中心」の表記は削除し「月4回までのご利用（全営業日OK）」に統一（HP・LP・frunk_plans.note。時間帯の制限は設けない＝ユーザー指定）。
- #137 (2026-08-14) **PRO SITE＝プロゴルファー公式HPの外販SaaSを新設（apps/pro-site・migration 0114適用済・Vercel本番デプロイ済）**。ユーザー指定（2026-08-14「石川遼オフィシャルと同じ構成・スマホで編集・Instagram共有・隠しコマンドでログイン・榎本剛志プロで先行」）。
  **(a) 構成** — 石川遼オフィシャル（ryo-ishikawa.jp）を踏襲: TOP（HERO/NEWS/MEDIA/RANKING/SCHEDULE/RESULT/INSTAGRAM）・NEWS一覧/詳細・SCHEDULE/RESULT・PROFILE（プロフィール表＋BIOGRAPHY＋主な戦歴＋クラブセッティング）。1プロ=1テナントの `/{slug}` 方式（第1号 /enomoto）。将来は独自ドメイン割当で横展開。
  **(b) 自己完結アプリ** — @yozan/core 非依存（スタッフ認証と無関係な外販商品のため）。認証はプロごとのパスワード（scrypt）＋HMAC署名Cookie（鍵はSUPABASE_SERVICE_ROLE_KEYから導出＝env追加なし）。テーブルは pgw_* 7本・service_role専用（RLS有効・ポリシー無し）。
  **(c) 隠しコマンド** — フッターの©表記を3秒以内に5回タップ→ /{slug}/admin ログイン。リンクは一切露出しない。管理画面はスマホ前提（大きい入力欄・タップで開く編集・素のHTML form＝server actions）。
  **(d) Instagram** — Meta API不使用（#127 Meta登録が端末認証で停止中のため）。プロが投稿の「リンクをコピー」を貼るだけ→公式embed.jsで表示。pgw_instagram にURL保存・新しい順に最大4件をトップ表示。
  **(e) SCHEDULE/RESULT** — pgw_tournaments 1テーブルを end_date と今日(JST・lib/jst.ts)の比較で自動振り分け。結果欄を後から埋めるだけで SCHEDULE→RESULT に移る。
  **(f) デプロイ** — Vercel MCP の direct deploy（gitを介さない）で pro-site プロジェクト新規作成・本番 https://pro-site-eight.vercel.app 。⚠残: ①Vercel env 2つ（NEXT_PUBLIC_SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY）が未設定＝設定＋Redeployまで500（ユーザー作業）②写真アップロード機能なし（URL指定のみ・次版でSupabase Storage）③独自ドメイン未取得④榎本プロの戦歴・クラブは本人ヒアリング待ち（プロフィール/経歴はALBA公開情報からシード済・パスワードはVault登録済）。
- #137b (2026-08-14) **PRO SITEにスポンサーバナー機能を追加（migration 0115適用済・デプロイ済）**。ユーザー指定（2026-08-14「管理画面からスポンサーのバナーを追加・多様なサイズ対応・画像データを挿入・表示形式もきれいに」）。
  **(a) 画像アップロード** — 管理画面 /{slug}/admin/sponsors からスマホの写真フォルダで直接選択→server action経由で storage バケット `pgw-sponsors`（public読み・書きはservice_roleのみ）へ。5MB上限・image/*のみ・拡張子サニタイズ。next.config の serverActions.bodySizeLimit=8mb。削除時はDB論理削除＋storage実削除。
  **(b) サイズ混在対応** — pgw_sponsors.size（large=1列/medium=2列/small=3列）をプロが選ぶ。表示は components/sponsor-grid.tsx: 大→中→小の順にグループ化し、白地カード＋object-contain（縦横比を崩さない）＋高さだけサイズ別に統一＝横長ロゴと正方形ロゴが混ざっても揃って見える。TOPのINSTAGRAM下にSPONSORセクション。
  **(c) 検証** — /tmp単独ビルド通過→direct deploy→仮バナー行を挿入してTOPにSPONSOR表示を実確認→行削除。ついでにIG IDを @eno_tsuyoshi に修正（検索で出る @eno1227golf は旧アカウント・ユーザー指摘）。
- #137c (2026-08-14) **PRO SITE 第2号テナント＝春馬凡夫プロ（/haruma）を開設**（migrationなし・DB追加のみ）。ユーザー指定（2026-08-14「卜部凡夫プロ、プロ名：春馬凡夫（はるまはんふ）。基本的には春馬凡夫で名前を統一」）。
  **(a) 表記の統一** — サイト上の表示は全て**プロ名「春馬凡夫」**（ローマ字 HANPU HARUMA）。本名「卜部凡夫」はサイトに一切出さない（staff / mon_pros の社内データとは別扱い＝[[lesson-allowance]] の「春馬」=卜部さんと同一人物）。GOLF WING所属の表記も伏せる（ユーザー判断）。
  **(b) 中身** — Web上に公開プロフィールが見つからないため、**プロフィール表は項目名（生年月日・身長・出身地など9行）だけ用意し値は空**＝プロ本人が管理画面から入力する運用。ニュースは開設のお知らせ1本をシード。パスワードは vault_systems 登録済み。
  **(c) 確認** — /haruma の TOP・NEWS・SCHEDULE・PROFILE・admin すべて200。アプリ側は無変更＝**1行INSERTで新テナントが立つ**ことを実証（外販時の手順はこれだけ）。
- #138 (2026-08-17) **シフトは「募集の開始」なしでいつでも提出・確定は期間まとめ＋1日単位の両方**（migration 0116・yozan-shift-cloud へ適用済）。ユーザー指定（2026-08-17「管理者が開始ボタンなどを押さなくてもシフト提出できるように、募集を開始するは削除」「提出後にこちら側で修正・調整して半月や月ごとに確定」「あとで編集することも考えて1つのシフトごとも確定や編集できるように」）。
  **(a) 募集期間(shift_request_periods)の廃止** — /admin/shifts の「希望募集の期間」カード（募集を開始／締め切る／募集中に戻す／削除）と period-form.tsx・delete-period-button.tsx、server actions 4本を削除。`shift_requests.period_id` を任意化し、一意キーを (period_id,staff_id,date) → **(staff_id,date)**（1人1日1件）へ。テーブルとデータは残す＝過去の提出の紐付けは壊さない。開いたままの期間は closed に。**開始ボタンの押し忘れ＝現場が1日も出せない、を構造ごと無くす**（休み希望を期間から切り離した [[shift-submission-rules]] #131 と同じ考え方を通常提出にも広げた）。
  **(b) スタッフ側 /requests** — 月送り（←/→・既定は翌月・「今月」リンク）で**今日以降ならいつでも・何ヶ月先でも**提出。締切の概念は撤去（ユーザー選択）。空にして提出＝その日の取り下げ（ドラフトシフトも消える）。**過去日と確定済みの日はロック**し、確定日は「確定 10:00〜19:00」と実際の時間を表示（ロックはUIだけでなく server action 側でも弾く）。募集の開始・締切という気づきの機会が無くなるので、**提出のたびにシフト作成権限者へ通知**（kind=shift_request_submitted）。
  **(c) 確定の粒度（1マス単位）** — 期間まとめ確定（日/週/半月/月の表示範囲＝#135のspan）は維持したまま、セルに **「✓ この日を確定」/「🔒 確定済み（押すと確定解除して編集）」** を追加（publishCells / unpublishCells）。確定解除はスタッフのシフト画面から消えるため**本人に「調整中」を通知**＝黙って消さない。
  **(d) 確定済みを直しても確定のまま** — saveDraft を **saveShifts** に改名し、published のセルを編集して保存しても status は published を維持（旧実装は黙って draft に戻り、**スタッフの画面からシフトが消えていた**）。代わりに内容が変わった確定シフトは本人へ変更通知（kind=shift_changed）。[[alerts-must-be-fixable]] と同じで「直せる」ことと「気づける」ことをセットにする。

- #139 (2026-08-18) **FRANK: 予約カレンダーの名前から詳細を開けるようにし、体験予約を受付台帳に流し込み、会員管理を作り直した**（migration 0117適用済）。ユーザー指摘3件への対応。**(a) カレンダーの予約詳細** — これまで予約ブロックは `title` 属性（マウスホバーのツールチップ）しか持たず、店頭PC/タブレットでは「誰の予約か」が実質読めなかった。`BayTimeline`/`WeekTimeline`/`UnplacedList` に `itemHref` を足して予約ブロックをリンク化し、`/dashboard?...&sel=<予約ID>` でサーバーコンポーネントのまま詳細パネル（`components/booking-detail.tsx`）を開く。**モーダルにしなかったのはカレンダー全体をクライアント化しないため**（URLで開ける＝更新にも共有にも耐える）。詳細には 区分/状態・氏名カナ・会員番号とプラン・電話（tel:）・メール・打席・会計（請求/入金/未収）・体験のゴルフ歴/ご要望・⚠重要説明事項 を出し、その場で 来店/無断欠/取消/入金記録 まで行える。会員名から会員カード（/frunk/<id>）へ飛べる。レッスン枠（id=`lesson:<uuid>`）は枠の詳細を出す。`/reservations` は同じ `itemHref` でブロック→下の一覧（`#bk-<id>`）へジャンプ。**(b) 体験予約が受付台帳に載っていなかった** — 体験は `mbr_trial_requests`＋`frunk_bookings` にしか入らず、`mbr_walkin_visits`（受付台帳＝**体験数KPIの正典**）は0行だった＝「予約は入っているのに台帳が空・体験数0」。決定（ユーザー選択）: **予約が入った瞬間に台帳へ書く**（来店を待たない）。共通処理を `packages/core/src/frank-walkin.ts`（`syncTrialWalkin`/`removeTrialWalkin`）に置き、genesis の `createTrialBooking`（サイトのセルフ予約）・`cancelTrialByToken`、member-os の `setTrialStatus`・`setBookingStatus`・`deleteBooking` から呼ぶ。冪等キーは `source_reservation_no='FRANK-TRIAL-<trial_request_id>'`（0070のユニーク索引を再利用）＝何度呼んでも増えない。**キャンセルは台帳から自動で下げる**（残すと体験数・体験→入会率が実態より多く出るため。ユーザー選択の文面は「手作業で削除」だったが、KPIが壊れる側の事故が大きいので自動に倒した）。**スタッフの追記（料金・成約・アンケート・メモ）は再同期でも絶対に上書きしない**（直すのは日付とお客様の紐付けだけ）。名寄せは電話下10桁とメールのみ＝氏名だけでは絶対にくっつけない（来店検索と同じ方針）。既存8件は 0117 で穴埋め済み。あわせて **受付台帳に「今後の来店予定」パネル**を追加（既定期間＝当月1日〜今日 から未来日の予約が漏れるため）、**当月サマリに翌月1日の上限**を入れて先の予約を当月に数えないよう修正、**体験フォローは未来日を除外**（まだ来ていない人がフォロー待ちに並んでいた）。**(c) 会員管理の作り込み** — `/frunk` は「承認待ち＋全会員ベタ並べ」で探す手段が無く、会員が増えると店頭でお客様を待たせる構造だった。一覧＝探す/絞る、詳細＝1人を深く見る、に分割。検索の当たり判定は `apps/member-os/src/lib/frunk-member-search.ts`（純関数・テスト6件）に集約＝**NFKC正規化でひらがな/カタカナ・全角英数・ハイフンの表記ゆれを吸収**し、電話は数字だけ（下10桁＋部分一致）で当てる。状態タブ（在籍/休会/退会/申込/却下＋件数）・プラン絞り込み・並び順（会員番号/カナ/入会日/状態）。既定は**在籍のみ**（退会者が混ざると読み違える）。新設 `/frunk/[id]`＝会員カード: プロフィール・プラン/月会費（税込）・入会金・自動課金（Square稼働/休会で一時停止/未登録）・キャンペーンと6か月継続・予約と来店の履歴（来店/無断欠/今後/未収合計）・レッスンカルテへのリンク（`lsn_students.member_code`→共有トークン）・重要説明事項・連絡先の編集（NameFields/AddressFields/BirthDateInput の共通入力を使用）。操作系（休会/復帰/退会/プラン変更/会員番号メール再送/⚠保存）は `/frunk` のサーバーアクションを共用し、hidden `back=/frunk/<id>` で実行後カードに戻す（戻り先は `/frunk` 配下に限定＝オープンリダイレクト防止）。検証: member-os / genesis の tsc 通過、テスト360件通過（新規6件含む）、0117適用で受付台帳8件を確認。

- #140 (2026-08-19) **Caddy OS: キャディシフト管理の一元化（カレンダー→確定→台帳→ゴルフ場提出CSV→API）**（migration `0118_caddy_shift_confirm.sql`・yozan-shift-cloud へ適用済）。小川さん依頼（2026-08-19「シフト入力→派遣確定→ゴルフ場提出用データ→キャディ台帳を1つのシステムで完結させたい」「今まで複数回入力していた同じ情報を、一度入力・確定したデータで使い回したい」）。
  **(a) 新しいテーブルを1本も作らなかった** — 依頼文には「キャディマスター / ゴルフ場マスター / シフト希望 / 派遣シフト」の4つを分けて持ちたいとあったが、それは既に `cad_partners` / `cad_clients` / `cad_availability` / `cad_dispatches` として存在していた（#45/#46/#62）。台帳・提出一覧も **`cad_dispatches` の別の見え方**にすぎない。台帳テーブルを別に作って「確定時にコピーする」設計は必ずどこかでズレる（Excel運用の事故そのもの）ので、**元データを1本に保ったまま status を足す**方向に倒した。＝依頼の7〜8割は作らずに満たしている（「無駄を削ぐ」というユーザー指定への回答）。
  **(b) 派遣シフトのステータス（仮・確定・キャンセル）** — `cad_dispatches.status` を追加（default `confirmed`）。既存329行は全て確定扱いになるため、**適用前後で請求・財務の数字は1円も動かない**（8ヶ月分を fin_entries と実データ照合して確認）。`refresh_caddy_finance` / `renumber_caddy_seq` を `status='confirmed'` に絞り、請求（受取/支払）の各クエリにも同条件を追加。画面側の `isBillable()`（`lib/shift.ts`）が同じ条件を持つ**SQLとTSの二重実装**なので、変えたら両方直す（#53と同じ注意）。
  **(c) シフトカレンダー `/calendar`** — 日付×キャディ×ゴルフ場×確定状態が一目で分かる月間表。日セルをタップすると、**その日に○/△を出しているキャディだけが候補に並ぶ**（集めた希望がそのまま割当候補になる＝転記が消える）。金額はマスタから自動補完（売上単価・委託料#62③・交通費単価表#62②）。同じ日・同じ人の二重割当はサーバー側で拒否。確定は「1件ずつ／その日まとめて／月まとめて」の3段階（#138でシフト側が採った粒度と揃えた）。確定した瞬間に採番振り直し→財務再集計が走る。
  **(d) キャディ台帳 `/ledger`** — 確定分から自動生成。個人ページに 勤務日/ゴルフ場/勤務区分/委託料・交通費・手当・計。支払請求書へ1クリック。**二重入力なし**（依頼3.への回答）。
  **(e) ゴルフ場提出 `/exports`** — ゴルフ場別の月間派遣一覧＋CSV。**確定分のみ**＝仮組みが外部に出る事故が構造的に起きない。書式は `cad_clients.csv_format`（standard/simple/grouped/wide）。組み立ては `lib/csv.ts` の純粋関数なので**画面プレビュー・ダウンロード・APIの出力が必ず一致**する。新書式は `CSV_FORMATS` に1つ足すだけ（画面もAPIも無改修）。**BOM付きUTF-8**（無しだとExcelで日本語が化ける＝現場で必ず踏む）。
  **(f) 外部連携API `/api/v1/*`（API_STANDARD.md準拠）** — partners / clients / availability / dispatches / exports の GET・POST・PATCH。認証は `Authorization: Bearer <CADDY_API_TOKEN>`（inventory-os #96 と同方式）。**トークン未設定なら常に401**＝設定漏れで口が開かない。`company_id` はリクエストから受け取らない。画面（Server Actions）とAPIは同じテーブル・同じ純粋関数を見る＝ロジックの二重実装をしない。
  **(g) キャディ本人のスマホ提出 `/s/[token]`** — `cad_partners.submit_token` を設定画面から発行し、URLをLINEで1回配れば以後は本人が入力できる。ログイン不要・トークンで本人を特定し**その人の行しか触れない**（#12/#23と同型）。タップで○→△→×→未回答、今月＋2ヶ月先まで、**過去日と確定済みの日はロック**（UIだけでなくサーバー側でも拒否）。保存先は管理者の代理入力と同じ `cad_availability`（`source='self'`）でカレンダーに `＊` 付きで出る。再発行で旧URLは即無効。
  **(h) ついでに直したもの** — caddy-os の本番ビルドが `masters/page.tsx` の型エラーで **ERROR のまま放置されていた**（Supabaseのネスト取得が配列型に推論される件 / #76 と同じ「ERROR放置」）。`unknown` 経由のキャストで解消。
  **(i) 検証** — `npx tsc --noEmit` 通過、`next build` 通過（23ルート）、テスト **369件通過**（`tests/caddy-shift-csv.test.ts` 12件を新規追加）、0118適用後に8ヶ月分の売上・外注費が fin_entries と完全一致することをSQLで確認。
  ⚠残: ①Vercel `caddy-os` に環境変数 `CADDY_API_TOKEN` の設定が必要（未設定でも画面は動く。APIだけが401になる）②LINE通知（#29）との接続は未着手＝提出URLの配布は当面手作業③ゴルフ場側システムへの直接送信は未実装（CSV書き出し＋メール添付を想定）。

- #141 (2026-08-22) **Lesson OS: FRANK予約カレンダーからカルテへ直行・会員/退会の自動同期・トラックマン写真のAI取込・撮影ガイド廃止**（migration `0119_lesson_frank_sync.sql`・yozan-shift-cloud へ適用済）。ユーザー依頼（2026-08-22「予約システムのカレンダーからタップしたらlesson-osに飛べるように」「会員登録をされたらそれも自動追加」「退会時にはlesson-osから非表示」「トラックマンデータを写真を撮ったら入れれるように（間違えているところは人間が修正）」「レッスン動画撮影時のガイド線の表記がおかしいので削除」）。
  **前提の実測** — 有効なFRANK会員4名のうち**カルテを持つ人は0人**だった。`frank-join.ts` の `ensureLessonKarte` は Web入会Webhook（#129）の経路にしか無く、店頭承認・手修正で会員になった人には走らない。Lesson OS 全体でも生徒1人・動画2本・最終記録 2026-07-14 で実質未稼働。
  **(a) 会員→カルテの自動化はDBトリガーで行う** — アプリ側に足すと入口（Webhook / 店頭承認 / 手修正）ごとに実装が要り、必ずどこかで抜ける。`frunk_members` の **member_no が付いた＝入会が確定した** というDBの事実1点に `trg_sync_frank_member_karte` を張り、`lsn_students` を find-or-create する。氏名・カナ・店舗は追従、目標/メモ/動画には触らない。既存4名は 0119 のバックフィルで作成済み。
  **(b) 退会は削除しない** — `status='left'/'rejected'` → カルテを `status='inactive'` に落とすだけ（`suspended`＝休会はレッスンが続くので active のまま）。動画・アドバイス・進捗は上達の記録なので消さない。生徒一覧・CSVは**既定で退会者を出さず**、「退会者も表示」チェック（`?inactive=1`）で過去の生徒として開ける（ユーザー選択）。
  **(c) 予約カレンダー→カルテは `/m/<会員番号>` で解決する** — member-os が `lsn_students` を引いてIDを組み立てると、アプリ間の結合が増えるうえカルテが無い会員でリンクが死ぬ。lesson-os 側に会員番号→カルテIDの解決ルートを置き、**無ければその場で作ってからリダイレクト**する（コーチの前で止めない）。member-os は 予約詳細パネル（`?sel=`）の会員行とボタン、レッスン枠パネル（予約者を表示）、会員カード `/frunk/[id]` からこのURLを開くだけ。会員カードの「レッスンカルテ」ボタンは**生徒の共有ページ**（`/s/<token>`）を開いていて紛らわしかったので、コーチ用カルテと別ラベルに分けた。店舗スコープ（#134）は解決ルート側でも検証する。
  **(d) トラックマンは「AIが下書き・人が確定」** — カルテに「計測」タブを追加。1ショットの数値タイルを撮る→端末側で長辺1600pxに縮小→Storageへ直PUT→Claude Vision（`lib/trackman-ai.ts`・genesis の `receipt-ai.ts` と同じ作り）で22項目を読む→**全項目を編集可能なフォームに載せてコーチが直す**→`lsn_measurements` に確定保存。読めない項目は空のまま（推測で埋めさせない）。**単位は換算せず写真に写っていたものを `_units` に持つ**（m/s ⇄ mph、yd ⇄ m を勝手に直すのが一番危ない）。桁が明らかに異常な値は `sanitizeTrackman` の範囲チェックで落とす。AIの生結果は `ai_raw` に別で残し、確定値 `data` と突き合わせて読取精度を後から検証できる。`ANTHROPIC_API_KEY` 未設定でも画面は動く（手入力の計測台帳になる）。
  **(e) 撮影ガイド線は廃止** — `GuideDTL`/`GuideFaceOn` とアングル切替ボタンを削除。説明テキストがSVGの viewBox 幅（90）を超えて画面外で切れており、線も被写体に重なって構図が取りづらかった。画角合わせは9:16の固定枠で足りる。手順書（`/manual` §7）も書き換えた。
  **(f) ついでに塞いだ穴** — 動画単位のアクション（コメント/ベスト/削除/描画/フェーズ/再生URL）が `company_id` しか検証しておらず、**動画IDさえ分かれば他店舗のカルテを操作できた**（#134「店舗またぎ廃止」の徹底漏れ）。`ownVideo()` を追加し、`ownStudent()` と同じ店舗判定を通す。
  ⚠残: ①Vercel `lesson-os` に `ANTHROPIC_API_KEY`（必要なら `LESSON_AI_MODEL`）の設定＝AI読取はそれまで無効 ②ロール「コーチング（店舗）」に `use_lesson` が無く、穴田さん・藤田さんは今もアプリを開けない（NEXT_TASKS A-2） ③GOLF WING 側（`mbr_members` 247名）の自動同期は未着手＝今回はFRANKのみ。

- #142 (2026-08-22) **ロール・権限の編集画面を作った（Shift Cloud `/admin/roles`）**（migrationなし）。ユーザー指摘（2026-08-22「これのページがないですよ？？」）。
  **何が起きていたか** — `roles.permissions` を編集するUIがどのアプリにも無かった。`roles` を読むのは shift-cloud `/admin/staff` と genesis `/accounts` の2画面だけで、どちらも `select id, name`＝**ロールを割り当てることしかできない**。そのため #141 のコーチ権限も「Shift Cloud → ロール → チェック」と案内してしまい、存在しない画面を指した。**警告を出すならその場で直せるUIまで作る**（#122）に反した状態だったので画面にする。
  **(a) オーナー限定** — 権限は会社全体に効き店舗の次元を持たないため、`manage_company` のみ。監査ログ（#134b）と同じ扱い。
  **(b) 誰に効くかを同じ画面に出す** — ロールに権限を足すと**そのロールを持つ全員**に即座に効く。各ロールに「使っている人（n人）: 氏名…」を常時表示する。実際 #141 で `use_lesson` を足したロールには デモ（SWING CORTEX）アカウントも入っていた。
  **(c) 同名ロールを警告する** — 「コーチング（店舗）」は本番に2つある（`5f45104c…`＝株式会社YOZAN / `357dab28…`＝別テナントFRANK GOLF社）。**名前で更新すると取り違える**ので、更新は必ずID、画面には赤バッジと先頭8桁のIDを出し、新規作成時は同名を拒否する。
  **(d) 締め出しを構造的に防ぐ** — ①`manage_company` を持つロールがゼロになる保存を拒否 ②自分が入っているロールからは `manage_company` を外せない ③`read_only` は他の全権限を打ち消す特殊値なので併用を拒否。いずれもサーバーアクション側で判定する（UIの出し分けではない）。
  **(e) カタログに無いキーは消さない** — チェックボックスは `lib/permissions.ts` の一覧から作るので、そこに未登録のキー（新しいアプリが先に使い始めた場合）は画面に出ない。保存時に既存の未登録キーをそのまま持ち越す実装にしてある＝**画面を通しただけで権限が消える事故が起きない**。新しい権限を足したら `lib/permissions.ts` に1行足すこと。
  **(f) 削除は「誰も使っていない・標準でない」ロールだけ** — 使用中は人数を出して拒否する。削除はソフトデリート。すべての変更は `logAudit` で `role.permissions.update` / `role.create` / `role.delete` として残る。
  なお #141 の `use_lesson` 付与は、この画面が無かった時点でDBを直接更新して実施済み（ロール `5f45104c…`）。

- #144 (2026-08-22) **Caddy OS シフトカレンダー: 出勤希望が来ていないキャディも割り当てられることを画面で明示し、希望の代理入力をカレンダー内でできるようにした**（migrationなし）。小川さん依頼（2026-08-22「CADの出勤希望が来てなくてもこちらから入力できるようにしてほしい」）。
  **実態** — サーバー側は最初から希望の有無を問わず割り当てできた（重複判定は日付×キャディのみ）。詰まっていたのは画面で、候補の見出しが「キャディ（出勤希望順）」だったうえ未回答者は並びの最後に無印で沈み、さらに × と回答した人は候補から丸ごと消えていた。**「希望を出した人しか選べない」と読める作りだったのが原因**。
  **(a) 候補は稼働中の全員を出す** — ドロップダウンを「出勤希望あり（○/△）」「希望なし・未回答（そのまま割り当てできます）」「×（不可と回答）※どうしてもの時だけ」の3グループに分けた。× の人も**消さずに選べる**（電話で後から都合がついた分を入れられないと現場が回らない）。並び順は ○→△→未回答→× のまま。
  **(b) 希望をカレンダーで代理入力できる** — 日パネルの「この日の出勤希望」を読み取り専用のチップから**押せるボタン**に変え、押すたび 空欄→○→△→× と一巡して即保存する（`setAvailability`＝/availability の表と同じ server action・source は "admin"）。電話やLINEで聞いた希望を、割当と同じ画面で入れられる。本人がスマホから出した分は従来どおり ＊ 付き。
  **(c) 表示のtypo修正** — 「確定に???ります」と文字化けしていた案内文を「確定になります」に直した。
  検証: caddy-os の tsc クリーン。migrationなし・データ移行なし。
  **(d) 同じ1行を見ている5画面の作り直し漏れ（#144b・同日追加）** — 小川さんから続けて「派遣台帳が過去の分と入力した分が見れない」「カレンダーに登録したのに表示されない」。派遣台帳から登録・削除・請求月変更をしても `revalidatePath` が `/` と `/dispatches`（＋一部 `/invoices`）だけで、**同じ cad_dispatches を見ている /calendar・/ledger・/exports を作り直していなかった**。`revalidateDispatchViews()` に集約して6画面すべてを必ず作り直す。カレンダー側の assignDispatch は元から全部呼べていた＝**入口によって整合性が変わる状態**だった。
  **(e) 月スコープが画面に出ていなかった（#144b）** — 派遣台帳もカレンダーも「表示中の1か月」しか出さない。つまり月がずれているだけで「過去の分が消えた」「登録したのに出ない」と全く同じ見え方になる。実データは無傷（2026-01〜09に332件・8月は12件）だったので、**消えたのではなく見えていないことを画面で言い切る**方向で対処: `components/month-nav.tsx` を新設し、登録のある月と件数をボタンで並べて1タップ移動できるようにし、表示中の月が0件のときは「消えたわけではありません。直近で登録があるのは 2026/08（12件）です」とリンクで案内する。まとめて登録の上にも「表示中の月以外の日付も入れられます。別の月で登録すると、その月に切り替えるまで一覧には出ません」と明記。集計は `getMonthCounts()`（日付だけ引いてJS側で数える・RPCは増やさない）。
- #144c (2026-08-22) **Caddy OS が台帳を「0件」と表示していた真因＝staff への外部キーが2本になり埋め込みクエリが壊れていた**（migrationなし）。小川さん報告「派遣一覧が0件と出る」「カレンダーにキャディ名とゴルフ場が出ない」。#144b で入れた月ナビが「2026/08 = 12件」と出しているのに一覧が0件、という矛盾が決め手になった。
  **原因** — migration 0118（#140・8/19）で `cad_dispatches.confirmed_by → staff(id)` が増え、**staff への外部キーが `staff_id` と `confirmed_by` の2本**になった。この状態で PostgREST に `staff(name)` と書くと「どちらの関係か決められない」で**クエリ全体がエラー**になる。ところが呼び出し側が `const { data } = await ...` と **error を捨てていた**ため、data=null → `[]` → 画面には「0件」とだけ出る。データは1件も欠けていない（2026-01〜09で332件）。8/19以降ずっと壊れていたが、月ナビを入れるまで誰も矛盾に気づけなかった。
  **修正** — `const STAFF_EMBED = "staff!cad_dispatches_staff_id_fkey(name)"` に集約して関係名を固定（該当4か所: `getDispatches` / `getMonthBoard` / `/api/v1/dispatches` / `/api/v1/exports` / `/masters`）。あわせて **`getDispatches` と `getMonthBoard` は error を握りつぶさず throw する**ようにした。金額と勤務実績の台帳が黙って空になるより、はっきり落ちて気づけるほうが安全。
  **教訓（横展開が要る）** — ①**外部キーを足したら、その親テーブルを埋め込んでいる既存クエリが全部壊れる**。0118のように後から `*_by` 列を足す migration では、同じ親テーブルへの embed を必ず grep する。②`const { data } = await admin...` と error を捨てる書き方は、**障害を「0件」という正常な見た目に化けさせる**。台帳・集計系では error を throw するか、最低でも console.error する。他アプリにも同じ書き方が多数あるので順次直す。
- #151 (2026-08-22) **member-os: 予約・体験・受付台帳を「後から直せる」ようにした**（migrationなし）。小川さん依頼「member-osで登録されている体験予約などの日時変更を行えるようにしてください。変更の可能性があるものはすべて変更できるように」。
  **発見** — member-os には **予約を直す手段が一つも無かった**。作る・状態を変える（来店/無断欠/取消）・入金する・消す、だけ。`booked_date` / `start_time` / `end_time` / `bay_id` を書くコードはリポジトリ全体で**新規作成の2か所だけ**だった。つまり日時を間違えた・お客様から変更の電話が来た、というときは「消してもう一度作る」しかなく、**体験予約だと申込(mbr_trial_requests)と受付台帳(mbr_walkin_visits)まで道連れに消える**。
  **(a) `updateBooking`（reservations/actions.ts）** — 日時・打席・人数・氏名・電話・備考を1本で直す。重なりチェックは **自分自身を除いて**やる（除かないと必ず自分と衝突して保存できない）。**レッスン枠（frunk_lesson_slots）とも重なりを見る** — 打席は共有なのに、既存の `createBooking` はレッスンと突き合わせていなかった（ダブルブッキングの穴）。営業時間・定休日も再判定する。会員予約の氏名・電話は会員マスタが正なので、都度予約のときだけ上書きする。
  **(b) 体験は3点セットで揃える** — 予約(frunk_bookings) / 申込(mbr_trial_requests) / 受付台帳(mbr_walkin_visits) は `trial_request_id` と `FRANK-TRIAL-<id>` の2つの鍵でつながっている。日時を変えたら申込の `booked_date/start_time/end_time/bay_id` と **`pref1`** も書き換える（/trials の一覧は今も pref1 を表示しているので、直さないと一覧が嘘をつく）。そのうえで `syncTrialWalkin` を呼ぶ。
  **(c) 受付台帳のメモが古い時刻のまま残る穴を塞いだ** — `syncTrialWalkin` は既存行の `visited_on` しか直さず、`note` に埋まった「体験予約 10:00〜11:00」は放置していた。**自動生成のまま（「体験予約」で始まる）ときだけ**作り直す。スタッフが書き換えたメモは尊重する。
  **(d) 受付台帳の `visited_on` / `visit_type` を編集可に** — 従来は金額・成約結果・メモしか直せず、**来店日そのものが直せなかった**。
  **(e) /trials に実際の予約日時を出した** — この画面は希望日(pref1〜3)しか出しておらず、サイトのカレンダーで確定した本当の日時が見えなかった。確定済みなら予約日時＋予約管理へのリンクを出す。
  **(f) お客様への変更メールは「チェックしたときだけ」** — `buildBookingRescheduleMail` を追加。電話で口頭合意した直後に自動で飛ぶと二度手間になる現場があるので、送るかどうかは毎回スタッフが決める。キャンセル用リンク（cancel_token）は元のまま有効なので再掲する。
  検証: member-os / genesis とも tsc クリーン、テスト375件通過。

- #147 (2026-08-22) **Shift Cloud: シフト作成で「業務」（キャディ等）を選べるようにし、紙シフトの並び順を▲▼で決められるようにした**（migration `0121_shift_work_types_and_staff_order.sql`・適用済）。小川さん依頼「シフト作成時にキャディー業務の選択ができるようにしたい、表示するかどうかは人ごとに設定できるようにしておいて」「紙シフト出力のときに名前の順番を変えれるようにしたい」。
  **(a) 業務区分は作らずに既にあるものを使った** — `schedule_types`（現場/レッスン/ラウンドレッスン/会議/営業/撮影/出張/コンペ/研修…13件）は 0001 からある業務区分マスタで、`shifts.schedule_type_id` という列まで用意されていたのに、**アプリから一度も参照されていなかった**（/admin/events だけが schedule_types を使っていた）。新しい概念を足さず、この眠っていた線をつないだ。「キャディ」を1件追加。
  **(b) 誰に出すかは `staff_schedule_types`（staff × schedule_types）** — 全員に13件のプルダウンを出すと現場が使えなくなる。**行が無い人には「業務」の選択肢自体を出さない**（＝従来どおりテンプレートと時間指定だけ）。スタッフ編集画面のチェックで決める。キャディに入る4名は既定でON。
  **(c) 保存は `shifts.schedule_type_id`。時刻は持たせない**＝終日その業務。時間を切りたいときは従来の「⌚ 時間指定」を使う。選択値は `wt:<id>` としてテンプレIDと混ざらないようにした。
  **(d) Caddy OSで確定した派遣は自動で出す** — 二度入力を避ける（#140の「一度入力・確定したデータで使い回す」と同じ方針）。紐付けは **`cad_partners.staff_id`**（列で明示的に持つ。氏名の一致だけで結ぶと事故るため。バックフィルは「空白を除いた氏名が両側で一意に一致」する場合だけ＝古川/小川うらら/穴田/卜部の4名）。シフト作成では ⛳ゴルフ場名 のバッジ、紙シフトでは未入力の日でも「キャディ」と出る。**Shift Cloud側から Caddy OS へは書かない**（入力口は Caddy OS の1か所のまま）。
  **(e) 並び順は `staff.sort_order`＋一覧の▲▼** — 数字を意識させないため、隣同士で sort_order を交換する。全員0（初期値）のままだと交換しても順番が変わらないので、**初回は現在の並びで 10,20,30… に振り直してから**交換する。スタッフ管理・シフト作成・紙シフトの3画面で同じ順になる（従来は紙だけ `position, name`、画面は `name` で**別々の順**だった）。紙シフトの役職グルーピングは残し、グループの出現順もこの並びに従う。
  検証: shift-cloud / caddy-os とも tsc クリーン。

- #146 (2026-08-22) **Caddy OS: ゴルフ場を色で、確定/仮を形で見分けられるようにした**（migrationなし）。小川さん依頼「ゴルフ場ごとに色分けをしてわかるようにしてほしい」「確定と仮もぱっとみで判断つくように」。
  決めごとを2つ固定した。**色＝ゴルフ場／形＝状態**。`src/lib/client-colors.ts` に集約。
  **(a) 主要4社は小川さん指定の固定色、それ以外は取引先IDのハッシュ** — 指定は **マスターズ=黄 / 加古川=赤 / 西宮高原=青 / 芦屋=ピンク**。判定は**名前の部分一致**にした（`延田エンタープライズ マスターズゴルフ倶楽部` のような法人名付き、`倶`と`俱`の表記ゆれで外れないため）。指定のない取引先は表示順ではなくIDのハッシュで決める — 表示順で割り当てると取引先が1社増えた瞬間に全部の色がずれて覚え直しになる。ゴルフ場未設定と自社GW勤務はグレー。
  **(b) 状態は色で表さない** — 確定=塗りつぶし＋実線、仮=**白地＋破線＋「仮」の文字**。色覚特性・白黒印刷・店頭の照明を考えると色だけの区別は危険なので、必ず形と文字を伴わせる。取消は状態を最優先してグレーの取り消し線。
  **(c) Tailwind v4 はクラス名を静的に走査する**ので、`bg-${color}-100` のような組み立ては CSS が生成されず無色になる（[[tailwind-v4-color-syntax]] と同種の罠）。パレットは**クラス文字列をベタ書き**で持つ。
  適用先: シフトカレンダー（日セルの帯・日パネルの割当一覧・凡例）／派遣台帳（取引先セル・凡例）／ゴルフ場提出（各パネルの見出し）。凡例は「色＝ゴルフ場」「形＝状態」の2行を常時表示し、対応を覚えなくても読めるようにした。

- #145 (2026-08-22) **Caddy OS ゴルフ場提出: 仮のままでも出せるようにし、CSVとPDFの両方に対応した**（migrationなし）。小川さん依頼「月間派遣一覧をゴルフ場に送るとき仮の状態でも提出できるようにしたい」「csvとPDFどちらの形でも提出できるように」。
  **(a) 仮を含める** — #140 では「確定だけ出す＝仮をゴルフ場に送る事故を構造で防ぐ」設計にしていたが、実務は**先に予定として渡し、確定後に送り直す**運用だった。`/exports?kari=1`（チェックボックス「仮も含めて出す」）で仮を含められる。既定は従来どおり確定のみ。
  **(a-2) 提出物に「仮」の印は出さない（#145b・同日の追加指示）** — 当初は状態列・注記・記号（△）で仮を明示していたが、小川さんから「仮はゴルフ場に知られたくない」。**ゴルフ場から見ればこれは「提出された予定」であって、確定/仮はYOZAN社内の管理状態でしかない**という整理。よって CSV・PDF から状態列／件数の注記／△記号／日付の(仮)をすべて外し、残すのは**表題（「日程表」→「予定表」）とファイル名（`_予定`）と「予定のため変更になる場合があります」の一文**だけにした。社内側（カレンダー・派遣台帳・提出画面のプレビュー）は従来どおり破線＋「仮」で区別できるので、**社内の取り違えは防ぎつつ対外的には出さない**という分け方に落ち着いた。
  **(c) PDFは同じ日を1行にまとめる（#145c・同日の追加指示）** — 「同じゴルフ場・同じ日に2名以上の派遣がある場合は1行に」。PDFは1ゴルフ場ぶんなので、1件1行だと「8/7が3行」のように同じ日付が並んでゴルフ場側が数えにくい。**日付でまとめ、人数列＋キャディ名（、区切り）**にした。名前が多い日は行の高さが伸びるので、ページ分割は件数ではなく**積み上げた高さ**で判定する（日本語は単語境界が無いので折り返しは1文字ずつ幅を測る）。備考は同じ文言を重複させずに `/` でつなぐ。CSVは1件1行のまま（Excelで並べ替え・集計する用途のため）。
  **(b) PDF** — CSVはExcelで開く相手向け。印刷・回覧にはPDFが要るので `/exports/pdf?ym=&client=&kari=1` を新設（`src/lib/export-pdf.ts`・pdf-lib＋NotoSansJP、**subset埋込は禁止** [[frank-instant-join]] と同じ理由）。罫線つきA4縦・複数ページ対応・宛名（ゴルフ場名 御中／ご担当者）・集計行・仮の注記入り。**行の組み立てはPDF側でも getMonthBoard からやり直す**（画面から行データを受け取らない＝URLを直接叩かれても中身を差し替えられない）。CSVとPDFは同じ ExportRow を使うので内容がズレない。
  依存追加: caddy-os に pdf-lib / @pdf-lib/fontkit（package-lock も更新）、`src/assets/NotoSansJP-Regular.ttf` を複製、next.config の outputFileTracingIncludes に `/exports/pdf` を追加。
- #143 (2026-08-22) **Lesson OS: 撮影は1ボタンで完結、再生はサムネイルを押すだけにした**（migration `0120_lesson_video_poster.sql`・yozan-shift-cloud へ適用済）。ユーザー依頼（2026-08-22「ファイルを添付するのではなく…動画撮影ボタンを押したらすぐに撮影できるように」「タップしたらすぐに再生」「スマホで見たらすでに動画の最初の画面が表示されていて、それを押したら再生される感じで」）。
  **(a) 撮影** — 撮影モジュール自体は #51 から存在したが、同じカードにファイル選択が並んでいて主導線が分からず、さらに **撮影後に【この動画を使う】で閉じ → カルテを下までスクロール → クラブ/飛距離を入れて【⬆登録】** という3手が残っていた。打った直後の現場で必ず抜ける導線なので、**大きな【📹 スイングを撮影する】1つを主導線にし、撮影モジュールの中でクラブ・飛距離・メモ・登録まで完結**させた。ファイル取り込みは「動画ファイルから取り込む」の中に畳んだ（カメラアプリで先に撮った動画を入れる用途は残す）。
  **(b) 再生** — 一覧は「▶ 再生・描画をひらく」というグレーの箱で、押す→サーバーアクションで署名URLを1本ずつ取得→やっと読み込み、と一拍待たされていた。**ページ表示の時点で `createSignedUrls` により全動画ぶんの再生URLを往復1回でまとめて発行**し、カードには最初から `<video>` を置く。押せばその場で再生される。描画・フェーズ・スローは【✎ 描画・フェーズ・スロー】を押したときだけ従来のプレーヤーに差し替える（機能は減らしていない）。
  **(c) サムネイルは登録時にブラウザで作る（0120 `poster_path`）** — 「押す前から1コマ目が見えている」を `<video preload="metadata">` だけで実現すると、**本数ぶん動画へレンジリクエストが飛ぶ**（現場は4G・1人20本超）。そこで登録時に canvas で1コマ目を切り出し、長辺640pxのJPEG（20KB前後）としてStorageに保存する。一覧は `poster` 画像だけを出し、動画本体は `preload="none"`＝押されるまで1バイトも読まない。**サムネイル生成が失敗しても登録は続行**し、`poster_path` が null の行は従来どおり `preload="metadata"` ＋ `#t=0.1` にフォールバックする（既存動画を遡って作り直す必要がない）。
  **(d) 生徒の共有ページも同じにした** — `/s/[token]` は署名URLを1本ずつ発行しており、記録20本＋お手本6本で **26往復**していた。ここも `createSignedUrls` 1回にまとめ、poster がある動画は `preload="none"`。生徒の通信量を使わずにサムネイルだけ出る。
  **(e) お手本スイングも同様に poster を持つ**（`lsn_model_videos.poster_path`）。
  ⚠残: 既存の動画2本には poster が無い（フォールバック表示になる）。必要なら再登録で付く。

- #148 (2026-08-23) **AI店長 第1弾: 体験フォローの文面下書き＋メール送信を /follow に実装**（migration `0122_walkin_follow_message.sql`・適用済）。外販の看板商品「AI店長」の最初のループ（気づく→下書き→承認で実行→記録）。検知と「要フォロー」表示は既存の /follow をそのまま使い、新概念は足していない。
  **(a) 文面はルールベースの即時生成**（`lib/follow-draft.ts`・純関数）。demo-sales #54 と同じ「AIより先に高速生成」方針。受付アンケートの体験目的（TRIAL_REASONS）に応じて一文を変える。Claude API には依存しない＝キー未設定でも全店で動く。tests/follow-draft.test.ts（3件）で検証。
  **(b) 送信＝承認**。スタッフが文面を確認・編集して「メールで送信」を押したときだけ送る（AI店長は自動送信しない、の原則）。**送信が成功したときだけ follow_up_at を立てる**（送れていないのに済になる事故を防ぐ）。二重送信は follow_up_at 既存チェックで防止。
  **(c) メール送信は FRANK 店舗の行のみ**。送信元が `FRANK GOLF <info@frankgolf.jp>`（frank-mail.ts / Resend）のため、GOLF WING の文面に FRANK ブランドが混ざらないようサーバー側で店舗名を検証して拒否。GOLF WING 等は従来どおり文面をコピーして公式LINEで送り「フォロー済にする」（channel='line' が入るようになった）。
  **(d) 記録**: `follow_up_channel`（email/line）と `follow_up_message`（送った本文）を台帳に残す。将来のAI店長の学習（どの文面が入会につながったか）の土台。undoFollowUp は channel/message も戻す。
  ⚠ member-os の Vercel env に `RESEND_API_KEY` / `FRANK_MAIL_FROM` が必要（#118のWeb入会メールと共通。未設定なら送信スキップ＝フォロー済にならない）。

- #149 (2026-08-23) **AI店長 第1.5弾: 朝のダイジェストに「店の今」＝昨日の売上・今日の予約・要フォローを追加**（migrationなし・`lib/morning-digest.ts`）。外販の看板「AI店長＝朝のダイジェスト」の実体。新しい配信は作らず、**#83の朝の個人LINEダイジェストに＜AI店長＞ブロックを足しただけ**（配信先・重複防止・gn_loop_runs記録は既存のまま）。
  **(a) 昨日の売上は mon_sales を店舗別に合算。source='ledger' は除外** — 台帳ロールアップは日次明細の合算行で、当日入力（app等）と混ぜると二重計上になる（/analysis の proSales #98 と同じ理由）。
  **(b) 今日の予約は frunk_bookings（status<>'cancelled'）** — FRANKのみ（GOLF WING宝塚の予約はSmart Hello側でDBに無いため件数に含めない。表示も「（FRANK）」と明記して誤読を防ぐ）。
  **(c) 要フォローは /follow と同じ条件**（trial・7日以上経過・未入会・未フォロー・直近60日）。1件以上あるときだけ /follow へのリンクを付け、#148のAI文面下書きへ誘導する＝ループがつながる。
  **(d) observed に sales_yesterday / bookings_today / follow_due を記録** — 後から「あの朝なんと言ったか」を追える。
  確認済み: gn_loops(morning_digest) は line_user_id 設定済み・直近7日で8回配信＝翌朝から自動で新ブロックが載る。

- #150 (2026-08-23) **member-os を外販テナント対応にし、UIを白基調×深緑×金へ刷新**（migrationなし）。きっかけ＝デモテナント「サンプルゴルフスタジオ」のオーナーに FRANK 予約カレンダー・FRANK会員・GOLF WING月次リンクが出ていた（ユーザー指摘・スクショ）。
  **(a) 原因はオーナーの無条件true** — `canAccessStore(owner)=true` を前提に `canAccessFrank`/`canAccessGolfWing` が会社を見ていなかった。**「会社がその店舗を持つか × 自分が触れるか」の二段判定**に修正: `companyHasFrank(companyId)`（新設・cache）を AND、`canAccessGolfWing` は gwStoreId が無ければオーナーでも false。YOZAN の見え方は不変。
  **(b) 汎用ダッシュボード新設** — GOLF WING/FRANK を持たない会社の /dashboard は、受付台帳だけを源泉にした汎用画面（今月の体験・入会・入会率・要フォロー4タイル＋最近の来店＋導線）。「表示できる店舗がありません」は配属未設定の場合だけに残した。外販顧客の最初の画面はこれが標準になる。
  **(c) ブランド表記の会社対応** — ヘッダーの「GOLF WING」固定を brand prop 化（GOLF WING を持つ会社は従来どおり、それ以外は会社名）。ログインの eyebrow は「YOZAN GOLF BUSINESS SYSTEMS」、metadata から GOLF WING 固有文言を除去。
  **(d) UI刷新はトークンだけで実施** — globals.css の @theme を indigo 系→**白基調×深緑#14452f×金#a9853b**（LP・AI店長・販促物と同一ブランドトーン）へ。背景radialを緑＋金の2灯に、.hud のホバー影を緑系に、ヘッダー下に金のヘアライン（header.topbar::after）。**コンポーネント側のクラスは未変更**＝全画面が一括で変わる（genesis-font-scale と同じ「1か所で全画面」方式）。
  検証: 変更6ファイル構文OK。ビルドはCI（member-os はマトリクスに含まれる）。

- #152 (2026-08-24) **会員ポータルにログイン済みなら、公式サイトの予約ページで会員番号を聞き直さない**（migrationなし・`packages/core/src/frank-handoff.ts`）。ユーザー指摘「会員ログインページからログインして予約したら、ウェブサイトでまた会員番号とパスワードを入力する必要があるのはおかしいですよね」（スクショ4枚）。member-os で `FR0002 古川様` としてログインしている状態で「＋ Web予約する」を押すと、遷移先の `frankgolf.jp/booking.html` が **会員番号＋電話番号下4桁を最初から要求**していた。
  **(a) 原因は「入口の一本化」の副作用** — #93 でお客様の予約を公式サイト1か所に集約したが、member-os（Vercel別プロジェクト・別ドメイン・cookieは `mos_member`）と公式サイト（静的HTML＋公開API）の間に**ログイン状態を渡す手段が無かった**。ドメインが違うので cookie は共有できない。
  **(b) 対策は署名付きの引き渡しトークン（ステートレス）** — 「この会員としてログイン済み」という事実だけを HMAC-SHA256 で署名し、`booking.html?t=…` で渡す。鍵は両アプリが必ず持っている `SUPABASE_SERVICE_ROLE_KEY` から派生（`FRANK_HANDOFF_SECRET` を置けばそちらが優先＝鍵の入れ替えが可能）。**引き換え表をDBに作らない**ので migration もクリーンアップ用cronも要らない。中身は**会員番号と期限だけ**で、電話番号などの個人情報は載せない。
  **(c) URLに残さない** — 受け取った booking.html は読み取り直後に `history.replaceState` でクエリからトークンを削り、`sessionStorage` にだけ持つ。URLに残すと共有・履歴・Referer に載る。有効期限は6時間、切れたら**従来の入力フォームに戻るだけ**（予約ページが使えなくなることはない）。鍵未設定でもトークンを付けないだけで同じくフォールバックする。
  **(d) 認証の入口を1本にまとめた** — genesis 側は `authMember(admin, {memberNo, phoneLast4, token})` を新設し、打席予約・レッスン予約・月会費のカード登録の3経路すべてがここを通る。トークンがあれば `verifyMemberByHandoff`、無ければ従来の `verifyMember`。**トークンで出来ることは「その会員として予約する」だけ**で、管理操作には一切使えない。`GET ?me=1&t=` を足して、ページ側が「◯◯様としてご予約いただけます」と名前を出せるようにした（入力欄はまるごと隠れる）。
  **(e) レッスン予約ページにも同じ仕組みを入れた** — booking.html から `lesson-booking.html` へのリンクがあり、そこで再入力を求めたら同じ不満が再発するため。両ページは `sessionStorage` の `fg_t` を共有する。
  **(f) ついでに直した表記** — 予約ページ・レッスン予約ページ・会員ログインの会員番号の例が `F0001` だったが、実際に発行しているのは `FR0002` のような **FR** 始まりだった（スクショで発覚）。3か所とも `FR0001` に修正。
  検証: genesis / member-os とも tsc クリーン、`tests/frank-handoff.test.ts`（改ざん・鍵違い・期限切れ・壊れた入力）を追加してテスト381件通過。

- #153 (2026-08-26) **Lesson OS 撮影: カウントダウンを選べるようにし、iOSで撮影直後のプレビューが再生も表示もされない不具合を直した**（migrationなし）。ユーザー指摘「3秒カウントをなくしてください、もしくは0カウントの設定に切り替えれるようにしてください」「動画撮影後にこの動画を登録するというページの動画が再生されないし表示されないので確認できない」（端末＝iPhone/iPad）。
  **(a) カウントは 0秒／3秒 の選択式・既定は0秒** — #143 で入れた3秒固定は「スマホを置いてから構えに戻る」一人撮り前提。実際は人に押してもらう・自分で押してすぐ打つ場面が多く、そのぶん毎回3秒の無駄玉になっていた。秒数（5/8/12）の隣に【カウント なし／3秒】を並べ、**選択は localStorage に記憶**（`lsn.rec.countdown` / 秒数も `lsn.rec.limit`）。0秒＝押した瞬間に `mr.start()`。撮影モジュールはクリック後にマウントされるので SSR とのハイドレーション不一致は起きない。
  **(b) 再生できなかった原因は Blob の type に codecs が付いていたこと** — `MediaRecorder.isTypeSupported` に通した文字列（`video/mp4;codecs=avc1.42E01E,mp4a.40.2`）をそのまま `new Blob(chunks, {type})` に渡していた。**iOS Safari は codecs パラメータ付きの type を持つ blob: URL をメディアとして読み込めない**ため、`<video>` が黙って何も出さない（onerror も飛ばない）。`baseMime()` で `;` 以降を落として **素の `video/mp4` / `video/webm`** にした。
  **(c) 同じ文字列が Storage の Content-Type にも入っていた** — karte-client の PUT が `blob.type` をそのまま送っており、本番の既存動画1本が `video/mp4;codecs=avc1.42e01e,mp4a.40.2` で保存されていた（＝**一覧からの再生も iOS では出ない**）。アップロード側も `;` 以降を落とすように修正し、**本番の storage.objects の mimetype も `video/mp4` に更新済**（lesson-videos バケット・1件）。
  **(d) 「何も映らないまま登録する」を構造的に無くした** — 端末やコーデックは今後も想定外があるので三段構えにした。①プレビュー枠を**固定高さ**にする（メタデータ未取得で高さ0に潰れて「表示されない」のを防ぐ）→ ②onerror または3.5秒経っても `readyState<2` なら **data: URL で再試行**（12MB以下のときだけ＝端末メモリ対策）→ ③それも駄目なら**1コマ目の静止画**と「登録すれば一覧から再生できます」の説明を出す。
  **(e) サムネイルは撮影直後に1回だけ作る** — ③のために `capturePoster` を撮影モジュール側で呼ぶので、その Blob を `Captured.poster` で karte-client に渡し、登録時の作り直しをやめた（#143 の poster_path の流れは不変）。
  **(f) MediaRecorder の webm は duration が Infinity になる**ことがありシークバーが効かないので、`loadedmetadata` で一度末尾へシークしてから 0 に戻す定番の回避を入れた。
  検証: lesson-os の tsc クリーン。⚠ 実機（iPhone）での確認は要お願い。

- #154 (2026-08-26) **FRANK 会員ポータル（my.frankgolf.jp）＋QRチェックイン＋モバイルオーダー**（migration 0123・**本番適用済み 2026-08-26／MCP**・メニュー24品投入済み）。構想の正典は `docs/modules/frank/MEMBER_PORTAL_構想.md`。
  きっかけ＝ユーザー「入会したらQRを発行して、来店時に受付のリーダーで読み取ってチェックインしたい。**狙いはチェックインそのものではなく、来店したらスマホを開く習慣をつくること**（開いたついでにドリンク注文・レッスンコメント確認ができる）」。
  **(a) 親はポータル、子がチェックインとモバイルオーダー** — 依頼はチェックイン単体だったが、狙いが習慣化なので「開いた先に何があるか」を先に決めないと、かざすだけの作業で終わる。
  お客様の入口は `my.frankgolf.jp` 1本。今は 予約=frankgolf.jp/booking.html・カルテ=lesson-os.vercel.app・会員情報=member-os `/member` と**3ドメインに割れている**のが習慣化の最大の敵。
  ハブは新規に作らず **既存の `/member` を育てた**（会員番号＋電話下4桁・60日セッション・#152の署名トークン持ち回りが既にある）。ホームは ①会員証QR ②予約 ③カルテ ④注文（来店中のみ）⑤公式LINE ⑥設定。**来店履歴は載せない**（ユーザー判断・「これからのご予約」は予定なので残す）。
  **(b) QRは固定式。ただし中身を会員番号にしない** — ユーザー判断で回転式（TOTP）は不採用（スクショ悪用は稀という読み）。ただし自動決済を入れる以上、なりすましの被害額が0円ではなくなる。
  そこで **①`frunk_members.checkin_token`＝推測不能な16桁**（`FR0001` は連番なので他人がQRを自作できる）**②QRでできるのはチェックインだけ・注文はポータルのログインセッションから**、の2点で被害を「他人に自分の名前でチェックインされる」だけに封じた。設定画面から**再発行**できる。
  トークンをハッシュではなく生で持つのは、**毎回QRとして描画し直す必要がある**ため（`res_member_sessions` のような使い捨てとは性質が違う）。そのぶん権限を最小にしてある。
  **(c) 文字種は「数字＋英大文字のみ」（0/O・1/I/L を除く31文字）** — 受付のリーダー **Tera 9200 は USB HIDキーボードで、既定がUS配列**。記号や小文字を混ぜると日本語配列のPCで化ける。この一点で文字種が決まった。仮想COM（Web Serial）に切り替えても同じく安全。
  **(d) 受け口を1本にした（仮想COMは"差し込み口だけ"用意）** — 読み取りは全部 `POST /checkin/api {action:"scan"}` → `checkInByToken()` に合流する。将来リーダーを仮想COMに替えても、同じPOSTに文字列を渡すだけ＝画面・DB・業務ロジックは1行も変えない。実機が未着で説明書も無いので、**両対応の実装はしない**（届いてから設定バーコードを見て判断すれば足りる）。
  `normalizeCheckinScan()` で「自社トークンの形でなければ黙って捨てる」。卓上リーダーは目の前のものを何でも読むので、これが無いと商品バーコードのたびにDBを引く。
  **(e) 受付PCとの兼用は不可と結論** — 「チェックイン用PCは他の作業に使わない」というキオスク運用は初版で書いたが**撤回した**（ユーザー指摘「メール確認や予約確認はしたい」）。運用ルールは破れるうえ、セルフでかざす＝**画面が客側を向く＝スタッフのメールや他のお客様の情報が丸見え**になる。
  → **チェックインPC（客側向き・Tera 9200）と 受付iPad（スタッフ側・Square＋電子伝票）を分ける**。これで運用ルール自体が要らなくなる。Tera 9200 はUSB有線なのでiPad兼用も物理的に無理。
  **(f) 打席QRは会員/ビジターで分けない1本のURL** — ユーザー懸念「会員が間違えてビジター用QRを読んでしまう」。**分けなければ起きない**。`/bay/<code>` を開いた瞬間のログイン状態で自動分岐する：
  ログイン済み会員→いつものポータル（`/member/order?bay=`）が打席セット済みで開き会員価格＋登録カードで決済／未ログイン→その場でビジター注文（登録不要・未決済で伝票に溜まる）。
  未ログインの会員は「**会員価格になります**」で誘導する（値段が違うので実利が一番効く）。保険として伝票側に**会員へ紐付け直す**操作を用意（会員価格に引き直し＋カードへ付替え。未決済の伝票にだけ効く）。
  会員が打席QRを読んだのに未チェックインなら、その場でチェックインも済ませる（source='bay'・**実際に読んだ打席を正**とする）。
  **(g) 会計は「注文＝即決済」** — ユーザー判断。`square_customer_id` があれば `GET /cards` → `POST /payments` で保存カードに即時課金（手数料は対面2.5%に対し3.6〜3.75%だが、500円で差6円）。
  **idempotency_key に注文IDを使う**（既存の `chargeCardOnFile` は randomUUID なのでリトライで二重課金になりうる。新しい `chargeOrderOnFile` は同じ注文なら何度呼んでも1回）。
  **カード未保存・決済失敗でも注文は止めない**。`payment_status='failed'|'unpaid'` として伝票に出し、退店時にレジで会計する＝**お客様の前で失敗させない**。「退店時にスタッフが声をかけてまとめて引き落とす」案は不採用（毎回の声かけと操作が残り、未収も出るため）。
  ⚠ **利用規約と入会フォームに「登録カードからの自動決済」の同意条項が要る**（ユーザー確認事項・9/2前）。
  **(h) 口頭注文は明細を継ぎ足さず、伝票を1枚立てる** — 会員の注文は1件ごとにカード決済が走っているので、後から明細だけ増やすと「決済済みの金額」と「伝票合計」がずれる。**1注文=1決済**を崩さない。画面は打席でグループ化しているのでスタッフの体感は「追加」のまま。
  **(i) Money OS への計上** — Square Webhook に `tryRecordMobileOrder` を追加。note が `FRANKオーダー#0826-014` の形なら伝票を引いて **category='店内飲食'＋品目の内訳つき**で記帳する。これが無いと全部 `category='利用料'` に丸められ、ドリンクの売上が分からない（カタログのitem/variation IDはDBに無いので、メニューは `frunk_menu_items` を自前の正典にした）。
  **(j) 声かけカード** — チェックインの瞬間、受付画面にスタッフ向けで1〜3行出す（「3回目のご来店です」「前回から21日空いています」「今月がお誕生月です」「本日レッスン 14:00〜 安東コーチ」「⚠重要説明事項」「未収」）。**退会予防に一番効くのは名前を呼んで一言かけること**で、それを毎回お膳立てする。材料集めはアプリ、判断は `greetingLines()`（純関数・テスト済）。
  受付画面に出すのは **氏名・プラン・打席・声かけまで**。客側を向いているので生年月日・住所は出さない。結果は8秒で待機画面に戻す（次のお客様に前の人の名前を見せない）。
  **(k) 手動チェックインは必ず残す** — スマホ忘れ・ログイン不能・リーダー故障。無いと受付が止まる。会員証の16桁は画面にも出しているので、最悪スタッフが読んで打てる（0/O・1/I/L を抜いたのはこのため）。
  検証: `tests/frank-portal.test.ts` 15件追加（トークンの文字種／形式違いを捨てる／会員価格の切替／明細は注文時点の値を保持／声かけの優先順位と3行上限）でテスト399件中398件通過。
  ⚠ 残る1件 `reserve-bookable.test.ts` は **今回の変更と無関係**（"2026-08-26 11:00" を固定で bookable と期待する時刻依存テストで、当日の11時を過ぎると落ちる）。
  構文チェックは全新規/変更ファイルOK。**型はVercelのビルドで確認**（サンドボックスのesbuild/tscはWindows版バイナリのため動かない）。

- #155 (2026-08-26) **会員ポータルの仕上げ: ホーム画面に追加（PWA）・自動チェックアウト・打席QR印刷・セッション1年化＋#154の店舗解決バグ修正**（migrationなし）。#154に続けて同日実施。
  **(a) ⚠ #154のバグを修正: store_id に company_id が入りうる** — `frunk_members.store_id` は古い行で null のことがあり、フォールバックで **company_id を store_id に流用**していた（`resolveFrankStoreId` と `member/order/actions.ts`）。
  そのまま動くと `frunk_checkins` / `frunk_orders` に**別店舗の行として残る**（[[store-scope-lockdown]] の店舗またぎと同じ事故）。`frankStore()` に一本化し、引けなければチェックインを失敗させる（黙って変な行を作らない）。
  **(b) ホーム画面に追加（PWA）** — 構想 §3-4 の3条件の最後。「来店したらスマホを開く」を狙う以上、ブックマークではなく**アイコン**でないと習慣にならない。
  `app/manifest.ts`（start_url=`/member`・scope=`/`＝打席QRから開いてもアプリ内に留まる）＋ apple-touch-icon（iOSは manifest の icons を見ない）＋ theme_color。
  アイコンは暫定（深緑に金の「F」）。**ロゴ画像をもらったら差し替える。**
  案内は `AddToHome`（すでに standalone なら出さない／閉じたら localStorage に覚えて二度と出さない／iOSは共有ボタン経由の文言に切り替え）。
  **(c) 会員セッションを 60日 → 1年、使っていれば自動延長** — 来るたびにログインを求めたら習慣にならない。短くしても安全は増えない（cookieはhttpOnly/secure・退会/却下は照合時に即無効化）。
  残り180日を切ったときだけ書き込む＝**最大でも半年に1回**。⚠ **Next.js はサーバーコンポーネントの描画中に cookie を書けない**ので try/catch で握り、Route Handler（滞在中ずっと叩いている `/member/visit`）で必ず揃うようにした。
  **(d) 自動チェックアウト** — 予約終了+30分を過ぎたら来店中モードを閉じる。**DBに書かずに判定だけで閉じる**（閉じるためのcronを増やしたくない）。スタッフが伝票から「退店」を押したときだけ `checked_out_at` が入り、滞在時間が確定する。
  **(e) 打席QRの印刷シート `/orders/qr`** — 打席1つにつき1枚。**URLは既定でその画面を開いているホストから作る**ので、`my.frankgolf.jp` のDNSが未設定でもそのまま使える（独自ドメインが通ったら `NEXT_PUBLIC_PORTAL_URL` を入れて刷り直す）。
  本番の打席コードは `bay-a` / `bay-b` / `bay-c` の3つ（`bay-d` は未設営で active=false）。**0081のシード値 `bay-1f-l` 等は現状と違う**ので、コード直書きはしない。
  **(f) 電子伝票にタブ見出しの未提供件数** — 「(2) 電子伝票」。iPad Safari は**一度タップしないと音を鳴らせない**ので、音をONにしていない／別タブを見ているときの保険。
  LINEへのスタッフ通知は**今回は入れていない**（member-os から公式LINEを直接叩く配線が無く、`gn_line_outbox` は #102 以降 n8n が拾わない。10分毎cronの `ai_action_queue` では注文通知には遅い）。iPadの10秒ポーリング＋音＋タブ見出しで足りるか、運用して判断する。
  **(g) 規約の同意条項の文案** — `docs/modules/frank/規約_モバイルオーダー同意条項_案.md`（会員規約の条項／入会フォームのチェックボックス／既存会員への周知文／店頭掲示／確認事項）。
  **決済の同意は月会費・規約への同意と分けてチェックボックスを立てる**（まとめると「同意を取った」と言いにくくなる）。周知から開始まで数日〜1週間あける。
  検証: テスト399件中398件通過（残1件 `reserve-bookable.test.ts` は #154 と同じ時刻依存の既存不備）。構文チェック全件OK。型はVercelのビルドで確認。

- #156 (2026-08-26) **会員ポータルの運用まわり: 注文の二度押し防止・メニュー管理・会員カードの来店・レッスンカルテの新着バッジ**（migration 0124・**本番適用済み 2026-08-26／MCP**）。#154 #155 の続き。
  **(a) ⚠ 注文ボタンの二度押しを止めた** — 会員の注文は**その場でカードに課金が走る**ので、連打すると**注文も決済も2件**できる。
  Squareの `idempotency_key` は注文IDごとなので、注文が2件になれば別々に通ってしまう＝冪等キーでは守れない。`useFormStatus` の `pending` でボタンを塞ぐ。
  **(b) メニュー管理 `/orders/menu`** — 売り切れトグル・価格（一般/会員）・メニューからの出し入れ。
  「売切は第一弾は手動トグル」と決めていたのに**切り替えるUIが無かった**ので追加した（Inventory OS 連動は必要になってから）。
  行は消さず `active` で出し入れする＝過去の伝票の `menu_item_id` を壊さない。
  ⚠ **価格はSquareのカタログ（`scripts/frank-square-setup.mjs`）と同じ値に保つこと。** 片方だけ直すと店頭レジとスマホ注文で金額がズレる。画面上にも警告を出してある。
  価格変更が効くのは**これから注文される分だけ**（`frunk_order_items` に注文時点の単価をコピーしているため）。
  **(c) 会員カード `/frunk/<id>` に「来店」** — 今月/通算の来店回数・前回来店（**14日以上空いていたら黄色**）・直近12件の履歴（打席・手動/打席QRの別）。
  予約の一覧とは別に置いた。予約が無くても来た日が入るのが `frunk_checkins` で、**退会予兆を見るのはこちら**。
  **(d) レッスンカルテの新着バッジ（migration 0124 `frunk_members.karte_seen_at`）** — Lesson OS が機能完成していたのに稼働ゼロだった最大の理由は**「書いても生徒に届かない」**こと（[[lesson-os-status]]）。
  ポータルができたので、動画かコメントが `karte_seen_at` より後に増えていたらホームのカルテボタンを金地＋「新着」にする。**一度も開いていない人は動画が1本でもあれば新着扱い**（最初の1回を必ず届ける）。
  リンク先を `/member/karte`（Route Handler）にしたのは、①既読を記録してから飛ばす ②**共有トークンをホームのHTMLに埋めない**（押した人にだけ渡す）の2点。
  **(e) ダッシュボードの来店KPIは見送った** — チェックインは9/2から貯まり始めるので、今タイルを置いても0が並ぶだけ。
  「0.0%＝未取得」を実績と誤読させた過去（[[report-os-churn-and-staff]]）と同じ罠になる。**データが1か月貯まってから**入れる。
  検証: テスト399件中398件通過（残1件は #154 と同じ時刻依存の既存不備）。構文チェック全件OK。

- #157 (2026-08-26) **リリース後の点検: 本番スモークテスト・時限爆弾テストの解体・会員証トークンの先行発行**（migrationなし・DB更新はMCPで実施済み）。
  **(a) 本番確認** — #154〜#156 のデプロイは member-os / yozan-genesis とも READY（型チェックはVercelビルドで通過）。`/bay/bay-a` を本番で開き、見出し・会員ログイン誘導・メニュー24品（3カテゴリ・±ボタン）の表示を確認した。
  **(b) ⚠ 発見: 保存カードを持つ会員が現時点で0名** — `square_customer_id` が入っている有効会員がいない（月会費のSquare本番課金がまだ動いていないため）。
  つまり**モバイルオーダーの自動決済は、今は誰に対しても発動せず、全員「退店時会計」フォールバックになる**。壊れているのではなく設計どおりの縮退だが、
  「注文＝即決済」を本当に動かすには **A-00のSquare本番切替（sk_live差替え＋実カードテスト）が前提**であることが確定した。テストの順番は 月会費の実カード1件 → その会員でモバイルオーダー1品。
  **(c) 時限爆弾テストを解体** — `reserve-bookable.test.ts` の `isBookable` テストが基準日を渡しておらず「今日」に依存＝**2026-08-26 11:00を過ぎた瞬間から毎回落ちる**状態だった（#154のリリース日にCIが赤くなる）。
  `isBookable` に `from`（既定=今日＝本番挙動は不変）を追加し、テストは基準日を固定して渡す。399件全通過に復帰。
  **(d) 会員証トークンの先行発行** — 有効会員4名（F0001/FR0002/FR0003/FR0004）に `checkin_token` をMCPで発行済み。
  本来はポータルを開いた時に自動発行されるが、**9/2前のスタッフテスト（/checkin に16桁を手打ち）を会員のログインを待たずにできる**ようにした。トークン原文はDBのみ（このログには残さない）。

- #158 (2026-08-26) **ユーザー作業の代行: Vercelドメイン追加・規約への同意条項の組込・レジ商品の価格確定**（migrationなし）。ユーザー指示「ユーザー作業も可能な限りあなたが行って」。
  **(a) ✅ `my.frankgolf.jp` を Vercel(member-os) に追加済み** — ダッシュボードの認証済みセッションから API で追加（モーダルUIはPOSTが飛かない不具合があり断念）。Production 環境に紐付け済み。
  残るは **DNS だけ**: frankgolf.jp のネームサーバーは dnsv.jp（お名前.com）。`my` の CNAME → `cname.vercel-dns.com` を1本足せば開通する。
  **(b) ⛔ お名前.com へのログインと Vercel の SQUARE_ACCESS_TOKEN の取り出しは、セキュリティ制約（パスワード/シークレットの取り扱い）でブロックされた。回避はしない。**
  DNSレコード追加はユーザー作業（1分）。レジ商品の実投入は `scripts/frank-square-setup.mjs` の再実行（ユーザーの既存フロー・冪等）。
  **(c) 会員規約に「第9条（会員ポータル・モバイルオーダー）」を追加** — member-os の `frank-terms.ts`（入会フォームに出る全文）と、公式サイト `_build.py` の terms.html の**両方**（片方だけ直すとフォームとサイトで規約が食い違う）。旧9条・10条は10条・11条へ繰り下げ。特商法（tokushoho.html）の支払時期にもモバイルオーダーを追記。
  **(d) 入会フォームに独立の同意チェックボックス `consent_mobile_order`** — 規約同意とまとめない（まとめると「決済の同意を取った」と言いにくくなる・規約_モバイルオーダー同意条項_案 §2）。サーバー側 actions.ts でも必須検証。
  ⚠ 既存会員4名にはこの同意が無い＝**モバイルオーダー公開前に周知文（同案 §3）を送り、異議のないことをもって同意扱いにするか、来店時に一言確認する**運用が要る。
  **(e) レジ商品の価格をユーザーが確定** — ビジター利用料 ¥5,500／レッスン単発(25分) ¥2,500／体験レッスン ¥3,300（キャンペーン中はレジで0円に変更して打つ）。`frank-square-setup.mjs` の FEE_ITEMS に追記済み（物販は後日リストが来たら追加）。
  **(f) `NEXT_PUBLIC_PORTAL_URL` はまだ設定しない** — DNSが通る前に設定すると `/orders/qr` が死んだURLのQRを刷れてしまう。**DNS開通を確認してから**入れる。

- #159 (2026-08-26) **レジ商品の投入を運用ワンショットAPIにした（`/api/public/frank/admin/square-catalog-sync`）**（migrationなし）。
  きっかけ＝ユーザー「SQUARE_ACCESS_TOKEN を保存していなかった」。
  **(a) トークンは失われていない** — Vercel(yozan-genesis)の env に type=`encrypted` で存在する（`sensitive` ではないのでダッシュボードで値を表示できる）。
  同じ env は member-os にも必要（[[frank-billing-stripe]] / OPERATIONS §14-1 の注記）。**Vault には未保存だったので、表示して Vault「スクエア」に控えること。**
  **(b) それでもローカル実行はやめた** — `scripts/frank-square-setup.mjs` を回すには誰かがトークンを手元にコピーする必要があり、その一手間とコピーが端末に残るリスクが毎回ついてくる。
  **#136 の `square-plan-sync` が同じ問題を「本番環境自身に作らせる」で既に解いていた**ので、レジ商品版を同じ形で足した（同じ認証・同じ冪等判定）。以後、商品を足すときもトークンを触らなくてよい。
  **(c) 冪等は「商品名が既にあればスキップ」**（setup.mjs と同一）。何度叩いても増えない。カテゴリ未対応の古いAPIバージョン向けフォールバックも同じものを入れた。
  ⚠ **品目と価格の正典は `scripts/frank-square-setup.mjs` の FEE_ITEMS。** このAPIは同じ値の写しなので、**片方だけ直さないこと**（route.ts のコメントにも明記）。
  認証は `gn_ops_tokens`（purpose=`frank_square_catalog_sync`・期限内・sha256）。登録できるのは service_role を持つ運用者だけ。

- #159b (2026-08-26) **レジ商品を本番投入・公式LINEのURLを設定**（コード変更なし・運用記録）。
  **(a) レジ商品3件を投入済み** — `POST /api/public/frank/admin/square-catalog-sync`（#159）を実行。
  結果: ビジター利用料5,500 / 体験レッスン3,300 / レッスン単発(25分)2,500 を**新規作成**、入会金・休会費は**既存のためスキップ**（冪等が意図どおり効いた）。
  **誰も SQUARE_ACCESS_TOKEN を手元にコピーしていない**。使ったワンショットトークンは実行後すぐ失効させた（`gn_ops_tokens.expires_at` を過去に更新）。
  **(b) 公式LINE** — 友だち追加URL `https://lin.ee/Xl0L2k7` を member-os の env `NEXT_PUBLIC_FRANK_LINE_URL` に設定し再デプロイ。ポータルに公式LINEボタンが出るようになった。
  **(c) Vault を更新** — 「スクエア」に今回の追記（**SQUARE_ACCESS_TOKEN は Vercel env が正・type=encryptedなので表示可能／LOCATION_ID と WEBHOOK_SIGNATURE_KEY は sensitive で表示不可**）、および新規レコード「FRANK 会員ポータル（お客様用）」を追加（URL・画面一覧・env・価格の同期注意）。

- #160 (2026-08-26) **重複会員 FR0004 を FR0002 に統合**（コード変更なし・MCPで実施）。ユーザー確認「両方僕なのでFR0002だけ残して消してOK」。
  **(a) 物理削除ではなく論理削除**（`deleted_at` ＋ `status='left'`）。この台帳の作法で、集計から外れて履歴は残る。`note` に統合の経緯を書いた。
  **(b) ⚠ 消す前に気づいたこと: レッスンカルテの実データが「消す側」FR0004 にぶら下がっていた** — 動画1・コメント1・計測1・進捗9件・共有トークン1。FR0002側は空だった。
  そのまま消していたら **Lesson OS にある唯一の実データを失っていた**（[[lesson-os-status]] の「動画2本」がこれ）。
  `lsn_videos` / `lsn_measurements` / `lsn_progress` / `lsn_share_tokens` の `student_id` を FR0002 の生徒へ付け替えてから、空になった FR0004 の生徒カルテを論理削除した。
  **教訓: 会員を消す前に、必ず lsn_* のぶら下がりを数える。** 予約・来店・注文がゼロでもカルテは残っていることがある。
  **(c) 在籍会員数** — FR0004 を落としたが、同時刻に小川さんのテスト会員 FR0005 が増えたため 4 のまま（数字だけ見て「消えていない」と誤読しないこと）。

- #161 (2026-08-26) **⚠ 本番バグ修正: Square の idempotency_key が45文字を超え、モバイルオーダーの決済が1件も通っていなかった**。
  小川さんの実機テスト（FR0005・A打席・コーヒー300円）で発覚。`frunk_orders.payment_error` に
  `Field must not be greater than 45 length` が残っていた。
  **原因**: #154 で入れた `` `frank-order-${orderId}` `` が **12 + UUID36 = 48文字**。Square Payments API の `idempotency_key` 上限は **45文字**。
  400 が返るので `chargeOrderOnFile` は必ず失敗し、**全注文が「未決済（退店時会計）」にフォールバックしていた**。
  設計どおり注文自体は止まらなかったので画面上は正常に見え、**DBの payment_error を見るまで誰も気づけなかった**。
  **修正**: 接頭辞を `fo-` にして39文字に収め、組み立てを `packages/core` の `squareOrderIdempotencyKey()` に集約。
  **長さをテストで固定**（`tests/frank-portal.test.ts`・401件全通過）。今後 idempotency_key に接頭辞を足すときは必ずこの関数を通すこと。
  **教訓**: 「注文を止めない」フォールバックは正しいが、**失敗が画面に出ない分、決済の疎通は必ず実データで確認する**必要がある。

- #162 (2026-08-27) **受付リーダーの読み取りを「Enter待ち」から「打ち終わり検知」に変え、設置用の診断モードを付けた**（migrationなし）。
  きっかけ＝ユーザー「QRコードリーダを接続しました テストします」。実機テストの前に、**沈黙したときに切り分けられない**ことに気づいた。
  **(a) 元の作りの弱点** — 隠し入力欄にフォーカスを当て、`Enter` が来たら送る形だった。これは2つの理由で**同じ「何も起きない」画面になる**:
  ① リーダーの Suffix=Enter が未設定（Tera 9200 は初期状態で設定されていない個体がある）、② 何かの拍子にフォーカスが外れている。
  現場では「リーダーが壊れている」「QRが悪い」「システムが動いていない」と区別がつかない。プレオープン当日にこれをやると受付が止まる。
  **(b) window の keydown を直接拾う形にした** — フォーカスが入力欄から外れていても拾える。
  さらに **最後の1文字から140ms 静かなら Enter が来なくても送る**（`SCAN_IDLE_MS`）。HIDリーダーは1文字を数ミリ秒で打つので、140ms空けば打ち終わり。
  **＝リーダーの Suffix 設定に関係なく動く**。設定済みなら Enter 側が先に飛ぶだけで、挙動は変わらない。
  **(c) `/checkin?debug=1` に診断表示** — 読み取った生の文字列・文字数・所要ms・Enterの有無・却下理由を画面下に出す。
  `?debug=1` のときだけ出す（この画面はお客様側を向いているため）。切り分けが1回のスキャンで終わる:
  「1文字も出ない」＝リーダーがPCに認識されていない／「文字は出るが化けている」＝キーボード配列／「16文字ちょうどで notfound」＝別環境のQR。
  **(d) トークンの定義を `packages/core/src/frank-token.ts` に切り出した** — 診断表示はクライアント側で「会員証の形か」を判定する必要があるが、
  `frank-portal.ts` は `node:crypto` を読むのでブラウザに持ち込めない。**画面側に文字集合をコピーすると、片方だけ直したときに診断表示だけが嘘をつく**ので、
  node非依存の部分（文字集合・長さ・形の判定）だけを別ファイルにし、`frank-portal.ts` はそこから読んで再エクスポートする。食い違いはテストで固定（404件全通過）。
  **教訓**: 「黙って捨てる」は運用中は正しいが、**設置初日は黙ってはいけない**。捨てた理由を見る口を必ず1つ用意する。

- #163 (2026-08-27) **予約が無いチェックインが「日付が変わるまで来店中」だった穴を塞いだ**（migrationなし）。
  きっかけ＝ユーザー「チェックインした後にいつチェックアウトされますか？」。答えを確認する過程で見つけた。
  **(a) 来店の終わり方は3通りあり、それぞれ意味が違う** — ここを混同しないこと。
  ① スタッフが電子伝票の「退店」を押す → **DBに `checked_out_at` が入る唯一の経路**（滞在時間が取れるのはこれだけ）
  ② 判定で閉じる → お客様のスマホの「来店中モード」が終わるだけ。**DBには何も書かない**（閉じるためだけに cron を増やしたくないため）
  ③ 日付が変わる → `visited_on = 今日` で引いているので翌日は必ず来店中ではない
  **(b) ②が予約のある人にしか効いていなかった** — 判定は「予約終了+30分」だけで、ビジター・飛び込みは `end_time` が無いので**その日いっぱい来店中のまま**だった。
  帰宅後もスマホに打席が出続け、**店外から注文画面を開ける**（提供されない注文が立つ）。
  **(c) 予約が無い場合は「チェックイン+2時間」で閉じる**ようにした（`VISIT_NO_BOOKING_MIN`）。打席枠が1時間なので延長1回ぶんを見た値。
  **(d) 判定を `visitClosed()` に切り出してテストで固定**（409件全通過）。
  ⚠ **時刻がどちらも取れないときは「閉じない」**を明示的に選んでいる。誤って閉じると**打席にいるお客様が注文できなくなり、しかも誰も気づけない**（#161 と同じ壊れ方）。迷ったら開けておく。
  **(e) 運用**: 「退店」を押さないと `checked_out_at` が永久に null。今すぐ困らないが**滞在時間は後から遡れない**ので、押す運用を決めておくこと。

- #164 (2026-08-27) **退店ボタンを押す場所が無かった**（migrationなし）。ユーザー「退店ボタンを押すとこが見つからないです」。
  **(a) 原因** — 退店ボタンは**打席カードの中**にしか無く、`bay_id` が入っている来店にしか表示されなかった。
  予約なしで来た会員は打席が決まらないままチェックインされる（`booking_id` が無いので自動割当が働かない）ので、
  **打席なしの来店＝退店を押す場所がどこにも無い**。実際に本番でこの状態になっていた（FR0002・8/27 18:31・source=qr）。
  **(b) 「来店中」の帯を伝票の一番上に置いた** — 打席の有無に関わらず、来店中の人が必ず1行ずつ出る。
  各行に 名前／会員番号／チェックイン時刻／打席（未設定なら打席を選ぶボタン）／**退店** を並べた。
  **(c) 打席カード内の小さい退店ボタンは外した** — 同じ操作の入口を2か所に置くと、どちらを押せばいいか迷う。
  カードには「誰がいるか」の表示だけ残した。**退店を押す場所は1か所**と決める。
  **(d) 伝票からも打席を割り当てられるようにした**（`assignSeatBay`）。
  受付チェックイン画面でも選べるが、あちらは**お客様側を向いた画面**で、お客様が待っている前での操作になる。
  **教訓**: 「押し忘れても自動で閉じる」を先に作ったせいで、**押す場所が無いこと自体に気づけなかった**。
  自動フォールバックがあるUIは、手動の入口が生きているかを別に確かめる必要がある（#161 と同じ構図）。

- #165 (2026-08-27) **⚠ 本番デプロイが5本連続で失敗していた: `packages/core` の拡張子つき相対 import**（コード変更なし・tsconfigのみ）。
  ユーザーが `/orders` を見て「退店ボタンが無い」と報告。**押す場所が無いのではなく、#164 が本番に出ていなかった**。
  **(a) 症状** — `git push` は通るが Vercel が ERROR。本番は `bf5fe8d`（#162より前）を配信し続けていた。**サイトは落ちない**ので気づきにくい。
  ```
  Type error: An import path can only end with a '.ts' extension
  when 'allowImportingTsExtensions' is enabled.
    packages/core/src/frank-booking.ts:14  import { isJpHoliday } from "./jp-holidays.ts";
  ```
  **(b) 原因** — `packages/core` の中で相対 import に `.ts` を付けると、**それを読む全アプリの型チェックが落ちる**。
  `apps/shift-cloud` と `apps/swing-cortex` だけ `allowImportingTsExtensions: true` が入っていたので、
  リポジトリ内に前例があり「この書き方でよい」と誤認した。**core は全アプリが読む＝一番厳しいtsconfigに合わせる必要がある**。
  同じ形の import が #162（`./frank-token.ts`）と祝日判定（`./jp-holidays.ts`）で**別々に同時に入った**。
  **(c) 対応** — `noEmit: true` を持つ全12アプリの tsconfig に `allowImportingTsExtensions: true` を追加（既存2アプリと同じ設定に揃えた）。
  拡張子を外す案は採らなかった。**`node --test` は拡張子なしの相対 import を解決できず、テストが動かなくなる**ため（両方を満たすのはこちら側）。
  **(d) 教訓 ①** — `packages/core` を触ったら、**core を読むアプリのどれか1つで型チェックが通ることを確認するまで完了ではない**。テストが全通過しても型は別。
  **(e) 教訓 ② これが一番重い** — **push した後、Vercel が READY になったことを確認していなかった**。
  ERROR でも本番は古い版を配信し続けるので、画面は「普通に動いている」ように見える。#161（決済が全件失敗しても画面は正常）と同じ壊れ方を、今度はデプロイで踏んだ。
  **以後、push を依頼したら必ずデプロイの状態まで見に行くこと。**

- #166 (2026-08-27) **モバイルオーダーを内税から外税に変えた（メニュー価格＝税抜の本体価格）**（migration 0127・適用済）。
  ユーザー指定「商品価格が300円（内税になっています）ので、300円＋消費税にしてください」。
  **(a) 数値の意味が変わった** — `frunk_menu_items.price_general/price_member` は **税抜の本体価格**。
  以前はこれを税込として扱い、そのまま Square に請求していた。**同じ列の意味が変わっているので、価格を触るときは必ずこの前提を確認すること。**
  コーヒー会員価格300円 → 請求は **330円**（300 + 消費税30）。
  **(b) 税率は10%** — 打席へお持ちする＝**店内飲食**。軽減税率8%は持ち帰りの扱いなので使わない。
  持ち帰り販売を始めるときは、税率を品目ごとに持つ必要が出る（いまは店全体で1つ）。
  **(c) 税は明細ごとではなく税抜合計に1回だけかける** — 品目ごとに丸めると、
  同じものを1個ずつ2回頼んだ人と2個まとめた人で総額がずれる。テストで固定した。
  **(d) 税率を注文行に残す**（`frunk_orders.tax_rate`）— 税率が改定されても過去の伝票が変わらないため。
  #166以前の行は `tax_rate=0 / tax_amount=0 / subtotal=amount` で埋めた（当時は税込価格だったという事実を保存）。
  **(e) お客様に見せる金額は税込**（総額表示義務・消費税法63条）。注文画面の単価は「¥330（税込）」、
  合計の横に「（税抜¥300 ＋ 消費税¥30）」を小さく添える。**税抜だけを大きく出す表示に戻さないこと。**
  メニュー管理 `/orders/menu` は逆に「**税抜で入力**」と明示し、各行に税込を併記した。
  **(f) 税計算を `packages/core/src/frank-tax.ts` に切り出した** — #162 と同じ理由で、
  `frank-portal.ts` は `node:crypto` を読むためクライアントから読めない。
  注文画面は「押す前に総額を見せる」ために同じ計算が要る。**画面側に税率や丸めをコピーすると、表示と請求がずれても誰も気づけない**（#161 と同じ壊れ方）。
  **(g) `linkOrderToMember`（ビジター注文を会員に付け替える）でも税を足す** — ここを忘れると**会員に付け替えた注文だけ税抜で請求**される。
  **(h) Money OS は変更不要** — Webhook は Square の税込金額を受けて `exTax()` で税抜を出している。
  むしろ今回で正確になった（従来は税込300円として 272円 を記帳していた）。
  **(i) 規約・特商法を更新** — 第9条2項に「注文代金は会員ポータルに表示する税込価格」を追記。
  member-os の `frank-terms.ts` と 公式サイト `_build.py`（terms.html / tokushoho.html）の**両方**。サイトは再生成済み。
  ⚠ **レジ商品（Squareカタログの入会金・ビジター利用料など）は従来どおり税込**。ここだけ外税になっていることを混同しないこと。

- #167 (2026-08-27) **ドリンクの売価を一律にした**（migration 0128・適用済）。ユーザー確定値。
  **(a) 決めたのは「お客様が払う額（税込）」** — ソフトドリンク 会員330円／ビジター660円、ノンアルコール 会員440円／ビジター880円。
  `price_*` は税抜の本体価格（#166）なので、DBには **300/600・400/800** を入れた。
  4つとも110で割り切れる＝**端数が出ず、表示も請求もぴったりこの額**になる。ここは狙って選んだ値なのでテストで固定した。
  **(b) ソフトドリンク＝ `DRINK` ＋ `FRANK SPECIAL`（ソーダ4品）**、ノンアルコール＝ `NON-ALCOHOL` の3品。
  結果、レッドブル・炭酸水も含め**全品同額**になった（従来は250〜500円のばらつきがあった）。
  **(c) プロテインドリンクとノンアルモヒートは取り扱いをやめた** — ユーザー指定。
  ⚠ **行は消していない**。`frunk_order_items.menu_item_id` の紐付けが切れて過去の伝票が壊れるため、`active=false` でメニューから外した（#156 で決めた作法）。
  復活させたいときは `/orders/menu` から戻せる。
  **(d) 値上げになっている品がある** — 会員のコーヒーは 300 → 330、炭酸水は 250 → 330。
  既存会員4名は身内なので周知は不要（ユーザー確認済み・#158(c)と同じ扱い）。
  **(e) レッドブルだけノンアルコールと同じ価格帯にした**（#167b・ユーザー指定）。税込 会員440／ビジター880。
  原価が他のソフトドリンクより高く、一律330円だとこの1品だけ利益率が落ちるため。
  ビジター880は「ビジター＝会員の2倍」という #167 の並びに合わせた値（ユーザーの指定は会員440円のみ）。

- #168 (2026-08-27) **生徒向けマイページに「GOLF WING」と出ていた（FRANK の会員にも）**（migrationなし）。
  小川さんからLINEで指摘。`lesson-os.vercel.app/s/<token>` を FRANK の会員が開くと、右上とフッターに **GOLF WING** と表示されていた。
  **(a) 原因** — `lsn_students` は**2店が同居している台帳**なのに、共有ページがブランド名を直書きしていた。
  直書きは「必ずどちらかの店で嘘になる」形。#134（店舗またぎ廃止）でデータは分けたが、**表示のほうが残っていた**。
  **(b) `store_id` で出し分けるようにした**（`apps/lesson-os/src/lib/brand.ts`）。
  店名だけでなく**ヘッダーの色も**変える（FRANK は深緑 `#1F6B41`＝公式サイトの `--green-2` と同じ値）。
  名前だけ直して青いままだと、FRANK の会員には結局よそのお店の画面に見える。
  **(c) 未設定は GOLF WING 扱い** — FRANK 由来のカルテには必ず `store_id` が入る一方、GOLF WING の既存生徒と手で追加した生徒は未設定のまま（`lib/auth.ts` と同じ判断）。
  **(d) タブのタイトルも上書き** — ルートレイアウトの metadata が `GOLF WING Lesson OS` 固定だったので、共有ページに `generateMetadata` を足した。
  **(e) 直していないもの** — ログイン画面の `GOLF WING` 表記（スタッフ用で両店のコーチが使う）と、
  お客様に見せているURLが `lesson-os.vercel.app` のままである点。後者は独自ドメインを当てるか、会員ポータル経由に寄せるかの判断が要る。

- #169 (2026-08-27) **会員ポータルのアプリアイコンを正規ロゴに差し替えた**（migrationなし）。#155 で置いた暫定アイコン（深緑に金のF）の解消。
  **(a) アイコンに `HIMEJI` は入れていない** — 192pxまで縮むと潰れて読めず、汚れにしか見えないため。
  「FRANK GOLF ＋ スマイル」までを切り出して中央に置いた。
  **(b) `any` と `maskable` を別画像にした** — ここが要点。
  maskable は端末が丸や角丸に切り抜くので、同じ画像を使い回すと**ロゴの端が欠ける**（従来は icon-512 を両方に指定していた）。
  `any` は配布素材どおり白地に緑、`maskable` は緑地に白抜きでロゴを56%に縮め、安全領域の内側に収めた。
  **(c) ロゴの緑は実測 `#16553A`** （画像から抽出した中央値）。公式サイトの `--green-2 #1F6B41` とは別の値なので、混ぜないこと。
  **(d) 元データを `sites/frank-golf/assets/brand/frank-golf-logo.jpg` に置いた** — 次に別サイズが要るとき、LINEを遡らずに作り直せるようにするため。
  ⚠ **公式サイトのファビコンは手つかず** — `assets/favicon-32.png` は金色を淡いクリーム地に置いたもので、**32pxではほぼ判読できない**。
  ただしサイト側は金×濃色の配色で作られており、緑ロゴに替えるとブランドの見え方が変わる。ユーザーの判断待ち。

- #170 (2026-08-27) **レッスンページの写真がサンプルのままだった**（コード変更のみ）。ユーザー指摘「ここに画像が残っていますよ」。
  **(a) 前回（トップのLESSON差し替え）で `images.lessonPic` は実写にしたが、`images.lesson` は `hero-3.jpg`（サンプル）のまま**だった。
  この2つは別のキーで、**lesson.html の主役写真と館内ギャラリーの「レッスン」は後者**を見ていた。
  キーが2つあることに気づかず片方だけ直したのが原因。
  **(b) 3:2に切り直した画像を作った**（`lesson-rara-wide.jpg`）。
  元画像は 1200×1200 の正方形で、`media()` の枠は 3:2。**中央でクロップするとコーチの頭が切れる**ので、
  y=120 から切って両者の顔とボールに置いた手が入る構図にした。正方形のまま流用しないこと。
  **(c) `_build.py` のフォールバック `src` も直した** — `assets/img/lesson.jpg` は**実体が料理写真**（`images.food` が指している）。
  JSが動かない環境では、レッスンページに料理写真が出る状態だった。
  ⚠ **まだサンプルのままの写真** — `play`（打席）／`lounge`（バー）／`community`（交流）／`concept`。
  館内ギャラリーには「オープンに向けて準備中です」と明記してあるが、**実写が撮れたら `site-data.js` の images を差し替えること**（ファイル名を揃えれば1行で済む）。

- #171 (2026-08-28) **店舗ダッシュボードのシフト表で、スタッフ行をドラッグして並べ替えられるようにした**（migrationなし）。ユーザー依頼「店舗ダッシュボードのスタッフの表示の並び替えをできるように」。発見: `/store` のシフト表だけが行順を**「その月に最初にシフトが出てきた順」**で組み立てていた（`staffNames` に登場順で push）。#147 で `staff.sort_order` を入れて スタッフ管理の▲▼／シフト作成／紙シフト は揃えたのに、**店頭でいちばん見る画面だけが取り残されていた**＝月が変わると勝手に行が入れ替わり、紙シフトとも並びが違った。決定: **(a) 既定順を `sort_order → 氏名` に変更**（全画面と同じ規則。同値なら氏名の localeCompare("ja")）。**(b) 保存先は新テーブルを作らず `staff.sort_order` 1本**＝店舗ダッシュボードで並べ替えると シフト作成・紙シフトの行順も同時に変わる（並び順の置き場所を2つにしない）。**(c) 並べ替えの範囲**: 画面に出るのは「その月にシフトがある人」だけなので、会社全体の並びの中で**その人たちが占めている位置だけを入れ替える**（表示していないスタッフ・他店スタッフの位置は動かさない）。全員 sort_order=0 のままだと並べても効かないので、保存時に現在の並びで 10,20,30… に振り直してから書く（#147 の▲▼と同じ方式）。**(d) 操作はポインタイベント**（HTML5 drag&dropではない）＝店頭のタッチ端末でも同じハンドル`⠿`で動く。ドラッグ中は見た目を先に入れ替え、指を離した時点で保存→`router.refresh()` でサーバーの並びに追従。**(e) 認可**: 対象IDはクライアント渡しなので、サーバー側で **①この店舗にシフトがあるスタッフか ②認証で解決した店舗への書込みか（#134 の `canWriteStore`）** を必ず確かめる。店頭共有端末＝スタッフログインとは限らないため audit_logs は actor=null（company_id と via='store-dashboard' で記録）。実装: `lib/store-dash.ts`（shiftsに `staff(id, name, sort_order)` を追加・StoreShiftに `staff_id`/`staff_sort`）、`app/store/actions.ts` `reorderStoreStaff`、`app/store/store-client.tsx`。`npx tsc --noEmit` / 既存425件パス

- #172 (2026-08-28) **店舗ダッシュボードから紙シフト（A4横）を印刷できるようにした**（migrationなし）。ユーザー依頼「店舗ダッシュボードからも紙シフト印刷できるように」。背景: 紙シフトは `/admin/shifts/print` にしか無く、**`requireActor("create_shifts")` が要る**＝店頭の共有端末（店舗ログインCookie／kioskデバイストークン）からは開けなかった。店頭で刷るたびに管理者アカウントで入り直す必要があった。決定: **(a) 紙そのものは1つに保つ**＝ページ本体を `src/components/shift-print.tsx`（`ShiftPrintSheet` / `resolvePrintRange`）へ切り出し、`/admin/shifts/print` はその薄いラッパにした。**紙の体裁を2箇所に持たない**（列幅・@page A4横・役職グルーピング・Caddy派遣の合流などが二重管理になると必ずズレる）。**(b) 入口を2つにする**＝`/store/print`（店舗ログインCookie）と `/store/<token>/print`（デバイストークン）を追加。`/store` は middleware の公開prefixなので配下もそのまま通る。**(c) 認可は入口が持つ**: 共通コンポーネントは「渡された会社・店舗の紙を描く」だけで店舗を解決しない。店舗側は `listStores(companyId, 自店舗のみ)` で **認証で解決した1店舗に固定**し、`?store=` の直打ちは効かない・切替タブも出さない（オーナーがスタッフとしてもログインしている場合のみ複数出る／#134・#128）。**(d) 導線**: ダッシュボードのシフト表見出しに「🖨 紙シフトを印刷」。**いま見ている月と半月（前半/後半）をそのまま持っていく**（?ym=&range=half1|half2）ので、画面で確認した範囲がそのまま紙になる。戻るリンクは「← 店舗ダッシュボードに戻る」。**(e) 印刷ボタン** `PrintButton` も `components/print-button.tsx` へ移動（旧パスは再エクスポートstub＝VMからファイルを削除できないため）。紙の中身は従来と同じ＝**その店舗の在籍スタッフ全員**（`staff_store_assignments`・役職でグルーピング）で、ダッシュボードのグリッド（その月にシフトがある人だけ）とは母集団が違う。行順はどちらも `staff.sort_order`（#171）。`npx tsc --noEmit` / 既存425件パス

- #173 (2026-08-28) **一時利用顧客名簿（Excel出力）の日付をスラッシュ区切りに、電話番号をハイフン区切りにした**（migrationなし）。ユーザー依頼「日時を2000-00-00の形になっていますが/にしてください。電話番号は090-0000-0000の形に」。決定: **(a) 日付は `2026/08/28`**。DBの date 列は PostgREST が `YYYY-MM-DD` で返すので区切りを差し替えるだけ。対象は 日付・生年月日・再来の場合日付記入・再アプローチ(日付)×2 の5列。**取込側 `import/actions.ts` の `cellDate` は "/" 区切りも受ける**ので、出した名簿をそのまま取り込み直せる（往復が壊れない）ことを確認済み。列は `numFmt="@"` に固定＝Excelが開いたときにロケール既定の表示形式へ勝手に直さない。**(b) 電話は「確実に直せるものだけ直す」**。実データを数えたところ `mbr_guests` 約6,200件のうち**5,684件は既に正しいハイフン区切り**で、崩れているのは数十件（数字だけ11桁28件・全角ハイフン・スペース区切り・`+81`始まり・ハイフン位置ちがい）。一方で「090-4300-5336（母弘子様携帯」「06-6777-3679・090-711…」のように**メモや2件目が書き込まれている行**があり、数字だけ抜いて組み直すとその情報が消える。よって ①記号ゆれを寄せて妥当なハイフン区切りになる→そのまま ②電話番号の文字だけ かつ 携帯/IP(11桁)・0120/0800/0570・03/06 →整形 ③それ以外→**原文のまま**、の3段。**固定電話の市外局番（1〜4桁）は表がないと切れ目を決められない**（`0797-81-1234` と `079-781-1234` はどちらも10桁）ので当てずっぽうに割らない＝正しかった番号を壊す方が多くなる。**(c) 純関数に切り出してテストで固定**＝`apps/member-os/src/lib/ledger-format.ts`（`ymdSlash`/`formatTel`）＋`tests/ledger-format.test.ts` 12件。書式は「見た目の話」に見えて**出した名簿を取り込み直す運用がある**ので、往復の壊れ方を回帰で止める。`npx tsc --noEmit` / テスト437件パス

- #174 (2026-08-28) **Lesson OS にボーン（骨格）表示を入れた**（migration 0129）。ユーザー依頼「体の動きを把握するためにボーンデータを出せますか」。**(a) 解析はリアルタイムではなく「撮り終わった動画のコマ送り」**＝スマホで撮影しながら推論すると15〜25fpsまで落ちてコマを落とす。スイングの切り返し〜インパクトは0.25秒しかないので取りこぼしが致命傷になる。撮影後に `currentTime` を送って1コマずつ `detectForVideo` に流せば、時間はかかるが全コマ解析できる（8秒動画で約30秒・進捗バーと中止ボタン付き）。**(b) エンジンは MediaPipe Pose Landmarker (lite) をブラウザのwasmで**＝Apache-2.0で外販に使える・サーバー費用ゼロ・動画を外に出さない。GPUデリゲートで作り、失敗したらCPUに落ちる。**(c) wasmとモデル(計10MB)はリポジトリに入れない**＝リポジトリはPublicで他アプリのビルドも重くなる。`scripts/prepare-mediapipe.mjs` が build 前に node_modules から複製＋モデルを1回だけ取得して `public/mp/` に置き、`.gitignore` 済み。**取得に失敗してもビルドは止めず**、実行時にCDN（jsDelivr／Google）へ落ちる（顧客環境でビルドが赤くなる方が困る）。**(d) 保存先は `lsn_videos` の列ではなく別テーブル `lsn_video_pose`**＝1本あたり数百KBあり、カルテは1人20本超を一覧で引くので同じ行に置くと一覧が重くなる。プレーヤーを開いたときだけ video_id で1行取る。形式は `{t:[ms], p:[[33関節×xyz を1000倍した整数]]}`（未検出コマは空配列）。サーバーアクションの bodySizeLimit を 4mb に引き上げ。**(e) 署名URLのまま canvas に描くと汚染されて画素を読めない**ので、いったん fetch→Blob→objectURL に落としてから解析する（失敗時は crossOrigin="anonymous" で直接）。**(f) 出す数字は「見た目の角度」だと明記**＝単眼カメラなので肩・腰・ねじれ・前傾はすべて2D投影。カメラ位置が変われば数字も変わるため、画面にも手順書にも「同じ生徒の前回との差で見る」と書いた。頭のブレはアドレスのコマを基準に**肩幅を100%とした割合**で出す（身長・カメラ距離に左右されない）。**(g) 次段の足場**＝クラブヘッド軌跡とスイングプレーン自動計測は、両手首(15/16)を起点にシャフトの直線検出をかける方式を想定しており、そのための手首座標がこれで揃う。60fpsではインパクト前後でヘッドが1コマ60〜80cm動き追えないので、**iPhone純正カメラの120/240fpsスロー撮影を取り込む導線**が前提になる。実装: `src/lib/pose.ts`、`students/[id]/video-player.tsx`、`actions.ts`（savePose/loadPose/removePose）、`public/manual.md` §9。`npx tsc --noEmit` パス

- #175 (2026-08-28) **クラブヘッド軌跡とスイングプレーンの自動計測を入れた**（migration 0130）。#174 の続きでユーザー依頼「体より先にクラブヘッドの動きをとらえて線を出したり、スイングプレーンを自動計測できるように」。**(a) ヘッドを直接追わない**＝ヘッドは秒速40m前後で、60fpsでは1コマに60〜80cm動き**帯状にブレて点として存在しない**。代わりに**両手首の中点を原点にした放射状スキャンをフレーム間差分にかけ、シャフトの向きを取ってその先端をヘッドとみなす**（シャフトは長い直線なのでブレていても「その向きに動いた画素が並ぶ」形で必ず残る）。腕も動くので**内側(r<0.42R)を採点から外す**＝クラブは腕より長いので外側の帯だけ見れば自然にクラブが勝つ（テストで固定）。直前コマの向きは**弱い後押しだけ**（±45度・最大12%）にした。切り返しは1コマで20度以上回るので、強く効かせると置いていかれる。**(b) クラブ長は各コマの到達距離の80パーセンタイル**（平均だと短い側に引っぱられる）。外れ値はこれでクランプ、確からしさ0.15未満のコマは**空にして線を飛ばす**＝滑らかにつないで嘘をつかない。UIでも確からしさで濃さを変え、「インパクト前後で薄くなる/飛ぶのは正常」と手順書に明記。**(c) プレーンはアドレスのコマから取れない**（静止＝差分が出ない）ので、**アドレスの手 × 動き出した最初の確かなコマのヘッド**を結ぶ。そのときヘッドはまだボールのそばにあるのでアドレスのシャフト線とほぼ同じになる。自動が外れたときは**線ツールで引いた直線を基準面に採用でき、手動(_method="manual")は解析し直しても優先**される。**(d) 角度は必ずpxで計算する**＝正規化座標のまま atan2 すると 9:16 の動画で角度が狂う（#174 の poseMetrics はこのバグを持っていた／同時に修正・テストで固定）。プレーンの符号も**線を必ず左→右に揃えてから**外積を取る（手で右から左に引くと上下が反転していた）。**(e) 実測fpsを requestVideoFrameCallback で計測**して画面に出す＝「60fpsで撮ったつもりが30fpsだった」を憶測でなく数字で確かめるため。解析コマ数に120（スロー撮影用）を追加。**(f) 保存は 0129 の `lsn_video_pose` に列を足すだけ**（club/plane/src_fps）＝骨格と必ず同時に作られ同時に読まれ同時に捨てられるので、行を分ける理由が無い。⚠ 単眼カメラなので出る角度はすべて2D投影。画面と手順書の両方に「同じ生徒の前回との差で読む」と書いた。実装: `src/lib/pose.ts`（analyzeSwing/scanShaft/buildClub/planeFromAddress/planeMetrics）、`video-player.tsx`（骨格・軌跡・プレーンの個別トグル）、`actions.ts`（savePose/loadPose/savePlane）、`public/manual.md` §9、`tests/lesson-swing-analysis.test.ts` 15件。`npx tsc --noEmit` / テスト452件パス

- #176 (2026-08-28) **クラブ軌跡が実機で1本も取れなかったので、実動画を見ながら検出を作り直した**（migration 0130 に diag 列）。実機結果: 通常動画104コマ・スロー動画364コマとも骨格は出るが「クラブ軌跡は取れませんでした」。ユーザーに実動画（GOLF WINGシミュレーター内・正面・スロー撮影12秒/1080p）を置いてもらい、**Playwright+headless Chromium で本番と同じ `analyzeSwing` を流す検証台**（`~/swing/run.mjs`）を作って原因を数字と画で特定した。**(a) 最大の発見＝スロー撮影は差分方式には不利**。フレーム間差分の画を目で見たら、**1コマ前との差分にシャフトが一切写っていない**（240fps相当なのでコマ間でクラブがほとんど動かない）。**8〜16コマ前と比べると同じ場所にシャフトがくっきり出る**。よって「何コマ前と比べるか」を決め打ちにせず、**1/2/4/8/12コマ前を試して一番きれいに出た最小の間隔を採る**方式にした（直近12コマを輪バッファで保持）。手元の動きから間隔を推定する案は**骨格の点のブレ数pxを動きと誤認して外れる**ので採らない。**(b) 光線に直角方向の幅が無かった**＝手首の中点は数pxずれ角度も1度刻み。**r=200pxで1度ずれると横に3.5px外れ**、数px幅のシャフトを遠くで見失う。±(1+0.025r)の3点の最大を採る。**(c) 中心−周り（ridge）で「細いもの」だけ残す**＝体の輪郭や背景の明滅は太い、シャフトは細い。**(d) 動きの閾値を固定22から画面の85パーセンタイル+4の実測へ**。**(e) 合計値ではなく fill（手首からヘッドまで途切れず並んでいるか）を主役に**。**(f) そのコマで一番強い向きを選ぶのをやめ、候補を上位4本まで出して動的計画法で1本に決める**＝シミュレーター画面・ネット・体の輪郭は1コマだけ見ればクラブと互角だが、「前のコマの続きになっている」「手元からヘッドまでの距離が体格に対してほぼ一定（実測 0.93×肩〜足首）」を入れると一意に決まる。**素点をサンプル数で割った norm は、本物のシャフト0.4〜0.9 対 ノイズ0.05 とはっきり分かれる**ので閾値がぶれない。**(g) 軌跡は再生位置から2秒ぶんの尾だけ描く**＝12秒の動画で全部描くと線がぐちゃぐちゃで読めない。**(h) 取れなかったときは diag（解析コマ数→手元→向きの候補→線として残った数＋閾値/fill/確からしさ/比較コマ間隔）を保存して画面に出す**。⚠ 検証台の注意: **Playwright の Chromium は H.264 を再生できない**のでVP9/WebMに焼き直してから流す。実動画は `_swing_sample/`（.gitignore・顧客の映像なのでコミット禁止）。検証結果: 363コマ中246コマでヘッドを検出、アドレス〜テークバック〜トップ〜フォローまで線が乗ることを画で確認済み。`npx tsc --noEmit` / テスト457件パス（新規20件）

- #177 (2026-08-28) **「三脚を毎回据える運用は続かない」というユーザー判断を受けて、画角の再現を撮影側とデータ側の両方で吸収した**（migrationなし）。背景: #175/#176 で出る角度は2D投影なので、比較するには毎回だいたい同じ画角が要る。当初は三脚固定を前提にしていたが、現場で続かないと判断された。**(a) 撮影画面に【👻 前回に重ねる】を追加**＝その生徒の**前回スイングの1コマ目（既存の poster）をプレビューに35%で重ねる**（`mix-blend-screen`・操作は素通し・localStorage `lsn.rec.ghost` に記憶）。人と打席が重なるように立てば画角が揃う。**枠線ガイドは復活させない**（2026-08-22 に「文字が枠からはみ出て切れる・線が被写体に重なる」で消した経緯）。絵そのものを重ねるほうが速く、ズレも一目で分かる。**(b) 画角を数字で出す**＝`viewPoint()` が「📷 正面72° ・体の大きさ 61%」を返す。アドレスでは肩のラインが飛球線と直角なので、**肩幅÷(肩〜足首) がそのまま撮影方向の目安**になる（正面でおよそ0.30・後方DTLでは肩が短く写る）。体の画面占有率は撮影距離の目安。前回と近ければ角度も比べられる、とコーチが自分で判断できる。**(c) どの数字がカメラに依存しないかを明記**＝頭のブレとプレーンからの離れ（%）は体の大きさで割ってあるので距離が変わっても比較可、角度は立ち位置に依存する。画面と手順書の両方に書いた。⚠ 撮影方向はカメラの高さや姿勢でも多少ぶれるので**目安**。実測ではユーザーのシミュレーター動画のアドレスは肩幅比0.081＝後方寄りだった。`npx tsc --noEmit` / テスト459件パス（新規2件）

- #178 (2026-08-28) **前腕の向きを事前情報にしてクラブ検出を底上げした**（migrationなし）。ユーザー提案「体の動きとシャフトの動きから推測と実測データのすり合わせで精度を上げられないか」。**まず実データで測った**＝#176 で視覚的に正しいと確認できたコマ（アドレス〜テークバック）で、**シャフトの向きは前腕（肘→手首）の向きから ±10度 以内**に収まっていた（手首→人差指の「手の向き」は肩幅8.7pxしかなく、ばらつき大で使いものにならない）。決定: **(a) 前腕から見て有り得ない向きの候補を落とす**＝手首のコックは解剖学的に ±120度 を超えない。**「画面の反対側を向いた強い動き」（シミュレーター画面・ネット・体の輪郭）がこれでほぼ消える**＝1コマだけ見れば互角だった競争が一気に決まる。**(b) コックのなめらかさをDPの遷移コストに入れた**＝前腕から見た角度が1コマで飛ぶ組み合わせは、どちらかが誤検出。**(c) 取れなかったコマを前腕から補う**＝前後の確かなコマのコックを線形につないで埋める。**外挿はしない**・10コマを超える空白は埋めない・**コックが60度以上飛ぶ区間も埋めない**（両端のどちらかが誤検出なので、無い方がまし）。**(d) 実測と推定は必ず区別して持つ**＝`club.p` の conf を**負にしたら推定**（0129/0130 の形は変えない）。画面ではオレンジ実線＝実測／青い点線＝推定、「実測◯コマ・推定◯コマ」も出す。**滑らかにつないで嘘をつかない**という #176 の方針をここでも守る。実動画での効果: 363コマ中 実測169＋推定34＝203コマに線が乗り、**アドレス〜トップ〜フォローで「none」が消えた**。⚠ 次段（未着手）＝トラックマンの実測値とのすり合わせ。`lsn_measurements` は video_id で動画に紐づけられるが**現状1件・動画紐付け0件**なので、まず「撮影→最終コマをAI読み取り→自動で紐付け」を作らないとデータが貯まらない。ヘッドスピードが揃えば px→m/s の換算とクラブ長の検証ができる。`npx tsc --noEmit` / テスト462件パス（新規3件）

- #179 (2026-08-28) **レッスンの会話を録音してAIがコメントの下書きを作る「会話メモ」を入れた**（migration 0131）。ユーザー提案「レッスンOSに会話を聞く設定を置いて、お客さんとの会話を録音してレッスンコメントを要約する形はどうか」。**(a) 設計の柱は3つで、崩さない**＝①**同意なしに録音は始められない**（画面のチェック→`consent_at`/`consent_by` を立ててから行を作る。ボタンはそれまで押せない）②**音声は要約が取れた時点で自動で消す**（`audio_deleted_at`。残すのは要約と本文だけ・文字起こしも任意で消せる）③**AIは下書き**でカルテと共有ページに出るのは**コーチが確認・修正した `body` だけ**（トラックマン読み取り #49 と同じ型）。**(b) AIは Gemini**＝**音声をそのまま渡せる**ので文字起こしと要約を1回で済む。swing-cortex ですでに `GEMINI_API_KEY` を使っており業者を増やさない。キーが無ければ null を返すだけで、録音は残るので後から要約し直せる。**(c) 文体はそのコーチの過去コメントを見本に渡す**（`lsn_comments` の直近5件・内容は真似させない）＝店ごとの言い回しに寄る。swing-cortex の症状マスタを跨いで参照する案は、アプリ間の結合が増えるので採らなかった。**(d) 会話に無いことは書かせない**＝聞き取れないところは空配列。健康状態や家族の事情などレッスンに関係のない私的な話は文字起こしにも要約にも入れない、とプロンプトで明示。**(e) route handler にした**（`/api/lesson-note/summarize`・`maxDuration=300`）＝50分の音声は数分かかりサーバーアクションの既定では足りない。**(f) 別テーブル `lsn_lesson_notes`**＝`lsn_comments` は video_id 必須で「この動画へのコメント」。レッスンメモは動画に紐づかない。**(g) 現場の制約**＝録音中に画面が消えると止まる端末があるので Wake Lock を取り、復帰時に取り直す。それでも切れるので**30分を超えるレッスンは2本に分ける**と画面と手順書に明記。音声は 32kbps mono・上限18MB（それ以上は要約せず「分けて録音」と出す）。⚠ **未了（ユーザー作業）**: ①lesson-os の Vercel に `GEMINI_API_KEY` を設定（現在 swing-cortex にしか無い）②**会員規約・店頭掲示への録音の記載**（リポジトリに記載ゼロ）③実地での音の確認（実サンプルの音声は声の帯域が全体の20.5%・区間中央値 −51dBFS で、スマホが遠いと厳しい。ピンマイクの検討）。`npx tsc --noEmit` / テスト462件パス

- #180 (2026-08-28) **会話メモの失敗理由を必ず持って帰るようにした**（#179 の直後・migrationなし）。「要約できませんでした」だけだと、**モデル名違い・キー不正・音声形式・上限超過**のどれなのか現場で切り分けられない。Gemini が 2xx を返さなかったときは **HTTPステータスと本文の先頭300字を `error` と `ai_raw` に残し、画面に出す**。あわせて**本文が空なら status を `failed` にして音声を消さない**（原因を直して要約し直せる）。モデル名は `LESSON_NOTE_MODEL` で差し替え可能にした＝音声対応モデルが変わっても再デプロイが要らない。#176 の「取れなかったときは数字を残す」と同じ方針。`npx tsc --noEmit` / テスト462件パス

- #181 (2026-08-28) **会話メモを AIカルテナレッジに紐づけた。ただし「AIに書かせる」のではなく「AIに分類させる」**（migration 0132）。ユーザーの問い「音声→要約→ナレッジから近いのを検索→コメント生成でもいいが、それだとナレッジの意味がない。どうしましょう」。**その指摘は正しい**＝ナレッジを言い回しの辞書に使うと、コーチが既に言ったことをAIが別の言葉に置き換えるだけで、**コーチの言葉が失われるぶん悪化する**。決定は**向きを逆にする**こと: **(a) 音声＝事実**（コーチが言ったこと・生徒が言ったこと。言い換えない）／**ナレッジ＝翻訳先**（その事実に症状ID・確認項目IDを付ける＋お客様向け説明文を差し出す）／**本文＝コーチの言葉のまま**。**(b) これでナレッジが3つの意味を持つ**＝①**記録が検索できる資産になる**（症状IDが付いて初めて、取り込み済みの28,842件と同じ土俵に今日のレッスンが乗る。「この生徒はすくい打ちが3か月で4回」が出せる）②**お客様向け説明はナレッジ側が持っている**（`sc_knowledge.client_explanation`・YOZAN 112件）＝コーチは書かなくていい ③どの症状にも当たらない表現＝「うちのメソッドに無い言葉」としてナレッジを育てる材料。**(c) AIが作ったIDは必ず捨てる**＝返ってきた symptomId / checkpointId が自社の一覧に無ければ無視（AIが発明した症状をDBに入れない）。**(d) コーチの○×は消さずに `rejected` で残す**＝何が外れやすいかがナレッジ側を直す材料になる。**(e) 紐づけは音声とは別のテキスト呼び出し**にした＝文字起こしをやり直さずにタグだけ付け直せる。**(f) 共有ページに出るのは `share_body` だけ**（コーチが確認して保存したもの）。文字起こしもAIの下書きもお客様には出さない。実装: migration 0132（`lsn_note_symptoms` ＋ `lsn_lesson_notes.share_body`）、`lib/lesson-note-ai.ts` の `matchSymptoms`、`api/lesson-note/summarize`、`lesson-note.tsx`（タップで○×・手で追加）、`s/[token]/page.tsx`（コーチからのアドバイス）。実データ: YOZAN 40症状/112確認項目、津 33/123、FRANK 46/53。`npx tsc --noEmit` / テスト462件パス

- #182 (2026-08-28) **Genesisのホームを「見る画面」から「話しかけて動く画面」に変えた**（migration 0133）。ユーザー依頼「ジェネシスのホームのところで、アイアンマンのジャービスのような会話型のAIにしていきたい」。**(a) 最初の一言はLLMを使わない**＝`openingLine()` がスコア・判断件数・いちばん上の1件から日本語を組み立てる。理由: ホームは1日に何度も開く画面で、**開くたびにLLMを叩くと課金が積み上がり、APIが落ちた日は無言で立っているだけの箱になる**。喋る内容は画面が計算し終えた値（`toBriefing`）をそのまま使うので、**JARVISが読み上げる数字と画面の数字が絶対にずれない**。**(b) 数字はJARVISに書かせない**＝ブリーフィングに無い数字を聞かれたら `intent=data` を返させ、既存の Ask Data（#56）へ丸投げする。**LLMが書くのはSQLだけで、計算はPostgres**という #56 の柱をそのまま引き継ぐ。生成SQLと件数は「出典」として会話の中に折りたたんで出す。**(c) 案内先は表で検証する**＝`findNav()` が `NAV_MAP` に無い href を捨てる。AIが存在しない画面のボタンを出すのがいちばん信用を失う。**(d) 音声は業者を増やさない**（#179 と同じ判断）＝`OPENAI_API_KEY` があれば gpt-4o-mini-tts、無ければ **swing-cortex/lesson-os で既に使っている `GEMINI_API_KEY`** で Gemini TTS（返るのは24kHzの生PCMなのでサーバー側でWAVヘッダを付ける）、どちらも無ければブラウザ内蔵の speechSynthesis。**キーが無くても無音にはならない**。ブラウザは操作前の自動再生を止めるので、拒否されたら小さく断りを出し最初のクリックで喋り直す。音声入力は Web Speech API（非対応ブラウザではマイクを出さない）。**(e) 開発依頼を受け取る口を作った**＝ユーザーの要望は「JARVISに開発までやらせ、完全権限を与えたい」。**本番へ出す最後の一歩（git push）は2026-08-17の決定でユーザーのPCからしか実行できず、それがそのまま最後の安全弁になっている**ので、**実装を起こす権限は全部渡し、本番に出す権限だけを人に残す**形にした。会話で出た依頼はAIが `/command` の generatePrompt と同じ型の指示書に起こして `gn_dev_requests` に積み、Cowork側のClaudeが `queued` を拾って実装し `done` + result_note を書き戻す。GenesisとCoworkは同じSupabaseを見ているので、この表が受け渡し口になる。**言われた原文は `said` にそのまま残し、AIの要約で上書きしない**（一次資料を潰さない）。AIが落ちてもテンプレートだけで依頼は積む。**(f) 下の画面は消さない**＝スコア・判断フィード・5大KPI・AIティッカーはそのまま残した。会話が外れたときに戻れる場所が無い状態を作らない。**(g) 承認ラインは崩さない**（VISION §7）＝JARVISが単独でしてよいのは 調べる・案内する・下書きを作る・開発依頼を積む まで。外部送信・課金・本番デプロイ・本番DB変更・契約は従来どおり判断フィードのボタンで人が承認する。⚠ **ユーザー作業**: ①Supabase に 0133 を流す ②Vercel(genesis) に `GEMINI_API_KEY`（または `OPENAI_API_KEY`）を設定。実装: `lib/jarvis.ts` / `lib/jarvis-pure.ts` / `components/jarvis.tsx` / `api/jarvis/speak/route.ts` / `app/(main)/dev-requests/`。`npx tsc --noEmit` / テスト477件パス（新規15件）

- #183 (2026-08-28) **開発依頼キューを「クラウドが実装 → 古川さんのPCが取り込む」パッチ受け渡しで回すことにした**（migration 0134）。#182 で作った `gn_dev_requests` を毎時のスケジュールタスクに消化させようとしたが、**そのタスクは端末接続の承認が下りず（承認の案内自体が出てこなかった）クラウドでしか動けない**＝古川さんのPCのフォルダに触れない。**(a) 実測して分かったこと**＝リポジトリは public なので**クラウドのコンテナから clone でき、`npm install` も通り、`npm test` 477件も `apps/genesis` の `tsc --noEmit` も完走した**。つまり「実装して検証する」まではクラウドだけで完結できる。**できないのは push だけ**（2026-08-17: サンドボックスからGitHubへは proxy 403）。**(b) よって役割を割り直した**＝クラウドが clone→実装→tsc＋テスト→`git -c core.quotepath=false diff --cached --binary` をパッチとして `gn_dev_requests.patch` に書き戻し、古川さんは `.\apply-dev-queue.ps1` を1回叩くだけで pull→`git apply --3way`→commit→push→デプロイまで進む。**#182 の「実装を起こす権限は全部AIに渡し、本番に出す権限だけ人に残す」は一文字も変えずに、夜のうちに実装が進む形になった**。**(c) 合言葉をリポジトリに置かない**＝**このリポジトリは public**。ps1 は `%USERPROFILE%\.yozan\dev-queue.key` から読み、API側は `DEV_QUEUE_SECRET`（無ければ既存の `CRON_SECRET`）と突き合わせる。**どちらも未設定のときは開けっぱなしにせず 503 で閉じる**＝envの入れ忘れが「誰でも社内のパッチを取れる」に化けない。middleware の公開prefixに `/api/dev-queue` を足した（#52 の教訓＝入れ忘れると307で黙って死ぬ）。**(d) 検証が通っていないパッチは渡さない**＝`verified` が空の行は `/api/dev-queue/pending` が返さない。クラウド側が tsc とテストを通せなかった実装を、PCが黙って main に載せる経路を作らない。**(e) `git apply` に失敗したら `blocked` に戻す**＝done のまま放置すると毎回同じパッチを取りに行って毎回失敗する。3way にしてあるので main が進んでいても大抵は合流するが、駄目なときは人が見る場所へ返す。**(f) 作業ツリーが汚れていたら ps1 は止まる**＝古川さんの途中作業を巻き込んでコミットしない（`.ps1` だけは除外＝手元に未コミットの deploy スクリプトが残りがちなため）。**(g) パッチは LF のまま書く**＝PowerShell の既定で書くとCRLFに化けて `git apply` が落ちるので `UTF8Encoding($false)` + `WriteAllText`。日本語ファイル名のために `core.quotepath=false`、バイナリのために `--binary`。⚠ **ユーザー作業**: `.\deploy-dev-queue-183.ps1` の実行と、`%USERPROFILE%\.yozan\dev-queue.key` の作成（1回だけ）。実装: `supabase/migrations/0134_dev_queue_patch.sql`（適用済み）、`apps/genesis/src/app/api/dev-queue/{pending,applied}/route.ts`、`lib/dev-queue-auth.ts`、`middleware.ts`、`app/(main)/dev-requests/page.tsx`、`apply-dev-queue.ps1`。`npx tsc --noEmit` / テスト477件パス

- #184 (2026-08-28) **「ジェネシス」と呼べば会話に入る常時待受にし、話し終わるまで待つようにした**（migrationなし）。ユーザー指摘は2つ:「毎回ボタンを押して話す形になっている。ボタンではなく、僕がジェネシスと言ったら会話モードに入るほうがいいのでは」「喋っている最中にいきなり終了して回答してしまいます」。**どちらも正しく、押してから話す限り "呼べば答える" にはならない**。**(a) 常時待受＋ウェイクワード**＝「🎧 待受にする」を1回押すと `SpeechRecognition` を録りっぱなしにし、聞き取り結果に呼びかけが出るまでは**何も拾わない**（雑談を勝手に送らない）。呼びかけが出たらそこから後ろを用件として拾う。選択は localStorage に残し、マイク許可はオリジンに残るので**次に開いたときは自動で待受に戻る**。**(b) 区切りを自前で測る**＝`continuous=false` のブラウザ標準の区切りは**日本語の"間"に対して短すぎて、言い終わる前に確定してしまう**（これが「いきなり終了して回答」の原因）。`continuous=true` にして、**最後の結果から一定時間 新しい結果が来なければ言い終わりとみなす**方式に変えた。適正値は人によるので はやい0.9秒 / ふつう1.8秒 / ゆっくり3.0秒 から選べるようにし、記憶する。**(c) 呼びかけただけで用件が無ければ送らない**（`rest` が空なら待ち続ける）＝「ジェネシス」と呼んで一拍おいてから話し始める人を切らない。**(d) 読み上げ中はマイクを切る**＝切らないと**JARVIS自身の声を聞いて自分に返事をし続ける**（無限ループ）。読み上げが終わったら自動で起こし直す。この判定は state ではなく ref で見る（`onend` のクロージャは作られた時点の値を握るので、state だと「読み上げ終わったのにマイクが起きない」で黙り込む）。**(e) `onend` で必ず起こし直す**＝Chromeは無音が続くと認識を勝手に止める。**止まったまま黙るのがいちばん気づきにくい壊れ方**なので、待受のつもりである限り再起動する。例外は `not-allowed`（マイク拒否）だけで、そのときは待受を切って理由を画面に出す。**(f) 聞き取り中の言葉を画面に出す**＝何が聞こえているか見えないと、外れたときに直しようがない。待ちきれないときの「いま送る」も添えた。**(g) 返事のあと10秒は呼びかけ不要**＝1往復ごとに「ジェネシス」と言わせない。**(h) 呼びかけの判定は純関数に切り出してテストで固定**（`lib/jarvis-pure.ts` の `detectWake()`）＝音声認識は同じ言葉を毎回同じ表記で返さない（ジェネシス / ゼネシス / genesis / ひらがな / 読点つき）。**ここが外れると永久に起動しない**という、症状から原因に辿り着けない壊れ方をする。何度呼んでも最後の呼びかけより後ろだけを用件にする。⚠ 待受中は**そのタブを開いている間ずっとマイクが入る**（ブラウザの録音インジケータが点く）。実装: `components/jarvis.tsx`、`lib/jarvis-pure.ts`（`detectWake`/`WAKE_WORDS`/`pauseMs`）、`app/globals.css`。`npx tsc --noEmit` / テスト485件パス（新規8件）

- #185 (2026-08-29) **クラブ軌跡は「取れた/取れない」ではなく「取れたものがクラブか」を検査するようにした**（migrationなし）。ユーザー指摘「LESSON-OSでまだクラブヘッド軌道をうまく取れていないですよ」。**(a) まず本番データを見た**（推測で直さない・#176と同じやり方）。`lsn_video_pose` を引くと、**線は出ていた**: video 71fb30cd は147コマ中146コマで線が出て `conf 75% / fill 65%` と報告されていた。ところが**ヘッドの座標を見ると y は 748〜904 の156pxしか動いておらず、体の大きさは661px**。さらに**手首の y は 875〜1082 で、ヘッドは一度も手元より下に来ていない**。もう1本（580447a5）も同じくヘッドが一度も手元より下に来ていない。**ゴルフスイングではアドレスとインパクトでヘッドは必ず手元より下を通る**。つまり**追っていたのはクラブではなく腕**で、しかもシステムはそれを「成功・確からしさ75%」と報告していた。**黙って間違っているのが、取れないことより悪い**。**(b) 原因**＝#175〜#178 の差分方式は「比較コマの間でシャフトが線として残る」ことが前提。本番動画の実測 `src_fps` は **23〜24**（アプリ内撮影 `swing-recorder.tsx` は `frameRate: {ideal:60}` を要求しているが、実機では出ていない）。手元の1コマあたり最大移動量を実測すると**体の 8.6% / 18.0%**、古い2本では 28.7% / 31.2%。**ヘッドは手元の3〜4倍の速さ**なので、1コマでヘッドは体の30〜100%動く＝差分は線ではなく**扇形の塗りつぶし**になる。そこから放射スキャンで一番よく並ぶ向きを探せば、**ゆっくり動く腕が勝つ**。DPの「前のコマの続きになっている」条件は、この誤りをむしろ安定させる方向に効いていた。**#176 が成功した検証動画（`_swing_sample/IMG_8982.mov`）は 1920x1080/30fps だが、1スイングが12秒364コマに引き伸ばされたスロー撮影**で、条件がまったく違った。**(c) `conf`/`fill` では弾けない**＝あれは「その向きに動いた画素が並んでいるか」しか見ていない。**腕はきれいに並ぶので高得点を出す**。だから確からしさをいくら調整しても解決しない。**出来上がった軌跡の形そのもの**を見るしかない。**(d) 入れた検査（`verifySwingTrack`・純関数）** ①**ヘッドが一度も手元より下に来ない → 却下**（これが今回の2本を両方捕まえる）②縦の動きが体の60%未満 → 却下（スイングなら100%を超える）③シャフトの向きの振れが150度未満 → 却下。**どれかに当たれば `club` も `plane` も返さない**。#175 の「滑らかにつないで嘘をつかない」と同じ方針を、軌跡そのものにも適用した。**(e) 撮り直しの案内を数字で出す**＝手元の1コマ最大移動量が体の4%を超えていたら「この撮り方ではクラブは追えません。iPhone純正カメラのスローで撮って取り込んでください」。画面には実測値（ヘッドが手元より下◯コマ／縦の動き◯%／向きの振れ◯度／手元の速度◯%）を出す。**撮り方の一般論ではなく、その動画で何が起きたか**を返す（#176「取れなかったときは数字を残す」の続き）。**(f) アプリ内撮影ではクラブ軌跡は取れない**と手順書に明記した。`getUserMedia` は `frameRate: {ideal:60}` を要求しているが実機は23〜24。**骨格・角度・頭のブレは通常撮影でも取れる**ので撮影機能自体は残す。クラブ軌跡はスロー撮影を取り込む導線（カルテの動画取り込み・既存）に寄せる。**(g) 誤検出していた既存2本の `club`/`plane` を消した**（手動プレーンは残す）＝画面が嘘の線を出し続けるため。解析し直せば新しい判定で作り直される。⚠ **別件**: 動画1本（d22ed03c・111コマ）で **`withPose` が 0**＝骨格が1コマも取れていない。クラブ以前の問題なので別途。実装: `lib/pose.ts`（`verifySwingTrack`/`TrackVerdict`・`ClubDiag.verdict`）、`students/[id]/video-player.tsx`、`public/manual.md` §9。`npx tsc --noEmit` / テスト491件パス（新規6件）

- #186 (2026-08-29) **フィッティング予約を受付台帳につなぐ — 同じことを二度書かせない**（migration 0135適用済）。**発見**: フィッティングの申込（Reserve OS `res_requests`）は受付台帳（`mbr_walkin_visits` visit_type='fitting'）に**1件も流れていなかった**。実例 R-0004 中清様＝8/25申込・第1希望8/29 13:30 → **申込は4日間 pending のまま**、当日14:03に店頭タブレットで氏名・カナ・電話・住所・生年月日をゼロから手入力して台帳が作られた。お客様は予約フォームで既に書いている。**表示の穴**: 申込が店舗ダッシュボードに出るのは `sp_tasks`（#55）経由の**申込を受けた日のマスだけ**で、確定すると `closeStaffTask` で done になり**フィッティング当日には何も出ない**。折り返し待ちが日付の奥に埋まる構造だった。**決定（ユーザー 2026-08-29）**: **(a) 台帳へ載せるのは「確定した瞬間」**（来店を待たない・FRANK体験 #150 と同じ思想）。見送り・キャンセルで自動で下げるが、**来店打刻済み（`arrived_at`）の行は残す**（実際に来た人を件数から消さない）。未確定(pending)は載せない＝載せる日が決まっていないため。**(b) 来店時のタブレットは無くさない**。ユーザー指示は「予約時に入力した内容を来店時にまた書き直さなくていいようにしたい」＝**入力済みで開く**。`/reception/v/[intakeToken]` を新設し、氏名・カナ・電話・メール（＋2回目以降は住所・生年月日も）を埋めた状態で開き、**予約でいただいた内容（クラブ・HS・お悩み）は読み上げカードで確認するだけ**。お客様は不足分と同意・署名のみ。**新しい行もお客様も作らない**（作ると同じ人が2件になり件数と購入率が狂う）。**(c) 店舗ダッシュボード上部に常設パネル**（ユーザー選択）＝「折り返し待ちの申込（◯日経過バッジ・電話リンク・申込詳細リンク）」と「本日のフィッティング（来店ボタン）」。日付マスには入れない。**(d) 来店ボタン** = `arrived_at` 打刻 ＋ その1件だけを開ける受付URLを発行（生トークンは発行時のみ表示・DBは sha256、**1回きり・6時間で失効**）。**(e) 冪等キーは `RES-<res_requests.id>`**（`source_reservation_no`・0070の複合ユニーク。FRANK体験の `FRANK-TRIAL-` と衝突しない）。再同期で直すのは日付・お客様の紐付け・**自動生成のままのメモ**だけで、スタッフが書いた料金・割引・成約・アンケートには触らない。**(f) 名寄せをDB関数に移した** — `find_guest_by_contact(company_id, phone, email)`（電話は `app.digits` で数字だけにして下10桁・氏名では引かない）。従来の `frank-walkin.ts` は `mbr_guests` を**500件だけ読んで**突き合わせており、GOLF WINGは既に**6,213人**なので既存客が新規として二重に増える状態だった（中清様も既存客としてヒットすることを実データで確認）。**注意**: 確定＝台帳なので、無断キャンセルの分もフィッティング件数に乗る。実来店は `arrived_at` で判別できるようにしてある（KPIを実来店ベースにするかは次の判断）。実装: migration `0135_fitting_walkin_link.sql`、`packages/core/src/fitting-walkin.ts`（新規・冪等同期）、reserve-os `requests/[id]/actions.ts`（確定/見送り/キャンセルで同期）、shift-cloud `lib/store-dash.ts` `getFittingBoard()` ＋ `app/store/{dashboard,store-client,actions}.tsx`、member-os `reception/v/[itoken]/page.tsx`（新規）・`reception/[token]/{actions.ts,reception-form.tsx}`。検証: shift-cloud/member-os/reserve-os の tsc通過・テスト498件パス（新規7件）

- #186 (2026-08-29) **Genesisに予約を聞けるようにし、話しかけて入れられるようにした**（migration 0135・適用済み）。ユーザー「このGENESISに例えば予約状況などを聞いても返答してくれますか？ 要はすべてのシステムの情報読み取り、予約追加などの操作をできるようにしたい」。**(a) まず答えは「今は無理」だった**＝0053 の `gnv_*` は16本あるが**予約のビューが1つも無い**。Ask Data の設計は「カタログに書いていないビュー・列は存在しないものとして扱う」なので、予約は `frunk_bookings` に実在する（9/2以降に有効23件）のに `CANNOT_ANSWER` が返る状態だった。読み取りは**ビューを足すだけ**なので素直に足した: `gnv_bookings`（打席予約）・`gnv_walkins`（受付台帳＝来店と体験）・`gnv_orders`（モバイルオーダー）。**(b) 途中で不具合を見つけた — `gnv_trials` が空テーブルを読んでいた**。体験数の正は `mbr_walkin_visits(visit_type='trial')`（2026-07-25・706dc1b で一度直したはずの話）なのに、0053 のビューは `mbr_trial_bookings`（0行）を見ていた。つまり**「体験は何件？」と聞くと黙って0件と答えていた**。Ask Data の柱は「数字はPostgresが計算する」だが、**読む場所が間違っていれば正しく0を返してしまう**。列の形は変えずに元データだけ向け直した（**0件 → 1,121件**）。**(c) 書き込みの線はユーザーが決めた**＝「取消枠（入るが数分は戻せる）」。#61 で入れた auto/auto_undo/approval の3階層と、ホームの「実行予定」取消UIが既にあるので、**新しい仕組みを作らずそこに乗せた**。`booking_create`/`booking_cancel`/`walkin_add` を auto_undo(5分) で `ai_execution_policies` に登録。`staff_directive`（社内スタッフへの公式LINE）はユーザー判断で approval → auto_undo(5分) に変更した。**(d) お客様への送信・課金・本番デプロイ・契約は `act` に入れない**（VISION §7）。`line_broadcast`/`customer_message`/`payment`/`prod_deploy` は approval のまま＝JARVIS経由でも承認カードになる。**(e) 実行してよい操作を4つに固定した**（`ACT_TYPES`・テストで固定）＝**AIが思いついた操作名でDBを書き換えられないようにする**。一覧に無い type は実行せず talk に落とす。**(f) 直接DBに書かず必ず `ai_action_queue` を通す**。理由は3つ: ①**実行の瞬間に空きを見直せる**（積んだ時点と5分後で店頭の状況が変わる。ハンドラ側で `booked_date`＋`bay_id` の重なりを取り直し、埋まっていれば失敗させる）②取り消しUIと承認UIが既にそこにある ③監査ログと失敗理由が1か所に残る。**(g) 予約のルールは既存を踏襲**＝営業時間・定休日は `BookingCfg`（#183/#171 の正典）、打席は A→B→C の順で空きを探し**レフティはB固定**、`active=false` の D打席は候補に入れない、**キャンセルは消さず status='cancelled'**（台帳から消えると経緯が追えない）。**(h) 曖昧なら作らない**＝日付・時刻・お名前のどれかが欠けていたら `act` にせず talk で1つだけ聞き返す、とプロンプトで明示。⚠ **GOLF WING宝塚の予約は Smart Hello（外部システム）**なので、Genesisからは読めても書けない。実装: `supabase/migrations/0135_ask_data_bookings.sql`、`packages/core/src/ask-data.ts`（カタログ）、`apps/genesis/src/lib/ai-execution.ts`（3ハンドラ）、`lib/jarvis.ts`／`lib/jarvis-pure.ts`（`act` インテント・`ACT_TYPES`）、`components/jarvis.tsx`。`npx tsc --noEmit` / テスト501件パス（新規3件）

- #187 (2026-09-01) **FRANK の打席予約を「毎時00分スタート・1時間/2時間」にし、25分パーソナルレッスンをオプションで付けられるようにした**（migration 0136適用済）。ユーザー依頼「30分毎に予約できるようにしていますが、00分スタートのみの予約をできるようにしてください。会員様も基本的には00分で打席予約をしてから、オプションで25分のパーソナルレッスンを申し込めるようにしてください」。**(a) お客様側とスタッフ側の刻みを分けた**＝`slot_minutes`（30分）は**台帳とスタッフ画面のまま**にし、お客様の刻みは `member_start_step`(60) / `member_minutes_options`([60,120]) を新設して持つ。理由: スタッフは電話で「14:30から30分」を受ける。**1つの `slot_minutes` を60に変えると、お客様側を直したいだけなのに店頭の自由度まで失う**。この2つが別物だと分かるよう `/site-admin` のラベルも「台帳・スタッフ画面の刻み」に変えた。**(b) 空き判定を「開始マスが空いているか」から「利用時間ぶん続けて空いているか」に変えた**＝従来は開始時刻のマスだけを見て○を出し、実際に取れるかはPOSTしてサーバーに聞いていた。**30分刻みのときは1マス＝1予約でほぼ一致していたが、60分刻み＋2時間の選択肢が入ると「○を押したのに予約できません」が普通に起きる**。画面側で `freeAt()` を持ち、利用時間を変えたらグリッドを引き直す。**(c) 埋まりの数え方をマスの頭に丸める方式にした**（`coveredCells`）＝従来は予約の開始時刻から `slot_minutes` ずつ足していたので、**60分刻みの列に対して 14:30〜15:30 の予約は1つも塗られず「空き」に見えた**。**塗り残しは二重予約になる**ので、`[start,end)` に重なるマスを必ず塗る形に変えた。25分のレッスン（14:00〜14:25）も1マス塗る。マスの粒度は `min(slot_minutes, member_start_step)`＝30分。**(d) パーソナルレッスンは「希望」までを受ける**（ユーザー確定）＝コーチが枠を公開する既存の仕組み（`frunk_lesson_slots`・#88）は**当日のシフトが決まらないと枠を出せない**。打席予約と同時に申し込めるようにするには、**先に会員が押さえて、担当は後から店舗が割り当てる**ほうが運用に合う。**(e) レッスンの時間帯も店舗が決める**（ユーザー確定）＝お客様には「打席のお時間の中で25分」とだけ約束し、開始位置は選ばせない。確定時に `lesson_option_start` が打席予約の `[start_time, end_time)` に収まることをサーバーで検査する。**(f) 予約1件に0か1件なので別テーブルを作らなかった**＝`frunk_bookings` に `lesson_option_*` 6列。`requested` の索引を貼り、member-os の予約管理**上部に未確定件数の常設パネル**を出す（#186 と同じ「日付の奥に埋めない」考え方）。**(g) お断りは `declined` で残す**＝行を消すと「頼んだのに何も言われなかった」になる。会員のマイ予約にも状態を出す。**(h) 体験予約は変更なし**＝`TRIAL_START_STEP=60`（2026-07-31）で既に毎時00分のみ。今回で打席予約が体験と同じ刻みにそろった。**(i) 設定はDBから変えられる**＝`gn_site_content.data.booking` 経由で `/site-admin` から刻み・利用時間・レッスン料金を変更でき**デプロイ不要**（#183/#171 の正典を踏襲）。**料金0で受付だけ止まる**。⚠ 既存の有効予約27件（9/2〜10/31）は**全部00分開始**なので、今回の変更で見え方が変わる予約は無い（実データで確認済み）。実装: `packages/core/src/frank-booking.ts`（`memberStartStep`/`memberMinutesOptions`/`lessonOption`/`grainOf`/`coveredCells`）、`apps/genesis/src/lib/frank-booking.ts`（`getSlots`/`createBooking`）、`api/public/frank/booking/route.ts`、`sites/frank-golf/booking.html`、`apps/member-os/src/lib/frank-reservation.ts`（`loadCoaches`）、`reservations/{page.tsx,actions.ts}`（`setLessonOption`）、`site-admin/{page.tsx,actions.ts}`。`npx tsc --noEmit` / `next build`（genesis・member-os）通過・テスト514件パス（新規7件）

- #188 (2026-09-01) **お客様が入るページを my.frankgolf.jp に一本化し、入会承認の前に決済を確かめられるようにした**（migrationなし）。ユーザー指摘は4つ:「決済ボタンを押さなくても入会を承認できてしまうので、実際に決済されているかを確認したい」「iCloud宛にメールが届いていないことがあった」「メールの『打席予約はこちら』がややこしい。全部 my.frankgolf.jp に飛ぶほうがきれい」「お客様が入るページは会員ポータルだけにしたい。簡易ログインQRのPDFも欲しい」。

  **(a) 承認画面に「決済がどこまで進んだか」を必ず出す。** Web入会（#129）は入金Webhookで自動的に確定するので、`/frunk` の承認待ちに残っている pending は **「まだ払っていない人」か「Webhookが届かなかった人」のどちらか**で、画面上はまったく見分けが付かなかった。見分けが付かないまま【承認して会員化】が押せた＝未入金のまま会員番号が出る。承認ボタンの手前に `joinPaymentView`（純関数・テスト4件）で状態を出す: `billing_status='active'`＝入金確認済み／`'checkout'`＝**決済ページまで進んだが入金は未確認（黄色で警告）**／未発行＝店頭でのお手続き。**DBのフラグは手がかりであって答えではない**ので言い切らず、Squareダッシュボードの探し方（取引をお客様のメールで検索）まで文面に書いた。

  **(b) 答えは Square に聞きに行く。** `lookupJoinPayment`（genesis）が ①決済リンク発行時に控えた注文ID（履歴込み）を `/orders/batch-retrieve` ②見つからなければ申込メール →`/customers/search`→`/orders/search` の順で完了注文を探す。**②が要るのは #137 の実障害**（サブスク付き決済リンクの入金は別の注文IDで届く）。**Square env は yozan-genesis にしか無い**ので照会はgenesis側の公開API `/api/public/frank/admin/join-payment` に置き、member-os から呼ぶ。認可は `member_id`（推測不能なUUID）＝ join-checkout と同じ考え方で、**できるのは「その申込の入金を見る」「入金が確認できたときだけ確定する」だけ**。

  **(c) 入金が確認できたら Web入会と同じ手順で確定する**（`confirmJoinByPayment` → `activateWebJoin`）。手動の【承認して会員化】は会員番号のメールしか出ない＝**控えPDF・カルテ・キャンペーン判定が付かない**。Webhookが届かなかっただけの人を、届いた人と同じ状態にする。⚠ サブスクの後始末（価格上書きの解除・前取り分のスキップ）はここでは触らない（二重に効く危険）。代わりに `frunk.join_confirmed_manually` を残して人がSquareで確かめる。【承認して会員化】は**現金・振込・口座振替の入口**として残し、その旨をボタンの下に書いた。

  **(d) お客様が入るページは会員ポータル（my.frankgolf.jp）1つにする**（ユーザー確定）。メールの中に `frankgolf.jp` と `member-os-tau.vercel.app` が混ざっていて、お客様から見ると「打席予約はこちら」が2種類あった。URLの正典を **`@yozan/core/frank-links`** に置き、**ここ以外にURLを直書きしない**（片方だけ直して片方が古いままになる事故＝#159 のレジ商品と同じ）。公式サイト `frankgolf.jp` は「これから知る人」が読む場所として残す（アクセス・料金・体験予約）。

  **(e) 打席予約の画面そのものをポータルの中に置いた**（`/member/book`）。旧実装は公式サイトへ**転送するだけ**だった（#93 で受付口を1か所にした名残）。**台帳もAPIも増やしていない**＝予約の作成・空き判定は従来どおり genesis の `/api/public/frank/booking` が唯一の窓口で、この画面はその表示。空き枠の数え方も `coveredCells`（#187）をそのまま使う＝サイトとポータルで「○なのに取れない」が出ない。認証は #152 の引き渡しトークンなので、**ログイン済みのお客様に会員番号と下4桁を聞き直さない**。鍵が未設定のときだけ従来どおり公式サイトへ転送する（予約できない状態は作らない）。

  **(f) 月会費のカード登録をポータルの「設定・お手続き」に移した**。従来は公式サイトの打席予約ページの下にあり、ログイン済みなのに会員番号と下4桁を再入力していた。Square決済後の戻り先も `my.frankgolf.jp/member/settings?billing=success` に変更（`join-checkout` の戻り先ホワイトリストにポータルを追加。**旧URLも残す**＝古いタブから発行された決済リンクを壊さない）。

  **(g) 体験のキャンセルURLもポータル経由にした**（`/cancel/<token>` → 公式サイトの `trial-booking.html` へ転送）。**メールに出るドメインを1つに保つ**ためだけの転送で、画面は従来のまま。転送先はトークンの形（英数字とハイフン）を検査してから作る＝他所へ飛ばされる細工を通さない。

  **(h) iCloud宛の未達**: DNSを実測したところ **frankgolf.jp の認証は正しく揃っていた** — SPF（バウンス用 `send.frankgolf.jp` に `include:amazonses.com`）・DKIM（`resend._domainkey.frankgolf.jp`）・DMARC（`p=none`）。**送信元の設定は原因ではない**。よって残るのは ①Appleの評価による受信側の選別（迷惑メール送りか無言の破棄）②Resend無料プランの上限（月3,000通）③ドメイン認証が外れたとき、のいずれか。**どれなのかを毎回あてずっぽうで切り分けないで済むように**、送信結果に **Resend の message id** を持ち帰るようにし（`MailResult.id`）、失敗時は本文の先頭160字まで理由を残す。**入会完了メールは送りっぱなしだった**ので、成功・失敗の両方を `events` に記録するようにした（`frunk.join_mail_sent` / `frunk.join_mail_failed`）＝会員番号と控えPDFが届いていないことに誰も気づかない、が無くなる。

  **(i) 簡易ログインQRのA4ポスター**（ユーザー確定＝店頭掲示用の共通QR。会員ごとの自動ログインQRは作らない）: `FRANK_GOLF_出店計画/FRANK_会員ポータルQR_A4.pdf`。中身は `https://my.frankgolf.jp/member/login` だけ＝**誰が読み取っても同じで、会員番号も個人情報も持たない**（掲示物として安全）。体裁は既存の `FRANK_打席QR_A4.pdf` に合わせた。再出力は `scripts/frank-qr-poster.py`。

  実装: `packages/core/src/frank-links.ts`（新規・URLの正典）、`apps/genesis/src/lib/frank-join-payment.ts`（新規）、`api/public/frank/admin/join-payment/route.ts`（新規）、`apps/genesis/src/lib/{frank-join,frank-mail,frank-mail-pure,frank-square-billing}.ts`、`api/public/frank/join-checkout/route.ts`、`apps/member-os/src/lib/{frank-mail,frunk-join-view}.ts`、`app/member/{book/*,settings/*,page.tsx}`、`app/cancel/[token]/page.tsx`、`app/(main)/frunk/{page.tsx,actions.ts}`、`app/join-web/actions.ts`、`middleware.ts`。検証: genesis / member-os の `tsc --noEmit` と **`next build` 通過**（クラウドでcloneして実走）・テスト **518件パス**（新規4件）

- #189 (2026-09-01) **iPhone でレッスンOSのカメラが開かなかったのを直した**（migrationなし・lesson-os のみ）。ユーザー報告「iPhone 17 Pro Max の時にレッスンOSでうまくカメラが開きませんでした。ブラウザ設定で許可はもちろんしています」。症状は赤いエラー文＝`getUserMedia` が失敗しており、**開き方はホーム画面のアイコンから**だった。**(a) 原因は iOS の「ホーム画面アプリは Safari と別あつかい」**＝iOS 17 以降、ホーム画面に追加したアイコンは standalone の Web アプリとして起動し、**カメラ・マイクの許可を Safari と共有しない**。Safari の設定でいくら許可しても、そちらには効かない。さらに許可の確認は**タップ起点でないと出ない**ことがあり、旧実装は画面を開いた直後の `useEffect` から `getUserMedia` を呼ぶだけだったので、**確認が一度も出ないまま NotAllowedError で落ちていた**。**(b) 【📷 カメラを開始】をプレビュー上に出した**＝タップから呼び直せる導線を作った。許可済みの端末では従来どおり自動で開くので、普段の手数は増えない。**(c) 失敗を握りつぶすのをやめた**＝旧実装は `catch {}` で常に「ブラウザのカメラ許可を確認してください」と出しており、**許可の問題なのか・カメラが他アプリに取られているのか・端末が要求を飲めないのかが現場で区別できなかった**。`DOMException.name` ごとに文面を出し分け（NotAllowed/Security・NotFound/Overconstrained・NotReadable/Abort・その他は name をそのまま出す）、standalone の iPhone のときだけ「Safari とは別あつかい／アイコンを追加し直す」まで書く。https でない場合も明示する。**(d) 要求を段階的に緩めるようにした**＝`1920x1080@60` → 素の `facingMode` → **音声なし** → `video:true` の順。**マイクだけ断られる端末があり、音声込みの1回勝負だと映像まで諦めていた**。ただし打球音はインパクトの自動推定に使うので、音が録れなかったときは画面にその旨を出す。**許可なし・カメラ無しは緩めても直らない**ので、その2つはラダーを打ち切って即エラーにする（無駄な再試行で確認ダイアログを潰さない）。実装: `apps/lesson-os/src/app/(main)/students/[id]/swing-recorder.tsx`（`isStandalone`/`isIOS`/`camMessage`/`openCamera`）、`apps/lesson-os/public/manual.md`。`tsc --noEmit` 通過

- #189 (2026-09-01) **予約作成の会員をお名前でも探せるようにし、注文の通知音を長く・大きく・鳴らし直すようにした**（migrationなし）。ユーザー依頼3件:「スタッフがPCで打席予約を取るとき、会員番号だけでなく名前でも検索できるように」「注文が入ったときの音が短すぎる。もっと長く大きく」「注文から提供済みにするまで3分たったらもう一度鳴らして」。

  **(a) 会員番号を覚えていないと予約が取れなかった。** `/reservations` の予約作成は「会員番号（会員時）」の入力欄だけで、電話で「山田です」と言われたら**別タブで会員管理を開いて番号を調べて戻る**運用になっていた。`MemberPicker`（お名前・カナ・会員番号・電話のどれでも当たる候補ドロップダウン）に置き換えた。

  **(b) 当たり判定は増やさない。** `/frunk` と同じ `lib/frunk-member-search.ts`（純関数・テスト済み）をそのまま使う。ここで独自に ilike を書くと**「会員管理では出るのに予約では出ない」**が起きる。ひらがな⇔カタカナ・全角半角・電話の表記ゆれはこの1か所が吸収している（#139 の設計コメントが「予約作成の会員指定でも必要になる」と予告していた通りの合流）。

  **(c) 候補はサーバーからまとめて渡して画面で絞る。** 会員はFRANK姫路で数百人。1文字ごとにサーバーへ聞きに行くと、電話を受けながら打つ速さに追いつかない（/frunk と同じ判断）。候補に出すのは `active` と `suspended` だけ＝**退会・却下は出さない**（予約が取れない相手を出すと選び間違えるだけ）。休会は出す（店頭で「今日から復帰」を受けることがある）。

  **(d) 選んだ会員は id で送り、サーバーで引き直す。** 表示名で送ると同姓同名を取り違える。`member_id` を受けても**必ず会社・店舗で引き直す**（画面の値をそのまま信じない・#134）。旧フォームの `member_no` も受け続ける（外部からのPOSTを壊さない）。

  **(e) 「区分」の選択欄を廃止した。** 会員を選んだかどうかで自動的に決まる（`customer_kind: memberId ? "member" : "dropin"` は元からそうなっていた）。**選び忘れて会員が都度利用として登録される**事故の芽を消す。

  **(f) 通知音は「0.35秒のピッ1回」では気づけなかった。** 厨房・ラウンジで手が離せないときに1回のピッは通らない。**約2.4秒のチャイム6連**（880/1175Hzの交互・triangle波）にし、音量を 0.25 → 0.9 に上げた。triangle にしたのは、sine より倍音があり同じ音量でも通るため。音声ファイルは置かない（配信物を増やさない）。

  **(g) 未提供のまま3分たったら鳴らし直す。** 最初の1回を聞き逃すと**以降は誰も気づけないまま伝票が残る**のがいちばん困る壊れ方だった。注文ごとに経過を測り、3分ごとに鳴らし直す（提供済み・取消で止まる）。鳴らし直しは**低めの音（660/494Hz）**にして新着と聞き分けられるようにし、何件たまっていても**鳴らすのは1回**（連打すると誰も聞かなくなる）。判定は `router.refresh()`（10秒）に乗せず自前の15秒タイマーで回す＝最大10秒のズレを持ち込まない。覚えている「最後に鳴らした時刻」は `useRef` の Map なので、10秒ごとの再描画では消えない。

  **(h) 音と同じ基準を画面にも出す。** 未提供の伝票に「注文時刻／経過◯分」を出し、**3分を超えたらカードごと赤**にする。音を切っている端末でも同じ判断ができる（#122「アラートは直せるまで作る」と同じ考え方）。あわせて音ONの横に**【テスト再生】**を置いた＝注文を待たずに店の環境で聞こえる音量かを確かめられる。

  ⚠ 音は iPad/Safari の制約で**一度タップしないと鳴らせない**（従来どおり「音をONにする」が要る）。ONにした瞬間に1回鳴らすようにしたので、押せているかどうかが分かる。

  実装: `apps/member-os/src/lib/frank-reservation.ts`（`loadMemberOptions`）、`app/(main)/reservations/member-picker.tsx`（新規）・`page.tsx`・`actions.ts`、`app/orders/live.tsx`・`page.tsx`。member-os の `tsc --noEmit` と **`next build` 通過**（クラウドでcloneして実走）・テスト518件パス

- #190 (2026-09-01) **体験予約に生年月日を必須で入れ、体験→受付台帳の名寄せの穴を塞いだ**（migration 0137適用済）。ユーザー指示「体験予約時に生年月日を入れるようにしてください、ここは必須」。

  **(a) なぜ体験の時点でいただくか。** 体験のあと入会される方は、店頭で会員申込書に**もう一度 生年月日を書いている**。受付台帳（`mbr_guests`）にも生年月日の欄はあるのに、Web体験予約からは一度も入っていなかった＝年代別の集客分析もできなかった。予約時にいただければ、来店時は**確認だけ**で済む（`/reception/v/` の受付フォームは `mbr_guests.birth_date` を既に流し込む・#186）。

  **(b) 判定は1か所に置く**＝`packages/core/src/birth-date.ts`（`birthDateError` / `normalizeBirthDate` / `ageOn`・テスト7件）。体験の入口は**2つ**ある（公式サイトの素のJS／member-os の `/trial`）ので、画面ごとに条件を書くと必ずズレる。**画面のチェックだけでは足りない**（画面を通らない直接POSTで空のまま入る）ので、**サーバー側でも同じ関数を通す**。弾くのは「日付として成立しないもの」だけ＝2月31日・未来・1900年より前。**年齢での足切りはしない**（体験には未成年も来る）。基準日は必ず引数で渡す＝環境の日付に依存する時限爆弾テストを作らない（#157）。

  **(c) 公式サイトは年/月/日の3プルダウン**（`input type="date"` はiPhone/iPadのホイールで「日」が合わせにくく、入力を諦める方が出る）。member-os 側は既存の `BirthDateInput` をそのまま使う。**日数は選んだ年月に合わせて出し直す**＝存在しない日を選ばせない。

  **(d) NOT NULL にはしない**（0137）。既存の申込には値が無く、過去分を捏造しない。スタッフが電話で受けて後から埋める入口（member-os `/trials`）も残っている。**必須はお客様が自分で予約する入口で担保する**。

  **(e) ついでに見つけた実害 — 体験の名寄せが500件しか見ていなかった。** `frank-walkin.ts` の `resolveGuestId` は `mbr_guests` を **`.limit(500)`** で読んでアプリ側で突き合わせていた。FRANK と GOLF WING は**同じ会社**で `mbr_guests` は既に6,000人超＝**既存のお客様が体験のたびに「新規」として増え、来店検索でも二重に出ていた**。#186 でフィッティング側だけをDB関数 `find_guest_by_contact`（0135）に寄せていたが、体験側が取り残されていた。同じ関数に寄せて塞いだ＝**名寄せの規則を2つ持たない**。

  **(f) 既存のお客様の生年月日は上書きしない**。空のときだけ、予約でいただいた値で埋める。

  実装: `packages/core/src/birth-date.ts`（新規）・`frank-walkin.ts`、`apps/genesis/src/lib/frank-trial.ts`・`api/public/frank/trial/route.ts`、`apps/member-os/src/app/trial/{actions.ts,trial-form.tsx}`、`sites/frank-golf/_build.py`（＋生成物 `trial-booking.html`）、`supabase/migrations/0137_trial_birth_date.sql`（**適用済み**）、`tests/birth-date.test.ts`。genesis / member-os の `tsc --noEmit` と **`next build` 通過**（クラウドでcloneして実走）・テスト **525件パス**（新規7件）

  **(g) FRANKのスタッフ打刻は新規開発なしで使える**（ユーザー依頼「フランクゴルフ用のスタッフ用の打刻できるようにしてください」）。Shift Cloud の打刻端末（`/kiosk/<token>`・ログイン不要）は **#88 で FRANK 用に発行済み**で、URLは Vault「FRANK 店頭タブレット（店舗ダッシュボード/打刻）」に記録されていた。実機で開いて「FRANK GOLF 姫路／名前を選んでください」と6名が出ることを確認済み。**打刻端末は店舗ダッシュボードと同じトークン**（`/store/<token>` と `/kiosk/<token>`）。⚠ 打刻画面に**スタッフではないアカウント「FRANK GOLF姫路」（login_id: frankgolf・店舗ログイン用）が人として並ぶ**。消すとログインが壊れるので、隠すには「人かどうか」の区別が要る＝次の判断（ユーザーへ確認済み）。

- #191 (2026-09-01) **経費の支出（納品書ぶんを含む）をスタッフが入力できるようにした**（migration 0138適用済）。ユーザー依頼「money-osで納品書、経費の支出の分をスタッフに入力してもらいたい」。

  **(a) これまで店で出ていったお金はどこにも入らなかった。** `mon_expense` に行が入る経路は「ファイン精算書の移行」と「カード・口座CSVの仕分け」の2つだけで、**店の現金で買った消耗品・立替・掛けの仕入は帳簿に存在しなかった**。本部が後から思い出して拾うしかなく、拾えなかった分はそのまま利益を過大に見せていた。

  **(b) 支払い方法は3つに絞った**（ユーザー確定）＝ **店の現金／立替／掛け（後日振込）**。ここが設計の中心で、**支払い方法ごとに帳簿のどこが動くかが変わる**:
  | 方法 | 経費(mon_expense) | 現金出納 | 銀行CSVからも入るか |
  |---|---|---|---|
  | 店の現金 | 計上する | **出金を自動で書く** | 出てこない（消込不要） |
  | 立替 | 計上する | 動かさない（店の金は減っていない） | 精算を振込にしたときだけ |
  | 掛け | 計上する | 動かさない | **必ず出る＝消込が要る** |

  **(c) 二重計上の急所を画面に出した。** PLの経費は `mon_expense`（発生）＋`mon_bank_txn` の確定出金（支払）の足し算（[[expense-settlement]]・SYSTEM.md §4-5 の恒久ルール「新しい自動計上を足すときは、その支払が銀行側からも入るか必ず確認する」）。掛けと立替(振込精算)は**銀行側からも入る**ので、`settled_txn_id` の消込を押し忘れると支払いが二重に乗る。よって **「あとで支払い・精算するもの」パネルを月の切り替えと無関係に常設**し、消込画面へのリンクを置いた。押し忘れを画面が覚えている状態にする（#122「アラートは直せるまで作る」と同じ）。

  **(d) 現金で払った分は現金出納にも書く。** 書かないと**レジの実残高と帳簿がズレる**。売上の現金連携と同じ形（`source='expense'` / `source_ref=経費ID`）で1行作り、金額や日付を直したら出納側も直し、削除したら出納の行も消して `rebalanceCashLedger` で残高を積み直す。**片方だけ残すのがいちばん危ない**（#98 の旧 deleteSale と同じ轍）。

  **(e) 承認は挟まない**（ユーザー確定「入力したら即計上」）。そのかわり **①押す前に「この操作で帳簿がどうなるか」を必ず表示 ②あとから編集・削除できる ③入力者名(`entered_by`)を残す** の3点で担保する。

  **(f) 科目はボタン**（ユーザー確定）。値は `mon_category_map(src_kind='expense')` に実在する表記に合わせる（仕入/備品/水道光熱費/広告/送料＋支払手数料・その他経費）。**「わからない」を用意し、押すと科目は空**＝集計では `other_expense` に落ちる（壊れない）うえ、一覧に「科目未設定 ◯件」と出るので本部が拾って直せる。**迷ったときに適当な科目を選ばせるより、空のまま拾えるほうが直しやすい。**

  **(g) 写真は撮らせない**（ユーザー回答「PC操作で行うので写真撮影はむずかしいかも」）。代わりに **納品書・伝票番号 (`doc_no`)** を入れてもらう＝紙と突き合わせる唯一の手がかり。PDFで残したいものは既存の `/receipts`（証憑・電帳法対応）に上げる導線が既にある。

  **(h) 判定は純関数に切り出してテストで固定**＝`apps/money-golfwing/src/lib/expense.ts`（`expenseEffect` / `expenseInputError` / `PAY_METHODS` / `EXPENSE_CATEGORIES`・テスト9件）。**支払い方法→帳簿のどこが動くか**を画面のJSXに散らすと、「現金で払ったのにレジが合わない」が静かに起きる。画面もサーバーも同じ関数を通す。

  ⚠ **権限**: money-os のアクセスは Shift Cloud の店舗配属をそのまま流用しているので、**ログインできるスタッフは自店舗のお金の画面を見られる**（本画面に限らず従来から）。見せたくない人がいる場合は staff_store_assignments 側の整理が要る＝次の判断。

  実装: `supabase/migrations/0138_expense_staff_input.sql`（**適用済み**・`entered_by`/`doc_no`/`paid_by`/`reimbursed_on`＋未消込の部分索引）、`apps/money-golfwing/src/lib/expense.ts`、`app/(main)/expense/{page.tsx,actions.ts,ExpenseEntry.tsx}`、`components/nav.tsx`、`tests/expense-input.test.ts`。money-golfwing の `tsc --noEmit` と **`next build` 通過**（クラウドでcloneして実走）・テスト **534件パス**（新規9件）

- #192 (2026-09-01) **退会・休会を「いつから」で受け付け、Squareの月会費を必ず止めるようにした**（migration 0139適用済）。ユーザー指摘「会員の削除や会員プランの変更を行ったときにスクエアの請求もとまりますか？」「会員プランを作って保存したのにプラン変更できない」「退会時と休会時（〇月末の退会と選べるように）に請求を止めてください」。

  **(a) 退会してもSquareの自動課金は止まっていなかった。** `setMemberStatus` は退会のときだけ意図的にSquareを触らず（コメント「お客様都合のタイミングがあるため自動解約しない」）、画面に「Squareダッシュボードで解約してください」と赤字を出すだけだった。**見落とすと翌月も引き落とされる。** 休会(pause)と復帰(resume)は動いていたので、抜けていたのは退会だけ。加えて **プランを削除しても、そのプランで動いているサブスクは止まらない**（プランは soft delete のみ）。会員そのものを消す機能は無い（退会にするだけ）。

  **(b) 0円プランに変更できなかった。** 会員カードのプラン変更プルダウンが `monthly_price > 0` で絞っていたため、**保存はできているのに変更先に出てこない**（「スタッフ」「モニター会員」が該当）。フィルタを外し、**0円プランへ変更したらサブスクを解約する**ようにした。ここを swap で済ませると 0円のバリエーションが存在せず**旧プランの金額のまま落ち続ける**。

  **(c) 受付ルールはユーザー確定のとおり純関数に置いた**（`packages/core/src/frank-membership.ts`・テスト14件）:
  | | 効力日 | 申し出の締切 |
  |---|---|---|
  | 退会 | **月末** | 退会月の**前月末**まで（9月末退会なら8月末まで） |
  | 休会 | **月初** | 前月**10日**まで（10月休会なら9月10日まで） |

  日付を1つ間違えると月会費が1か月ぶん余分に落ちる／止まりすぎる＝**そのままお金の事故**になるので、選択肢の生成（画面）と受け取った日付の検証（サーバー）は必ず同じ関数を通す。**月末以外・月初以外の日付は受け付けない**（日割りを発生させない）。

  **(d) statusは当日まで変えない。** 「10月末で退会」を受け付けても status は active のまま＝**その日までは予約も会員証も通常どおり**。切り替えは genesis の日次cron `/api/cron/daily`（6:00 JST・`runFrankMembershipSchedule`）で行う。退会日は「その日までは在籍」なので **翌日**に left へ落とす。

  **(e) お金はcronに依存させない。** 受付の時点で Square 側に予約を入れる＝**退会は `PUT /v2/subscriptions/{id}` の `canceled_date`**（その月までは請求され翌月から停止）、**休会は `pause` の `pause_effective_date`**。cronが遅れても請求は正しい日付で止まる。⚠ Squareの `POST /cancel` は**即時ではなく現在の請求サイクルの終わり**で効く。ここを「即時」と思い込むと1回余分に落ちる。

  **(f') 退会もプラン変更もせず「引き落としだけ止めたい」出口も用意した**（`stopSquareBilling`）。0円プランに切り替えたのにサブスクだけ残っている状態を画面から潰せる。

  **(f) 予約は取り消せる**（`cancelScheduledChange`）。DB側の予定日を消すだけでなく、**Square側も戻す**（退会=`canceled_date: null`／休会=`resume`）。片方だけ戻すのがいちばん危ない。

  **(g) 予定は一覧と会員カードの両方にバッジで出す。** 店頭で「この人もうすぐ退会だっけ」を思い出せる場所が無いと、予約を取ってしまう。

  実装: `packages/core/src/frank-membership.ts`（新規）、`apps/member-os/src/lib/frank-square.ts`（`cancelSubscription`/`uncancelSubscription`追加・`pauseSubscription`に日付）、`apps/member-os/src/app/(main)/frunk/{actions.ts,page.tsx,[id]/page.tsx}`、`apps/genesis/src/lib/frank-membership-cron.ts`（新規）＋`api/cron/daily/route.ts`、`supabase/migrations/0139_frank_scheduled_leave_suspend.sql`（**適用済み**・`scheduled_leave_date`/`scheduled_suspend_start`）、`tests/frank-membership.test.ts`。member-os / genesis の `tsc --noEmit` と **`next build` 通過**（クラウドでcloneして実走）・テスト **548件パス**（新規14件）

  ⚠ **運用の残り**: 在籍6名は全員「スタッフ」プラン(0円)に変更済み。**小川うらら様(FR0005)のSquareサブスク（月100円）だけは解約が残っている** — このセッションからは Square のアクセストークン（Vercelのenvが正）に触れないため止められない。デプロイ後、**会員カードの「自動課金」欄に付けた【自動課金を解約する】**（`stopSquareBilling`）で止める。

- #193 (2026-09-01) **Member OS のタブを店頭の手の動き順に並べ替え、予約カレンダーと予約管理を1画面に統合し、カレンダーのマスをタップして体験・会員の予約を入れられるようにした**（migrationなし）。ユーザー指示「ダッシュボードでのスケジュール管理が一番よく見る画面。上の並び替えをしてください」「必要のない確認するだけのものは"その他"タブから開くように」「体験予約を電話で受けたときの入れ方がすごく分かりづらい。枠を選択してスケジュールを引かないといけないのでややこしい。カレンダーの該当のところをタップしたら、そこから予約できるようにしたい」。

  **(a) タブが10個あって、探す時間のほうが長かった。** ダッシュボード／受付台帳／来店検索／体験フォロー／体験申込／予約（姫路）／FRANK会員／電子伝票／チェックイン／データ取込 が横一列に並び、**1日に何度も触るものと、月に数回しか開かないものが同じ重さで並んでいた**。お客様が来てからの手の動き（受付台帳 → 予約 → FRANK会員 → 電子伝票 → チェックイン）を常時表示にし、**確認するだけの4つ（体験申込・体験フォロー・来店検索・データ取込）を「その他 ▾」に畳んだ**。畳むほうは `<details>` で作る＝JSの状態を持たないので、店頭タブレットでタップを取りこぼさない。

  **(b) 「カレンダーで見る画面」と「登録・入金する画面」が別タブに分かれていた。** `/dashboard`（予約カレンダー・#135）と `/reservations`（予約管理）は**同じ台帳の同じ日を、別のタブで開いていた**。空いている時間を探してから登録するのに毎回タブを往復する。**`/reservations` に統合**し、月/週/日カレンダー・予約詳細・未収金・当日一覧をこの1画面に置いた。FRANK配属者が `/dashboard` を開いたら `/reservations` に転送する（`?date=` `?sel=` はそのまま引き継ぐので、会員カードからの既存リンクとブックマークは壊れない）。GOLF WING 宝塚の月次KPIダッシュボードは従来どおり `/dashboard`。

  **(c) 電話で体験を受けたとき、スタッフには入口が無かった。** 体験の予約はお客様向けの `frankgolf.jp/trial-booking.html` にしか無く、**スタッフは公式サイトを自分で開いてお客様のふりをして入力していた**。member-os のカレンダーの空きマスを押すと、その日・その時刻・その打席が入った状態で入力パネルが開き、**【体験（初めての方）】【会員・都度利用】をタブで選んで**そのまま登録できるようにした。会員の追加予約（帰り際に「次いつ？」と言われるやつ）も同じ入口。

  **(d) 体験の規則は member-os 側で作り直さない。** 体験は「毎時00分・約55分（60分押さえ）・打席はA→B→Cの優先順で自動割当・レフティは左右打席のみ・生年月日必須（#190）・受付台帳へ自動連携・確定メール」という決まりがあり、その**正典は Genesis の `/api/public/frank/trial`**（`apps/genesis/src/lib/frank-trial.ts`）。スタッフ画面からも**同じAPIをサーバー間で呼ぶ**。ここに同じ処理を書き写すと、規則を変えたときに片方だけ古くなる。流入元は `src=staff` で渡すので、受付台帳では「Web体験予約（staff）」として**お客様ご自身の申込と区別できる**。

  **(e) 登録が失敗しても黙って何も起きなかった。** 旧 `createBooking` は営業時間外・重複・会員未指定のいずれでも `return` するだけで、**スタッフから見ると「押したのに増えない」だけ**だった。`useActionState` で結果を返し、理由を画面に出す。ついでに**レッスン枠との重なりも見る**ようにした（作成時は見ておらず、打席のダブルブッキングが作れた。#151 の変更側だけ直っていた）。

  **(f) 個人情報の同意は電話でも省かない。** 体験の入力パネルには「お客様にご説明のうえ同意をいただきました」のチェックがあり、入れないと登録できない（Web申込と同じ扱い）。

  実装: `apps/member-os/src/components/nav.tsx`（PRIMARY/SECONDARY・`その他 ▾`）、`app/(main)/reservations/{page.tsx,actions.ts,booking-sheet.tsx}`、`components/bay-timeline.tsx`（空きマスを `data-book-*` のボタンにする `emptyTap`・週表示の空きマスは日表示へ）、`app/(main)/dashboard/page.tsx`（FRANKは転送）。member-os の `tsc --noEmit` と `next build` 通過（クラウドでcloneして実走）・全548件パス

- #194 (2026-09-01) **Lesson OS をスマホで見られるようにした**（migrationなし・lesson-os のみ）。ユーザー指示「レッスンOSに関してはスマホの画面がもう少し見やすいようにUIを変更してください。スマホで開いているという自動の意識みたいなのがあれば、そのUIをスマホ用に勝手に変更できるようにしておいてください」。

  **(a) 原因は"モバイル対応"として入れた一括の書き換えだった。** `globals.css` に `@media (max-width:767px) { .grid-cols-2 { 1列 } .grid-cols-3〜6 { 2列 } }` があり、**これが Tailwind の `grid-cols-2 md:grid-cols-4` を丸ごと打ち消していた**（unlayered なCSSは `@layer utilities` より強いので必ず勝つ）。結果、**作った人が「スマホでは2列」と書いた場所がすべて1列に伸び**、画面がひたすら縦に長くなっていた。一括の書き換えをやめ、**折り返しは各画面の `md:` 指定に任せる**。

  **(b) CSSに残すのは「指で操作するために要ること」だけにした。** 表は横スクロール／**入力欄は16px**（iOS Safari は16px未満の入力欄をタップすると画面を勝手に拡大し、以後の操作が全部ズレる）／ボタンは最低44px（Apple HIG）／`safe-area-inset-bottom`。

  **(c) ヘッダが潰れていた。** 「ブランド名・タブ3つ・担当者名・ログアウト」を1行に詰めていたので、iPhoneの幅ではタブが読めなかった。**広い画面は今までどおり1行、スマホはタブを2段目に出して横スクロール**にし、ついでに**いま開いているタブに色**を付けた（今までどこにいるか分からなかった）。

  **(d) カルテのタブ7つ。** 2〜3列に折ると縦に伸びて、下の内容が画面から押し出されていた。**スマホは横スクロールの1行**、md以上は7列のグリッド。生徒ヘッダ（写真・名前・共有リンク）も、スマホでは共有ボタンを名前の下に回す（右に置くと名前が潰れる）。

  **(e) スマホかどうかはサーバー側でも判定できるようにした**（`lib/device.ts` の `isMobileDevice`・User-Agent）。ただし**見た目の切り替えは原則CSS**（画面を回しても追随し、判定を外しても崩れないため）。UAは偽装もできるし新しい端末は取りこぼすので、**これで動作を止めない**＝「最初から開いておくか畳んでおくか」のような初期値寄せにだけ使う。レイアウトの一番外側に `data-mobile="1"` を出しているので、今後CSSだけでは決められない出し分けが要るときはそこから引っかけられる。

  実装: `apps/lesson-os/src/app/globals.css`、`src/components/nav.tsx`（新規・`LessonNav`）、`src/lib/device.ts`（新規）、`src/app/(main)/layout.tsx`、`src/app/(main)/page.tsx`、`src/app/(main)/students/[id]/karte-client.tsx`。lesson-os の `tsc --noEmit` と `next build` 通過（クラウドでcloneして実走）

- #195 (2026-09-01) **法人プラン（法人ライト／法人プレミアム）を入会できるようにし、「予約は消化してから次を取る」を全会員共通にした**（migration 0140適用済）。ユーザー依頼「法人ライトとプレミア会員の登録ができるようにしてください」「入会は通常通りHPからしていきたいです、法人会員の説明や魅力を伝えるページもHPに追加してください」。

  **(a) 事故の修正: 非公開のはずのプランがお客様の入会フォームに並んでいた。** `/join-web` は `active` なプランを全部出していたため、note に「一般公開しない」「Web入会フォームには表示しない」と書いてある **テスト会員(月110円税込)・スタッフ(0円)・モニター会員(0円)** がそのまま選べる状態だった。`active`（画面に出す/出さない）と **`public_signup`（お客様が申し込めるか）を別の列**にして塞ぎ、**直接POSTされても通さない**（画面から消すだけでは守れない・#134と同じ考え方）。

  **(b) 法人は「会社が契約して、社員が使う」形にした**（ユーザー確定）:
  | | 月額(税抜) | 登録できる利用者 | 先に持てる予約 | 同伴ビジター |
  |---|---|---|---|---|
  | 法人ライト | 39,800円 | 2名 | 御社合計 **4コマ** | なし |
  | 法人プレミアム | 59,800円 | 4名 | 御社合計 **8コマ** | **無料・回数制限なし** |

  **利用者ごとに frunk_members の行を作り、会員番号を発行する。** 会社で番号を1つ使い回すと「誰が来たか」が残らず、レッスンカルテも分けられない。お一人ずつ番号を出せば、予約・会員証QR・カルテが**普段の会員と同じ仕組みのまま**動く。⚠ **月会費のサブスク（square_subscription_id）を持つのは契約者の行だけ** — ここを取り違えると人数分の請求が立つ。利用者は `corporate_parent_id` で契約者にぶら下げる。

  **(c) 「予約は消化してから次を取る」は全会員共通**（ユーザー確定「基本的に全会員統一です」）。まだ消化していない予約として同時に持てるコマ数（1コマ=1時間）に上限を置き、**消化する（その時間が過ぎる／来店になる）まで次が取れない**。法人は**登録者全員の合計**で数える。`frunk_plans.max_open_slots` = ライト1・レギュラー1・マスター2・法人4・法人8。判定は `packages/core/src/frank-corporate.ts`（テスト13件）に置き、画面もサーバーも同じ関数を通す。**ここがズレると「○を押したのに予約できません」か、逆に上限超えで取れてしまう。**

  **(d) 行の作り方は core に1か所だけ。** 入口が2つある（Web入会の入金確定＝genesis／店頭の承認＝member-os）ので `packages/core/src/frank-corporate-members.ts` に寄せた。会員番号の採番はアプリごとに実装があるためコールバックで受ける。**何度呼ばれても増えない**（親＋電話番号で既存を探す＝Webhookの再送と手動承認が重なっても二重に作らない）。

  **(e) 人は入れ替わる。** 会員カードに利用者パネルを置き、店頭で**追加・登録を外す**ができる（上限は超えられない・外した方は行を消さず退会にして履歴を残す）。⚠ 利用者ごとに**違う電話番号**が要る（会員ページのログインが会員番号＋電話下4桁のため。同じ番号だと取り違える）。

  **(f) 公式サイト。** `corporate.html` を作り直した（2プランの比較カード・スペック表・法人でのご入会の流れ4段・法人向けFAQ6問・**「法人プランで入会を申し込む」ボタン**）。従来は金額2行と「公式LINEでご相談ください」だけで**入会への導線が無かった**。料金ページの法人行にも内容と法人ページへのリンクを追加。**ついでに site-data.js の会員向けURLが member-os-tau.vercel.app のまま**だったのを my.frankgolf.jp に直した（#188 の一本化から漏れていた）。

  **(g) 請求書払いは無い**（現状カードのみ）。法人は請求書を希望されることが多いので、**FAQに明記**したうえで請求先の住所・メールをご担当者と別に指定できるようにした（経理の方に届く）。口座振替・請求書払いを入れるかは次の判断。

  実装: `supabase/migrations/0140_frank_corporate_plans.sql`（**適用済み**）、`packages/core/src/frank-corporate.ts`・`frank-corporate-members.ts`（新規）、`apps/genesis/src/lib/{frank-booking.ts,frank-join.ts}`、`apps/member-os/src/app/join-web/{page.tsx,web-join-form.tsx,actions.ts}`、`apps/member-os/src/app/(main)/frunk/{actions.ts,[id]/page.tsx}`、`sites/frank-golf/{_build.py,assets/site-data.js}`（生成物 corporate.html / plan.html）、`tests/frank-corporate.test.ts`。member-os / genesis の `tsc --noEmit` と **`next build` 通過**（クラウドでcloneして実走）・テスト **561件パス**（新規13件）

- #196 (2026-09-01) **電子伝票の通知音を最初からONにした**（migrationなし）。ユーザー依頼「電子伝票の画面で最初から音オンにしておいてください」。

  **(a) これまでは開くたびに【音をONにする】を押す必要があった**（#189で音そのものは作り直したが、ONにする操作は残っていた）。iPad を再起動した・タブを開き直した・スタッフが交代した、のどれでも無音に戻る。**押し忘れに誰も気づけない**のがいちばん困る壊れ方だった。

  **(b) 開いた瞬間に AudioContext を作って `resume()` を試み、表示も最初から「🔔 音ON」にする。** ⚠ ただし **iPad Safari / Chrome は一度も操作していないページで音を鳴らせない**（自動再生の制限）。これはこちら側の設定では外せない。

  **(c) だから「押させる」のをやめて「触れば効く」にした。** 鳴らせない間は `window` の `pointerdown` / `touchstart` / `keydown` を拾って `resume()` する＝**伝票を1枚押しただけ・スクロールしただけで音が使えるようになる**。開店時に一度画面に触れば、その日はもう意識しなくてよい。

  **(d) 鳴らせない状態は小さなボタンではなく帯で出す**（「🔔 画面を一度タップすると音が鳴ります」・琥珀色）。**気づかないまま無音で営業する**のを防ぐのが目的なので、目立たせる側に倒す。`onstatechange` と `visibilitychange` で状態を追い、放置で suspended に落ちても復帰させる。

  **(e) 「音を止める」も残した**（夜間の事務作業など）。既定がONになっただけで、切る自由は残す。

  実装: `apps/member-os/src/app/orders/live.tsx`。member-os の `tsc --noEmit` と **`next build` 通過**（クラウドでcloneして実走）

- #197 (2026-09-01) **予約・体験申込の画面をひとりでに最新にした（自動更新）＋合図音を共通化**（migrationなし）。ユーザー指摘「予約などに関してはリロードを押さないと反映されないですか？予約の見落としにつながるので自動リロードや即時リアルタイム反映できますか？」。

  **(a) その通りで、押すまで出なかった。** `/reservations`（#193で予約の正典になった画面）も `/trials` も `dynamic = "force-dynamic"` なだけで、**開いたまま置いておくと何時間でも古いまま**。予約はお客様が24時間いつでも入れられるので、押し忘れがそのまま**見落とし**になる。自動更新が入っていたのは `/orders`（電子伝票）だけだった。

  **(b) 15秒ごとに `router.refresh()`**（`components/live-refresh.tsx`）。画面まるごとのリロードではなくサーバー側だけ取り直すので、**入力中のフォームもスクロール位置も飛ばない**。`/trials` は20秒。

  **(c) Supabase Realtime（サーバー発の即時通知）は採らなかった。** ブラウザから購読するには anon キーと RLS を予約テーブルに開ける必要があり、**店頭端末に会員の予約が読めるキーを置く**ことになる。得られるのは15秒 → 1秒未満の差で、見落とし防止には15秒で足りる。**お金と個人情報のリスクに見合わない。**

  **(d) 別のタブを見ている間は止める。** 開きっぱなしの端末が無駄に問い合わせ続けるのを防ぐ。戻ってきた瞬間に1回取り直すので、画面に目を戻したときは必ず最新。

  **(e) 「変わったこと」を目に見せる。** 最終更新の時刻を常に出し（**画面が止まっていないことが分かる**＝確かめるためにリロードを押さなくて済む）、中身が変わったときだけ緑のバッジと音。毎回鳴らすと誰も聞かなくなる。開いた直後は鳴らさない。

  **(f) 判定は「今日以降の予約 ＋ 体験申込」の件数と最終更新時刻**（`loadLiveSignature`）。表示している日だけ見ると**来週の予約が入っても気づけない**。件数だけだと「1件入って1件キャンセル」で同じ数になるので最終更新時刻も混ぜる。体験は日付で絞らない（日程未定の申込こそ取りこぼせない）。

  **(g) 音は `components/chime.ts` に共通化した**（#189で作り #196 で最初からONにしたもの）。電子伝票と予約画面で同じ音・同じ復帰の仕組みを使う。実装を2つ持つと片方だけ直る。

  実装: `apps/member-os/src/components/{chime.ts,live-refresh.tsx}`（新規）、`app/orders/live.tsx`、`lib/frank-reservation.ts`、`app/(main)/{reservations,trials}/page.tsx`。member-os の `tsc --noEmit` と **`next build` 通過**（クラウドでcloneして実走）

- #198 (2026-09-02) **体験カウンセリングシートを受付台帳に入れられるようにし、朝のスタッフ連絡を店舗ごとに分けた**（migrationなし）。ユーザー依頼「（体験カウンセリングシートの写真）これをフランクゴルフの予約台帳などで入力できるようにしてください」「出勤ラインですがゴルフウィングとフランクゴルフは分けてください。ゴルフウィングのグループラインにフランクゴルフの情報があがるのはよくないので」。

  **(a) 朝連絡が全店ぶん1通で、GOLF WINGのLINEにFRANKの出勤者が流れていた。** `ceo-ai.ts` の朝連絡は全店の出勤・やることを1つの本文にまとめ、`payload.target='all'` で登録済みの全グループへ送っていた（#83/#85）。ところが `gn_line_groups` に入っていた配信先は **「スタッフ連絡（YOZAN公式）」＝GOLF WING 宝塚 の1つだけ**。つまり全店ぶんの本文が丸ごとGOLF WINGのグループに届いていた（9/2の朝連絡＝出勤5名＝FRANK3名＋GW2名）。

  **(b) 店舗ごとに1通にした。** 出勤・やること・持ち越しは**その店舗の行だけ**を本文にし、`payload.store_id` を付けてその店舗のグループにだけ送る（dedupe も `staff-brief-<日付>-<店舗>`）。**店舗の無いタスク（store_id が null＝全社共通）はどの店にも出す**（【全店共通】と付ける）。1店舗にスコープされた実行（#134）も同じ道を通るので分岐が消えた。

  **(c) 送り先が無い店舗は、他店へ寄せない。** LINEグループ未登録の店舗は送らずに `staff.brief_no_group` イベントを残す。**「送り先が無いから既定のグループへ」は、まさに今回の事故そのもの**なので絶対にやらない。なお FRANK GOLF のグループは 2026-09-02 に古川さんがOAを招待して自動登録済み（`C30e97…`／FRANK GOLF 姫路）。

  **(d) 体験カウンセリングシート（紙）はスタッフが台帳に入力する。** お客様のタブレット入力欄は増やさない（ユーザー選択）。受付台帳（`/`）の体験の行に「カウンセリングを入力」ボタンを出し、①ゴルフ歴 ②練習・ラウンドの頻度 ③普段の練習場所 ④平均スコア ⑤改善したいこと（最大2つ）⑥場所選びで重視すること（最大2つ）を入れる。

  **(e) 重複は作らない（ユーザー選択「重複を統合」）。** ⑦知ったきっかけ＝既存の `referral_source`（何で知ったか）、⑧今日の体験で知りたいこと＝既存の `survey.comment`、スタッフ記入欄＝既存の `note`（備考・フォロー状況）。**同じことを二度聞かない・二度入力しない。**

  **(f) 器は `mbr_walkin_visits.survey`（jsonb）＝列を増やさない＝migrationゼロ。** 保存時は**既存の survey を読んでからマージ**する（`survey.reserve`＝予約でいただいた内容やタブレットの回答を消さないため。受付フォームと同じ作法）。⑤⑥の「最大2つ」は画面で押せなくするだけでなく**サーバー側でも選択肢の照合と2件への切り詰め**を行う（画面を信じない）。

  **(g) Excel出力にも出る。** 一時利用者名簿の**空き列（45〜53列目）に9列**を足した＝**57列のまま**なので現行シートの形は崩れない。

  **(h) 朝連絡以外の「スタッフへ連絡」も宛先を持たせた。** これまで宛先を書かない連絡は `is_default` のグループ＝GOLF WING だけに届き、**FRANKのスタッフには一生届かなかった**（かつFRANKの話がGWに出た）。①JARVIS の `staff_directive` に `store` を持たせ（「FRANK」「姫路」等の店舗名で解決／1つに決まらなければ寄せない）、店舗が決まらないときは**既定1件ではなく全店**へ送る。②本人が1店舗しか所属していなければその店に寄せる。③Genesisの /notice は**選択肢に店舗名**を出し、「全店に送る」を明示的に選んだときだけ両方へ出す（「やること」も送った店それぞれに作る）。④ホームの承認カードの実行プランに**送信先の店舗名**を出す（承認する前に分かる）。

  **(i) /notice の送信が「積んだだけで永久に届かない」状態だったのを直した。** `sendStaffNotice` は `gn_line_outbox` に status='pending' で積み、n8nが拾う設計のままだったが、**その拾い役は #102 以降存在しない**。スタッフ用OAのトークンでその場でPushし、outboxは履歴（sent / error）として残す。送れなかったグループ名は画面に返す（「送ったつもりで届いていない」を作らない）。

  実装: `apps/genesis/src/lib/{ceo-ai.ts, jarvis.ts, judgment-feed.ts, staff-notice.ts}`、`apps/genesis/src/app/(main)/notice/notice-client.tsx`、`apps/member-os/src/{lib/walkin.ts, app/(main)/actions.ts（updateCounseling）, app/(main)/visit-row.tsx, app/api/ledger-export/route.ts}`。member-os / genesis の `tsc --noEmit` と `next build` 通過・テスト561件通過（クラウドでcloneして実走）

- #199 (2026-09-03) **パーソナルレッスン(25分)のチケットを作り、9月入会に2枚プレゼントし、会員ページで買えるようにした**（migration 0141適用済）。ユーザー指示「現在９月入会でパーソナルチケット２５分のチケット２枚プレゼントキャンペーンをしています。９月入会の方はそれを付与しておいてください。また会員ページからもレッスンチケットを購入、チケット保有枚数などを確認できるようにしてください」。

  **(a) チケットは「1行=1枚」ではなく増減の台帳（`frunk_lesson_tickets`）。** 残枚数＝`sum(qty) where status='granted'`。付与(+2)・購入(+1)・利用(-1) が1本の時系列に並ぶので、**お客様に「なぜ2枚なのか」を聞かれてその場で答えられる**。会員行に枚数カラムを持たせると、必ず履歴と食い違う。

  **(b) 付与の条件は `@yozan/core/frank-lesson-tickets` に1か所。** 入口が2つある（店頭の承認＝member-os `/frunk`／Web入会の入金確定＝genesis `activateWebJoin`）ので、条件をどちらかに書くと必ずズレる。対象は**入会日が9/1〜9/30・在籍中・一般公開プラン（`public_signup`）・法人でない・法人の利用者行でない**（ユーザー選択「一般プランのみ・9月中自動」）＝スタッフ／テスト／モニターには付かない。**二重付与はDBの一意索引（member_id × campaign）が最後の砦**で、画面の作りに頼らない。既に9月入会だった方には 0141 の中で付与済み（実測1名＝FR0009 木之下様。他の9月入会5名はスタッフプランのため対象外）。

  **(c) お支払いは「カード → 無ければ店頭」**（ユーザー選択）。登録カードがあればその場で決済して**すぐ使える**。無い／失敗したら**お申し込みは残して `status='pending_payment'`＝残枚数には入れない**。スタッフが店頭で受け取り【受領】を押して初めて有効になる。**お客様の前で申し込みを失敗させない**（モバイルオーダー #154 と同じ方針）が、**払っていないチケットは使えない**の両立。

  **(d) 有効期限なし**（ユーザー選択）。期限切れの苦情も、期限を管理する仕事も作らない。

  **(e) 消費は打席予約のレッスン確定時に自動。** `/reservations` でパーソナルレッスンを confirmed にした瞬間に1枚引き、その予約の `lesson_option_fee` を0にする（画面表示も「¥2,500」→「チケット1枚」＝**レジで二重に請求しない**）。お断り・取り消しで戻す。**二重消費は「予約1件につき1枚」の一意索引**で止める。戻しは +1 の行を足さず**使った行を `void`** にする（残高は合うのに履歴が読めない、を作らない）。予約を通さない店頭レッスンは会員カードの【1枚使う】。

  **(f) 金額の正典は `BookingCfg.lesson_option.price`（税抜2,500）。** 料金変更は `gn_site_content` の1か所でデプロイ不要。**お客様に見せるのは必ず税込**（2,750円・総額表示義務／`frank-tax.ts`）。一度に買えるのは10枚まで（押し間違いの事故防止）。

  **(g) 会員ページ `/member/tickets`** — 残枚数を大きく／購入（枚数±・押す前に税込総額を表示）／履歴（付与・購入・利用）。マイページにも「残り◯枚」を出す（**開かないと分からない、を作らない**）。スタッフ側は会員カードに残枚数・履歴・受領・付与・1枚使う。

  **(h) 公式サイトの回数券の表記を取り下げた**（2026-09-03 ユーザー指示「4回チケット 9,000円／8回チケット 16,000円 これは削除しておいてください」）。サイトは「25分マンツーマン 2,500円 ／ 4回チケット 9,000円 ／ 8回チケット 16,000円」と出していたが、**売っているのは1枚2,500円だけ**なので、残すとお客様の期待と店の実務が食い違う（「HPに書いてある4回券をください」に応えられない）。`sites/frank-golf/assets/site-data.js` の `price.lessonPrice` を **「25分マンツーマン 2,500円」** に変更（**静的サイトのデータ1行・_build.py の再実行は不要**、frank-golf のデプロイのみ）。「レッスンチケットもご用意しています」「チケット制も選べます」の表現は**そのまま残す**（1枚単位のチケットは実在するため嘘にならない）。

  実装: `supabase/migrations/0141_frank_lesson_tickets.sql`、`packages/core/src/frank-lesson-tickets.ts`（新規）、`apps/member-os/src/lib/frank-tickets.ts`（新規）、`apps/member-os/src/app/member/tickets/*`（新規）、`apps/member-os/src/app/member/page.tsx`、`apps/member-os/src/app/(main)/frunk/{actions.ts, [id]/page.tsx}`、`apps/member-os/src/app/(main)/reservations/{actions.ts, page.tsx}`、`apps/genesis/src/lib/frank-join.ts`。member-os / genesis の `tsc --noEmit` と `next build` 通過・テスト561件通過（クラウドでcloneして実走）

- #200 (2026-09-03) **予約の変更が「黙って元に戻る」のをやめ、体験予約ページの曜日ズレ（9/2 水 → 火）を直した**（migrationなし）。ユーザー報告「金田さんの打席と日付を変更したところ画面が前の予約に戻っています」「お客様から2日の予約を取ったときに火曜日と表示されていたと連絡がありました」。

  **(a) 予約の変更は、拒否した理由を1つも出していなかった。** `updateBooking` は 定休日／営業時間外／他の予約と重なる／レッスン枠と重なる／保存エラー のすべてで `return back(date)` ＝**画面を作り直して元の日に戻すだけ**。スタッフから見ると「保存を押しても何も起きない・前の予約のまま」にしか見えない。実測でも 9/3 に `frank.booking.update` の監査ログが1件も無く、**DBは1文字も変わっていない**＝どれかの条件で弾かれていた（金田様の体験は 9/2 11:04 に 9/6→9/4 へ移した状態のまま）。

  **(b) すべての拒否に理由を付けて画面に返す**（`refuse()`）。「9/8 は定休日・休業日のため予約を入れられません」「A打席は 9/4 14:00〜15:00 に別のご予約が入っています」のように、**どこが埋まっているかまで書く**。予約画面の上部に赤帯で出す（`?err=`）。

  **(c) 変更できたときは、変更後の日へ連れて行く**（`moved()`）。日付を変えても画面は変更前の日を映したままだったので、**その日にはもう無い＝「消えた／元に戻った」に見えていた**。緑帯で「9/6 → 9/4 14:00〜15:00 A打席 に変更しました」と出し、`?date=` も新しい日にする。

  **(d) お客様へのメール送信で例外が出ても、変更は成功のまま返す。** これまでは Resend が落ちると予約は直っているのに画面がエラーになり、「保存できていない」と勘違いして二重に直すことになっていた。送れたかどうかは帯の文言に足す。

  **(e) 体験予約ページの曜日が1日ずれていた。** `new Date("2026-09-02T00:00:00+09:00")` は UTC では **9/1 15:00Z**。そこへ `getUTCDay()` を掛けると**前日の曜日**が返る。カレンダーの日付ボタンは別経路（`jstNow()`＋`getUTC*`）で正しかったため、**選んだ日は正しいのに「選択中」と完了画面と キャンセル画面だけが火曜と表示**されていた（9/2＝水／火は定休日なのでお客様が不安になる）。3か所を `"T00:00:00Z"` に統一。**日付そのものは正しく入っているので予約の入れ直しは不要**。

  **(f) 同じ間違いを二度としないための見張り**: `tests/frank-site-weekday.test.ts` — サイトのinline JSはimportできないので、**書き方（`T00:00:00+09:00` の混入）をテストで禁止**し、Zで読めば 9/2=水・9/8=火 になることを固定した。旧実装が火を返すことも記録として残している。

  実装: `apps/member-os/src/app/(main)/reservations/{actions.ts, page.tsx}`、`sites/frank-golf/{trial-booking.html, _build.py}`、`tests/frank-site-weekday.test.ts`（新規）。member-os の `tsc --noEmit` と `next build` 通過・テスト563件通過（クラウドでcloneして実走）

- #201 (2026-09-03) **会話メモ・計測を「本日のレッスン」に紐づけ、お客様への説明もAIが書くようにした**（migration 0142適用済）。ユーザー指示「会話メモを本日のレッスンのところに紐付けて、前回のレッスンで何を言っていたかもそのページで表示してください」「お客様への説明も、お客様用の文章に直して生成するようにしてください」「確認して保存を押したら、本日のレッスンのスイング動画のところに紐付いて保存されるように」「計測も本日のレッスンにレッスンデータとして紐付けれるように」「お客さんには、計測データももしあれば表示する、なければ表示しない」。

  **(a) 症状だった構造: カルテのタブが完全に分かれていた。** 本日のレッスン（動画）／会話メモ（録音とAI下書き）／計測（トラックマン）が別々で、**レッスン中にタブを行き来しないと「今日のレッスン」が1枚に見えない**。お客様に見せながら話せる画面が無かった。

  **(b) コピーせずに紐づける。** 会話メモの本文を `lsn_comments` に複製すると、あとから先生がメモを直したときに**動画側の文だけ古いまま残る**（必ずズレる）。`lsn_lesson_notes.video_id` で指すだけにして、正典は `lsn_lesson_notes` のまま。計測は 0041 の時点で `lsn_measurements.video_id` を用意してあったのに画面から一度も使っていなかったので、そこへ入れる（列の追加は不要）。

  **(c) 紐づけ先は「その日の最後に撮ったスイング動画」**（ユーザー選択）。保存を押した時点で自動で決める＝押す回数を増やさない。**その日に動画が無ければ null のまま＝日付だけのカードとして残す**（消さない）。付け替えたいときだけ選択欄を触る（`setNoteVideo`）。保存前のメモも画面上はその日の最後の動画の下に出す＝**保存の前後で場所が変わらない**。

  **(d) 「確認して保存」が先生の記録しか保存していなかった。** お客様への説明は欄から離れたときに裏で保存する作りで、**押した内容と保存される内容が違った**。1回の保存で 先生の記録・お客様への説明・動画への紐づけ をまとめて確定する。

  **(e) お客様への説明はAIが今日の会話から書く**（ユーザー選択「AIが自由に書く」）。それまではナレッジの標準説明（`sc_knowledge.client_explanation`）を最大3件そのまま貼っていたが、**毎回ほぼ同じ文になり「今日の話」にならなかった**。要約と**同じ1回の呼び出し**で `body`（先生の記録＝先生の言葉のまま）と `client`（お客様向け・150〜250字・専門用語を噛み砕く・評価しない）を両方作らせる＝**AIを2回呼ばないので待ち時間が増えない**。⚠ **先生の記録をAIに書き直させる話ではない**（#181 の柱は生きている）。症状タグ（分類）も従来どおり続ける＝記録が数えられる資産であることは変わらない。ナレッジを下敷きにする連携は別途。

  **(f) 前回のふりかえりを本日のレッスンの先頭に。** 前回の「直したこと／出した宿題／次回みるところ」を最初に出す（#179で見送っていた項目）。今日いちばん最初に見たいものが最初に出る。

  **(g) お客様の画面は「あれば出す・なければ出さない」。** 紐づいた計測がある動画の下にだけレッスンデータを出す。項目は**8つに絞る**（クラブスピード／ボールスピード／ミート率／打ち出し角／スピン量／キャリー／クラブパス／フェースアングル・`CLIENT_FIELDS`／ユーザー選択）。22項目を全部並べてもお客様は読めない。前回比は**同じクラブの1つ前**とだけ比べる（ドライバーと7番アイアンを比べても意味がない）。良し悪しは決めつけず増減だけ出す。

  **(h) 生成の待ち時間を消した**（ユーザー選択）。それまでは 止める→12MBを丸ごと送る→文字起こし(最大4分)→**そのあと**症状タグ(最大1分半) が全部直列で、その間コーチは画面の前で待っていた。
  ・**録音しながら5秒ずつ送る**（`createNotePartUploadUrl` → `finishNoteParts` がサーバー側で結合）。止めてから送るのは最後の数秒だけ。**断片が1つでも欠けたら結合しない**（欠けた音声で要約すると嘘が混ざる）＝丸ごと送り直す従来の道にそのまま落ちる。
  ・**要約は投げっぱなしにして画面はポーリングで追う。** 本文は症状タグより先に入るので途中経過がそのまま出る。
  ・**会話メモのパネルはタブを移っても閉じない**（`hidden` にするだけ）。閉じると録音が止まり、裏の進み具合も見失う。**録音したまま本日のレッスンで撮影できる**。

  実装: `supabase/migrations/0142_lesson_note_video_link.sql`、`apps/lesson-os/src/app/(main)/students/[id]/{actions.ts, karte-client.tsx, lesson-note.tsx, measure-panel.tsx, page.tsx}`、`apps/lesson-os/src/app/s/[token]/page.tsx`、`apps/lesson-os/src/lib/{lesson-note-ai.ts, trackman.ts}`、`apps/lesson-os/src/app/api/lesson-note/summarize/route.ts`。lesson-os の `tsc --noEmit` 通過

- #202 (2026-09-03) **音が鳴ったときに「何が届いたのか」を1行で出すようにした**（migrationなし）。ユーザー依頼「体験予約や通知が来たときに音が鳴るのはいいですが、それが何の内容なのかを通知するようにしてください」。

  **(a) これまでは音と「予約に動きがありました」だけだった。** 鳴った理由が分からないと、どの画面のどこを探せばいいのか分からない。**そのうち鳴っても何もしなくなり、本当に困る通知まで見逃す**——通知として最悪の壊れ方になる手前だった。

  **(b) 鳴った理由を1行にする。** 「体験 ／ 9/5(土) 13:00 ／ 岸田 拓也 様 ／ C打席」「注文 ／ A打席 ／ 福島 晃 様 ／ コーヒー×1・トースト×2 ／ 14:32」。**区分・いつ・だれ・どこ（注文は何を）**を必ず入れる。日程が決まっていない体験申込は「日程未定」と言い切る（空欄で流さない）。

  **(c) 直近5件は消さずに残す。** 手が離せなくて見逃しても、あとから読み返せる。消すのは「確認したので消す」を押したときだけ。**流れて消える通知は、忙しいときほど役に立たない。**

  **(d) 文字を作るところは純関数に切り出した**（`lib/live-feed-pure.ts`）。DBもReactも触らないのでテストで固定できる（`tests/live-feed.test.ts` 8件）。曜日は #200 と同じく `T00:00:00Z` で読む＝**同じ日付ズレを二度作らない**。

  **(e) 出す場所は3画面**（ユーザー選択「電子伝票も含めて全部」）: 予約（/reservations）・体験申込（/trials）・電子伝票（/orders）。電子伝票は伝票カードが下に並んでいるが、**鳴った瞬間に「どこへ・何を」だけ読めたほうが速い**ので上部に出す。

  **(f) 開いた瞬間には出さない。** 画面を開いた時点で並んでいるものは既読として扱う（開くたびに5件の帯が出ると、それも見なくなる）。

  実装: `apps/member-os/src/lib/live-feed-pure.ts`（新規）、`apps/member-os/src/lib/frank-reservation.ts`（`loadLiveItems`）、`apps/member-os/src/components/live-refresh.tsx`、`apps/member-os/src/app/(main)/{reservations,trials}/page.tsx`、`apps/member-os/src/app/orders/{page.tsx,live.tsx}`、`tests/live-feed.test.ts`（新規）。member-os の `tsc --noEmit` と `next build` 通過・テスト571件通過（クラウドでcloneして実走）

- #203 (2026-09-03) **骨格を「モデルが返したまま」保存するのをやめ、スイング1本ぶんまとめて直してから使うようにした**（migrationなし）。きっかけはユーザー提供の3次元姿勢推定の研究資料（多視点2次元姿勢からの3次元再構成／リフティングモデルの自前学習）。**うちは単眼iPhone1台なので3次元再構成そのものは採らず、資料が「最適化の制約」として使っていた3つを「明らかにおかしい点を見つける物差し」に読み替えて入れた。**

  **(a) 骨の長さの一定性 → 伸びた骨は遠い側の点を疑う。** 体の骨の長さはスイング中ずっと変わらない。画面に映る長さは向きによって**縮む**ことはあっても**伸びる**ことはない（投影）。だから「本来の長さ」の目安はスイング中の長さの90パーセンタイル（いちばん伸びて写ったとき）で、その1.3倍を超えたコマは肘や手首が飛んでいる。**縮んだコマは直さない**（前傾やDTLでは正しく縮む）。

  **(b) 左右対称性 → 直さずに「点検」だけ。** 3次元なら左右の骨は同じ長さなので、資料は損失関数に対称性の項を足していた。**2Dでこれを補正に使うと嘘になる**（向きで縮むぶんまで揃えてしまう）。左右差40%以上は「片側が体に隠れて取れていない」の合図なので、画面に⚠として出すだけにした。

  **(c) 鏡像の判定 → 左右ラベルの入れ替わりの検出。** 資料はカメラの並び順で鏡像を判定していた。単眼版は「前のコマと比べて、左右を入れ替えたほうが明らかに近いか」で見る。後方（DTL）から撮ると体が真横を向くので MediaPipe は数コマだけ左右を取り違える。**クラブ候補の抽出は両手首・両肩・両足首の *中点* しか使っていないので、ここは影響を受けない**（中点は入れ替えても動かない）。

  **(d) 時間方向の滑らかさ → 平滑化ではなく「行って戻る飛び」だけを直す。** ダウンスイングは30fpsでも1コマで手元が画面の1割動く。**低域通過をかけるといちばん速いところが鈍って、インパクトが別のスイングになる。** そこで「距離が大きいか」ではなく「出ていって戻ってきたか」（前後2コマの距離が往復の和の0.4未満）で判定する。**行ったきり戻らない速い動きには触らない**（テストで固定）。

  **(e) スイング全体で共通の物差しを1つ持つ。** 資料の「腰の平均位置・人物の平均高さで全フレームを共通に正規化する」（コマごとに腰を原点に固定すると重心移動が消える、という話）と同じ考え方。うちも肩〜足首の**中央値**を1本につき1つ決めて分母に使う。コマごとの肩幅で割ると、肩幅のブレまで数字に乗る。

  **(f) モデルを lite → full にした。** 「軽いほうが速い」で lite を選んでいたが、**ここは撮り終わった動画のコマ送りでリアルタイムではない**。1コマの推論より動画のシークのほうが長く、軽いモデルを選ぶ理由が最初から無かった。lite は手首から先・足首から先が特に弱い。full は約9MB（初回だけ・以降はブラウザのキャッシュ）。端末に無ければ lite → CDN の順に落ちる。

  **(g) 骨格に渡す画像を差分用と分けた（640 → 960）。** 「モデルの入力は256pxだから上げても無駄」というコメントは誤りだった。256pxに縮むのは**人物を切り抜いたあと**で、切り抜き元はこちらが渡した画像。640の画面に人が6割で写ると切り抜きは約380px、後方から小さく写ると256pxを割って手足の先から情報が落ちる。**毎コマ全画素を読むクラブの差分用は640のまま**（こちらを上げると重くなる）。

  **(h) 直した件数は画面に出す。** 「きれいに出た」のか「直した結果きれいに見えている」のかは、コーチが角度の数字を読むときに知っておくべき差。黙って直さない。`diag.pose` に残すので、次に開いたときも消えない（#185 の verdict をここで落としていた轍を踏まない）。

  **採らなかったもの:** 多視点3次元再構成（AniPose）と 2次元→3次元リフティングモデルの自前学習。**カメラ3台と据え置きの三脚が要る**ので、iPhone1台で撮る今の運用には載らない。資料の警告（パース・焦点距離の曖昧さで鏡像や左右の脚長の食い違いが起きる）は、将来スタジオに固定2〜3台を置くときに効く。**17関節では表現できないとして資料が除外した「手首のコック」「かかとの浮き」は、BlazePose 33関節なら親指(21,22)・かかと(29,30)・つま先(31,32)があるので取れる**——ただし lite では飛びすぎていた。full にしたので次の候補。

  実装: `apps/lesson-os/src/lib/pose.ts`（`cleanPose` 新規・`MODELS`・`POSE_EDGE`）、`apps/lesson-os/scripts/prepare-mediapipe.mjs`、`apps/lesson-os/src/app/(main)/students/[id]/{actions.ts, video-player.tsx}`、`tests/pose-clean.test.ts`（新規9件）。lesson-os の `tsc --noEmit` と `next build` 通過・テスト580件通過（クラウドでcloneして実走）

- #206 (2026-09-03) **FRANK 法人プランを「無記名でご入会・使う人だけ記名」に変えた**（migration 0144適用済）。ユーザー指摘「法人の入会が記名制になっていますよ、無記名で使えるようにしたいです。利用者登録は会員ページで追加できるようにしてください。会員表記は法人名＋個人名。利用する人に関しては利用者登録は必須。法人名義での予約数なども制限のために表示してください」。

  **(a) 何が詰まっていたか。** #195 の申込フォームは、ご利用者のお名前と電話番号を**その場で全員ぶん**必須にしていた。法人の商談は「まず契約して、使う人はあとで決める」順に進むので、**決裁が下りた会社ほど申し込めない**。人事異動のたびに店舗へ電話が来て、スタッフが member-os で入れ替えていた（会社側からは何も直せなかった）。

  **(b) 入会は無記名、利用は記名。** 申込は会社名・ご担当者・請求先だけで成立させる（`corporate_users` は null で登録）。そのうえで**打席を使う人は必ずご登録いただく**。ここを緩めなかったのは、誰が来たかが会社名しか残らないと**レッスンカルテを分けられず、会員証QRも出せない**ため。ご利用者の追加・削除はご契約者が **会員ページ `/member/corporate`** から行う（正典 `apps/member-os/src/app/member/corporate/actions.ts`。店頭の `frunk/actions.ts` と**行の作り方は `@yozan/core/frank-corporate-members` の1か所**のまま）。

  **(c) ご契約者は「お支払い専用」にした。** ご担当者ご自身が使う場合は `corporate_self_use` を立てていただく（人数にも1名として数える）。判定は `canBookAsCorporate`。⚠ **既存の法人契約者は migration で true に埋めている** — #195 の申込フォームが「ご担当者様がご利用になる場合は同じ内容をご入力ください」と案内しており、契約者行で予約できる前提で運用が始まっていたため。false のまま出すと、その方が翌日から予約できなくなる。

  **(d) 人数はライト2名・プレミアム無制限**（ユーザー確定）。`frunk_plans.max_users` の **null を「無制限」に読み替えた**。⚠ `?? 2` のように既定値へ落とすと、無制限のはずのプランが2名で止まる（`corporateSpec` で null を保つ）。プランの違いは**同時に押さえられるコマ数**（ライト4・プレミアム8）に寄せた。

  **(e) 枠は必ず画面に出す。** 人数が無制限でも同時に押さえられるのは8コマのまま＝**1人が押さえ切ると他の方は取れない**。会員ホーム・予約画面・【ご利用者の管理】・スタッフの会員カードの4か所に「御社名義のご予約 n／8コマ」を出す（言い回しは `slotUsageLabel` の1か所）。数え方は #195 の `openSlots` のまま変えていない。

  **(f) 会員表記は「法人名＋個人名」。** `memberDisplayName` を core に置き、会員ポータル・会員一覧/詳細・予約台帳・電子伝票・チェックイン・予約の会員候補で通す。会員検索（`frunk-member-search`）も `company_name` を対象に加えた＝「株式会社◯◯の誰か」で引ける。

  **(g) 外すときは先のご予約を見る。** 予約を残したまま登録を外すと、本人はログインできなくなり、その予約を**誰もキャンセルできないまま御社の枠が埋まり続ける**（枠は消化されるまで戻らない）。件数を出して止める。

  実装: `packages/core/src/frank-corporate.ts`（`corporateSeats`・`memberDisplayName`・`canBookAsCorporate`・`slotUsageLabel`）、`apps/member-os/src/app/member/corporate/{page.tsx,actions.ts}`（新規）、`apps/member-os/src/lib/{member.ts,frank-mail.ts,frank-member-no.ts,frank-portal.ts,frank-reservation.ts,frunk-member-search.ts}`、`apps/member-os/src/app/join-web/*`、`apps/genesis/src/lib/{frank-booking.ts,frank-join.ts}`、`supabase/migrations/0144_frank_corporate_open.sql`、`sites/frank-golf/{_build.py,assets/site-data.js}`、`tests/frank-corporate.test.ts`（18件）。member-os / genesis の `tsc --noEmit` 通過・全585件パス

- #204 (2026-09-03) **当月体験人数と入会率の数え方を直した**（migration 0143適用済）。ユーザー報告「当月体験人数と入会率の数字がおかしいですチェックしてください」。実測すると**2つ壊れていた**。

  **(a) 体験人数に「まだ来ていない予約」が混ざっていた。** FRANKは体験予約が入った瞬間に受付台帳へ行を作る（#139）。`visited_on` は**予約日**なので、9/4以降の予約15件も「当月の体験」として数えていた（9月28件のうち**来店済は13件**）。開店直後で先の予約が積み上がるほど、実績が実態より大きく見える。

  **(b) 入会率が構造的に必ず 0.0% だった。** 分子は受付台帳の `result='join'`（台帳で【入会】を押した行）だけ。**FRANKの入会はWeb入会で `frunk_members` に入るので、誰も押していない**。実際には9月の体験から2名（FR0009・FR0010）が入会しているのに 0% と出ていた＝**押し忘れではなく、押す場所が業務動線に存在しない**。

  **(c) 入会は「会員台帳との照合」でも数える。** 体験のお客様（`mbr_guests`）と `frunk_members` を**電話下10桁／メール**で突き合わせる。誤カウントを避けるため **同じ店舗・一般公開プラン（`public_signup`／法人と法人利用者行は除く）・入会日 >= 体験日** に限る（スタッフ／テスト／モニター、体験より前からの会員は数えない）。従来の `result='join'`（GOLF WINGの台帳・名簿経路）も引き続き有効で、**どちらかが立てば入会**。

  **(d) 率の分母は「来店済」。** これから来る予約で割ると、**予約が入るほど率が下がる＝実態と逆に動く数字**になる。件数（当月合計）は今までどおり出し、`notes` に「来店済◯件・これから◯件」の内訳を書いてカード上で説明できるようにした。

  **(e) 計算は `app.trial_kpi_monthly` の1か所に置いた**（全店合算と店舗別で式が割れないように）。`refresh_member_kpis` はこれを呼ぶだけ。member-os の GOLF WING ダッシュボードも同じ考え方に揃え、体験数・フィッティング件数を**来店済**で数え、「これから◯件」を注記に出す（率が先の予約で薄まらないように）。

  適用後の実測: **FRANK 9月＝体験28件（来店済13・これから15）／入会2名 → 15.4%**。GOLF WING は 7月 13件・9名＝69.2%／8月 8件・5名＝62.5% と従来値のまま（過去の集計を壊していない）。

  ⚠ 残（運用の判断）: **30件の体験予約すべてが `status='confirmed'` のままで、【来店】を誰も押していない**。いまは「日付が過ぎた＝来た」とみなしているので、無断キャンセルも体験に数える。正確に出すなら来店を押す運用が要る（押さなくても数字は出るので、業務は止まらない）。

  実装: `supabase/migrations/0143_frank_trial_kpi_fix.sql`（`app.trial_kpi_monthly` 新設・`refresh_member_kpis` 差し替え）、`apps/member-os/src/app/(main)/dashboard/page.tsx`。member-os の `tsc --noEmit` と `next build` 通過

- #205 (2026-09-03) **FRANK は【来店】を押さなくても来店として扱う**（migrationなし・既存データは投入済み）。ユーザー指示「フランクゴルフに関しては来店を押さなくても来店としてください」（#204 で「30件すべて未押下」と報告した回答）。

  **(a) 押させる運用に賭けない。** 実測で9月の体験予約30件すべてが `confirmed` のまま＝**【来店】は一度も押されていなかった**。押す前提の数字（体験人数・入会率・来店履歴）は、押されない限り永遠に出ない。**押さなくても正しい方に倒す**。

  **(b) 判定は「終了時刻を過ぎたか」**（ユーザー追加指示「翌朝ではなく、レッスン時間を過ぎたら来店済みに」）。`lib/frank-visit-cron.ts` を **10分ごとの `/api/cron/execute`** に乗せた＝**レッスンが終われば最大10分で来店になる**（翌朝までのタイムラグを作らない）。前日以前は全部、当日は `end_time` を過ぎたものだけ（**まだ打っている人を来店済にしない**）。日次cronからも呼ぶ（10分cronが止まっていても翌朝には必ず揃う二重の保険）。触るのは `confirmed` だけで **cancelled / no_show / visited には触らない**（スタッフが決めた事実を上書きしない）、**GOLF WING は対象外**（あちらは Smart Hello が正典）。体験は申込側も `done` にそろえ、受付台帳に `arrived_at`（予約開始時刻）を入れる＝打刻の代わり。

  **(c) 自動で来店にする以上、「来なかった人」を外す道が要る。** 【無断欠】を押したら**受付台帳から下げる**ようにした（従来はキャンセルのみ下げ、no_show は台帳に残って体験人数に混ざっていた）。来店に戻せばまた載る。予約画面には「【来店】は押さなくて大丈夫。**来られなかった方だけ【無断欠】**」と常時書いておく。

  **(d) 既存データも合わせた**（2026-09-03 18:08 JST 実行）: 9/2以前の8件＋当日の終了済み3件（10:00/11:00×2/14:00開始）を visited に、体験申込10件を done に、受付台帳10行に arrived_at を投入。**その時点で進行中だった18:00〜と19:00〜は confirmed のまま**＝終了時刻を過ぎてから自動で切り替わる。

  **(e) KPI は変わらない。** #204 の体験人数・入会率は元から日付ベース（visited_on <= 今日）で数えているので、status とついに一致した形。無断欠が台帳から下がるぶん、これからは実態に近づく。

  実装: `apps/genesis/src/lib/frank-visit-cron.ts`（新規）、`apps/genesis/src/app/api/cron/{execute,daily}/route.ts`、`apps/member-os/src/app/(main)/reservations/{actions.ts, page.tsx}`。genesis / member-os の `tsc --noEmit` と `next build` 通過・テスト571件通過

- #207 (2026-09-03) **AIカルテナレッジに音声メモを載せ、ナレッジを「自動で追加」ではなく「候補として溜めて人が採用する」形にした**（migration 0145適用済）。ユーザー提案「lesson-osについている音声メモの機能をナレッジにつけていこうと思います。PGA NOTEの補助システムとして売り出す予定です。カルテナレッジ開く→音声録音開始→ナレッジを検索しながらレッスン→録音終了→コメントの生成→この時の生成内容がナレッジになければ追加（1日に一回自動追加、完成度の高い生成のみを採用）という方式はどうおもいますか？」。**流れはそのまま採り、自動追加だけを変えた。**

  **(a) 生成をナレッジ本体に自動で書かない。** 理由は3つ。①ナレッジは売り物の芯で、1日1件でも半年で180件＝GOLF WING 40症状・津 33症状という元の量を超える（誰も承認していないもので芯が埋まる）。②「完成度の高いものだけ採用」の判定をAIにさせると**自分の答案を自分で採点する**ことになる（2026-08-28 の自律進化の検証で、進化したエージェントが減点していたログのほうを消して満点を取った実例を確認している）。③`jp-search` は言い換えを同じ症状に寄せる作りなので、言い換え症状が自動で増えると**診断が2つに割れて両方痩せる**。→ AIが出した知識は `sc_knowledge_candidates` に溜めるだけ。`sc_symptoms`/`sc_checkpoints`/`sc_knowledge` に書く入口は **`settings/candidate-actions.ts` の採用ボタンだけ**。

  **(b) 昇格の門は「AIの自己採点」ではなく「別々の日に3回」。** `hits` は回数ではなく**出た日数**として数える（同じレッスンの中で同じ話が繰り返されるのは普通なので、素の回数では門にならない）。AIが操作できない外側の事実であり、かつ「この教室で本当に繰り返し使われている言葉」という堀そのものの意味を持つ。判定は純関数 `lib/candidates.ts` に置いてテストで固定（`tests/swing-cortex-candidates.test.ts` 7件）。

  **(c) 寄せ先もAIに決めさせない。** 候補をどの症状・確認項目に置くかは `jp-search` のあいまい一致（`placeCandidate`）。AIに既存IDを選ばせると無いIDを作って返してくる（lesson-note-ai の教訓）。**新しい症状を作るより、既存の確認項目に言い回し・ドリルを足すほうを優先**する。既存に足すときは本文を消さずに継ぎ足す（同じ文が二重に並ばないよう含有チェック）。採用したものは `source='learned'` ＝ manual/ai/seed/import と混ぜないので「AIが育てた知識 n件」が数えられる。

  **(d) 生徒には紐づけない**（ユーザー指示「現在このシステムで生徒との紐づけは考えていない」）。録音1本＝1レッスンで完結するので、生徒CRMの無い **standard プランのまま載る**＝売っている仕様のまま出せる。出口は **PGA NOTE に貼るテキスト**で、PGA NOTE 側への自動投入はしない（相手のシステムに書きに行くと障害の切り分けができなくなる）。

  **(e) 録音バーはレイアウトに置く。** 現場の使い方が「録音しながら症状を検索する」なので、ページの中に置くと画面遷移で作り直されて録音が止まる。同意チェック・5秒ごとの逐次アップロード・Wake Lock・要約後の音声自動削除は lesson-os #179/#201 と同じ作り（**2回目なので `packages/` への切り出し対象**。今回はまだ切り出していない）。昇格の判定は設計では毎晩のバッチだったが、純粋な計算で軽いので**録音のたびに走らせて cron を1本も増やさなかった**（結果は同じ）。

  実装: `apps/swing-cortex` に `lib/candidates.ts`・`lib/voice-note-ai.ts`・`(main)/note-actions.ts`・`(main)/voice-bar.tsx`・`(main)/note/{page,note-client}.tsx`・`(main)/settings/{candidate-actions.ts,candidates-client.tsx}`・`api/voice-note/summarize/route.ts`（新規）、`(main)/{layout,nav}.tsx`・`settings/page.tsx`（更新）。migration `0145_cortex_voice_note.sql`（`sc_voice_notes`・`sc_knowledge_candidates`・`cortex-audio` バケット・`sc_knowledge.source` に `learned` を追加）。正典 `docs/modules/swing-cortex/VOICE_NOTE.md`。tsc 通過・**next build はクラウドで実走して通過**（ユーザーPCのVMは Bus error）・テスト592件通過。

  ⚠ **外販テナントで有効化する前に、録音同意（規約の条項・店頭掲示・契約書）を先に固める。** 当面テナントを跨いだ知識の共有はしない。

- #207 (2026-09-03) **会員ページの【レッスンカルテ】が一部の会員に出ていなかったのを直し、本日のレッスンに「お客様への説明」と「コーチ向けのレッスン内容」を並べた**（migrationなし）。ユーザー報告「会員ページからレッスンノートに飛ぶところが僕のはあるのですが穴田君の分がないです」「本日のレッスンのコーチからのアドバイスでもお客様のコメントを表示してください。あと、その下にコーチ向けの生成したレッスン内容も」「僕らは前回のレッスンでお客様の説明文とコーチ向けのレッスン文章を見たいです」。

  **(a) 事故の形: リンクを出す条件が「共有トークンがあるか」だった。** トークンは Lesson OS でコーチが【生徒へ共有リンク】を押したときにしか作られない。押していない会員は、動画もレッスンメモもあるのに**会員ページにボタンがまったく出ない**（実測: 穴田様 FR0006＝動画2本・メモ2件・トークン0。古川・林・小川様などWeb入会組は #129 の経路で自動発行されていたので出ていた）。**押し忘れに誰も気づけない形で機能が消えていた**（[[alerts-must-be-fixable]] と同じ壊れ方）。

  **(b) 出す条件を「お客様に見せるものがあるか」に変えた**（`karteHasContent`＝動画が1本以上、またはお客様への説明が入ったメモが1件以上）。**トークンは会員ご本人が押したときに発行する**（`karteShareUrl` が無ければその場で作る）。ホームのHTMLにトークンは載らないまま（#155 の約束）。新着バッジ（`karteHasNew`）も**会話メモの説明を数に入れた**——動画を撮らない日でも説明は届くので、動画だけを見ていると「説明は増えているのにバッジが出ない」に戻る。

  **(c) 本日のレッスンの「コーチからのアドバイス」に2つの文章を並べた。** 順番は **お客様への説明 → コーチ向けのレッスン内容**。お客様の隣で開く画面なので、まずお客様に見せる文章が目に入る位置に置く。**本文はコピーせず `lsn_lesson_notes` の正典をそのまま映す**（0142の方針のまま）。**動画の無い日のレッスンでも描く**（従来はコーチコメント欄ごと動画がある時しか出なかった）。まだ確定していないメモには「※保存するまでお客様には出ません」を添える。

  **(d) 前回のふりかえりにも両方出す**（前回お客様にお伝えした説明／前回のコーチ向けレッスン内容）。前回の話を確認するのがこのカードの用なので、片方だけでは足りない。

  **(e) お客様の共有ページも日付で拾うようにした。** `video_id` は #201 の保存時にしか入らないので、それ以前のメモは全部「動画と関係のない一覧」に落ちていた。**同じ日の最後のスイングの下に出す**フォールバックを入れた（カルテ側と同じ規則・**過去データは書き換えない**）。

  **(f) 過去のメモに【お客様への説明を作る】を足した。** #201 より前のメモには説明が無く、**音声は約束どおり消えている**ので録音からは作り直せない。残っている**先生の記録と文字起こし**から作る（`writeClientExplanation`）。材料に無い助言・数値は足さない。作るのは下書きまでで、**お客様に出るのはコーチが保存を押したもの**という柱は変えていない。

  実装: `apps/member-os/src/lib/frank-portal.ts`、`apps/member-os/src/app/member/page.tsx`、`apps/lesson-os/src/app/(main)/students/[id]/{actions.ts, karte-client.tsx, lesson-note.tsx}`、`apps/lesson-os/src/lib/lesson-note-ai.ts`、`apps/lesson-os/src/app/s/[token]/page.tsx`。member-os / lesson-os の `tsc --noEmit` 通過・テスト592件通過

- #208 (2026-09-03) **入会申込が決済ページに飛ばないことがあったのを直した。原因は「電話番号の打ち間違い」で、Squareが決済リンクの発行そのものを断っていた**（migrationなし）。ユーザー報告「フランクゴルフの入会申し込み後に決済ページに飛ばないことがあります」。

  **(a) 何が起きていたか（実測・2026-09-03 18:53 JST）。** 立岩様の申込の電話番号が `0905655867`＝**携帯なのに10桁**（1桁足りない）。旧 `toE164Jp` は「0始まり10桁以上」を無条件で通すので `+81905655867` を作り、Squareの決済リンクAPIが `Invalid phone number.` で **400** を返した（Vercel runtime log `POST /api/public/frank/join-checkout 400` で確認）。電話番号は決済画面にあらかじめ入れておくだけの**おまけ**なのに、それが原因で**決済リンクごと作られなかった**。member-os はリンクが取れないと「承認待ち」画面に落ちるので、**お客様には申込成功に見えて、決済ページには一度も行けない**。DBにも足跡が残る＝`billing_status` が `checkout` にならず `none` のまま（Web入会の他の申込はすべて11桁で `checkout`/`active`。9桁のテスト入力は `toE164Jp` が null を返して**渡さなかった**ので通っていた＝10桁だけが地雷だった）。

  **(b) お客様の入力で決済を止めない。** `pre_populated_data`（メール・電話の事前入力）が原因と分かる失敗のときだけ、**prefill を外してもう一度だけリンクを作り直す**（`createPaymentLink`）。400は注文が作られないので二重注文にならない。それ以外のエラーは握りつぶさずそのまま投げる。

  **(c) 電話番号の判定は1か所に置いた（正典 `@yozan/core/jp-phone`）。** 携帯・IP（070/080/090/050）と020は11桁、0120は10桁、0800は11桁、それ以外の固定は10桁。ハイフン・全角・+81は正規化する。**画面（/join-web）とサーバー（actions.ts）が同じ関数を通す**（生年月日 #190 と同じ考え方）。`frank-pos-pure.toE164Jp` は中身を消してここへ再export＝**検証を通った番号しか E.164 を返さない**（怪しければ null＝渡さない）。テスト `tests/jp-phone.test.ts` 6件で実障害の番号を固定。

  **(d) 打ち間違いはその場で教える。** 入会フォームの電話番号欄に「携帯電話の番号は11桁です（入力は10桁です）」とその場で出す（[[alerts-must-be-fixable]]＝直せるところまで作る）。**会員ページのログインは電話番号の下4桁**なので、間違ったまま入会するとご本人が後で入れない。保存はハイフンなしの数字にそろえた。

  **(e) それでも決済ページを出せなかったら、黙って承認待ちにしない。** `frunk.join_checkout_failed`（severity=warning・理由と連絡先つき）を events に残し、お客様の画面にも**「お支払いはまだ完了していません」**と明記する（従来は緑の✓で成功と見分けが付かなかった）。/frunk 承認待ちの決済状況表示（#188）と合わせて、未入金のまま会員番号を出さない。

  実装: `packages/core/src/jp-phone.ts`（新規）・`packages/core/package.json`、`apps/genesis/src/lib/{frank-pos-pure.ts, frank-square-billing.ts}`、`apps/member-os/src/app/join-web/{actions.ts, web-join-form.tsx}`、`tests/jp-phone.test.ts`（新規）。genesis / member-os の `tsc --noEmit` 通過・テスト598件通過。

- #209 (2026-09-03) **会員ページからコーチの出勤予定を見られるようにした。出す人は「出すと決めた人だけ」（migration 0146適用済）。** ユーザー指示「会員ページにプロの出勤状況を確認できるようにしてください。藤田プロは絶対に表示しないように」。

  **(a) 除外リストにしなかった。** 「藤田プロを出さない」を素直に書くと除外リスト（この人だけ出さない）になるが、それは**新しく入ったスタッフ・店舗ログイン用のアカウント・他店の人が、何もしなくてもお客様の画面に出る**という意味になる。出してよい人を1人ずつ決める形（オプトイン）に変えた。`staff.member_page_role`（会員ページに出すときの肩書き）が**入っている人だけ**を返し、空の人は関数の入口で落とす。藤田プロは空＝どのルートを通っても出ない。初期設定は 小川うらら＝コーチ／穴田 賢太＝コーチ／林 和希＝スタッフ。

  **(b) 確定したシフトだけ出す。** `status='published'` のみ。下書きは店の中で検討している予定で、これを出すと「いると思って来たのにいない」を作る。休みの行（`is_day_off`）と、時間が入っていない行も出さない。

  **(c) 「定休日」と「未定」を書き分けた。** 誰もいない日を全部「未定」にすると、定休日に「そのうち決まるのかな」と待たせてしまう。営業時間の設定（`businessHours`）で店が開いていない日は**定休日**と出す。

  **(d) 開かないと分からない、を作らない。** マイページの一覧に「🏌️ コーチの出勤予定／本日 ◯◯・◯◯」と**本日いる人の名前まで**出す。詳細（/member/coaches）はこれから2週間ぶんを日付順に並べ、**予定は変更になる場合があります**と必ず添える。仮会員（入金前）には出さない。

  実装: `supabase/migrations/0146_staff_member_page_role.sql`（新規）、`apps/member-os/src/lib/frank-coach-shifts.ts`（新規）、`apps/member-os/src/app/member/coaches/page.tsx`（新規）、`apps/member-os/src/app/member/page.tsx`。member-os の `tsc --noEmit` 通過・`next build` 成功・テスト598件通過。

- #210 (2026-09-03) **レッスンノートを、共有URLを発行せずに会員ページの中で直接見られるようにした**（migrationなし）。ユーザー指示「リンクを発行せずに即時に見えるようにしてください」。

  **(a) それまでは「見るために秘密のURLを1本作る」作りだった。** 会員ページの【レッスンカルテ】は lesson-os の共有ページ `/s/<token>` へ飛ばしていた。#207 でトークンが無ければその場で発行するようにしたが、**見るたびに秘密のURLが増える**のは筋が悪い（漏れたら誰でも見られる・失効の管理が要る・会員ごとに何本あるか誰も把握していない）。

  **(b) 根拠を「秘密のURLを持っているか」から「誰としてログインしているか」に変えた。** `/member/lesson` を会員ページの中に作り、**ログインしている会員ご本人であること**（member セッション）だけを根拠に、会員番号 → `lsn_students.member_code` で引いたそのカルテの中身だけを描く。**トークンは1本も作らない**。

  **(c) 共有URL（`/s/<token>`）は残す。** 用途が違う——LINEで送る／会員でない体験の方に見せる。コーチが Lesson OS で必要なときだけ作る。`karteShareUrl` は**発行をやめて、あれば返すだけ**に戻した。旧 `/member/karte` は `/member/lesson` への転送だけにして、古いブックマークを死なせない。

  **(d) 出すものは共有ページと同じ**（スイング動画＝スロー・コマ送りつき／今日のレッスンの説明＝**先生が確認して保存した `share_body` だけ**／レッスンデータ＝紐づいた計測の8項目＋同じクラブの前回比／コーチからのアドバイス／お手本スイング）。文字起こしもAIの下書きもお客様には出さない（#179 の柱）。

  **(e) 同じものを2か所で描くことになったので、規則を `@yozan/core/lesson-share` に出した**（`CLIENT_FIELDS` 8項目・`latestVideoByDay`・`noteVideoId`・`diffOf`）。どちらかに書くと「会員ページには出るのに共有URLには出ない」が必ず起きる。`tests/lesson-share.test.ts` で 項目数と並び／古いメモの拾い方／変化なしの前回比を出さないこと を固定した（602件通過）。

  **(f) 署名URLはページ表示時に1回でまとめて発行**（`createSignedUrls`）。1本ずつ取ると本数ぶん往復して数秒待たされる（#143 と同じ理由）。サムネイルがある動画は `preload="none"`＝**お客様のギガを使わない**。開いた時点で `karte_seen_at` を進めるので、新着バッジは次に増えたときだけ出る。

  実装: `packages/core/src/lesson-share.ts`（新規）、`apps/member-os/src/app/member/lesson/{page.tsx, lesson-video.tsx}`（新規）、`apps/member-os/src/app/member/karte/route.ts`、`apps/member-os/src/app/member/page.tsx`、`apps/member-os/src/lib/frank-portal.ts`、`apps/lesson-os/src/{lib/trackman.ts, app/s/[token]/page.tsx}`、`tests/lesson-share.test.ts`（新規）。member-os / lesson-os の `tsc --noEmit` 通過・テスト602件通過

- #211 (2026-09-03) **林 和希をコーチに変更し、シフトで「キャディ」を選べるようにした**（migration 0147適用済・**コード変更なし**）。ユーザー指示「林君はコーチになりましたので変更お願いします。またシフトを組むときに林君がキャディーの選択ができるようにしてください」。

  **(a) どちらも「人ごとの設定」で決まる作りだったので、設定を変えただけ。** 会員ページに出す肩書きは `staff.member_page_role`（#209 のオプトイン欄）、シフトで選べる業務は `staff_schedule_types`（#147 の本人ごとの許可リスト）。**名前を条件に書いたコードは1行も足していない**——ここを場当たりに書くと、次に人が増えたときに必ずコードを触ることになる。

  **(b) キャディが出ていなかった理由。** 林さんだけ `staff_schedule_types` に行が無かった（古川博庸・小川うらら・穴田 賢太 の3名は #147 の時点で入っていた）。行が無い人は業務のプルダウンごと出ない。1行入れて解決。

  **(c) 同じことは画面からもできる。** `/admin/staff` → 本人 → **「シフトで選べる業務（この人のプルダウンに出るもの）」**のチェック。会員ページの肩書きも `staff.member_page_role` に文字を入れるだけ（空＝出さない）。**次からは私を通さずに変えられる**ことを申し送りとして残す。

  **(d) 業務区分は終日扱いのまま**（#147 の設計）。「キャディ 8:00〜15:00」のように時間を持たせたい場合は、いまの `shifts` は1人1日1行（`unique (staff_id, store_id, date)`）なので設計変更が要る。今回は要望に無いので触っていない。

  実装: `supabase/migrations/0147_hayashi_coach_and_caddy.sql`（新規・適用済）のみ。

- #212 (2026-09-03) **体験の同時受入数を「その時間にいるコーチの人数」で決めるようにした**（migrationなし）。ユーザー依頼「シフトを読み込んでコーチが２人いるときは２人まで対応可能、３人目不可。１人ときは１人まで」「現在体験が入っているところはそのままで大丈夫です」。

  **(a) これまでの上限は打席の数だった。** 体験は A→B→C の優先順で打席を自動割当していたので、**打席さえ空いていれば同じ時間に3件受けられた**（`pickBay`）。コーチが1人しかいない時間でも3件入る＝当日に人を増やせないのに予約だけ増える。

  **(b) 数に入れるのは会員ページの出勤予定に出している人**（`staff.member_page_role` が入っている人・#209 のオプトイン欄）。**専用のフラグを増やさなかった**——「お客様に見せる人」と「体験を担当する人」を別々に持つと、片方だけ直して食い違う。増やすときも1か所で済む。

  **(c) 確定（`status='published'`）シフトだけを見る。** 下書きは店の中の検討中の予定で、それで受け入れを増やすと「来たけれど担当がいない」を作る。業務区分（キャディ等）は終日扱いで時刻が無い＝店にいないので数えない。

  **(d) 体験の最初から最後まで在席する人だけ数える。** 18:45上がりの人に18:00開始（約55分）は任せられない。途中まで在席を1人と数えると、席だけ埋まって担当が消える。

  **(e) シフトがまだ確定していない日は2名まで**（`NO_SHIFT_CAPACITY`・ユーザー決定）。0にするとシフト作成が遅れた期間の申込が全部止まり、3（打席数）のままだと人が足りない時間に3件入る。**コーチの行が1件も無い日＝まだ決まっていない**と見なす（休みの行があればその日は決まっている）。

  **(f) すでに入っている予約は動かさない。** 判定は「その時間に重なっている体験の件数 < コーチ人数」で、超えている時間帯は**増やさないだけ**（例: 9/12 は小川のみ出勤だが体験4件が既に入っている）。

  **(g) 判定は1か所（`@yozan/core/frank-coach-capacity`）で、出す側と受ける側の両方が通る。** 空き時刻の一覧（`getTrialSlots`）と申込の受付（`createTrialBooking`）の両方に入れた。**スタッフの代理登録（member-os）も同じAPIをPOSTする**ので同じ判定が効く（#160 の方針のまま）。パーソナルレッスンは数えない（ユーザー決定・体験だけ）。

  実装: `packages/core/src/frank-coach-capacity.ts`（新規）・`packages/core/package.json`、`apps/genesis/src/lib/frank-trial.ts`、`tests/frank-coach-capacity.test.ts`（新規8件）。genesis の `tsc --noEmit` 通過・`next build` 成功・テスト610件通過。

- #213 (2026-09-04) **会員ページからコーチを指名して予約できるようにした（出勤していない人は出さない）**（migrationなし）。ユーザー依頼「予約の色やコーチの指名ができるようにしてほしい。あともちろん出勤していないコーチの指名はできないようにしてください」。

  **(a) 指名は「その時間に25分いられる人」だけ出す。** 打席の予約時間と確定シフトの重なりが**レッスン時間以上**ある人に限る（`coachesForLesson`）。打席が2時間でもレッスンは25分なので「予約時間の全部にいること」までは求めない——求めると、遅番のコーチを昼の2時間予約から指名できなくなる。

  **(b) 画面だけの制限にしない。** 空き枠API（`getSlots`）が返すコーチ一覧と、予約作成（`createBooking`）の検証が**同じ関数**を通る。直接POSTされても出勤していない人は入らない。名簿は体験の受入上限（#212）と同じ `frank-coach-roster`（確定シフト・`staff.member_page_role` のオプトイン）。

  **(c) 「おまかせ」を既定にした。** 指名を必須にすると、コーチを知らない入会直後の方が予約できない。シフト未確定の時間は選択肢を出さず「担当は店舗でお決めします」と書く（指名させてから断らない）。

  **(d) ご指名は希望として扱う。** 保存先は既存の `lesson_option_staff_id`（0136）で、確定するのは従来どおり店舗。会員様には「当日の状況により担当が変わる場合があります」と明示する。

  実装: `apps/genesis/src/lib/frank-coach-roster.ts`（新規・#212の名簿をここへ集約）、`apps/genesis/src/lib/{frank-booking.ts, frank-trial.ts}`、`apps/genesis/src/app/api/public/frank/booking/route.ts`、`apps/member-os/src/app/member/book/book-client.tsx`、`packages/core/src/frank-coach-capacity.ts`。

- #214 (2026-09-04) **予約表で「レッスン付き」「チケットで支払い済み」「担当コーチ」が開かずに分かるようにした**（migrationなし）。ユーザー報告「レッスンチケットを買うになっているかをどう確認すればいいかわかりずらい」。

  **(a) 種別の色は変えていない。** 会員＝青／体験＝橙／都度＝緑は「何のお客様か」を読む色なので触らない。**左端に太い縦線**を足した（確定＝紫／希望＝橙）。色を作り替えるより、足すほうが読み替えを強いない。

  **(b) ブロックの中に1行足した。** 「🎫 レッスン14:30 小川うらら」。**チケットは🎫**で、当日精算の有無がその場で分かる（判定は #199 の「チケットで承ったぶんは料金0で保存」）。担当が決まっていれば名前まで出す——これまで**確定した担当コーチの名前はどこにも表示されていなかった**（選択欄の初期値としてしか残っていなかった）。

  **(c) 一覧のバッジにも出した。** 「パーソナル25分 14:30〜／小川うらら」＋「🎫 チケット1枚（当日精算なし）」または「当日精算 2,500円」。**レジで二重に請求しない**ためには、開かずに見えることが要る。

  **(d) 担当プロの選択肢を「その日いる人」に絞った。** これまでは在籍スタッフ全員が並び、休みの人を担当にできた（会員様には確定として届く）。シフト未確定の日は全員から選べる（確定できずに詰まない）。すでに担当になっている人は休みでも選択肢に残す（消えると誤って上書きする）。

  実装: `apps/member-os/src/lib/{bay-timeline-pure.ts, frank-reservation.ts}`、`apps/member-os/src/components/bay-timeline.tsx`、`apps/member-os/src/app/(main)/reservations/page.tsx`、`tests/lesson-option-display.test.ts`（新規7件）。

- #215 (2026-09-04) **当日の連絡事項（申し送り）を作り、カレンダーの印と朝6時のLINEに出した**（migration 0148適用済）。ユーザー依頼「当日の連絡事項みたいなメモが欲しい、表やカレンダーにマークが出るような感じで、あとそれを朝のラインに流せるようにしておいてください。シフトボードの連絡事項共有のようなシステムです」。

  **(a) 1日だけと期間を1つの表にした**（ユーザー決定「1,2両方」）。`date_from = date_to` なら「その日だけ」。分けると**今日出す連絡を2か所から集める**ことになり、必ず片方を出し忘れる。

  **(b) 書く場所は予約画面。** スタッフが1日じゅう開いている画面に置く。別画面にすると、書くために移動が要る＝書かれない。既定の期間はその日1日で、長い連絡だけ終了日を入れる。

  **(c) カレンダーには📌。** 予約件数の点（下）とぶつからないよう右上に置く。月表示は日付の横に出す。

  **(d) 朝のLINEは同じ表を読む。** 6時のスタッフブリーフ（#198 の店舗別）の**いちばん上**に「▼本日の連絡事項」を入れた。出勤やタスクの下に埋めると、長い日は読まれない。**全店共通（store_id = null）はどの店にも出す**。期間の連絡は期間中ずっと毎朝出る。

  **(e) 既存の `announcements`（shift-cloud の店舗掲示）とは分けた。** あちらは会社の掲示板で、これは現場の申し送り。混ぜると古い掲示まで朝のLINEに流れる。

  **(f) 消すのではなく「下げる」。** `deleted_at` を入れるだけで行は残す（誰が何を伝えたかは後から辿れる）。

  実装: `supabase/migrations/0148_store_notices.sql`（新規・適用済）、`apps/member-os/src/lib/store-notices.ts`（新規）、`apps/member-os/src/app/(main)/reservations/{actions.ts, page.tsx}`、`apps/member-os/src/components/month-picker.tsx`、`apps/genesis/src/lib/ceo-ai.ts`。member-os / genesis の `tsc --noEmit` 通過・`next build` 成功・テスト617件通過。

- #217 (2026-09-04) **カードを持ってきていない方の「後日決済」を、店舗のiPadから会員に紐づけて開けるようにした**（migrationなし）。ユーザー依頼「会員登録はできるんですけども、クレジットカードを持ってきてないなどの理由で後日決済になることがあります。後日決済のページに飛べるようにしてほしい。ホームページからの通常方法ではなく、店舗のiPadを使って会員情報と紐付いた決済ページに飛ぶように」。

  **(a) お客様にHPの入会フォームをやり直させない。** これまで後日決済の入口が無く、やり直すと**申込がもう1件でき、会員番号も請求も二重になる**。既存の行に対して決済リンクを作る入口を、スタッフ画面（`/frunk` の承認待ち・`/frunk/[id]` のプラン・請求）に置いた。

  **(b) リンクを作るのは Genesis のまま**（`/api/public/frank/join-checkout`・#129）。Squareのキーは Genesis にしか無く、**Web入会と同じ経路**を通る＝金額の計算（入会金・日割り・前取り月数・キャンペーン）も、入金Webhookでの会員化（`activateWebJoin`）も、既存のものがそのまま効く。member-os 側に金額計算を作らない（2か所に置くと必ずずれる）。

  **(c) すでにカード登録済み（`billing_status='active'`）の人には作らない。** 二重契約を作らないため、member-os 側でも Genesis 側でも弾く。

  **(d) 戻り先はスタッフのiPadの会員カード**（`/frunk/<id>?paid=1`）。お客様の手元に決済画面を残さない。反映は入金Webhook待ちなので、戻った画面に「数十秒で『自動課金 稼働中』に変わります」と書く（黙って待たせない）。

  **(e) 作れなかったときは理由をその場で直せる言葉にする**（`joinCheckoutError`）。0円プラン・`square_variation_id` 未設定・退会済み・Squareが電話番号を断った（#208）を書き分ける。

  **(f) 一覧に「決済未」バッジを足した。** 在籍しているのにカードのお支払いが未登録の方は、探さないと分からなかった＝**請求漏れはここでしか気づけない**。月会費0円のプラン（スタッフ・モニター）と、現金・振込・口座振替の方は対象から外す（催促する相手ではない）。判定は `tests/frank-pay-later.test.ts` で固定（5件）。

  実装: `apps/member-os/src/app/(main)/frunk/{actions.ts, page.tsx, [id]/page.tsx}`、`tests/frank-pay-later.test.ts`（新規5件）。member-os の `tsc --noEmit` 通過・`next build` 成功・テスト622件通過。

- #218 (2026-09-05) **公式サイトに電話番号・公式LINE・Instagramを載せた**（migrationなし）。ユーザー報告「ホームページに電話番号が載っていない／公式LINEに飛べる／Instagramに飛べる」。

  **(a) 値は `assets/site-data.js` の1か所だけ**（`store.tel` / `links.line` / `links.instagram`）。`site.js` が `[data-tel]`・`[data-cta="line"]`・`[data-link="links.instagram"]` を全ページで差し替えるので、**ここを直せば全ページに反映**される（ビルドも不要）。null のままだと「近日公開」と出る設計で、電話は開業から3日間ずっとそれだった。

  **(b) 手書きの2ページ（`booking.html` / `lesson-booking.html`）にも同じフッターを入れた。** この2つは `_build.py` の生成対象外で、フッターがコピーで持たれている。片方だけ直すと**予約ページからだけSNSに行けない**——気づけない差になる。

  **(c) 特商法ページの「電話番号は請求があれば開示」を実際の番号に差し替えた。** 番号がある以上、請求を待たせる理由がない。

  **(d) 構造化データ（JSON-LD）にも `telephone` と `sameAs`（Instagram・LINE）を入れた。** 検索結果の店舗情報から直接電話できる。確定した事実だけを載せる方針は維持（住所の緯度経度と実写画像はまだ TODO のまま）。

  実装: `sites/frank-golf/assets/site-data.js`、`sites/frank-golf/_build.py`、`sites/frank-golf/{booking,lesson-booking}.html` ＋ 再ビルドした19ページ。

- #219 (2026-09-05) **体験の詳細に生年月日を出した**（migrationなし）。ユーザー依頼「体験の詳細画面に生年月日を反映して欲しい」。申込時に伺っている（#190・migration 0137）のに、**予約詳細にも体験一覧にも出していなかった**ので、カウンセリングや入会手続きのたびに聞き直していた。予約詳細（`booking-detail.tsx`）は `DETAIL_COLS` に `birth_date` が入っていなかったのが原因で、体験一覧（`/trials`）は `select("*")` なので表示を足すだけ。実装: `apps/member-os/src/lib/frank-reservation.ts`、`apps/member-os/src/components/booking-detail.tsx`、`apps/member-os/src/app/(main)/trials/page.tsx`。

- #220 (2026-09-05) **利用時間を過ぎた在店を自動で「退店」にした**（migrationなし）。ユーザー報告「利用時間が過ぎても退店にならない」。

  **(a) 原因。** チェックイン（QR・店頭・打席）は `frunk_checkins` に行を作るが、**退店は電子伝票の【退店】を押したときだけ** `checked_out_at` が入る（#164）。押し忘れると在店のまま残る。一方、**お客様のスマホ側は #163 の判定で来店中を閉じていた**（`visitClosed`・DBには書かない設計）。結果、**画面では帰った人が、DBでは在店**という食い違いが常態化していた。

  **(b) その判定をそのままDBにも書くようにした**（予約ありは終了+30分、予約なしはチェックイン+2時間）。ルールは `@yozan/core/frank-portal` の1か所のままなので、会員のスマホ・店頭・DBが同じ答えになる。**新しい規則は作っていない**——増やすと必ずどれかがずれる。

  **(c) スタッフが押した退店は上書きしない**（`checked_out_at is null` の行だけ）。前日以前の在店は時刻が取れなくても閉じる（日付が変われば在店ではない）。10分ごとのcronと日次cronの両方から呼ぶ（#205と同じ二重の保険）。

  実装: `apps/genesis/src/lib/frank-visit-cron.ts`（`runFrankAutoCheckout`）、`apps/genesis/src/app/api/cron/{execute,daily}/route.ts`。

- #221 (2026-09-05) **レッスンチケットの付与を見つけられるようにした**（migrationなし）。ユーザー報告「メンバーOSからチケット付与設定（が見つからない）」。**機能はあった**（会員カードの「レッスンチケット」パネル・#199）が、会員カードを開くまで存在が分からず、誰に何枚あるかは1人ずつ開かないと見えなかった。会員一覧に **🎫列**（残枚数／0枚なら「付与」リンク）を足し、押すとその会員のチケット欄に直接飛ぶようにした（`Panel` に `id` を足してアンカーにした）。残枚数はまとめて1回で数える（`ticketBalances`・会員数ぶんの往復を作らない）。実装: `packages/core/src/frank-lesson-tickets.ts`、`apps/member-os/src/app/(main)/frunk/page.tsx`、`apps/member-os/src/app/(main)/frunk/[id]/page.tsx`、`apps/member-os/src/components/ui.tsx`。

- #222 (2026-09-05) **月会費・入会金の領収書を会員カードからPDFで出せるようにした**（migrationなし）。ユーザー依頼「月会費の領収書を出したい／明日の14:00 レギュラー2ヶ月分」。

  **(a) 電子交付にした。** 5万円以上の領収書は紙だと収入印紙が要る（印紙税法）。**電子データで交付すれば課税文書に当たらない**ので、法人の年払い（13万円台の実例あり）でも印紙が不要になる。新しいタブでPDFを開き、その場で見せる／保存する／印刷するのどれでも渡せる。

  **(b) 金額を人が打ち込む欄を作らなかった。** 選べるのは「どの入金ぶんか」だけで、金額は `mon_sales`（Squareの入金Webhookが書いた行）から取る＝**受け取っていない金額の領収書は作れない**。税込は `tax_included`、内消費税は10%で切り捨て（受領額を上回る税額を書かない）。

  **(c) 適格請求書の登録番号は載せない。** 未取得のまま「適格」の体裁にすると、受け取った側の仕入税額控除で問題になる。

  **(d) PDFの生成だけ Genesis に置いた**（日本語フォントと pdf-lib があちらにしかない）。ただし **URLを知っただけでは作れない**——member-os がスタッフ権限で内容を確定し、**HMAC署名（有効5分・鍵は両アプリが持つ service_role キー）**を付けて呼ぶ。新しい環境変数は増やしていない。金額を1文字でも書き換えると署名が合わない（テストで固定）。

  **(e) 領収書番号は入金の組み合わせから決まる**ので、再発行しても同じ番号になる（二重発行を「別の領収書」に見せない）。

  実装: `packages/core/src/admin-sign.ts`（新規）・`packages/core/package.json`、`apps/genesis/src/lib/frank-receipt-pdf.ts`（新規）、`apps/genesis/src/app/api/public/frank/admin/receipt/route.ts`（新規）、`apps/genesis/next.config.ts`、`apps/member-os/src/lib/frank-receipt{,-pure}.ts`（新規）、`apps/member-os/src/app/(main)/frunk/[id]/receipt/route.ts`（新規）、`apps/member-os/src/app/(main)/frunk/[id]/page.tsx`、`tests/frank-receipt.test.ts`（新規5件）。

- #223 (2026-09-05) **小西様の重複会員（FR0012）を整理した**（コード変更なし・SQLのみ）。ユーザー指示「12番小西さん削除」。9/4にWeb入会（FR0012・未入金）→ 9/5にもう一度Web入会（FR0019・入金済）となっていた。**#217 で塞いだ「決済できずにフォームをやり直す」導線が、塞ぐ前に実際に起きていた事例**。FR0019 に寄せる形で、9/5の来店実績（予約1件）を付け替え、FR0012 側の重複キャンペーンチケットを無効化し、FR0012 を削除扱い（`status='rejected'` + `deleted_at`、理由をメモに残す）にした。**行は消さずに残す**——会員番号を振り直すと過去の伝票と合わなくなる。

- #224 (2026-09-05) **予約に「担当コーチ」を持たせ、レッスンの有無に関わらず指名できるようにした**（migration 0149適用済）。ユーザー依頼「パーソナルレッスンだけでなく、担当コーチの選択ができるようにしてほしい」。

  **(a) `lesson_option_staff_id`（0136）を使い回さなかった。** あちらは「25分パーソナルを誰が教えるか」で、確定するとチケットや料金と結びつく。担当コーチは「その打席のときに見る人」で、レッスンが無くても付く。同じ列に入れると、**レッスンをお断りしたときに担当まで消える／担当を替えるとレッスン料の扱いが動く**——別々に動くべきものが連動する。新しい列 `frunk_bookings.coach_staff_id` を足した。

  **(b) お客様が選べる条件は、レッスンのときと同じ**（`coachesForLesson`＝選んだ時間に25分ぶん一緒にいられる確定シフトの人）。条件を2つに分けると「レッスンでは選べるのに担当では選べない人」が出て、説明できなくなる。

  **(c) スタッフ側は出勤者に絞らない。** 店頭は「今日は急きょ◯◯が見る」が起きる。**縛るのはお客様が選ぶ側だけ**にして、店の運用を止めない。すでに担当になっている人は選択肢に残す。

  **(d) レッスンのご指名があれば担当も同じ人にする**（画面に2つの担当が出ない）。予約表のブロック・一覧のバッジ・予約詳細に「担当 ◯◯」を出す。

  実装: `supabase/migrations/0149_frank_booking_coach.sql`（新規・適用済）、`apps/genesis/src/lib/frank-booking.ts`、`apps/genesis/src/app/api/public/frank/booking/route.ts`、`apps/member-os/src/app/member/book/book-client.tsx`、`apps/member-os/src/app/(main)/reservations/{actions.ts, page.tsx}`、`apps/member-os/src/lib/{frank-reservation.ts, bay-timeline-pure.ts}`、`apps/member-os/src/components/{bay-timeline.tsx, booking-detail.tsx}`。

- #225 (2026-09-05) **パーソナルレッスンの同時受入数を、その時間のコーチ人数までにした**（migrationなし）。ユーザー依頼「パーソナル シフト変動制 予約件数上限」＝**上限をシフトに連動**させる。

  **(a) これまで上限が無かった。** ご指名の場合だけ「その人が出勤しているか」を見ていて（#213）、**おまかせは何件でも通っていた**。コーチ1人の時間に3件たまり、店頭で2件お断りする——という形が残っていた。

  **(b) 体験（#212）と同じ考え方にした。** 受入数＝その時間に25分ぶん一緒にいられるコーチの人数、使用数＝重なっているレッスン付き予約（**ご希望・確定の両方／おまかせも数える**）。

  **(c) まだ確定していない予約はレッスンの開始時刻が決まっていない**（店舗が後で決める）ので、**打席の予約時間まるごと**を占有として数える——実際に取り合いになる単位はここ。

  **(d) 画面と受付の両方に同じ判定を置いた**（`canTakeLesson`）。満席の時間はチェックボックスを押せなくし、**「打席のご予約はこのままお取りいただけます」**と書く（予約ごと諦めさせない）。シフト未確定の日は体験と同じ2件まで。

  実装: `packages/core/src/frank-coach-capacity.ts`、`apps/genesis/src/lib/frank-booking.ts`、`apps/member-os/src/app/member/book/book-client.tsx`、`tests/frank-coach-capacity.test.ts`（+5件）。member-os / genesis の `tsc --noEmit` 通過・`next build` 成功・テスト632件通過。

  なお同時に依頼のあった「レッスンOSのパーソナル設定欄」は、ユーザー判断で**作らない**（2026-09-05）。

- #226 (2026-09-06) **店頭タブレットの受付に「2回目以降の方」を作り、常連の方に毎回全部書かせるのをやめた**（migration 0150・適用済み）。ユーザー指摘「再来の人に何回も書いてもらうの申し訳ないので、名前を検索したら出るようにしてください」。

  **(a) これまで来店のたびに全部だった。** /reception/[token] は氏名・カナ・生年月日・住所・電話・メール・職業を毎回お願いしていた。書き直すたびに表記がぶれて、**mbr_guests に同じ人が何人も増える**（#190で名寄せを直した根っこと同じ問題）。GOLF WING の受付台帳は既に6,250人。

  **(b) 最初の1枚で道を分ける。** 「2回目以降の方」／「初めてのご来店の方」。再来はお名前（漢字・カナ・ひらがな・姓だけ可）で引き、候補を選べば確定。**本人確認（電話下4桁など）は挟まない**——ユーザー選択。誤って別人を選んでも増えるのは来店1行だけで、スタッフが台帳で直せる。

  **(c) 前回の個人情報は画面に出さない。** ここが肝。お客様のタブレットは誰でも触れるので、**名前を打っただけで他人の住所・生年月日が読める画面を作らない**。DB関数 `search_reception_guests`(0150) が返すのは **氏名・カナ・電話の下4桁・前回来店日・来店回数だけ**（ご自身を見分けていただく分）。前回の氏名・住所・電話はサーバー側で `guest_id` からたどって台帳につなぐので、そもそも画面に出す必要が無い。**mbr_guests は作らないし上書きもしない**（前回のご登録が正）。

  **(d) アンケートは今日の利用区分のぶんを毎回いただく**（ユーザー指示）。フィッティングならフィッティングの設問、体験なら体験の設問。設問の出し分けは `reception-ui.tsx` の `SurveyFields` 1か所（画面ごとに書くと必ず片方だけズレる）。「当店を何で知りましたか」だけは初回で伺い済みなので再来には出さない。

  **(e) 再来カウントが手入力なしで正しくなる。** 前回のご来店日を `repeat_date`（台帳P列「再来の場合日付」）に自動で入れる。ダッシュボードの再来判定は元々この列を見ていたが、スタッフが手で入れない限り埋まらなかった。

  **(f) 検索の正規化はDB側1か所。** `app.kana`(0150) ＝ ひらがな→カタカナ・空白/中黒/ドット除去。`app.digits`(0110) の氏名版。これで「山田 太郎」「山田太郎」「やまだ」「ヤマダ」が同じお名前になる。**1文字では引かない**（名簿がずらりと並ぶ）。候補は最大8件・最終来店が新しい順。実測 約90ms／6,250人。

  実装: `supabase/migrations/0150_reception_returning_guest.sql`（新規・適用済み）、`apps/member-os/src/lib/reception-search-pure.ts`（新規）、`apps/member-os/src/app/reception/[token]/{actions.ts, page.tsx, reception-form.tsx, reception-ui.tsx（新規）, returning-form.tsx（新規）, reception-entry.tsx（新規）}`、`tests/reception-search.test.ts`（+9件）。member-os の `tsc --noEmit` 通過・`next build` 成功（クラウドで実走）・テスト641件通過。予約からのご来店 `/reception/v/[intakeToken]`（#186）は入口が確定しているのでこの選択画面を通らない（従来どおり）。

  **残る判断**: 同姓同名が多いお名前で他の方の氏名が8件まで並ぶ。気になれば「候補を選んだあとに電話の下4桁を確認する」を足せる（1画面追加で済む作りにしてある）。

- #227 (2026-09-07) **公式サイトのスマホメニュー（右上の三本線）を作り直した**（コード変更のみ・`assets/style.css` と `assets/site.js`）。ユーザー報告「三本線をタップすると簡易ログインだとか出る画面が、後ろのスクロールなどと反応してうまく動かない」。

  **(a) メニューが画面の外にはみ出していた。** `.nav__menu.is-open` は `position: fixed` だが、親の `.nav` に `backdrop-filter: blur(14px)` が効いている。**backdrop-filter の効いた要素は、その中の fixed の包含ブロックになる**——つまり基準がビューポートではなく `.nav` になり、`inset: calc(bar-h + nav-h)` がヘッダーの上端からさらに102px下、という意味になっていた。実測（画面高721px）: メニュー上端142px・**下端761px＝画面外**。下端に届かないので、その先を送ると背面が動いた。**`position: absolute; top: 100%`**（基準は `.nav` のままで正しく効く）に変更。実測 上端101px・下端615px／画面高664px。

  **(b) 背面がロックされていなかった。** `is-open` の付け外しだけで body はスクロールできるまま。`overscroll-behavior: contain`（メニュー端まで送っても背面に伝えない）＋**body を `position: fixed`** にして固定し、閉じるときに `window.scrollTo` で元の位置へ戻す。**iOS Safari は `overflow: hidden` だけでは止まらない**ため位置固定方式。戻すときは `scroll-behavior: smooth` を一時的に切る（滑って戻ると別の場所に着地する）。

  **(c) 閉じる手段が三本線しかなかった。** JS が body 直下に**スクリム**（`.nav-scrim`）を1枚作り、外側タップで閉じる。メニューの高さを画面より48px低くして、背面が少し見える＝閉じられることが分かる形にした。Escでも閉じ、閉じたらフォーカスを三本線に戻し、開いている間は Tab をメニュー内で回す。**PC幅に広げたら自動で閉じる**（開いたまま回転・リサイズすると body 固定が残っていた）。

  **(d) 重なり順。** 下の固定CTAバー（z-index:70）がメニューの上に乗っていた。開いている間はヘッダーと告知バーを 90、スクリムを 80 に上げ、CTAバーは引っ込める。**メニューの地は不透明 `#FFFDF8` に**（`.99` の半透明が親のぼかしと合成されて背面の文字が透けていた）。開いている間はヘッダーのぼかしも止める。

  **(e) 別のバグも見つかった: 狭い端末で三本線が画面の外にあった。** 実測、画面幅320pxでロゴ＋体験予約ボタン＋三本線が横に収まらず、**三本線の左端が x=325（画面の外）で押せない**。360px（Androidに多い幅）でもはみ出す。480px以下・360px以下で余白と文字を詰め、`.burger` は縮まない（`flex: none`）ようにした。320 / 360 / 375 / 390 / 430 / 768px で収まることを実測。

  検証: Playwright（Chromium・iPhone 12相当ほか6幅）で、開いた位置・背面が動かないこと・スクリム/Esc/リンクで閉じること・**閉じたあと元のスクロール位置に戻ること**・PC幅に広げると閉じることを確認。JSエラー0。`index.html` と、手直しの入っている `booking.html` の両方で確認。**HTMLの構造は変えていないので `_build.py` の再生成は不要**（全21ページが同じ `assets/style.css` `assets/site.js` を読む）。

- #228 (2026-09-05) **会話メモ（レッスンノート）の担当プロを選べるようにした**（migrationなし）。ユーザー依頼「レッスンOSで（レッスン）内容を入力するときに、担当プロを選択できるようにしてほしい」。

  **(a) これまでは「ログインしている人＝担当」で固定だった**（`coach_staff_id: actor.staffId`）。受付や別のコーチが代わりに入力すると、**お客様の共有ページに出る担当名まで変わる**。店頭では代理入力が普通に起きるので、選べる必要がある。

  **(b) 既定はログインしている人のまま。** 毎回選ばせない（ほとんどは本人が書く）。違うときだけ選び直す＝**間違いが起きるときだけ手が要る**形にする。選ぶと「（代理で入力しています）」と出す。

  **(c) あとからでも直せる。** メモの行の担当プロも選び直せる（`setNoteCoach`）——「これは◯◯が見た日だった」は後から分かる。

  **(d) 候補は在籍スタッフ全員。** 会員ページの出勤予定（`member_page_role`・#209）や確定シフトでは絞らない——記録は**過去の日付**にも書くので、「今出ている人」ではなく「その日教えた人」を選ぶ必要がある。他社・退職者は入らないよう、保存時にも会社と在籍を確かめて、違えば操作した人に倒す（黙って他社の人を入れない）。

  **(e) 候補の読み込みは押したときだけ**（`onFocus`）。カルテを開くたびにスタッフ一覧を引かない。

  実装: `apps/lesson-os/src/app/(main)/students/[id]/{actions.ts, lesson-note.tsx, karte-client.tsx, page.tsx}`。lesson-os の `tsc --noEmit` 通過・`next build` 成功。

  なお同じ依頼にあった「スイング動画へのコメント」「FRANKレッスンカレンダーの記録」の担当プロは、ユーザー選択により**今回は対象外**（会話メモのみ）。
