# -*- coding: utf-8 -*-
"""② レッスンマニュアル"""
from common import cover, slide

F = "② レッスンマニュアル"
S = []

S.append(cover(
    "MANUAL 02",
    "レッスンマニュアル",
    "誰が担当しても、同じことを、同じ順番で。<br>初心者レッスンの型を、ここに統一します。"))

# 01
S.append(slide("01", "FRANKのレッスンの種類", """
<table class="tight">
  <tr><th style="width:150px">種類</th><th style="width:78px">時間</th><th style="width:90px">料金</th><th>中身</th></tr>
  <tr><td class="k">ワンポイントレッスン</td><td class="c">5分</td><td class="c"><b>会員無料</b></td><td>ご来店中のお客様に、その日の1点だけをお伝えする。<b>会員特典の中心</b></td></tr>
  <tr><td class="k">パーソナルレッスン</td><td class="c">25分</td><td class="c">2,500円</td><td>ワンポイントに追加で受けていただく有料レッスン</td></tr>
  <tr><td class="k">体験レッスン</td><td class="c">10分</td><td class="c">体験に含む</td><td>入会をご判断いただくためのレッスン。<b>① 体験マニュアル参照</b></td></tr>
</table>
<div class="cols" style="margin-top:13px">
  <div class="c60">
    <h2 class="sec">このマニュアルの適用範囲</h2>
    <div class="box">
      <ul class="dot" style="font-size:10pt">
        <li>このマニュアルは<b>初心者レッスン</b>の共通の型です。<br>誰が担当しても同じ順番・同じ言葉になるように統一します</li>
        <li><b>初心者レッスン以外</b>（中級・上級・課題別）は、<b>レッスンカルテ（Lesson OS）</b>と<b>AIアシスタント</b>を併用して組み立てます</li>
      </ul>
    </div>
    <h2 class="sec mt">レッスンの進め方（毎回この順番）</h2>
    <div class="cols" style="gap:.1in">
      <div><table class="xtight">
        <tr><td class="k c" style="width:26px">1</td><td>まずはストレッチ</td></tr>
        <tr><td class="k c">2</td><td>ウォームアップを兼ねて<b>ビジネスゾーン</b>から</td></tr>
        <tr><td class="k c">3</td><td>ハーフスイング</td></tr>
      </table></div>
      <div><table class="xtight">
        <tr><td class="k c" style="width:26px">4</td><td>フルスイング</td></tr>
        <tr><td class="k c">5</td><td>崩れたら<b>②③に戻ってやり直す</b></td></tr>
        <tr><td class="k c">6</td><td>カルテを書く（レッスン直後）</td></tr>
      </table></div>
    </div>
  </div>
  <div class="c40">
    <div class="banner">レッスン ＝ 上達させること</div>
    <div class="box gold" style="margin-top:11px">
      <h4>一貫性が一番大事</h4>
      <p style="font-size:9.8pt">同じ会員様に、コーチによって<b>違うことを教えない</b>。<br>
      前のコーチが言ったことを否定すると、お客様は「どちらが正しいのか」で迷い、練習が止まります。<br>
      <b>カルテを読んでからレッスンに入る。</b>これが一貫性を守る唯一の方法です。</p>
    </div>
    <div class="box ng" style="margin-top:11px">
      <p style="font-size:9.7pt">上達を止める最大の原因は、才能でも練習量でもなく<b>「言われることが毎回違う」</b>ことです。</p>
    </div>
  </div>
</div>
""", sub="ワンポイント／パーソナル／体験", foot_l=F, foot_r="01"))

# 02
S.append(slide("02", "「型」と「コツ」の違い", """
<div class="cols">
  <div class="c60">
    <p class="lead">ゴルフスイングを指導する時、皆さんに意識してほしいことがあります。<br>
    それは、<b>「型」のアドバイスなのか「コツ」のアドバイスなのか</b>を区別することです。</p>
    <table class="tight">
      <tr><th style="width:64px">種類</th><th>中身</th><th style="width:110px">誰に</th></tr>
      <tr><td class="k">型</td><td>目に見える形。<b>誰が見ても同じ判定ができる</b><br><span class="small">グリップ／スタンス幅／振り幅／シャフトの位置</span></td><td>初心者・初級者<br><b>まずこちら</b></td></tr>
      <tr><td class="k">コツ</td><td>感覚の言葉。<b>人によって受け取り方が変わる</b><br><span class="small">「グッと溜める」「スパッと振る」</span></td><td>型ができた人</td></tr>
    </table>
    <div class="box gold" style="margin-top:12px">
      <h4>順番を間違えない</h4>
      <p style="font-size:9.8pt">型を作らずにコツから入ると、その場では打てても<b>再現できません</b>。<br>
      逆に、型が固まった人にいつまでも型の話をすると、動きが硬くなりスピードが上がりません。<br>
      <b>型 → スピード（コツ）</b>の順で進みます。</p>
    </div>
  </div>
  <div class="c40">
    <h2 class="sec">なぜ型から入るのか</h2>
    <ul class="dot" style="font-size:9.8pt">
      <li><b>チェックできる</b>から。型は目で確認でき、次のコーチにも申し送れます</li>
      <li><b>お客様が自分で直せる</b>から。家や他の練習場でも再現できます</li>
      <li><b>コーチによる差が出ない</b>から。感覚の言葉は人によってバラバラになります</li>
    </ul>
    <div class="box" style="margin-top:12px">
      <h4>指導するときの言い換え</h4>
      <table class="xtight">
        <tr><td class="k">×</td><td>「もっとタメを作って」</td></tr>
        <tr><td class="k">○</td><td>「トップで<b>シャフトを地面と平行</b>にしましょう」</td></tr>
        <tr><td class="k">×</td><td>「体で振ってください」</td></tr>
        <tr><td class="k">○</td><td>「<b>三角形をキープ</b>したまま腰まで振りましょう」</td></tr>
      </table>
    </div>
  </div>
</div>
""", sub="初心者は「型」から", foot_l=F, foot_r="02"))

# 03
S.append(slide("03", "スイングチェックの4段階", """
<div class="tl">
  <div class="step"><div class="t">STEP 1</div><div class="bar"></div><div class="l">アドレス</div><div class="m">構え</div></div>
  <div class="step"><div class="t">STEP 2</div><div class="bar"></div><div class="l">ビジネスゾーン</div><div class="m">腰から腰</div></div>
  <div class="step"><div class="t">STEP 3</div><div class="bar"></div><div class="l">ハーフスイング</div><div class="m">肩から肩</div></div>
  <div class="step"><div class="t">STEP 4</div><div class="bar"></div><div class="l">フルスイング</div><div class="m">全体</div></div>
</div>
<p class="lead">チェックポイントは全部で約30個あります。<b>一度に全部は直しません。</b>1回のレッスンで扱うのは<b>多くて3つまで</b>です。</p>
<div class="cols">
  <div>
    <h2 class="sec">STEP 1 ｜ アドレス</h2>
    <table class="xtight">
      <tr><td class="k">1</td><td>ボールの位置</td></tr>
      <tr><td class="k">2</td><td>スタンス幅</td></tr>
      <tr><td class="k">3</td><td>重心の位置（左右・前後）</td></tr>
      <tr><td class="k">4</td><td>手元の位置（ハンドファースト）</td></tr>
      <tr><td class="k">5</td><td>姿勢（骨盤前傾）</td></tr>
      <tr><td class="k">6</td><td>3つの線（肩・膝・スタンス）</td></tr>
      <tr><td class="k">7</td><td>リズムの有無</td></tr>
      <tr><td class="k">8</td><td>顔（目線）の向き</td></tr>
    </table>
  </div>
  <div>
    <h2 class="sec">STEP 2 ｜ ビジネスゾーン</h2>
    <table class="xtight">
      <tr><td class="k">1</td><td>アドレス（再確認）</td></tr>
      <tr><td class="k">2</td><td><b>三角形のキープ</b></td></tr>
      <tr><td class="k">3</td><td>振り幅（シャフトが地面と平行）</td></tr>
      <tr><td class="k">4</td><td>目線</td></tr>
      <tr><td class="k">5</td><td>リズムの有無</td></tr>
      <tr><td class="k">6</td><td>シャフトの向き</td></tr>
      <tr><td class="k">7</td><td>左右の軸ブレ</td></tr>
    </table>
  </div>
  <div>
    <h2 class="sec">STEP 3 ｜ ハーフ</h2>
    <table class="xtight">
      <tr><td class="k">1</td><td>振り幅（左腕が地面と平行）</td></tr>
      <tr><td class="k">2</td><td>目線</td></tr>
      <tr><td class="k">3</td><td>腰の動き・腰の位置</td></tr>
      <tr><td class="k">4</td><td>フェースの向き</td></tr>
      <tr><td class="k">5</td><td>シャフトの位置</td></tr>
    </table>
    <h2 class="sec mt">STEP 4 ｜ フル</h2>
    <table class="xtight">
      <tr><td class="k">1</td><td>右足の踏み上げ具合</td></tr>
      <tr><td class="k">2</td><td>肩の回転角度</td></tr>
      <tr><td class="k">3</td><td>腰の回転角度</td></tr>
      <tr><td class="k">4</td><td>シャフトライン</td></tr>
    </table>
  </div>
</div>
""", sub="約30項目 ／ 1回で直すのは3つまで", foot_l=F, foot_r="03"))

# 04
S.append(slide("04", "STEP 1｜アドレスの見方", """
<div class="cols">
  <div>
    <table class="tight">
      <tr><th style="width:96px">項目</th><th>基準</th></tr>
      <tr><td class="k">ボール位置</td><td>7Iは<b>スタンス中央</b>。1Wは左足かかと内側の延長線上</td></tr>
      <tr><td class="k">スタンス幅</td><td>7Iで肩幅程度。<b>広すぎると回転が止まり、狭すぎると軸がぶれる</b></td></tr>
      <tr><td class="k">重心（左右）</td><td>7Iは<b>5：5</b>。1Wは右足に6：4</td></tr>
      <tr><td class="k">重心（前後）</td><td><b>母指球</b>。かかと体重・つま先体重はここで直す</td></tr>
      <tr><td class="k">手元の位置</td><td><b>ハンドファースト</b>。左太もも内側の前</td></tr>
    </table>
  </div>
  <div>
    <table class="tight">
      <tr><th style="width:96px">項目</th><th>基準</th></tr>
      <tr><td class="k">姿勢</td><td><b>骨盤から前傾</b>。背中を丸めない。膝は軽く曲げる程度</td></tr>
      <tr><td class="k">3つの線</td><td><b>肩・膝・スタンス</b>の3本がターゲットラインと平行</td></tr>
      <tr><td class="k">グリップ</td><td><b>ナックルが2〜3個</b>見える。強く握りすぎない</td></tr>
      <tr><td class="k">目線</td><td>ボールの<b>後ろ半分</b>（目標と反対側＝右打ちなら右のふち）を見る。頭を下げすぎない<br><span class="small">お客様には「ボールの<b>右のふち</b>を見ていてください」と言うと伝わります</span></td></tr>
      <tr><td class="k">リズム</td><td>構えてから打つまで<b>毎回同じ秒数</b>。止まったまま固まらない</td></tr>
    </table>
  </div>
</div>
<div class="cols" style="margin-top:12px">
  <div class="c60">
    <div class="box gold">
      <h4>アドレスが8割</h4>
      <p style="font-size:9.8pt">アマチュアのミスの多くは<b>フェースコントロールとクラブコントロール</b>、つまり<b>アドレスとグリップ</b>で起きています。<br>
      スイング中の動きを直す前に、<b>構えを直すだけで球が変わる</b>ことがほとんどです。</p>
    </div>
  </div>
  <div class="c40">
    <div class="box">
      <h4>教える順番</h4>
      <p style="font-size:9.8pt"><b>グリップ → 姿勢 → ボール位置 → スタンス</b><br>
      <span class="small">この順番で固定します。グリップを最後に直すと、それまでの調整が全部やり直しになります。</span></p>
    </div>
  </div>
</div>
""", sub="構えを直すだけで球が変わる", foot_l=F, foot_r="04"))

# 05
S.append(slide("05", "STEP 2｜ビジネスゾーン（腰から腰）", """
<div class="cols">
  <div class="c60">
    <p class="lead"><b>ビジネスゾーン（BZ）＝ 腰から腰まで</b>の振り幅。ここができれば球は必ず前に飛びます。<br>
    レッスンは毎回<b>ここから始めます</b>（ウォームアップも兼ねる）。</p>
    <table class="tight">
      <tr><th style="width:104px">項目</th><th>基準・伝え方</th></tr>
      <tr><td class="k">三角形キープ</td><td>両腕と胸で作る三角形を<b>崩さない</b>。腕だけで上げない</td></tr>
      <tr><td class="k">振り幅</td><td>バックもフォローも<b>シャフトが地面と平行</b>まで</td></tr>
      <tr><td class="k">シャフトの向き</td><td>地面と平行になったとき、シャフトが<b>ターゲットラインと平行</b></td></tr>
      <tr><td class="k">フェースの向き</td><td>その位置で<b>トゥが真上</b>を向く（スクエア）</td></tr>
      <tr><td class="k">左右の軸ブレ</td><td>頭が左右に動かない。<b>その場で回る</b></td></tr>
      <tr><td class="k">目線</td><td>ボールから外れない</td></tr>
      <tr><td class="k">リズム</td><td><b>1・2のテンポ</b>を口に出して合わせる</td></tr>
    </table>
  </div>
  <div class="c40">
    <h2 class="sec">練習のさせ方</h2>
    <div class="stepbox"><div class="stepno">1</div><div class="stepbd"><b>ブラッシング素振り</b><br>
      <span class="small">ボールを置かず、マットを擦る音だけを揃える</span></div></div>
    <div class="stepbox"><div class="stepno">2</div><div class="stepbd">音が揃ったら<b>ボールを置いて</b>同じ振り幅で打つ</div></div>
    <div class="stepbox"><div class="stepno">3</div><div class="stepbd">10球中<b>7球が真っ直ぐ</b>出たらハーフへ進む</div></div>
    <div class="box ng" style="margin-top:10px">
      <h4>ここで必ず伝えること</h4>
      <p style="font-size:9.7pt">「<b>手上げ</b>（腕だけで上げること）が、フェースの向きと軌道が乱れる一番の原因です」<br>
      <span class="small">アウトサイドイン・インサイドバックのほとんどは手上げから起きています。</span></p>
    </div>
  </div>
</div>
""", sub="毎回ここから始める", foot_l=F, foot_r="05"))

# 06
S.append(slide("06", "STEP 3・4｜ハーフスイングとフルスイング", """
<div class="cols">
  <div>
    <h2 class="sec">STEP 3 ｜ ハーフスイング（肩から肩）</h2>
    <table class="tight">
      <tr><th style="width:92px">項目</th><th>基準</th></tr>
      <tr><td class="k">振り幅</td><td><b>左腕が地面と平行</b>になるまで</td></tr>
      <tr><td class="k">腰の動き</td><td>バックで<b>右腰が後ろへ</b>回る。スライドしない</td></tr>
      <tr><td class="k">腰の位置</td><td>アドレスの高さを保つ。<b>起き上がらない</b></td></tr>
      <tr><td class="k">フェースの向き</td><td>左腕が地面と平行のとき、フェースが<b>前傾した上体と同じ角度</b>（＝斜め下を向く）<br><span class="small">真下を向く＝閉じすぎ／空を向く＝開きすぎ。お客様には「<b>自分の前かがみと同じくらい下を向いていればOK</b>」と伝える</span></td></tr>
      <tr><td class="k">シャフトの位置</td><td>手元が右腰の高さでシャフトが<b>ターゲットラインと平行</b></td></tr>
      <tr><td class="k">目線</td><td>顔が右を向きすぎない</td></tr>
    </table>
    <div class="box" style="margin-top:10px">
      <p style="font-size:9.6pt"><b>ハーフで崩れたら、必ずBZに戻す。</b>先に進めても直りません。</p>
    </div>
  </div>
  <div>
    <h2 class="sec">STEP 4 ｜ フルスイング</h2>
    <table class="tight">
      <tr><th style="width:92px">項目</th><th>基準</th></tr>
      <tr><td class="k">肩の回転</td><td>トップで<b>約90度</b>。背中が目標を向く</td></tr>
      <tr><td class="k">腰の回転</td><td>肩の<b>半分（約45度）</b>。捻転差を作る</td></tr>
      <tr><td class="k">右足の踏み上げ</td><td>右膝が流れない。<b>右股関節に乗る</b></td></tr>
      <tr><td class="k">シャフトライン</td><td>トップでシャフトが<b>ターゲットラインと平行</b></td></tr>
      <tr><td class="k">切り返し</td><td>下半身から。<b>上半身リード（手打ち）にならない</b></td></tr>
      <tr><td class="k">フィニッシュ</td><td>右足かかとが上がり、<b>3秒立てる</b></td></tr>
    </table>
    <div class="box gold" style="margin-top:10px">
      <p style="font-size:9.6pt"><b>フィニッシュで3秒立てない＝バランスが崩れている。</b><br>
      分かりやすい判定基準なので、お客様にもそのまま伝えてください。</p>
    </div>
  </div>
</div>
<div class="banner" style="margin-top:12px">崩れたら必ず1つ前の段階に戻る。先に進めて直ることはありません</div>
""", sub="崩れたら1つ前へ戻る", foot_l=F, foot_r="06"))

# 07
S.append(slide("07", "伝わる説明の順番", """
<div class="cols">
  <div class="c60">
    <h2 class="sec">説明の5ステップ</h2>
    <div class="stepbox"><div class="stepno">1</div><div class="stepbd"><b>前提をそろえる</b><br>
      <span class="small">「今日はダフりとトップの原因を1つに絞って見ていきます」</span></div></div>
    <div class="stepbox"><div class="stepno">2</div><div class="stepbd"><b>結論（本質）</b><br>
      <span class="small">「原因は手上げです」── 先に答えを言う</span></div></div>
    <div class="stepbox"><div class="stepno">3</div><div class="stepbd"><b>根拠・事実</b><br>
      <span class="small">映像とデータを見せる。「ここでシャフトがこう向いています」</span></div></div>
    <div class="stepbox"><div class="stepno">4</div><div class="stepbd"><b>補足・具体例</b><br>
      <span class="small">「同じ症状の方はだいたいここから直します」</span></div></div>
    <div class="stepbox"><div class="stepno">5</div><div class="stepbd"><b>もう一度、結論</b><br>
      <span class="small">「なので今日は、三角形のキープだけ覚えて帰ってください」</span></div></div>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>ポイントは「順序」にある</h4>
      <p style="font-size:9.8pt">説明が下手な人の特徴は3つ。<br>
      ① 何をどの順番で説明するのか整理できていない<br>
      ② 説明する相手の理解レベルを見誤っている<br>
      ③ 自分が言いたいことだけを言っている</p>
    </div>
    <div class="box" style="margin-top:11px">
      <h4>1回のレッスンで扱う量</h4>
      <p style="font-size:9.8pt">伝えることは<b>多くて3つ</b>。<br>
      持ち帰っていただくのは<b>1つだけ</b>。<br>
      <span class="small">「今日はこれだけ覚えて帰ってください」で締めると、次回のレッスンが繋がります。</span></p>
    </div>
    <div class="box ng" style="margin-top:11px">
      <p style="font-size:9.6pt"><b>お客様に理解度を確認する質問を必ず入れる。</b><br>
      「どう感じますか？」「今のはどうでしたか？」<br>
      うなずきだけで進めない。</p>
    </div>
  </div>
</div>
""", sub="前提 → 結論 → 根拠 → 補足 → 結論", foot_l=F, foot_r="07"))

# 08
S.append(slide("08", "ティーチングとコーチングの違い", """
<div class="cols">
  <div class="c60">
    <table class="tight">
      <tr><th style="width:80px"></th><th>ティーチング</th><th>コーチング</th></tr>
      <tr><td class="k">意味</td><td>教える・指示する</td><td>引き出す・気づかせる</td></tr>
      <tr><td class="k">メリット</td><td>教えることができる<br>やり方・価値観が統一しやすい<br>人によって差が出にくい</td><td>相手の個性を活かせる<br>時間はかかるが定着する<br>相手の知識・スキルが伸びる</td></tr>
      <tr><td class="k">デメリット</td><td>相手が受け身になる<br>指示待ちの状態を生む</td><td>時間がかかる<br>知識がない場合は効果が薄い</td></tr>
      <tr><td class="k">向いている<br>相手</td><td><b>初心者</b>・基礎が固まっていない方</td><td><b>経験者</b>・自分で考えられる方</td></tr>
    </table>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>FRANKの使い分け</h4>
      <ul class="dot" style="font-size:9.8pt">
        <li><b>初心者＝ティーチング中心。</b>型を教える。迷わせない</li>
        <li><b>経験者＝コーチング中心。</b>「どこが原因だと思いますか？」と先に聞く</li>
        <li>どちらの相手にも<b>質問は必ず入れる</b>。一方的に喋り続けない</li>
      </ul>
    </div>
    <div class="box" style="margin-top:11px">
      <h4>コーチングで大切なこと</h4>
      <p style="font-size:9.8pt">答えを教えるのではなく、<b>相手が自分で気づく</b>のを助けます。<br>
      自分で気づいたことは忘れません。教えられたことはすぐ忘れます。</p>
    </div>
  </div>
</div>
""", sub="初心者は教える、経験者は引き出す", foot_l=F, foot_r="08"))

# 09
S.append(slide("09", "ラポール形成（信頼関係のつくり方）", """
<div class="cols">
  <div class="c60">
    <h2 class="sec">ラポールとは</h2>
    <p class="lead">お互いに<b>安心して信頼し合える関係</b>のこと。ラポールがない状態では、どんなに正しいことを言っても届きません。</p>
    <table class="tight">
      <tr><th style="width:118px">スキル</th><th>やり方</th></tr>
      <tr><td class="k">① ペーシング</td><td>相手の<b>話す速さ・声の大きさ・呼吸</b>に合わせる。<br>ゆっくり話す方にはゆっくり、早い方には早く</td></tr>
      <tr><td class="k">② ミラーリング</td><td>相手の<b>姿勢・動作</b>を鏡のように合わせる。<br>相手が前のめりなら自分も前のめりに</td></tr>
      <tr><td class="k">③ バックトラッキング</td><td>相手の言った<b>言葉をそのまま返す</b>。<br>「コンペに行かれるんですね！」</td></tr>
    </table>
    <div class="box gold" style="margin-top:11px">
      <h4>類似性の法則</h4>
      <p style="font-size:9.8pt">人は<b>自分と似たもの</b>に安心し、好感を持ちます。<br>出身地・趣味・年齢・仕事──共通点が1つ見つかるだけで距離は一気に縮まります。<b>ヒアリングで共通点を探してください。</b></p>
    </div>
  </div>
  <div class="c40">
    <h2 class="sec">言葉以外で合わせる</h2>
    <table class="xtight">
      <tr><td class="k">姿勢</td><td>前のめり／背もたれ</td></tr>
      <tr><td class="k">ジェスチャー</td><td>手の動き・大きさ</td></tr>
      <tr><td class="k">表情</td><td>笑顔・真剣さ</td></tr>
      <tr><td class="k">声のトーン</td><td>高さ・大きさ</td></tr>
      <tr><td class="k">話すスピード</td><td>速い／ゆっくり</td></tr>
      <tr><td class="k">まばたき・呼吸</td><td>テンポを合わせる</td></tr>
    </table>
    <div class="box" style="margin-top:11px">
      <p style="font-size:9.7pt"><b>電話のときは特に重要。</b>視覚情報が使えないぶん、声の大きさ・速さ・トーンだけで印象が決まります。</p>
    </div>
    <div class="box ng" style="margin-top:11px">
      <p style="font-size:9.7pt">わざとらしく真似すると逆効果です。<b>「合わせにいく」のではなく「自然に寄せる」</b>くらいで十分です。</p>
    </div>
  </div>
</div>
""", sub="ペーシング・ミラーリング・バックトラッキング", foot_l=F, foot_r="09"))

# 10
S.append(slide("10", "相手の五感タイプに合わせる", """
<p class="lead">人は情報を処理するとき、得意な感覚があります。<b>相手のタイプに合った言葉</b>を使うと、同じ説明でも伝わり方がまったく変わります。</p>
<table class="tight">
  <tr><th style="width:96px">タイプ</th><th style="width:190px">特徴</th><th style="width:220px">よく使う言葉</th><th>指導での伝え方</th></tr>
  <tr><td class="k">視覚タイプ</td><td>話すのが速い／頭の中で映像化して処理する</td><td>「見える」「イメージが湧く」「明るい」</td><td><b>映像とデータを見せる。</b>お手本を実演する。<br>「ここを見てください」</td></tr>
  <tr><td class="k">聴覚タイプ</td><td>順序立てて話す／理屈で納得したい</td><td>「聞こえる」「なるほど」「つまり」</td><td><b>理由を言葉で説明する。</b>「なぜそうなるか」を丁寧に。<br>音（ブラッシング音）も有効</td></tr>
  <tr><td class="k">身体感覚<br>タイプ</td><td>ゆっくり話す／体で覚えるのが得意</td><td>「しっくりくる」「重い」「掴む」</td><td><b>実際に動かして体感してもらう。</b><br>「今の感じ、覚えておいてください」</td></tr>
</table>
<div class="cols" style="margin-top:13px">
  <div class="c60">
    <div class="box gold">
      <h4>見分け方は「話す速さ」と「使う言葉」</h4>
      <p style="font-size:9.8pt">早口で「イメージ」と言う方は視覚タイプ。<br>
      理屈っぽく順序立てて話す方は聴覚タイプ。<br>
      ゆっくり間を取って話す方は身体感覚タイプ。<br>
      <b>ヒアリングの5分で、必ず観察してください。</b></p>
    </div>
  </div>
  <div class="c40">
    <div class="box">
      <h4>迷ったら3つとも使う</h4>
      <p style="font-size:9.8pt">「<b>見て</b>いただくと（視覚）、ここで<b>音が</b>変わるので（聴覚）、<b>この感じ</b>を覚えてください（身体感覚）」<br>
      <span class="small">1つの説明に3つの感覚を混ぜると、誰にでも届きます。</span></p>
    </div>
  </div>
</div>
""", sub="視覚・聴覚・身体感覚", foot_l=F, foot_r="10"))

# 11
S.append(slide("11", "NGレッスン集 ①", """
<table class="xtight">
  <tr><th style="width:36px">#</th><th style="width:120px">NGレッスン</th><th style="width:230px">NGワード・行為</th><th>解決方法</th></tr>
  <tr><td class="c">1</td><td class="k">NOレッスン</td><td>「わかりません」「知りません」<br>「どうですかね」</td><td>質問がわからないときは<b>次回までに調べてくる</b>と伝える。<br>お客様は<b>プロに聞いている</b>。曖昧に濁さない</td></tr>
  <tr><td class="c">2</td><td class="k">出来ますでしょう<br>レッスン</td><td>「前にできていましたよね？」<br>「1回もやらなくていいですか」</td><td>お客様の顔色を見て、できなくなっていたら<b>改めてやる事を丁寧に伝える</b>。<br>以前できたことを前提にしない</td></tr>
  <tr><td class="c">3</td><td class="k">何度も教えない<br>レッスン</td><td>「何回も教えましたよね」</td><td>何回聞かれても<b>初めてのように答える</b>。<br>忘れるのは当たり前。覚えていないことを責めない</td></tr>
  <tr><td class="c">4</td><td class="k">お説教レッスン</td><td>「全然だめですね」<br>「ちゃんと練習してますか？」</td><td>できていないことより<b>できたことを言う</b>。<br>「ここは前より良くなっていますよ」から入る</td></tr>
  <tr><td class="c">5</td><td class="k">命令レッスン</td><td>「〜してください」だけ<br>「〜以外やるな」</td><td><b>「〜していただけますか」</b>に言い換える。<br>理由を添えると命令ではなくなる</td></tr>
  <tr><td class="c">6</td><td class="k">近すぎレッスン</td><td>会員様の顔に近づく／背後から近づく<br>不用意に体に触れる</td><td><b>正面から、腕1本分の距離</b>を空ける。<br>触れる必要があるときは<b>必ず先に一言</b>「失礼します、触れますね」</td></tr>
  <tr><td class="c">7</td><td class="k">手抜きレッスン</td><td>時間を早く切り上げる<br>スマホを見る／他のスタッフと喋る</td><td><b>時間はきっちり使う。</b>ワンポイントの5分も、5分きっちり向き合う。<br>手が空いたら次の球出しや準備をする</td></tr>
</table>
""", sub="言ってはいけない言葉と、その解決方法", foot_l=F, foot_r="11"))

# 12
S.append(slide("12", "NGレッスン集 ②", """
<table class="xtight">
  <tr><th style="width:36px">#</th><th style="width:120px">NGレッスン</th><th style="width:230px">NGワード・行為</th><th>解決方法</th></tr>
  <tr><td class="c">8</td><td class="k">恩着せレッスン</td><td>「私が教えてあげたから上手くなった」</td><td>上達は<b>お客様の努力の結果</b>。<br>「◯◯様が練習されたからです」と返す。<br><b>他の人から褒められると人は嬉しい</b>ので、他コーチにも共有する</td></tr>
  <tr><td class="c">9</td><td class="k">曖昧アドバイス<br>レッスン</td><td>「〜だと思います」<br>「たぶん〜じゃないですかね」</td><td><b>わからないときは、その場で答えを出さずに正直に。</b><br>「確認して次回きちんとお伝えします」<br>いい加減な断定も、曖昧な逃げも、どちらも信頼を失う</td></tr>
  <tr><td class="c">10</td><td class="k">専門用語が多い<br>レッスン</td><td>アウトサイドイン／シャローイング<br>フェースローテーション</td><td><b>誰でも分かる言葉に置き換える。</b><br>「クラブが外から入ってきています」<br>専門用語を使うときは<b>必ず日本語の説明をセットで</b></td></tr>
  <tr><td class="c">11</td><td class="k">ネタ切れレッスン</td><td>下品な会話／政治・宗教の話<br>他のお客様の噂話</td><td>会話のネタは<b>ゴルフ・季節・旅・食べ物</b>で十分。<br>信頼関係ができていても<b>下品な言葉は使わない</b></td></tr>
  <tr><td class="c">12</td><td class="k">比較レッスン</td><td>「◯◯さんはもうできてますよ」</td><td>比べるのは<b>その方の過去とだけ</b>。<br>「先月より確実に良くなっています」</td></tr>
  <tr><td class="c">13</td><td class="k">ひいきレッスン</td><td>特定の会員様にだけ長く付く<br>上手い人にだけ丁寧</td><td><b>全員に同じ時間・同じ熱量。</b><br>初心者ほど時間をかける</td></tr>
</table>
<div class="banner" style="margin-top:12px">レッスンで信頼を失う原因は、技術ではなく「言葉」と「態度」です</div>
""", sub="言ってはいけない言葉と、その解決方法", foot_l=F, foot_r="12"))

# 13
S.append(slide("13", "カルテの書き方（Lesson OS）", """
<div class="cols">
  <div class="c60">
    <h2 class="sec">いつ書くか</h2>
    <div class="banner gold">レッスンが終わった直後。その場で書く</div>
    <p class="lead" style="margin-top:10px">後回しにすると必ず内容が薄くなります。次のお客様に入る前に書き切ってください。</p>
    <h2 class="sec mt">必ず書く5項目</h2>
    <table class="tight">
      <tr><td class="k c" style="width:26px">1</td><td><b>今日見た症状</b>（スライス／ダフり／トップ など）</td></tr>
      <tr><td class="k c">2</td><td><b>原因</b>（アドレス／グリップ／手上げ／股関節 など）</td></tr>
      <tr><td class="k c">3</td><td><b>今日お伝えしたこと</b>（1〜3つ。伝えた言葉のまま）</td></tr>
      <tr><td class="k c">4</td><td><b>宿題</b>（次回までに練習していただくこと1つ）</td></tr>
      <tr><td class="k c">5</td><td><b>次回やること</b>（次のコーチへの申し送り）</td></tr>
    </table>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>カルテは会員様にも届きます</h4>
      <p style="font-size:9.8pt">書いたカルテは<b>会員ポータルに通知され、お客様ご本人が読めます</b>。<br>
      社内メモではありません。<b>お客様が読んで意味が分かる言葉</b>で書いてください。</p>
    </div>
    <div class="box" style="margin-top:11px">
      <h4>書き方のコツ</h4>
      <ul class="dot" style="font-size:9.6pt">
        <li>専門用語は使わない</li>
        <li>できなかったことより<b>できたこと</b>を先に書く</li>
        <li>宿題は<b>1つだけ</b>。3つ書くとどれもやってもらえません</li>
        <li>動画を撮ったら必ず紐づける</li>
      </ul>
    </div>
    <div class="box ng" style="margin-top:11px">
      <p style="font-size:9.6pt"><b>レッスンに入る前に、前回のカルテを必ず読む。</b><br>
      これをやらないと一貫性が崩れ、「言われることが毎回違う店」になります。</p>
    </div>
  </div>
</div>
""", sub="レッスン直後に、その場で", foot_l=F, foot_r="13"))

# 14
S.append(slide("14", "計測機器の使い分け", """
<table class="tight">
  <tr><th style="width:130px">機器</th><th style="width:100px">設置打席</th><th>得意なこと・使いどころ</th></tr>
  <tr><td class="k">DTECT</td><td><b>A打席（1F）</b></td><td>スイングの動きの計測。フォームの確認に使う。<b>体験はこのA打席が最優先</b></td></tr>
  <tr><td class="k">TrackMan 4</td><td><b>B打席（2F・左右打席）</b></td><td>弾道・クラブの入り方まで数値で出る。<b>原因を数字で示したいレッスン</b>と<b>左打ちの方</b>はここ</td></tr>
  <tr><td class="k">OKONGOLF</td><td><b>C打席（2F）</b></td><td>シミュレーションラウンド。<b>コースを想定した練習</b>や、楽しんでいただく時間に使う</td></tr>
</table>
<div class="cols" style="margin-top:13px">
  <div class="c60">
    <h2 class="sec">機器を使うときの原則</h2>
    <ul class="dot" style="font-size:10pt">
      <li><b>数字を読み上げるだけにしない。</b>お客様が知りたいのは数字ではなく「だから何をすればいいか」です</li>
      <li>データは<b>1〜2項目に絞って</b>見せる。全部見せると混乱します</li>
      <li><b>映像と実感のズレ</b>を本人に確認していただく。「どう感じますか？」が最強の質問です</li>
      <li>レッスン前に<b>前のお客様のデータを必ず消す</b></li>
    </ul>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>体験のときは必ずBefore／After</h4>
      <p style="font-size:9.8pt">最初の球と最後の球を<b>並べて見せられる状態</b>にしておく。<br>
      言葉で説明するより、映像を並べるほうが100倍伝わります。</p>
    </div>
    <div class="box" style="margin-top:11px">
      <p style="font-size:9.6pt">機器の起動・終了手順は<b>④開店マニュアル／⑤閉店マニュアル</b>に記載しています。</p>
    </div>
  </div>
</div>
""", sub="TrackMan 4 ／ DTECT ／ OKONGOLF", foot_l=F, foot_r="14"))

# 15
S.append(slide("15", "レッスン前後のチェックリスト", """
<div class="cols">
  <div>
    <h2 class="sec">レッスン前</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li><b>前回のカルテを読んだ</b></li>
      <li>今日扱うテーマを1つに決めた</li>
      <li>計測機器を起動し、前データを消した</li>
      <li>ボールを補充した<br><span class="small">タオル・お水は事前に置かず、ご希望があればお出しする</span></li>
      <li>お客様のお名前を確認した</li>
    </ul>
    <h2 class="sec mt">レッスン中</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>明るく挨拶し、お名前でお呼びした</li>
      <li><b>ストレッチ</b>から入った</li>
      <li><b>ビジネスゾーン</b>から始めた</li>
      <li>まず<b>できていることを1つ褒めた</b></li>
      <li>伝えたことは<b>3つ以内</b>に絞った</li>
    </ul>
  </div>
  <div>
    <h2 class="sec">レッスン中（続き）</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>専門用語を日本語に言い換えた</li>
      <li>「どう感じますか？」と<b>理解を確認</b>した</li>
      <li>崩れたら1つ前の段階に戻した</li>
      <li>Before／Afterの映像を残した</li>
      <li>腕1本分の距離を保った</li>
      <li>触れる前に必ず一言かけた</li>
      <li>時間をきっちり使った</li>
    </ul>
    <h2 class="sec mt">レッスン後</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>「今日はこれだけ覚えて帰ってください」と1つに絞って締めた</li>
      <li><b>レッスン終了後すぐ、その場でカルテを書いた</b>（5項目）<br><span class="small">次のレッスンが続くときはお見送り後の空き時間に。<b>その日のうちにポータルへ届くまで</b>が仕事です</span></li>
      <li>宿題を<b>1つだけ</b>お伝えした</li>
      <li>次回のご予約を確認した</li>
    </ul>
  </div>
  <div>
    <div class="box gold">
      <h4>迷ったときの判断基準</h4>
      <ul class="dot" style="font-size:9.6pt">
        <li>直すのは<b>3つまで</b></li>
        <li>持ち帰りは<b>1つだけ</b></li>
        <li>崩れたら<b>1つ前へ戻る</b></li>
        <li>前のコーチを<b>否定しない</b></li>
        <li>比べるのは<b>その方の過去</b>とだけ</li>
      </ul>
    </div>
    <div class="box" style="margin-top:12px">
      <h4>初心者レッスン以外は</h4>
      <p style="font-size:9.7pt">レッスンカルテ（Lesson OS）とAIアシスタントを併用して組み立てます。<br>
      <span class="small">過去のカルテから傾向を出せるので、必ず参照してからメニューを決めてください。</span></p>
    </div>
    <div class="box ng" style="margin-top:12px">
      <p style="font-size:9.6pt"><b>カルテを書かないレッスンは、やっていないのと同じ。</b><br>
      書いても届かなければ意味がありません。ポータルに届くまでが仕事です。</p>
    </div>
  </div>
</div>
""", sub="印刷して打席まわりに置いてください", foot_l=F, foot_r="15"))

SLIDES = S
