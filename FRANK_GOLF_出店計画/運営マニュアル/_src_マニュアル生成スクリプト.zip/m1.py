# -*- coding: utf-8 -*-
"""① 体験マニュアル"""
from common import cover, slide

F = "① 体験マニュアル"
S = []

S.append(cover(
    "MANUAL 01",
    "体験マニュアル",
    "体験の55分で、入会を決めていただく。<br>その手順とセリフを、そのまま書いています。"))

# ---------------------------------------------------------------- 01
S.append(slide("01", "このマニュアルの位置づけ", """
<div class="cols">
  <div class="c60">
    <h2 class="sec">体験は「レッスン」ではなく「入会の入口」</h2>
    <p class="lead">通常のレッスンは<b>上達させる</b>ことが目的です。<br>
    体験レッスンは<b>「レッスンが必要だ」と気づいていただく</b>ことが目的です。<br>
    ここを取り違えると、いいレッスンをしたのに入会されない、が起こります。</p>
    <div class="box gold" style="margin-top:10px">
      <h4>体験で必ず持ち帰っていただく3つ</h4>
      <ul class="dot" style="font-size:9.5pt">
        <li><b>必要性</b>　独学では遠回りになる、と自分で気づいた状態</li>
        <li><b>違い</b>　　来たときと帰るときで、球が変わった実感</li>
        <li><b>ビジョン</b>　FRANKに通う自分の姿が具体的に描けている</li>
      </ul>
    </div>
  </div>
  <div class="c40">
    <h2 class="sec">集客〜入会のサイクル</h2>
    <table class="tight">
      <tr><td class="k">① 集客</td><td>広告・MEO・SNS</td></tr>
      <tr><td class="k">② 来店促進</td><td>予約後の連絡・リマインド</td></tr>
      <tr><td class="k">③ 入会促進</td><td><b>体験＋クロージング</b></td></tr>
      <tr><td class="k">④ 提供</td><td>レッスン・カルテ</td></tr>
    </table>
    <p class="small" style="margin-top:7px">どれか1つでも欠けると数字は落ちます。③はスタッフの力で一番動かせる場所です。</p>
    <div class="tiles" style="margin-top:12px">
      <div class="tile"><div class="n">55<span style="font-size:11pt">分</span></div><div class="lb">体験の所要時間</div></div>
      <div class="tile"><div class="n">60<span style="font-size:11pt">分</span></div><div class="lb">打席の予約枠</div></div>
    </div>
  </div>
</div>
<div class="banner" style="margin-top:14px">体験の目的は「いいレッスンをすること」ではなく「入会という一歩を踏み出していただくこと」</div>
""", sub="体験＝入会の入口", foot_l=F, foot_r="01"))

# ---------------------------------------------------------------- 02
S.append(slide("02", "体験55分の時間割", """
<div class="tl">
  <div class="step"><div class="t">0:00</div><div class="bar"></div><div class="l">お出迎え<br>着席</div><div class="m">2分</div></div>
  <div class="step"><div class="t">0:02</div><div class="bar"></div><div class="l">カウンセリング<br>シート</div><div class="m">5分</div></div>
  <div class="step"><div class="t">0:07</div><div class="bar"></div><div class="l">打席へご案内<br>使い方の説明</div><div class="m">5分</div></div>
  <div class="step"><div class="t">0:12</div><div class="bar"></div><div class="l">体験レッスン<br>コーチが入る</div><div class="m">10分</div></div>
  <div class="step"><div class="t">0:23</div><div class="bar"></div><div class="l">自由練習<br>一度離れる</div><div class="m">7分</div></div>
  <div class="step"><div class="t">0:30</div><div class="bar"></div><div class="l">内容の確認<br>店内のご案内</div><div class="m">5分</div></div>
  <div class="step"><div class="t">0:35</div><div class="bar"></div><div class="l">お迎え<br>カウンターへ</div><div class="m">2分</div></div>
  <div class="step"><div class="t">0:37</div><div class="bar"></div><div class="l">クロージング</div><div class="m">10〜13分</div></div>
  <div class="step"><div class="t">0:50</div><div class="bar"></div><div class="l">入会手続き<br>／お見送り</div><div class="m">5分</div></div>
</div>
<div class="cols" style="margin-top:6px">
  <div class="c65">
    <h2 class="sec">各パートの中身</h2>
    <table class="tight">
      <tr><th style="width:62px">時刻</th><th style="width:120px">パート</th><th>やること</th></tr>
      <tr><td class="c">0:00</td><td class="k">お出迎え</td><td>お名前でお呼びする／上着・お荷物／カウンター前テーブルへご着席</td></tr>
      <tr><td class="c">0:02</td><td class="k">カウンセリング</td><td><b>カウンセリングシート（紙）にご記入いただく</b>。書かれた内容から会話を広げる</td></tr>
      <tr><td class="c">0:07</td><td class="k">打席案内</td><td>打席・貸クラブのご案内と<b>シミュレーターの使い方を5分ご説明</b>。ここは付き添う</td></tr>
      <tr><td class="c">0:12</td><td class="k">体験レッスン</td><td>コーチが入り<b>10分</b>。ビフォーアフターを必ず作る</td></tr>
      <tr><td class="c">0:23</td><td class="k">自由練習</td><td>習ったことを一人で試していただく。<b>コーチは一度必ず離れる</b></td></tr>
      <tr><td class="c">0:30</td><td class="k">内容の確認</td><td>打席で<b>今日のレッスン内容を5分で振り返る</b></td></tr>
      <tr><td class="c">0:35</td><td class="k">お迎え</td><td><b>軽く店内をご案内しながら</b>カウンター前テーブルへ。<b>ここでお飲み物をお出しする</b></td></tr>
      <tr><td class="c">0:37</td><td class="k">クロージング</td><td>感想 → 現状肯定 → 損失 → 数値化 → プラン提示 → 意思確認</td></tr>
      <tr><td class="c">0:50</td><td class="k">手続き</td><td>お客様のスマホでWeb入会フォーム → カード決済</td></tr>
    </table>
  </div>
  <div class="c35">
    <h2 class="sec">担当の決め方</h2>
    <div class="box">
      <ul class="dot" style="font-size:9.5pt">
        <li><b>原則、コーチ1名が最初から最後まで担当</b>します（カウンセリングもクロージングもコーチ）</li>
        <li><b>体験が同じ時刻に重なるときは、コーチ1名＋受付1名で分担</b>。コーチ＝打席とレッスン、受付＝お出迎え・シート・お飲み物・クロージングの準備。<b>クロージングはコーチが順番に入る</b></li>
        <li>途中で担当を替えない。替えると信頼が切れ、入会率が落ちます</li>
      </ul>
    </div>
    <div class="box ng" style="margin-top:10px">
      <h4>時間の厳守 ── 遅らせない3つの手</h4>
      <p style="font-size:9.2pt">打席は<b>60分枠</b>で次の予約が入ります。<b>35分でのお迎えを絶対に遅らせない。</b></p>
      <ul class="dot" style="font-size:9pt">
        <li><b>0:30にタイマーをセット</b>して打席へ戻る</li>
        <li>手が離せないときは<b>受付がお迎えに行く</b></li>
        <li>レッスンが乗っていても<b>0:30で必ず区切る</b>。続きはクロージングで話す</li>
      </ul>
    </div>
  </div>
</div>
""", sub="打席は60分枠 ／ 体験の中身は55分", foot_l=F, foot_r="02"))

# ---------------------------------------------------------------- 03
S.append(slide("03", "体験前の準備", """
<div class="cols">
  <div>
    <h2 class="sec">前日までに</h2>
    <ul class="chk">
      <li><b>翌日の体験予約を一覧で確認</b>（人数・時間・お名前・利き手）</li>
      <li>打席の割当を確認する。<b>打席は予約時に自動で割り当てられます</b>。<b>左打ちの方がB打席か</b>を見て、違えば入れ替える</li>
      <li><b>ネット予約では利き手が分かりません。</b>前日までに確認のお電話（またはLINE）を1本入れ、<b>利き手・お持ち物・お時間</b>をご案内する</li>
      <li>担当コーチを決め、シフト表に体験マークを入れる</li>
      <li>前日リマインドの連絡が届いているか確認する</li>
      <li>貸クラブ（男性用・女性用・レディース）とグローブの在庫を確認</li>
    </ul>
    <h2 class="sec mt">当日・開店後</h2>
    <ul class="chk">
      <li><b>カウンセリングシート</b>とペンをカウンターに用意する</li>
      <li>受付iPadの<b>体験アンケート画面</b>を開けるようにしておく（シートの内容を後から転記します）</li>
      <li>打席の計測機器を起動し、<b>前のお客様のデータを消す</b></li>
      <li>カウンター前テーブルを片づけ、<b>料金表を伏せて置いておく</b></li>
    </ul>
  </div>
  <div>
    <h2 class="sec">お客様到着5分前</h2>
    <ul class="chk">
      <li>打席に<b>貸クラブ・グローブ</b>を用意<br><span class="small">タオル・お水は事前に置きません。ご希望があればその場でお出しします</span></li>
      <li><b>バッグエリア</b>を空けておく（ゴルフバッグをお預かりします）</li>
      <li>ボールを補充し、マットの位置を整える</li>
      <li>お名前を声に出して確認する（読み間違いを防ぐ）</li>
      <li>予約情報を見て<b>声かけのネタを1つ決めておく</b>（初来店／紹介／体験の目的）</li>
      <li>入口のドアが開くのが見える位置に立つ</li>
    </ul>
    <div class="box gold" style="margin-top:12px">
      <h4>お客様にお持ちいただくもの（予約時にご案内）</h4>
      <table class="xtight" style="margin-top:5px">
        <tr><td class="k">貸出あり</td><td>クラブ・グローブ（無料）</td></tr>
        <tr><td class="k">貸出なし</td><td><b>シューズ</b>。動きやすい靴でお越しください</td></tr>
        <tr><td class="k">服装</td><td>動きやすい服装であればOK。着替えスペースあり</td></tr>
        <tr><td class="k">入会される場合</td><td><b>クレジットカード</b>と<b>身分証明書</b></td></tr>
      </table>
      <p class="small" style="margin-top:6px">「手ぶらでOK」と案内していますが、<b>入会を考えている方にはカードと身分証だけ前日にお伝えする</b>と、その場で完結します。</p>
    </div>
  </div>
</div>
""", sub="準備が9割", foot_l=F, foot_r="03"))

# ---------------------------------------------------------------- 04
S.append(slide("04", "お出迎え〜ご着席（0:00〜0:02）", """
<div class="cols">
  <div class="c60">
    <div class="script">
      <div class="line"><div class="who">スタッフ</div><div class="say">「<em>◯◯様</em>ですね。本日はお越しいただきありがとうございます。FRANK GOLFの<em>◯◯</em>と申します。本日担当させていただきます。」
      <span class="note">▶ 必ず「お名前」＋「自分の名前」。名乗らないと最後まで距離が縮まりません。</span></div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「お荷物と上着、こちらでお預かりしますね。<em>ゴルフバッグはこちらのバッグエリア</em>でお預かりします。」
      <span class="note">▶ 手を空けていただく。荷物を持ったままだと人は身構えます。<br><b>ゴルフバッグ＝バッグエリア／上着・お荷物＝お席の脇。テーブルの上には置きません。</b></span></div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「本日は<em>55分</em>のお時間をいただきます。<br>
      はじめに5分ほどご記入とお話をお願いして、そのあと<em>約30分</em>打っていただきます。最後に少しだけお時間をください。」
      <span class="note">▶ 最初に全体の流れを言う。先が読めると人は安心して話します。</span></div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「まずはこちらにおかけください。こちらのシートに、分かる範囲でご記入をお願いできますか。」
      <span class="note">▶ <b>お飲み物はここでは出しません。</b>0:35でカウンターにお戻りいただいたときにお出しします。</span></div></div>
    </div>
  </div>
  <div class="c40">
    <div class="box">
      <h4>この2分でやること</h4>
      <ul class="chk" style="font-size:9pt">
        <li>お名前でお呼びする</li>
        <li>自分の名前を名乗る</li>
        <li>お荷物・上着をお預かりする</li>
        <li>ゴルフバッグをバッグエリアでお預かりする</li>
        <li>今日の流れを先に伝える</li>
        <li>カウンター前テーブルへご案内</li>
        <li><b>カウンセリングシート</b>とペンをお渡しする</li>
      </ul>
    </div>
    <div class="box ng" style="margin-top:10px">
      <h4>やってはいけない</h4>
      <ul class="dot" style="font-size:9.2pt">
        <li>いきなり料金表を出す</li>
        <li><b>最初にお飲み物を出す</b>（お飲み物はクロージングのときに）</li>
        <li>お荷物をテーブルの上に置く</li>
        <li>「ご予約の方ですか？」と確認から入る（お名前は分かっているはず）</li>
        <li>立ち話のままヒアリングを始める</li>
        <li>スタッフ同士で私語をする</li>
      </ul>
    </div>
    <div class="box gold" style="margin-top:10px">
      <p style="font-size:9.5pt"><b>メラビアンの法則</b>　伝わる情報の<b>55%は見た目</b>、38%は声、言葉そのものは7%。<br>
      <b>姿勢・表情・声の大きさ</b>が、台本より先に効きます。</p>
    </div>
  </div>
</div>
""", sub="第一印象は55%が見た目", foot_l=F, foot_r="04"))

# ---------------------------------------------------------------- 05
S.append(slide("05", "ヒアリングの型", """
<div class="cols">
  <div class="c40">
    <h2 class="sec">ヒアリングの目的は3つ</h2>
    <table class="tight">
      <tr><th style="width:26px">#</th><th style="width:96px">目的</th><th>中身</th></tr>
      <tr><td class="c">1</td><td class="k">アイスブレイク</td><td>緊張と警戒心をほどく</td></tr>
      <tr><td class="c">2</td><td class="k">情報を得る</td><td>クロージングで使う材料を引き出す</td></tr>
      <tr><td class="c">3</td><td class="k"><b>聞いてくれる<br>状態をつくる</b></td><td><b>これが最重要。</b>聞いてもらえない状態でいくら説明しても入会しません</td></tr>
    </table>
    <div class="box gold" style="margin-top:11px">
      <h4>会話の比率は お客様7：スタッフ3</h4>
      <p style="font-size:9.5pt">しゃべりすぎない。<b>沈黙を怖がって埋めない。</b></p>
    </div>
  </div>
  <div class="c60">
    <h2 class="sec">使う4つの技術</h2>
    <table class="tight">
      <tr><th style="width:120px">技術</th><th>使い方</th></tr>
      <tr><td class="k">バックトラッキング</td><td>お客様の言葉をそのまま返す。「コンペに出られるんですね！」<br><span class="small">これだけで「聞いてもらえている」感じが増します</span></td></tr>
      <tr><td class="k">さしすせそ</td><td><b>さ</b>すがですね／<b>し</b>らなかったです／<b>す</b>ごいですね／<b>せ</b>ンスありますね／<b>そ</b>うなんですか！</td></tr>
      <tr><td class="k">5W1Hで聞く</td><td>いつ・どこで・誰と・何を・なぜ・どのように。<br><span class="small">「はい／いいえ」で終わる聞き方をしない</span></td></tr>
      <tr><td class="k">キドニタテカケ</td><td>季節／道楽・趣味／ニュース／旅／テレビ／家族／健康／会社<br><span class="small">雑談は1〜2分まで。長い雑談は「時間を奪われた」と感じられます</span></td></tr>
    </table>
    <div class="box ng" style="margin-top:10px">
      <h4>NG：解釈・決めつけトーク</h4>
      <ul class="dot" style="font-size:9.2pt">
        <li>「じゃあ◯◯ってことですね」と勝手にまとめる</li>
        <li>お客様の話を<b>否定する</b>（「それは違いますね」は絶対に言わない）</li>
        <li>話題を急に変える。変えるときは接続詞を必ず挟む</li>
      </ul>
    </div>
  </div>
</div>
""", sub="聞く力・伝える力・非言語", foot_l=F, foot_r="05"))

# ---------------------------------------------------------------- 06
S.append(slide("06", "カウンセリングシートの8項目", """
<p class="lead">お席にご案内したら、<b>カウンセリングシート（紙）とペンをお渡しし、お客様ご自身にご記入いただきます</b>。<br>
書いていただいた内容を見ながら会話を広げるのがヒアリングです。<b>スタッフは受付iPadに後から転記</b>してください。</p>
<div class="cols">
  <div class="c60">
    <h2 class="sec">シートの8項目（お客様が記入）</h2>
    <table class="xtight">
      <tr><th style="width:22px">#</th><th style="width:96px">項目</th><th>選択肢・書き方</th></tr>
      <tr><td class="c">1</td><td class="k">ゴルフ歴</td><td>未経験・始めたばかり／1年未満／1〜3年／3〜10年／10年以上</td></tr>
      <tr><td class="c">2</td><td class="k">普段の頻度</td><td>練習＝ほぼしない／月1〜2回／週1回／週2回以上<br>ラウンド＝ほぼしない／月1回程度／月2回以上</td></tr>
      <tr><td class="c">3</td><td class="k">普段の練習場所</td><td>記述。<b>他店名が出ても否定しない</b></td></tr>
      <tr><td class="c">4</td><td class="k">平均スコア</td><td>120以上／110台／100台／90台／80台以下／まだコースに出たことがない</td></tr>
      <tr><td class="c">5</td><td class="k">一番改善したいこと<br><span class="small">（最大2つ）</span></td><td>ドライバー／アイアン／アプローチ／飛距離アップ／方向性／基礎から整えたい／スコアアップ／その他</td></tr>
      <tr><td class="c">6</td><td class="k">練習場所選びで<br>重視すること<span class="small">（最大2つ）</span></td><td>通いやすさ／完全個室／シミュレーター・設備／レッスン／好きな時間／落ち着ける／料金／その他</td></tr>
      <tr><td class="c">7</td><td class="k">知ったきっかけ</td><td>Instagram／Google／YouTube／紹介／店舗・看板／チラシ／その他</td></tr>
      <tr><td class="c">8</td><td class="k">今日知りたいこと</td><td>記述。<b>ここが今日のレッスンのテーマになります</b></td></tr>
    </table>
    <p class="small" style="margin-top:5px">シート下部の<b>スタッフ記入欄</b>には、担当者名・打席・気づいたこと（利き手、体の硬さ、会話で出た日付など）を書きます。</p>
  </div>
  <div class="c40">
    <h2 class="sec">会話で必ず聞き足す3つ</h2>
    <table class="xtight">
      <tr><td class="k">コンペ・<br>ラウンド予定</td><td>「直近でコンペやラウンドのご予定は？」<br><b>日付が出たら必ずメモ。最強の材料です</b></td></tr>
      <tr><td class="k">通える<br>曜日・時間帯</td><td>「お仕事帰りと土日、どちらが動きやすいですか？」</td></tr>
      <tr><td class="k">ご自宅・職場<br>からの距離</td><td>「どちらからお越しですか？」</td></tr>
    </table>
    <div class="box gold" style="margin-top:9px">
      <h4>そのままクロージングの材料になります</h4>
      <table class="xtight" style="margin-top:4px">
        <tr><td class="k">①②④</td><td>「見えない損失」を数値化する前提になる</td></tr>
        <tr><td class="k">⑤⑧</td><td>今日のレッスンのテーマ。<b>最後に必ず答えを返す</b></td></tr>
        <tr><td class="k">⑥＋聞き足し</td><td><b>提案するプランが決まる</b>（下記）</td></tr>
        <tr><td class="k">⑦</td><td>受付台帳に記録（集客の判断材料）</td></tr>
      </table>
    </div>
    <div class="box" style="margin-top:9px">
      <h4>プランの決め方</h4>
      <table class="xtight">
        <tr><td class="k">平日の昼に月2〜4回</td><td>ライト会員</td></tr>
        <tr><td class="k">週1〜2回・仕事帰り</td><td><b>レギュラー会員</b></td></tr>
        <tr><td class="k">がっつり通う・2時間</td><td>マスター会員</td></tr>
        <tr><td class="k">会社で使いたい</td><td>法人プラン</td></tr>
      </table>
    </div>
  </div>
</div>
""", sub="記入はお客様／iPadへは後から転記", foot_l=F, foot_r="06"))

# ---------------------------------------------------------------- 07
S.append(slide("07", "ヒアリング台本（0:02〜0:07）", """
<div class="script">
  <div class="line"><div class="who">スタッフ</div><div class="say">「ご記入ありがとうございます。<em>Instagram</em>で見つけてくださったんですね、うれしいです。」
  <span class="note">▶ 入りは<b>シートに書かれたことを1つ拾って返す</b>。同じことをもう一度聞かない。</span></div></div>
  <div class="line"><div class="who">スタッフ</div><div class="say">「ありがとうございます。ゴルフはどれくらいされてるんですか？」　→　<b>①ゴルフ歴</b></div></div>
  <div class="line"><div class="who g">お客様</div><div class="say g">「3年くらいですね。でも全然上手くならなくて…」</div></div>
  <div class="line"><div class="who">スタッフ</div><div class="say">「<em>3年</em>されてるんですね！　ベストスコアはどのくらいですか？」　→　<b>バックトラッキング＋②</b>
  <span class="note">▶ お客様の言葉を必ず1度返してから次の質問へ。</span></div></div>
  <div class="line"><div class="who g">お客様</div><div class="say g">「105が一番良くて、いつも110台です。」</div></div>
  <div class="line"><div class="who">スタッフ</div><div class="say">「もう<em>100切りが目の前</em>じゃないですか！　あと少しですね。<br>
  そもそも何がきっかけで始められたんですか？」　→　<b>ほめる＋③</b></div></div>
  <div class="line"><div class="who">スタッフ</div><div class="say">「なるほど。直近でコンペやラウンドのご予定ってあるんですか？」　→　<b>⑤（最重要）</b>
  <span class="note">▶ ここで日付が出たら必ずメモ。クロージングで「その日までに」と使えます。</span></div></div>
  <div class="line"><div class="who">スタッフ</div><div class="say">「<em>◯◯ゴルフセンター</em>で練習されているんですね。週にどのくらい行かれますか？」
  <span class="note">▶ ③④に書かれた内容から広げる。<b>他店を絶対にけなさない。</b></span></div></div>
  <div class="line"><div class="who">スタッフ</div><div class="say">「ちなみに今日はどちらからお越しですか？　お仕事帰りと土日だと、どちらが動きやすいですか？」　→　<b>⑦⑧</b></div></div>
  <div class="line"><div class="who">スタッフ</div><div class="say">「ありがとうございます。だいたい分かりました。<br>
  <em>◯◯様は「◯月のコンペまでに100を切りたい」</em>ということですね。<br>
  では、まず実際に打っていただいて、今どういう状態なのか一緒に見ていきましょう。」
  <span class="note">▶ <b>最後に必ず要約して言い直す。</b>ここで合意が取れると、クロージングが一気に楽になります。</span></div></div>
</div>
""", sub="シートを見ながら会話を広げる", foot_l=F, foot_r="07"))

# ---------------------------------------------------------------- 08
S.append(slide("08", "打席へのご案内（0:07〜）", """
<div class="cols">
  <div class="c60">
    <div class="script">
      <div class="line"><div class="who">スタッフ</div><div class="say">「本日は<em>◯打席</em>をご用意しています。こちらへどうぞ。」
      <span class="note">▶ 左打ちの方は必ずB打席（左右打席）。</span></div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「まず<em>シミュレーターの使い方を5分ほどご説明</em>しますね。<br>
      こちらが<em>弾道計測器</em>です。ボールのスピード・飛距離・曲がり方・クラブの入り方まで、全部数字で出ます。<br>
      <em>今日は「なんとなく」ではなく、数字と映像でご自身の状態を見ていただきます。</em>」
      <span class="note">▶ 機器は「すごい機械」ではなく<b>「お客様の現状が見えるもの」</b>として紹介する。<b>この5分は必ず付き添う。</b></span></div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「では実際に打ってみましょう。いつも通りで大丈夫です。<br>
      このあと<em>10分ほど</em>、一緒に見させていただきますね。」
      <span class="note">▶ そのまま<b>0:12から体験レッスン10分</b>へ入る（⑨⑩へ）。</span></div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「ここからは<em>ご自身で試してみてください</em>。私はいったん離れますので、何かあればいつでもお声がけください。」
      <span class="note">▶ <b>0:23から自由練習。コーチはここで一度必ず離れる。</b>見られていると力みます。<br>
      「一人でもできた」という実感が、そのまま入会の理由になります。</span></div></div>
    </div>
  </div>
  <div class="c40">
    <h2 class="sec">打席と機器</h2>
    <table class="xtight">
      <tr><th style="width:60px">打席</th><th style="width:32px">階</th><th>備考</th></tr>
      <tr><td class="k">A打席</td><td class="c">1F</td><td><b>DTECT</b>／<b>体験は最優先でここ</b></td></tr>
      <tr><td class="k">B打席</td><td class="c">2F</td><td><b>TrackMan 4</b>／<b>左右打席</b>・左打ちの方は必ずここ</td></tr>
      <tr><td class="k">C打席</td><td class="c">2F</td><td><b>OKONGOLF</b>／A・Bが埋まっているとき</td></tr>
      <tr><td class="k">D打席</td><td class="c">2F</td><td class="tbd">オープン約3ヶ月後に増設予定</td></tr>
    </table>
    <div class="box" style="margin-top:10px">
      <h4>0:07〜0:35 コーチの動き</h4>
      <table class="xtight">
        <tr><td class="k c" style="width:38px">0:07</td><td>使い方を<b>5分説明</b>（付き添う）。この間に球筋を見る</td></tr>
        <tr><td class="k c">0:12</td><td><b>体験レッスン10分</b>。直すのは3つまで、ほめる材料を1つ見つける</td></tr>
        <tr><td class="k c">0:23</td><td><b>離れる</b>。他のお客様の対応をしてもよいが<b>時計は必ず見る</b></td></tr>
        <tr><td class="k c">0:30</td><td>打席に戻り、<b>今日の内容を5分で振り返る</b></td></tr>
        <tr><td class="k c">0:35</td><td>軽く店内をご案内しながらカウンターへ</td></tr>
      </table>
    </div>
  </div>
</div>
""", sub="使い方5分 → レッスン10分 → 自由練習", foot_l=F, foot_r="08"))

# ---------------------------------------------------------------- 09
S.append(slide("09", "体験レッスン｜初心者の方（0:12〜0:23／10分）", """
<p class="lead">初心者の方は<b>「型（かた）」</b>を教えます。感覚ではなく、チェックできる形で覚えていただくのが基本です。</p>
<table class="tight">
  <tr><th style="width:36px">STEP</th><th style="width:180px">内容</th><th>ポイント・声かけ</th></tr>
  <tr><td class="c">1</td><td class="k">PWを2球打っていただく</td><td>難しさを知っていただく／Before確認のため。<b>「まず1球いってみましょう、大丈夫ですよ」</b>と安心させる声かけを先に</td></tr>
  <tr><td class="c">2</td><td class="k">軌道とフェースの向きを説明</td><td>計測データと映像から解説。<b>「どう感じますか？」</b>と必ず問いかけ、映像と実感のズレを本人に確認してもらう</td></tr>
  <tr><td class="c">3</td><td class="k">アドレス・ビジネスゾーン</td><td>グリップ（ナックル確認）・骨盤前傾・ハンドファーストを<b>型として</b>教える。<b>ここまでの経過時間を必ず伝える</b></td></tr>
  <tr><td class="c">4</td><td class="k">フルスイングを実演</td><td>チェックポイントが<b>30個ある</b>ことを示し、「段階的に学ぶ必要がある」と伝える</td></tr>
  <tr><td class="c">5</td><td class="k">ビジネスゾーンの説明</td><td>振り幅・三角形キープ・シャフトの位置を解説。ブラッシングで素振りをしていただく</td></tr>
  <tr><td class="c">6</td><td class="k">実際に打っていただく</td><td>腕の曲がり・振り幅・起き上がりを指摘。<b>苦手な点を重点的に</b>。ここでBefore→Afterを作る</td></tr>
  <tr><td class="c">7</td><td class="k">まとめ・テストクロージング</td><td>BZ→ハーフ→フルの流れと、<b>必要なレッスン回数の目安</b>を伝える</td></tr>
</table>
<div class="cols" style="margin-top:11px">
  <div class="c60"><div class="box gold">
    <h4>体験で必ず言うセリフ</h4>
    <p style="font-size:9.8pt">「今、<em>◯分</em>でここまで変わりました。<br>
    ただ、<b>ここまでの説明はグループレッスンでは難しい</b>んです。」<br>
    <span class="small">▶ 経過時間を言うと、変化の速さが数字で伝わります。必ず時計を見てから言うこと。</span></p>
  </div></div>
  <div class="c40"><div class="box ng">
    <h4>初心者に絶対やらないこと</h4>
    <ul class="dot" style="font-size:9.2pt">
      <li>専門用語を並べる（アウトサイドイン等）</li>
      <li>1回で全部直そうとする</li>
      <li>「感覚で覚えてください」で終わる</li>
    </ul>
  </div></div>
</div>
""", sub="初心者＝型を教える", foot_l=F, foot_r="09"))

# ---------------------------------------------------------------- 10
S.append(slide("10", "体験レッスン｜経験者の方（0:12〜0:23／10分）", """
<p class="lead">経験者の方は<b>「原因を言い当てる」</b>ことが信頼につながります。ミスの理由を、データと映像で本人に納得していただきます。</p>
<table class="xtight">
  <tr><th style="width:36px">STEP</th><th style="width:170px">内容</th><th>ポイント・声かけ</th></tr>
  <tr><td class="c">1</td><td class="k">7I（3〜4球）＋1W（2球）</td><td>エラーが出やすいクラブで現状把握。<b>1球目からナイスショットを打っていただけるよう素振りをさせる</b></td></tr>
  <tr><td class="c">2</td><td class="k">ミスの原因を本人に聞く</td><td>「<b>どこが原因だと思いますか？</b>」　→ 先に言わせる。答えを当てにいかない</td></tr>
  <tr><td class="c">3</td><td class="k">現状のミス＋データ説明</td><td>手打ち・フェースの向き・軌道を解説。<b>手打ちが原因でフェースの向きと軌道が乱れる＝ゴルフの基礎基本で一番大事な部分</b>と伝える</td></tr>
  <tr><td class="c">4</td><td class="k">映像とイメージのギャップ</td><td>「どう感じますか？」<b>悪い動きと良い動きを本人に体感していただく</b></td></tr>
  <tr><td class="c">5</td><td class="k">体の使い方を指摘</td><td>スイングプレーン・股関節・アーリーリリース。<b>アウトサイドインは手上げが原因</b>であることを説明</td></tr>
  <tr><td class="c">6</td><td class="k">アドレス＆BZに繋げる</td><td>骨盤前傾・スタンス幅・3ライン・ハンドファースト。<b>今までのアドレスとの違いを認識していただく</b></td></tr>
  <tr><td class="c">7</td><td class="k">BZの説明</td><td>振り幅・三角形キープ・シャフト位置（手上げとの違い）</td></tr>
  <tr><td class="c">8</td><td class="k">BZを打っていただく</td><td>ブラッシング素振り → 一人練習の限界を伝える。<b>ここまでの経過時間をお伝えする</b></td></tr>
  <tr><td class="c">9</td><td class="k">振り返り＋テストクロージング</td><td>BZ7項目→ハーフ→フルの流れを<b>実演して</b>伝える</td></tr>
</table>
<div class="box gold" style="margin-top:10px">
  <p style="font-size:9.8pt"><b>アマチュアのミスのほとんどの原因</b>＝ フェースコントロールとクラブコントロール（＝アドレスとグリップ）／手上げ・手打ち／股関節を使えていない／アーリーリリース。<br>
  <span class="small">この4つのどれかに必ず当てはまります。当てはめて説明できると「この人は分かっている」と伝わります。</span></p>
</div>
""", sub="経験者＝原因を言い当てる", foot_l=F, foot_r="10"))

# ---------------------------------------------------------------- 11
S.append(slide("11", "35分でお迎え → カウンターへ", """
<div class="cols">
  <div class="c60">
    <div class="script">
      <div class="line"><div class="who">スタッフ</div><div class="say">「<em>◯◯様、お疲れさまでした。</em>いかがでしたか？」
      <span class="note">▶ 打席で立ち話をしない。感想は座ってから聞く。</span></div></div>
      <div class="line"><div class="who c">動作</div><div class="say">打席からカウンターへ向かいながら<b>軽く店内をご案内する</b>（1〜2分）<br>
      「せっかくなので、他の打席もご覧になりますか。こちらが<em>TrackManの打席</em>で…」
      <span class="note">▶ 設備の広さと<b>選べる楽しさ</b>を体感していただくと、通うイメージがつきます。</span></div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「今日のデータをまとめてお見せしたいので、<em>あちらのお席</em>でお話しさせてください。<br>
      クラブはそのままで大丈夫です。」
      <span class="note">▶ <b>「クラブはそのままで」</b>が効きます。片づけを意識させると帰るモードに入ります。</span></div></div>
      <div class="line"><div class="who c">動作</div><div class="say"><b>ここでお飲み物をお出しする</b>（体験中はお出ししません）<br>
      「<em>FRANKレモンスカッシュ</em>です。当店オリジナルなので、よろしければどうぞ。」
      <span class="note">▶ 一言そえてお出しする。ドリンクは<b>通いはじめてからの楽しみ</b>として印象に残します。</span></div></div>
      <div class="line"><div class="who c">動作</div><div class="say">カウンター前テーブルへご案内 → お客様が<b>入口を背にする側</b>に座っていただく
      <span class="note">▶ 出口が見えると人は落ち着かなくなります。スタッフが入口側に座る。</span></div></div>
      <div class="line"><div class="who c">動作</div><div class="say">テーブルに<b>①料金表 ②今日のデータ（iPad）</b>を置く。<b>ペンも一緒に出す</b></div></div>
    </div>
  </div>
  <div class="c40">
    <div class="box ng">
      <h4>ここが体験の一番の分かれ目</h4>
      <p style="font-size:9.7pt">お迎えが遅れる／打席で立ち話で終わる／お客様が自分で片づけ始める ── この3つが起きた時点で、入会率は大きく下がります。<br>
      <b>35分経過で、必ず迎えに行く。</b></p>
    </div>
    <div class="box" style="margin-top:11px">
      <h4>席に着くまでにやっておくこと</h4>
      <ul class="chk" style="font-size:9pt">
        <li>今日のBefore／Afterの映像を出しておく</li>
        <li>ヒアリングで聞いた<b>目標とコンペの日付</b>を見返す</li>
        <li>提案するプランを<b>1つに決めておく</b>（第2候補も1つ）</li>
        <li>キャンペーンの条件をもう一度確認する</li>
        <li><b>お飲み物を用意しておく</b></li>
      </ul>
    </div>
  </div>
</div>
""", sub="0:35〜0:37", foot_l=F, foot_r="11"))

# ---------------------------------------------------------------- 12
S.append(slide("12", "クロージングの考え方", """
<div class="cols">
  <div class="c60">
    <div class="banner">クロージングは「押し売り」ではなく「支援」</div>
    <p class="lead" style="margin-top:11px">お客様が<b>自分で決める</b>ための手助けです。決めるのはお客様、材料をそろえるのがこちらの仕事です。</p>
    <h2 class="sec">流れは4ステップ</h2>
    <table class="tight">
      <tr><th style="width:28px">#</th><th style="width:100px">ステップ</th><th>セリフの型</th></tr>
      <tr><td class="c">1</td><td class="k">現状肯定</td><td>「今のやり方でも、たしかに可能かもしれません」</td></tr>
      <tr><td class="c">2</td><td class="k">見えない損失</td><td>「しかし、そこには<b>莫大な時間</b>が隠れています」</td></tr>
      <tr><td class="c">3</td><td class="k">数値化</td><td>「具体的には<b>◯年</b>を損する可能性があります」</td></tr>
      <tr><td class="c">4</td><td class="k">解決策</td><td>「その損を最小にして最短でゴールに行くために、このレッスンがあります」</td></tr>
    </table>
    <div class="box gold" style="margin-top:11px">
      <p style="font-size:10pt"><b>営業とは、お客様が気づいていない「損」を教えてあげて、それを「得」に変える手助けをすること。</b></p>
    </div>
  </div>
  <div class="c40">
    <h2 class="sec">成約率を高める4つの手法</h2>
    <table class="tight">
      <tr><td class="k">テスト<br>クロージング</td><td>「もし〜なら、始めたいですか？」と<b>仮の意思確認</b>を挟む</td></tr>
      <tr><td class="k">ベネフィットの<br>具体化</td><td>入会後の明るい未来を具体的に想像していただく</td></tr>
      <tr><td class="k">事例の提示<br>（第三者話法）</td><td>「似たような方も入会されて100切りされています」</td></tr>
      <tr><td class="k">二者択一話法</td><td>「AとB、どちらが良さそうですか？」<br><b>購入前提で選択肢を出す</b></td></tr>
    </table>
    <div class="box ng" style="margin-top:10px">
      <h4>クロージングの5原則</h4>
      <ul class="dot" style="font-size:9.2pt">
        <li>先入観を抱かない</li>
        <li>楽しく</li>
        <li>お悩みの解消が目的</li>
        <li>自分を好きになってもらう</li>
        <li><b>最後まで諦めない</b></li>
      </ul>
    </div>
  </div>
</div>
""", sub="押し売りではなく支援", foot_l=F, foot_r="12"))

# ---------------------------------------------------------------- 13
S.append(slide("13", "クロージング台本① 感想 → 現状肯定", """
<div class="script">
  <div class="line"><div class="who">スタッフ</div><div class="say">「<em>体験、いかがでしたか？</em>」
  <span class="note">▶ <b>必ず先に感想を言っていただく。</b>自分の口で「良かった」と言った人は、そのあとの話を聞いてくれます。こちらから感想を言わない。</span></div></div>
  <div class="line"><div class="who g">お客様</div><div class="say g">「いや、面白かったです。全然違いますね。」</div></div>
  <div class="line"><div class="who">スタッフ</div><div class="say">「よかったです。実際、<em>最初の球と最後の球</em>、見比べてみてください。」　<b>（映像を並べて見せる）</b>
  <span class="note">▶ 言葉で説明しない。<b>映像を見せて、お客様に言わせる。</b></span></div></div>
  <div class="line"><div class="who">スタッフ</div><div class="say">「今日、<em>◯分</em>でここまで変わりました。<br>
  ◯◯様は<b>元々スイングの◯◯が良い</b>ので、そこは変えなくて大丈夫です。」
  <span class="note">▶ 必ず1つ、本気でほめる。お世辞ではなく、観察して見つけた具体的な1点を。</span></div></div>
  <div class="line"><div class="who">スタッフ</div><div class="say">「ちなみに、今のまま一人で練習を続けていく、というのも<em>もちろんアリだと思います。</em><br>
  実際それで上手くなる方もいらっしゃいます。」　<b>← 現状肯定</b>
  <span class="note">▶ ここで否定すると壁ができます。<b>いったん全部肯定する。</b>肯定してから損失を出すのが順番。</span></div></div>
  <div class="line"><div class="who">スタッフ</div><div class="say">「ただ、<em>1つだけ気になることがあって</em>……」
  <span class="note">▶ この一言で次のステップへ。ここから「見えない損失」の話に入ります。</span></div></div>
</div>
<div class="box gold" style="margin-top:6px">
  <p style="font-size:9.8pt"><b>順番を絶対に飛ばさない。</b>　感想 → 映像 → ほめる → 現状肯定 → 「ただ1つだけ」。<br>
  <span class="small">この5つを踏まずに料金の話に入ると、ほぼ確実に「検討します」で終わります。</span></p>
</div>
""", sub="0:37〜0:41", foot_l=F, foot_r="13"))

# ---------------------------------------------------------------- 14
S.append(slide("14", "クロージング台本② 見えない損失 → 数値化", """
<div class="cols">
  <div class="c60">
    <div class="script">
      <div class="line"><div class="who">スタッフ</div><div class="say">「100切りを<em>独学</em>で達成するには、だいたい<em>800〜1,000時間</em>の練習が必要と言われています。<br>
      週1回2時間の練習だと……<b>10年</b>かかります。毎日1時間でも3年です。」</div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「<em>◯◯様、それだけの時間を確保できそうですか？</em>」
      <span class="note">▶ ここで必ず問いかけて、いったん止める。答えを待つ。</span></div></div>
      <div class="line"><div class="who g">お客様</div><div class="say g">「いや、それは無理ですね……」</div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「ですよね。しかも独学だと、<em>間違った動きが癖として固まっていく</em>ので、
      あとから直すのにさらに時間がかかります。<br>
      <b>今日ご覧いただいたとおり、正しい形は「知れば」その場で変わります。</b>知らないだけで損をしているんです。」</div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「パーソナルで通っていただければ、同じ100切りが<em>半年〜1年</em>です。<br>
      <b>10年分の遠回りを、数ヶ月に短縮できる</b>とお考えください。」</div></div>
    </div>
  </div>
  <div class="c40">
    <h2 class="sec">100切りまでの目安</h2>
    <table class="tight">
      <tr><th>やり方</th><th>100切りまで</th></tr>
      <tr><td class="k">独学で練習</td><td><b>800〜1,000時間</b><br><span class="small">週2時間なら約10年</span></td></tr>
      <tr><td class="k">グループレッスン</td><td><b>2年〜5年</b></td></tr>
      <tr><td class="k">パーソナルレッスン</td><td><b>半年〜1年</b></td></tr>
    </table>
    <div class="box gold" style="margin-top:11px">
      <h4>判断の3軸</h4>
      <p style="font-size:10pt"><b>質・量・コスト</b><br>
      <span class="small">お客様は「高いか安いか」ではなく、この3つで比べています。<br>
      値段の話になったら、必ず<b>時間（＝量）</b>と並べて話してください。</span></p>
    </div>
    <div class="box" style="margin-top:10px">
      <p style="font-size:9.5pt"><b>コンペの日付を聞けていたら、必ずここで使う。</b><br>
      「<em>◯月のコンペまで、あと◯ヶ月ですよね。</em>独学だとその日には間に合いません。」</p>
    </div>
  </div>
</div>
""", sub="0:41〜0:45", foot_l=F, foot_r="14"))

# ---------------------------------------------------------------- 15
S.append(slide("15", "クロージング台本③ プランの提示", """
<table class="tight">
  <tr><th style="width:120px">プラン</th><th style="width:78px">月会費(税込)</th><th style="width:78px">税抜</th><th style="width:150px">使い方</th><th>おすすめする方</th></tr>
  <tr><td class="k">ライト会員</td><td class="c">10,780円</td><td class="c">9,800円</td><td>月4回まで（全営業日OK）</td><td>まずは月1〜2回。様子を見たい方</td></tr>
  <tr><td class="k"><b>レギュラー会員</b></td><td class="c"><b>15,180円</b></td><td class="c">13,800円</td><td>全営業日・<b>1日1時間通い放題</b></td><td><b>一番人気。</b>仕事帰りに週1〜2回通える方</td></tr>
  <tr><td class="k">マスター会員</td><td class="c">21,780円</td><td class="c">19,800円</td><td>全営業日・1日最大2時間</td><td>本気で短期間に仕上げたい方</td></tr>
  <tr><td class="k">法人ライト</td><td class="c">43,780円</td><td class="c">39,800円</td><td>最大2名様登録・1日1時間</td><td>福利厚生／接待前の調整に</td></tr>
  <tr><td class="k">法人プレミアム</td><td class="c">65,780円</td><td class="c">59,800円</td><td>最大4名様登録・1日2時間<br>同伴ビジター無料枠つき</td><td>接待利用のある会社</td></tr>
</table>
<div class="cols" style="margin-top:11px">
  <div class="c60">
    <div class="script">
      <div class="line"><div class="who">スタッフ</div><div class="say">「プランは3つあります。<br>
      ◯◯様は<em>お仕事帰りに週1〜2回</em>とおっしゃっていたので、<b>レギュラー会員</b>が一番合うと思います。」
      <span class="note">▶ <b>3つ全部を平等に説明しない。</b>ヒアリングを根拠に1つを名指しする。</span></div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「もし<em>月に2〜4回くらい</em>のペースであれば、ライト会員でも十分です。<br>
      <em>レギュラーとライト、どちらが生活に合いそうですか？</em>」　<b>← 二者択一</b>
      <span class="note">▶ 「入るか入らないか」ではなく「どちらか」で聞く。</span></div></div>
    </div>
  </div>
  <div class="c40">
    <div class="box">
      <h4>単発でご利用の場合</h4>
      <table class="xtight">
        <tr><td class="k">ビジター</td><td class="c">5,500円</td></tr>
        <tr><td class="k">体験レッスン</td><td class="c">3,300円 → <b>現在無料</b></td></tr>
        <tr><td class="k">追加パーソナル<br>レッスン25分</td><td class="c">2,500円</td></tr>
      </table>
      <p class="small" style="margin-top:6px">会員の方には<b>5分のワンポイントレッスンが無料</b>です。これは大きな価値なので、必ずお伝えしてください。</p>
    </div>
  </div>
</div>
""", sub="ヒアリングを根拠に1つ名指しする", foot_l=F, foot_r="15"))

# ---------------------------------------------------------------- 16
S.append(slide("16", "クロージング台本④ キャンペーンと意思確認", """
<div class="cols">
  <div class="c60">
    <div class="script">
      <div class="line"><div class="who">スタッフ</div><div class="say">「今、<em>オープンキャンペーン</em>をやっていまして、<br>
      本来<b>入会金5,500円</b>のところ<em>0円</em>、さらに<b>入会月の月会費も0円</b>です。」</div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「条件は<em>6ヶ月の継続</em>です。課金開始月から6ヶ月はご継続いただく形になります。<br>
      もし途中でおやめになる場合は、<b>無料になった入会金と初月分をお支払いいただければ、いつでも退会できます。</b>」
      <span class="note">▶ 縛りの話は<b>こちらから先に</b>、はっきり言う。隠すと後でクレームになり、紹介も止まります。</span></div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「<em>もし始められるとしたら、いつからがご都合よさそうですか？</em>」　<b>← テストクロージング</b>
      <span class="note">▶ 「入会されますか？」とは聞かない。<b>始めた後の話</b>をする。</span></div></div>
      <div class="line"><div class="who g">お客様</div><div class="say g">「まあ、来週からとかですかね。」</div></div>
      <div class="line"><div class="who">スタッフ</div><div class="say">「でしたら<em>今日から</em>スタートしてしまいましょう。<br>
      入会金と初月が0円になるので、<b>今日お手続きされるのが一番おトク</b>です。<br>
      お手続きは<em>5分</em>で終わります。」</div></div>
    </div>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>キャンペーン（正）</h4>
      <table class="xtight">
        <tr><td class="k">入会金</td><td>5,500円（税込）→ <b>0円</b></td></tr>
        <tr><td class="k">入会月の月会費</td><td><b>0円</b></td></tr>
        <tr><td class="k">条件</td><td><b>課金開始月から6ヶ月継続</b></td></tr>
        <tr><td class="k">途中解約</td><td>割引分（入会金＋初月分）をお支払いいただければ退会可</td></tr>
      </table>
    </div>
    <div class="box" style="margin-top:11px">
      <h4>言い方のコツ</h4>
      <ul class="dot" style="font-size:9.2pt">
        <li>金額は<b>1日あたり</b>に換算して言う<br><span class="small">レギュラー15,180円 ÷ 30日 ＝ 1日約506円</span></li>
        <li>「高い」ではなく<b>「早い」</b>で勝負する</li>
        <li><b>沈黙を破らない。</b>提示したら黙って待つ</li>
      </ul>
    </div>
  </div>
</div>
""", sub="0:45〜0:50", foot_l=F, foot_r="16"))

# ---------------------------------------------------------------- 17
S.append(slide("17", "入会手続きの進め方（0:50〜0:55）", """
<div class="cols">
  <div class="c60">
    <div class="stepbox"><div class="stepno">1</div><div class="stepbd">
      <b>お客様のスマートフォンで</b>Web入会フォームを開いていただく<br>
      <span class="small">QRコードをお見せして読み取っていただきます。スタッフの端末では行いません。</span></div></div>
    <div class="stepbox"><div class="stepno">2</div><div class="stepbd">
      <b>プランを選択</b>していただく<br>
      <span class="small">先ほど合意したプランを、こちらから口頭でもう一度お伝えしながら選んでいただく。</span></div></div>
    <div class="stepbox"><div class="stepno">3</div><div class="stepbd">
      お名前・ご連絡先・<b>クレジットカード</b>をご入力いただく<br>
      <span class="small">入力中は横から画面を覗き込まない。少し離れて待ちます。</span></div></div>
    <div class="stepbox"><div class="stepno">4</div><div class="stepbd">
      <b>身分証明書</b>でお名前を確認する</div></div>
    <div class="stepbox"><div class="stepno">5</div><div class="stepbd">
      決済完了 → <b>会員番号が発行される</b>のを画面で確認する</div></div>
    <div class="stepbox"><div class="stepno">6</div><div class="stepbd">
      <b>会員ポータルをホーム画面に追加</b>していただき、<b>そのままログイン</b>までしていただく<br>
      <span class="small"><b>iPhone</b>＝Safariで開き、画面下の<b>共有ボタン</b> →「ホーム画面に追加」<br>
      <b>Android</b>＝Chromeで開き、右上の<b>⋮</b> →「ホーム画面に追加」（機種により「アプリをインストール」）<br>
      ▶ これをやらないと、次回のQRチェックインでつまずきます。<b>必ずその場で。</b></span></div></div>
    <div class="stepbox"><div class="stepno">7</div><div class="stepbd">
      <b>公式LINEを友だち追加</b>していただく → 次回のご予約をその場で取る</div></div>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>この場で必ず終わらせる4つ</h4>
      <ul class="chk" style="font-size:9.3pt">
        <li>カード決済の完了</li>
        <li><b>会員ポータルのホーム画面追加＋ログイン</b></li>
        <li>公式LINEの友だち追加</li>
        <li><b>次回のご予約</b></li>
      </ul>
      <p class="small" style="margin-top:6px">「あとでやっておいてください」は、ほぼやってもらえません。</p>
    </div>
    <div class="box ng" style="margin-top:11px">
      <h4>注意</h4>
      <ul class="dot" style="font-size:9.2pt">
        <li>カードをお持ちでない場合は<b>後日のお手続き</b>になります。日時をその場で決める</li>
        <li>会員規約に<b>登録カードからの自動決済（モバイルオーダー）</b>への同意欄があります。<b>必ず口頭でも説明</b>してください</li>
        <li>ご入力内容の代行入力はしない</li>
      </ul>
    </div>
  </div>
</div>
""", sub="お客様のスマホで完結させる", foot_l=F, foot_r="17"))

# ---------------------------------------------------------------- 18
S.append(slide("18", "断られたときの切り返し", """
<p class="lead"><b>ネガティブは、ポジティブで返す。</b>断りは拒否ではなく「まだ情報が足りない」というサインです。1回は必ず返してから引く。</p>
<table class="tight">
  <tr><th style="width:150px">断りのパターン</th><th>切り返し</th></tr>
  <tr><td class="k">「値段が高くて…」</td><td><b>1日あたりに換算</b>して伝える。「レギュラーだと1日約506円です」<br>
  さらに「スコアが良くなると<b>コース代の無駄打ちが減ります</b>」と、実際に浮くお金の話をする。<br><b>価格ではなく価値で勝負する。</b></td></tr>
  <tr><td class="k">「忙しくて通えるか不安」</td><td>「<b>月2〜4回からでも大丈夫</b>です。振替もできます」<br>
  お仕事帰りの方は<b>レギュラー会員で「まずは週1回」</b>から。<b>平日の昼に動ける方</b>にはライト会員（平日10:00〜15:00・月4回）。<b>無理のないペース</b>を先に提案する。</td></tr>
  <tr><td class="k">「家族に相談してから」</td><td><b>ご家族向けの説明資料（A4・1枚／受付カウンターに常備）</b>をお持ち帰りいただく。<b>その場でお電話していただく</b>のも有効。<br>難しければ<b>次回来店の日時をその場で約束する</b>。</td></tr>
  <tr><td class="k">「内容がまだ気になる」</td><td>別プラン、または<b>追加の体験</b>を提案する。<br><b>YES BUT法</b>：一度受け止めてから代替案を出す。</td></tr>
  <tr><td class="k">「時期を見てから」</td><td><b>今始める理由</b>を具体的に伝える。「◯月のコンペに間に合わせるなら、逆算して今月からです」<br>キャンペーンの期限も添える。</td></tr>
</table>
<div class="cols" style="margin-top:11px">
  <div class="c60"><div class="box gold">
    <p style="font-size:9.8pt"><b>1回返して、それでも「持ち帰りたい」と言われたら、気持ちよく引く。</b><br>
    <span class="small">粘りすぎると「二度と行かない店」になります。引くときも笑顔で、次につながる形で終わってください。</span></p>
  </div></div>
  <div class="c40"><div class="box ng">
    <h4>絶対にしないこと</h4>
    <ul class="dot" style="font-size:9.2pt">
      <li>ため息・表情を変える</li>
      <li>値引きを勝手に約束する</li>
      <li>他店をけなす</li>
    </ul>
  </div></div>
</div>
""", sub="ネガティブをポジティブで返す", foot_l=F, foot_r="18"))

# ---------------------------------------------------------------- 19
S.append(slide("19", "入会に至らなかった場合", """
<div class="cols">
  <div class="c60">
    <h2 class="sec">その場で必ずやる3つ</h2>
    <div class="stepbox"><div class="stepno">1</div><div class="stepbd">
      <b>公式LINEを友だち追加</b>していただく<br>
      <span class="small">「空き枠やキャンペーンのご案内をお送りしますね」と理由を添えてお願いする。これができれば体験は失敗ではありません。</span></div></div>
    <div class="stepbox"><div class="stepno">2</div><div class="stepbd">
      <b>メールアドレス</b>を受付台帳に入力する<br>
      <span class="small">LINEを断られた場合の連絡手段。必ずどちらかは残す。</span></div></div>
    <div class="stepbox"><div class="stepno">3</div><div class="stepbd">
      受付台帳に<b>「今日決まらなかった理由」を1行で残す</b><br>
      <span class="small">例：「値段。奥様に相談。来週返事とのこと」　── これがないと次の連絡が打てません。</span></div></div>
    <h2 class="sec mt">後日のフォロー</h2>
    <table class="tight">
      <tr><th style="width:88px">タイミング</th><th>内容</th></tr>
      <tr><td class="k">当日中<br><span class="small">閉店までに</span></td><td><b>お礼のメッセージ＋今日の映像・データを必ず送る</b><br><span class="small">その日のうちに届くかどうかで、後日の返信率が変わります</span></td></tr>
      <tr><td class="k">3日後</td><td>担当から一言。<b>断られた理由に対する答え</b>を1つだけ添える</td></tr>
      <tr><td class="k">1〜2週間後</td><td>キャンペーン期限・空き枠のご案内</td></tr>
    </table>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>AI店長の体験フォロー</h4>
      <p style="font-size:9.7pt">体験後のフォローは<b>AI店長が自動で下書きを作成</b>します。<br>
      スタッフは内容を確認して、必要なら手を入れてから送信してください。<br>
      <b>自動では送信されません。</b>承認するのは人です。</p>
    </div>
    <div class="box" style="margin-top:11px">
      <h4>お見送り</h4>
      <ul class="dot" style="font-size:9.3pt">
        <li>入会されなかった方にも<b>同じ温度で</b>お見送りする</li>
        <li>入口の外まで出て、お客様が見えなくなるまで待つ</li>
        <li>「またいつでもお越しください。<b>◯◯様、今日はありがとうございました</b>」とお名前で締める</li>
      </ul>
    </div>
    <div class="box ng" style="margin-top:11px">
      <p style="font-size:9.5pt"><b>断られた瞬間に態度が変わる</b>のが、店として一番losing。<br>今日入らなかった方が、3ヶ月後に紹介を連れて来ます。</p>
    </div>
  </div>
</div>
""", sub="体験は「終わり」ではなく「始まり」", foot_l=F, foot_r="19"))

# ---------------------------------------------------------------- 20
S.append(slide("20", "体験のNG集", """
<div class="cols">
  <div>
    <table class="xtight">
      <tr><th style="width:130px">NG</th><th>言い換え・対処</th></tr>
      <tr><td class="k">「分かりません」<br>「知りません」</td><td>「確認してまいります」。分からないことは<b>その場で調べるか、後で必ず連絡する</b></td></tr>
      <tr><td class="k">「初めてなので」<br>「まだ慣れてなくて」</td><td>言わない。自信がなさそうに見えた瞬間に信頼が消えます</td></tr>
      <tr><td class="k">同じ説明を何度もする</td><td>1回で伝える。伝わったか<b>相手の表情で確認</b>する</td></tr>
      <tr><td class="k">お客様を否定する</td><td>「それは違います」→「なるほど。もう一つの考え方として…」</td></tr>
      <tr><td class="k">専門用語だらけ</td><td>アウトサイドイン → 「クラブが外から入ってきています」</td></tr>
      <tr><td class="k">他のお客様と比較する</td><td>比べるのは<b>その方の過去</b>とだけ</td></tr>
    </table>
  </div>
  <div>
    <table class="xtight">
      <tr><th style="width:130px">NG</th><th>言い換え・対処</th></tr>
      <tr><td class="k">距離が近すぎる<br>体に触れる</td><td>特に異性のお客様。<b>声かけの前に一言</b>「失礼します、少し触れますね」</td></tr>
      <tr><td class="k">命令口調</td><td>「〜してください」→「〜していただけますか」</td></tr>
      <tr><td class="k">下品な言葉・タメ口</td><td>親しみと馴れ馴れしさは別。<b>最後まで敬語</b></td></tr>
      <tr><td class="k">スタッフ同士の私語</td><td>お客様がいる間はしない。指示は短く</td></tr>
      <tr><td class="k">時計を見ない</td><td><b>35分でのお迎えを絶対に遅らせない</b>。<b>0:30にタイマー</b>をセットし、手が離せなければ受付に頼む</td></tr>
      <tr><td class="k">腕を組む・<br>ポケットに手</td><td>非言語で拒否のサインになります</td></tr>
    </table>
  </div>
</div>
<div class="banner" style="margin-top:13px">迷ったら「自分の家族がお客様だったらどうするか」で決める</div>
""", sub="言ってはいけない言葉", foot_l=F, foot_r="20"))

# ---------------------------------------------------------------- 21
S.append(slide("21", "体験1件の全チェックリスト", """
<div class="cols">
  <div>
    <h2 class="sec">前日・開店後</h2>
    <ul class="chk" style="font-size:9pt">
      <li>体験予約の確認（時間・人数・利き手）</li>
      <li>打席の割当（左打ち＝B打席）</li>
      <li>担当コーチの決定</li>
      <li>貸クラブ・グローブの用意（タオル・お水は置かない）</li>
      <li><b>カウンセリングシート</b>とペンの用意</li>
      <li>バッグエリアを空けた</li>
      <li>計測機器の起動、前データの消去</li>
    </ul>
    <h2 class="sec mt">0:00〜0:07</h2>
    <ul class="chk" style="font-size:9pt">
      <li>お名前でお呼びし、自分も名乗った</li>
      <li>お荷物・上着をお預かりした</li>
      <li>ゴルフバッグをバッグエリアでお預かりした</li>
      <li>今日の流れ（55分）を先に伝えた</li>
      <li><b>カウンセリングシート</b>にご記入いただいた</li>
      <li>コンペ・ラウンド予定の<b>日付</b>を聞いた</li>
      <li>最後に要約して言い直した</li>
    </ul>
  </div>
  <div>
    <h2 class="sec">0:07〜0:35</h2>
    <ul class="chk" style="font-size:9pt">
      <li><b>使い方を5分説明した</b>（付き添った）</li>
      <li><b>0:12から体験レッスン10分</b>を行った</li>
      <li>原因を3つに絞り、ほめる材料を1つ見つけた</li>
      <li><b>Before / After の映像</b>を残した</li>
      <li>「◯分でここまで変わりました」と伝えた</li>
      <li><b>0:23から自由練習。一度必ず離れた</b></li>
      <li><b>0:30に打席へ戻り、内容を振り返った</b></li>
      <li><b>35分でお迎えに行った</b></li>
      <li>軽く店内をご案内しながらカウンターへ</li>
      <li><b>お飲み物をカウンターでお出しした</b></li>
    </ul>
    <h2 class="sec mt">0:37〜0:50</h2>
    <ul class="chk" style="font-size:9pt">
      <li>「体験いかがでしたか？」と先に聞いた</li>
      <li>映像を並べて見せた</li>
      <li>具体的に1つほめた</li>
      <li><b>現状肯定</b>してから損失の話に入った</li>
      <li>質・量・コストで数値化した</li>
    </ul>
  </div>
  <div>
    <h2 class="sec">0:37〜0:50（続き）</h2>
    <ul class="chk" style="font-size:9pt">
      <li>プランを<b>1つ名指し</b>で提案した</li>
      <li>二者択一で聞いた</li>
      <li>キャンペーンと<b>6ヶ月条件</b>を正直に伝えた</li>
      <li>テストクロージングを入れた</li>
      <li>提示のあと<b>沈黙を守った</b></li>
    </ul>
    <h2 class="sec mt">0:50〜（入会された）</h2>
    <ul class="chk" style="font-size:9pt">
      <li>お客様のスマホでWeb入会・カード決済</li>
      <li>身分証で確認</li>
      <li><b>ポータルをホーム追加＋ログイン</b></li>
      <li>公式LINE友だち追加</li>
      <li><b>次回のご予約</b></li>
    </ul>
    <h2 class="sec mt">0:50〜（入会されなかった）</h2>
    <ul class="chk" style="font-size:9pt">
      <li>公式LINE または メールを取得</li>
      <li>受付台帳に<b>理由を1行</b>残した</li>
      <li>AI店長のフォロー下書きを確認・送信</li>
      <li>外までお見送りした</li>
    </ul>
  </div>
</div>
""", sub="このページを印刷して受付に置いてください", foot_l=F, foot_r="21"))

SLIDES = S
