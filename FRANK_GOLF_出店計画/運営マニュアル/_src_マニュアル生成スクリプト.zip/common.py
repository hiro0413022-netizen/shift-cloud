# -*- coding: utf-8 -*-
"""FRANK GOLF 運営マニュアル — 共通テンプレート（レター横・スライド型）"""

CSS = r"""
@page { size: 11in 8.5in; margin: 0; }
* { box-sizing: border-box; margin: 0; padding: 0; }
html { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
body {
  font-family: "Noto Sans CJK JP", "Noto Sans JP", sans-serif;
  color: #1B2A22;
  background: #fff;
  font-feature-settings: "palt";
}
:root{
  --green:#14452F; --green2:#1D6144; --gold:#B08D3F; --gold-l:#D9C089;
  --ink:#1B2A22; --mute:#5E6E64; --bg:#F2F6F3; --line:#D8E2DA;
}

/* ---------- slide frame ---------- */
.slide{
  position:relative; width:11in; height:8.5in; overflow:hidden;
  page-break-after:always; break-after:page;
  padding:0.52in 0.62in 0.46in 0.62in;
  display:flex; flex-direction:column;
}
.slide:last-child{ page-break-after:auto; }

/* header */
.sl-head{ display:flex; align-items:flex-end; gap:.14in; border-bottom:2.5px solid var(--green); padding-bottom:7px; margin-bottom:14px; flex:none;}
.sl-num{ font-size:11pt; font-weight:900; color:#fff; background:var(--green); border-radius:4px; padding:2px 9px; letter-spacing:.02em;}
.sl-title{ font-size:19pt; font-weight:900; color:var(--green); line-height:1.15; letter-spacing:.01em;}
.sl-sub{ font-size:10pt; color:var(--mute); margin-left:auto; padding-bottom:3px; font-weight:700;}

/* footer */
.sl-foot{ position:absolute; left:0.62in; right:0.62in; bottom:0.2in; display:flex; justify-content:space-between;
  font-size:8pt; color:#93A39A; border-top:1px solid var(--line); padding-top:5px;}
.sl-body{ flex:1; min-height:0; }
.sl-inner{ transform-origin: top left; }

/* ---------- cover ---------- */
.cover{ background:var(--green); color:#fff; padding:0; align-items:stretch; justify-content:center;}
.cover .inner{ margin:auto; text-align:center; padding:0 1in;}
.cover .brand{ font-size:13pt; letter-spacing:.42em; color:var(--gold-l); font-weight:700; margin-bottom:.30in;}
.cover .rule{ width:2.1in; height:3px; background:var(--gold); margin:0 auto .34in;}
.cover h1{ font-size:44pt; font-weight:900; line-height:1.14; letter-spacing:.02em;}
.cover .no{ font-size:14pt; color:var(--gold-l); font-weight:800; margin-bottom:.16in; letter-spacing:.16em;}
.cover .lead{ font-size:12.5pt; color:#CFE0D6; margin-top:.30in; line-height:1.85;}
.cover .meta{ position:absolute; bottom:.55in; left:0; right:0; text-align:center; font-size:9.5pt; color:#8FB3A0;}

/* ---------- generic blocks ---------- */
h2.sec{ font-size:13pt; font-weight:900; color:var(--green); border-left:6px solid var(--gold); padding-left:9px; margin:0 0 9px;}
h2.sec.mt{ margin-top:15px; }
p.lead{ font-size:10.5pt; line-height:1.7; margin-bottom:10px; }
.small{ font-size:9pt; color:var(--mute); line-height:1.6; }

.cols{ display:flex; gap:.22in; align-items:flex-start; }
.cols > *{ flex:1; min-width:0; }
.c40{ flex:0 0 calc(40% - .11in) !important; } .c60{ flex:0 0 calc(60% - .11in) !important; }
.c35{ flex:0 0 calc(35% - .11in) !important; } .c65{ flex:0 0 calc(65% - .11in) !important; }
.c30{ flex:0 0 calc(30% - .11in) !important; } .c70{ flex:0 0 calc(70% - .11in) !important; }

/* table */
table{ width:100%; border-collapse:collapse; font-size:9.5pt; table-layout:fixed; word-break:break-word; overflow-wrap:anywhere; }
th{ background:var(--green); color:#fff; font-weight:800; text-align:left; padding:6px 9px; border:1px solid var(--green); font-size:9.5pt;}
td{ border:1px solid var(--line); padding:6px 9px; vertical-align:top; line-height:1.55; }
tr:nth-child(even) td{ background:#F7FAF8; }
td.k{ background:#EAF1EC !important; font-weight:800; color:var(--green); }
td.c{ text-align:center; white-space:nowrap; }
table.tight td, table.tight th{ padding:4px 7px; font-size:9pt; }
table.xtight td, table.xtight th{ padding:3px 6px; font-size:8.5pt; }

/* callouts */
.box{ background:var(--bg); border:1px solid var(--line); border-radius:6px; padding:11px 14px; font-size:10pt; line-height:1.68;}
.box.gold{ background:#FCF8EF; border-color:var(--gold-l); }
.box.ng{ background:#FDF2F2; border-color:#E9BFBF; }
.box h4{ font-size:10.5pt; color:var(--green); margin-bottom:5px; font-weight:900;}
.box.ng h4{ color:#A33; }
.banner{ background:var(--green); color:#fff; border-radius:6px; padding:9px 15px; font-size:11.5pt; font-weight:900; text-align:center; letter-spacing:.02em;}
.banner.gold{ background:var(--gold); }
.tagline{ font-size:9.5pt; color:var(--mute); text-align:center; margin-top:6px;}

/* script (台本) */
.script{ font-size:10pt; line-height:1.72; }
.line{ display:flex; gap:9px; margin-bottom:7px; align-items:flex-start;}
.who{ flex:0 0 62px; font-size:8.5pt; font-weight:900; color:#fff; background:var(--green2); border-radius:3px; text-align:center; padding:3px 0; margin-top:2px;}
.who.g{ background:var(--gold); }
.who.c{ background:#7B8C82; }
.say{ flex:1; background:#fff; border:1px solid var(--line); border-left:3px solid var(--green2); border-radius:4px; padding:6px 10px;}
.say.g{ border-left-color:var(--gold); background:#FCF8EF;}
.say em{ font-style:normal; color:var(--gold); font-weight:800;}
.say .note{ display:block; font-size:8.5pt; color:var(--mute); margin-top:3px;}

/* checklist */
ul.chk{ list-style:none; font-size:9.5pt; line-height:1.5;}
ul.chk li{ display:block; position:relative; padding:4.5px 0 4.5px 21px; border-bottom:1px dashed var(--line);}
ul.chk li:before{ content:""; position:absolute; left:0; top:7px; width:13px; height:13px; border:1.6px solid var(--green); border-radius:2.5px;}
ul.chk li b{ color:var(--green); }

ul.dot{ list-style:none; font-size:10pt; line-height:1.7; }
ul.dot li{ padding-left:15px; position:relative; margin-bottom:4px;}
ul.dot li:before{ content:"●"; position:absolute; left:0; color:var(--gold); font-size:7pt; top:5px;}

/* timeline */
.tl{ display:flex; gap:0; margin:8px 0 12px; }
.tl .step{ flex:1; text-align:center; position:relative; padding:0 4px;}
.tl .t{ font-size:8.5pt; font-weight:900; color:var(--gold); }
.tl .bar{ height:9px; background:var(--green); margin:4px 0; position:relative;}
.tl .step:first-child .bar{ border-radius:5px 0 0 5px;}
.tl .step:last-child .bar{ border-radius:0 5px 5px 0;}
.tl .step:nth-child(even) .bar{ background:var(--green2);}
.tl .l{ font-size:9pt; font-weight:800; color:var(--ink); line-height:1.3;}
.tl .m{ font-size:8pt; color:var(--mute); }

/* steps big number */
.stepbox{ display:flex; gap:10px; align-items:flex-start; margin-bottom:8px;}
.stepno{ flex:0 0 30px; height:30px; border-radius:50%; background:var(--green); color:#fff; font-weight:900; font-size:12pt; display:flex; align-items:center; justify-content:center;}
.stepbd{ flex:1; font-size:10pt; line-height:1.62;}
.stepbd b{ color:var(--green); }

/* KPI tiles */
.tiles{ display:flex; gap:.16in; }
.tile{ flex:1; background:var(--bg); border:1px solid var(--line); border-top:4px solid var(--gold); border-radius:6px; padding:10px 12px; text-align:center;}
.tile .n{ font-size:20pt; font-weight:900; color:var(--green); line-height:1.15;}
.tile .lb{ font-size:9pt; color:var(--mute); margin-top:3px; font-weight:700;}

/* index */
.idx{ display:flex; flex-wrap:wrap; gap:.18in; }
.idx .card{ flex:0 0 calc(33.333% - .12in); background:var(--bg); border:1px solid var(--line); border-radius:7px; padding:12px 14px;}
.idx .card .n{ font-size:9pt; font-weight:900; color:#fff; background:var(--gold); border-radius:3px; padding:1px 7px; display:inline-block; margin-bottom:6px;}
.idx .card .t{ font-size:12pt; font-weight:900; color:var(--green); margin-bottom:4px;}
.idx .card .d{ font-size:8.8pt; color:var(--mute); line-height:1.55;}

.warn{ font-size:9.5pt; color:#A33; font-weight:800;}
.fill{ display:inline-block; min-width:60px; border-bottom:1.4px solid var(--gold); }
.tbd{ color:#B00; font-weight:800; }
"""


def html_doc(title, slides):
    body = "\n".join(slides)
    return f"""<!DOCTYPE html>
<html lang="ja"><head><meta charset="utf-8"><title>{title}</title>
<style>{CSS}</style></head><body>
{body}
</body></html>"""


def cover(no, title, lead, meta="株式会社YOZAN ／ FRANK GOLF 姫路"):
    return f"""<section class="slide cover"><div class="inner">
  <div class="brand">FRANK GOLF</div>
  <div class="rule"></div>
  <div class="no">{no}</div>
  <h1>{title}</h1>
  <div class="lead">{lead}</div>
</div><div class="meta">{meta}</div></section>"""


def slide(num, title, body, sub="", foot_l="FRANK GOLF 運営マニュアル", foot_r=""):
    sub_html = f'<div class="sl-sub">{sub}</div>' if sub else ""
    return f"""<section class="slide">
  <div class="sl-head"><div class="sl-num">{num}</div><div class="sl-title">{title}</div>{sub_html}</div>
  <div class="sl-body"><div class="sl-inner">{body}</div></div>
  <div class="sl-foot"><span>{foot_l}</span><span>{foot_r}</span></div>
</section>"""
