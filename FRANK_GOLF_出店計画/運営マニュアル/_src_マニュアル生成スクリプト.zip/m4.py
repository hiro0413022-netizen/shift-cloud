# -*- coding: utf-8 -*-
"""④ 開店マニュアル"""
from common import cover, slide

F = "④ 開店マニュアル"
S = []

S.append(cover(
    "MANUAL 04",
    "開店マニュアル",
    "開店15分前に出勤。<br>その15分で、ここまで終わらせます。"))

# 01
S.append(slide("01", "開店の全体像", """
<div class="tl">
  <div class="step"><div class="t">−15分</div><div class="bar"></div><div class="l">出勤・解錠<br>店内の確認</div><div class="m">2分</div></div>
  <div class="step"><div class="t">−13分</div><div class="bar"></div><div class="l">照明・空調<br>BGM</div><div class="m">2分</div></div>
  <div class="step"><div class="t">−11分</div><div class="bar"></div><div class="l">システム<br>立ち上げ</div><div class="m">3分</div></div>
  <div class="step"><div class="t">−8分</div><div class="bar"></div><div class="l">打席・機器<br>の準備</div><div class="m">4分</div></div>
  <div class="step"><div class="t">−4分</div><div class="bar"></div><div class="l">釣銭・<br>ドリンク</div><div class="m">2分</div></div>
  <div class="step"><div class="t">−2分</div><div class="bar"></div><div class="l">当日の予約<br>確認</div><div class="m">2分</div></div>
  <div class="step"><div class="t">開店</div><div class="bar"></div><div class="l"><b>開店</b></div><div class="m">解錠</div></div>
</div>
<div class="cols" style="margin-top:8px">
  <div class="c60">
    <h2 class="sec">基本情報</h2>
    <table class="tight">
      <tr><td class="k" style="width:100px">平日</td><td><b>10:00 〜 22:00</b>　／　出勤 <b>9:45</b>・退勤 <b>22:15</b></td></tr>
      <tr><td class="k">土日祝</td><td><b>9:00 〜 20:00</b>　／　出勤 <b>8:45</b>・退勤 <b>20:15</b></td></tr>
      <tr><td class="k">定休日</td><td><b>毎週火曜日</b></td></tr>
      <tr><td class="k">スタッフ</td><td>いつでも<b>開店15分前に出勤・閉店15分後に退勤</b></td></tr>
      <tr><td class="k">稼働打席</td><td>A打席（1F・DTECT）／B打席（2F・TrackMan 4・左右打席）／C打席（2F・OKONGOLF）<br><span class="small">D打席はオープン約3ヶ月後に稼働予定</span></td></tr>
      <tr><td class="k">警備会社</td><td><b>現時点で警備会社との契約はありません。</b>導入したら解除・セットの手順をここに追記します</td></tr>
    </table>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>24時間営業への移行について</h4>
      <p style="font-size:9.8pt">オープンから<b>半年後を目処に24時間営業</b>へ移行する予定です。<br>
      移行時は、無人時間帯の入退館・安全確認・清掃の手順を<b>このマニュアルに追記</b>します。</p>
    </div>
    <div class="box ng" style="margin-top:11px">
      <p style="font-size:9.7pt"><b>開店時刻ちょうどに開けられる状態</b>を作るのが目的です。<br>
      作業が終わっていなくても、お客様が来られたら<b>接客を優先</b>してください。</p>
    </div>
  </div>
</div>
""", sub="平日 9:45出勤／土日祝 8:45出勤", foot_l=F, foot_r="01"))

# 02
S.append(slide("02", "開店作業チェックリスト", """
<div class="cols">
  <div>
    <h2 class="sec">開店15分前 ｜ 入館</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>解錠する</li>
      <li>戸締りと施錠状態を確認する<br><span class="small">※警備会社の契約はまだありません（導入後にここへ追記）</span></li>
      <li>異常がないか店内を一周する<br><span class="small">水漏れ・異臭・破損・侵入の形跡</span></li>
      <li>前日の閉店メモ・引き継ぎを読む</li>
    </ul>
    <h2 class="sec mt">13分前 ｜ 環境</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>照明を全点灯（1F・2F・トイレ）</li>
      <li>空調をONにする（<b>設定24℃</b>）</li>
      <li>BGMを流す（音量は<b>会話が普通にできる大きさ</b>）</li>
      <li>換気する</li>
      <li>入口の自動ドア・<b>看板（サイン）の照明</b>の電源を入れる<br><span class="small">スイッチは受付カウンター内。分からないときは店長に確認し、このページに書き込んでおく</span></li>
    </ul>
  </div>
  <div>
    <h2 class="sec">11分前 ｜ システム</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li><b>受付PC</b>を起動し、チェックイン画面を開く（客側に向ける）</li>
      <li><b>QRリーダー</b>を接続し、テスト読み取りをする</li>
      <li><b>受付iPad</b>を起動し、Squareと電子伝票を開く</li>
      <li>Squareリーダーの接続と充電を確認</li>
      <li>Wi-Fiがつながっているか確認</li>
      <li>打席QRステッカーが<b>3枚とも貼られている</b>か確認</li>
    </ul>
    <h2 class="sec mt">8分前 ｜ 打席・機器</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>A・B・Cの<b>計測機器を起動</b>する</li>
      <li>前日のデータが残っていないか確認して消す</li>
      <li>モニター・PCの動作確認（3打席とも1球打つ）</li>
      <li>マットの位置を整える／ボールを補充する</li>
      <li>貸クラブ・グローブを所定の位置に戻す</li>
      <li>打席まわりのゴミ・落下物を拾う</li>
    </ul>
  </div>
  <div>
    <h2 class="sec">4分前 ｜ 受付・カフェ</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>金庫から<b>釣銭準備金</b>を出し、金種を数える</li>
      <li>レシートロールの残量を確認</li>
      <li>コーヒーマシンの電源・水・豆を確認</li>
      <li>冷蔵ドリンクの在庫を確認し、<b>売切品はメニュー管理で切替</b></li>
      <li>氷を確認する</li>
      <li>カップ・ストロー・おしぼりを補充</li>
      <li>カウンターとテーブルを拭く</li>
    </ul>
    <h2 class="sec mt">2分前 ｜ 当日確認</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>本日の<b>予約一覧</b>を確認</li>
      <li><b>体験の予約</b>と担当コーチを確認</li>
      <li>レッスン枠と担当を確認</li>
      <li>左打ちの方がいれば<b>B打席</b>を確保</li>
      <li>共有事項をスタッフ全員に一言で伝える</li>
    </ul>
  </div>
</div>
""", sub="上から順に、そのまま実行してください", foot_l=F, foot_r="02"))

# 03
S.append(slide("03", "システムの立ち上げ（詳細）", """
<div class="cols">
  <div class="c60">
    <table class="tight">
      <tr><th style="width:120px">機器</th><th>手順と確認</th></tr>
      <tr><td class="k">受付PC<br>（客側向き）</td><td>① 電源を入れる ② チェックイン画面 <b>/checkin</b> を開く<br>
        ③ <b>画面をお客様側に向ける</b><br>
        <span class="small">この端末では会計をしません。チェックイン専用です</span></td></tr>
      <tr><td class="k">QRリーダー<br>（Tera 9200）</td><td>① USB／レシーバーを接続 ② 自分の会員QRで<b>テスト読み取り</b><br>
        <span class="small">読めない場合はチェックイン画面の入力欄をクリックしてから再度読み取る</span></td></tr>
      <tr><td class="k">受付iPad<br>（スタッフ側）</td><td>① Squareアプリを開く ② <b>電子伝票 /orders</b> を開く<br>
        ③ Squareリーダーの接続と充電を確認</td></tr>
      <tr><td class="k">計測機器<br>3打席</td><td>① 各打席のPC・モニターを起動<br>
        ② ソフトを立ち上げ、<b>前日のデータを消す</b><br>
        ③ 1球ずつ打って<b>計測されるかを確認</b></td></tr>
    </table>
  </div>
  <div class="c40">
    <div class="box ng">
      <h4>よくあるトラブル</h4>
      <table class="xtight">
        <tr><td class="k">QRが<br>読めない</td><td>入力欄にカーソルがない／リーダーの電池切れ。<b>手動チェックイン</b>で回せます</td></tr>
        <tr><td class="k">計測されない</td><td>ソフトの再起動 → PCの再起動。<b>直らなければその打席を使わない</b>設定にして店長へ連絡</td></tr>
        <tr><td class="k">Squareが<br>つながらない</td><td>Wi-Fi確認 → iPad再起動。復旧しなければ現金対応</td></tr>
      </table>
    </div>
    <div class="box gold" style="margin-top:11px">
      <h4>手動チェックインは必ず残す</h4>
      <p style="font-size:9.7pt">スマホを忘れた方・ログインできない方は<b>スタッフが手動でチェックイン</b>します。<br>
      QRが使えないことを理由にお客様を待たせないでください。</p>
    </div>
  </div>
</div>
""", sub="受付PC／QRリーダー／受付iPad／計測機器", foot_l=F, foot_r="03"))

# 04
S.append(slide("04", "開店前の共有（1分ミーティング）", """
<div class="cols">
  <div class="c60">
    <h2 class="sec">開店2分前に、全員で1分だけ</h2>
    <p class="small" style="margin-bottom:6px"><b>仕切るのはその日の早番リーダー（いなければ店長）。</b>カウンター前で立ったまま1分。<br>
    決まったことは<b>シフトクラウドの日報に1行だけ</b>残します。<b>1人勤務の日は、この6項目を自分で声に出して確認</b>してください。</p>
    <table class="tight">
      <tr><td class="k c" style="width:26px">1</td><td><b>今日の体験</b>　何時に何名、担当は誰か</td></tr>
      <tr><td class="k c">2</td><td><b>今日のレッスン</b>　枠と担当コーチ</td></tr>
      <tr><td class="k c">3</td><td><b>混む時間帯</b>　打席が埋まる時間はいつか</td></tr>
      <tr><td class="k c">4</td><td><b>注意が必要なお客様</b>　初来店・前回トラブル・お誕生月</td></tr>
      <tr><td class="k c">5</td><td><b>不具合・売切</b>　使えない機器、切れているドリンク</td></tr>
      <tr><td class="k c">6</td><td><b>今日の一言</b>　全員で意識すること1つ</td></tr>
    </table>
    <div class="box gold" style="margin-top:12px">
      <p style="font-size:9.8pt"><b>体験がある日は、必ず担当と時間を全員が知っている状態</b>にしてください。<br>
      担当コーチの手が空かないときに、受付が代わりに入れるようにするためです。</p>
    </div>
  </div>
  <div class="c40">
    <h2 class="sec">声かけカードを見る</h2>
    <div class="box">
      <p style="font-size:9.7pt">チェックイン時、受付画面に<b>その方への声かけのネタ</b>が表示されます。</p>
      <ul class="dot" style="font-size:9.5pt">
        <li>入会後3回目のご来店</li>
        <li>前回から21日空いています</li>
        <li>今月がお誕生月</li>
        <li>レッスン枠が14時からあります</li>
      </ul>
      <p class="small" style="margin-top:6px">出てきたら<b>必ず一言かけてください。</b>名前を呼んで一言かけることが、退会防止に一番効きます。</p>
    </div>
    <div class="box ng" style="margin-top:11px">
      <p style="font-size:9.7pt">開店作業が終わっていなくても、<b>開店時刻にお客様が来られたら接客が最優先</b>。作業は後で構いません。</p>
    </div>
  </div>
</div>
""", sub="1分で、今日の形を全員でそろえる", foot_l=F, foot_r="04"))

SLIDES = S
