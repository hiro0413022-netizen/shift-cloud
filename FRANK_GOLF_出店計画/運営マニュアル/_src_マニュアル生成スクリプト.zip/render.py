# -*- coding: utf-8 -*-
import sys, os, asyncio, importlib
from playwright.async_api import async_playwright
from common import html_doc

OUT = os.path.join(os.path.dirname(__file__), "out")
os.makedirs(OUT, exist_ok=True)


async def render(pairs):
    """pairs: list of (module_name, title, pdf_filename)"""
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page()
        for mod_name, title, fname in pairs:
            mod = importlib.import_module(mod_name)
            importlib.reload(mod)
            html = html_doc(title, mod.SLIDES)
            hp = os.path.join(OUT, fname.replace(".pdf", ".html"))
            with open(hp, "w", encoding="utf-8") as f:
                f.write(html)
            await pg.goto("file://" + hp, wait_until="networkidle")
            # auto-fit each slide body (fill sparse slides, shrink dense ones)
            await pg.evaluate("""() => {
              document.querySelectorAll('.slide').forEach(s=>{
                const body = s.querySelector('.sl-body');
                const inner = s.querySelector('.sl-inner');
                if(!body||!inner) return;
                const ZMIN=0.74, ZMAX=1.42;
                const apply = (v) => {
                  inner.style.width = (100/v) + '%';
                  inner.style.transform = 'scale(' + v + ')';
                };
                let z = 1;
                for(let k=0;k<14;k++){
                  apply(z);
                  const H = inner.offsetHeight;
                  if(!H) break;
                  let zH = (body.clientHeight / H) * 0.995;
                  let zW = ZMAX;
                  if(inner.scrollWidth > inner.clientWidth + 4){
                    zW = z * (inner.clientWidth / inner.scrollWidth) * 0.99;
                  }
                  let nz = Math.max(ZMIN, Math.min(ZMAX, Math.min(zH, zW)));
                  if(Math.abs(nz - z) < 0.004){ z = nz; break; }
                  z = nz;
                }
                apply(z);
                // last resort: never let it spill vertically
                for(let k=0;k<8;k++){
                  if(inner.offsetHeight * z <= body.clientHeight + 1) break;
                  z = Math.max(0.62, z * 0.97);
                  apply(z);
                }
              });
            }""")
            # overflow check
            ov = await pg.evaluate("""() => {
              const r=[];
              document.querySelectorAll('.slide').forEach((s,i)=>{
                const body=s.querySelector('.sl-body'), inner=s.querySelector('.sl-inner');
                if(!body||!inner) return;
                const z = parseFloat((inner.style.transform.match(/[\d.]+/)||[1])[0]);
                const h = inner.offsetHeight * z, ah = body.clientHeight;
                if (h > ah + 2) r.push([i+1,'H',Math.round(h),ah]);
                if (inner.scrollWidth > inner.clientWidth + 4) r.push([i+1,'W',inner.scrollWidth,inner.clientWidth]);
              });
              return r;
            }""")
            if ov:
                print(f"!! OVERFLOW in {fname}: {ov}")
            await pg.pdf(path=os.path.join(OUT, fname), width="11in", height="8.5in",
                         print_background=True, margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})
            n = len(mod.SLIDES)
            print(f"OK {fname}  ({n} pages)")
        await b.close()


if __name__ == "__main__":
    import json
    pairs = json.loads(sys.argv[1])
    asyncio.run(render([tuple(x) for x in pairs]))
