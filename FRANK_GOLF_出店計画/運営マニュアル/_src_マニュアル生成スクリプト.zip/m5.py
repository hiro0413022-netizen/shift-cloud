# -*- coding: utf-8 -*-
"""⑤ 閉店マニュアル"""
from common import cover, slide

F = "⑤ 閉店マニュアル"
S = []

S.append(cover(
    "MANUAL 05",
    "閉店マニュアル",
    "閉店15分後に退勤。<br>翌日の開店が楽になる終わり方を。"))

# 01
S.append(slide("01", "閉店の全体像", """
<div class="tl">
  <div class="step"><div class="t">−15分</div><div class="bar"></div><div class="l">最終案内<br>片づけ開始</div><div class="m">10分</div></div>
  <div class="step"><div class="t">閉店</div><div class="bar"></div><div class="l">閉店<br>お見送り</div><div class="m">3分</div></div>
  <div class="step"><div class="t">+3分</div><div class="bar"></div><div class="l">レジ締め<br>現金照合</div><div class="m">4分</div></div>
  <div class="step"><div class="t">+7分</div><div class="bar"></div><div class="l">打席・機器<br>清掃と停止</div><div class="m">4分</div></div>
  <div class="step"><div class="t">+11分</div><div class="bar"></div><div class="l">カフェ<br>洗い物</div><div class="m">2分</div></div>
  <div class="step"><div class="t">+13分</div><div class="bar"></div><div class="l">日報<br>翌日準備</div><div class="m">2分</div></div>
  <div class="step"><div class="t">+15分</div><div class="bar"></div><div class="l"><b>施錠・退勤</b></div><div class="m">戸締り</div></div>
</div>
<div class="cols" style="margin-top:8px">
  <div class="c60">
    <h2 class="sec">閉店15分前のご案内（最終）</h2>
    <div class="script" style="font-size:9.8pt">
      <div class="line"><div class="who">スタッフ</div><div class="say" style="padding:5px 9px">「<em>◯◯様</em>、本日は<em>◯時</em>までとなっております。<br>
      あと15分ほどですので、よろしくお願いいたします。」
      <span class="note">▶ 打席を回って、お一人ずつ声をかける。館内放送だけで済ませない。</span></div></div>
    </div>
    <div class="box gold" style="margin-top:10px">
      <p style="font-size:9.8pt"><b>お客様がいらっしゃる間は、片づけの音を立てない。</b><br>
      掃除機・洗い物・機器の電源オフは、最後のお客様が出られてから。<br>
      「早く帰れ」と言われているように感じさせないでください。</p>
    </div>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>閉店時刻</h4>
      <table class="xtight">
        <tr><td class="k">平日</td><td><b>22:00</b> 閉店 ／ 21:45 最終案内 ／ 22:15 退勤</td></tr>
        <tr><td class="k">土日祝</td><td><b>20:00</b> 閉店 ／ 19:45 最終案内 ／ 20:15 退勤</td></tr>
        <tr><td class="k">定休日</td><td>毎週火曜日</td></tr>
      </table>
    </div>
    <div class="box" style="margin-top:11px">
      <h4>お見送り</h4>
      <ul class="dot" style="font-size:9.6pt">
        <li>入口までお送りする</li>
        <li>「<b>◯◯様</b>、本日はありがとうございました。またお待ちしております」</li>
        <li>次回のご予約があれば日時を復唱する</li>
      </ul>
    </div>
    <div class="box ng" style="margin-top:11px">
      <p style="font-size:9.7pt"><b>忘れ物の確認</b>を必ず。打席・トイレ・カウンター・更衣スペース。<br>
      見つけたら記録を残し、翌日ご連絡します。</p>
    </div>
  </div>
</div>
""", sub="平日 22:00閉店／土日祝 20:00閉店", foot_l=F, foot_r="01"))

# 02
S.append(slide("02", "閉店作業チェックリスト", """
<div class="cols">
  <div>
    <h2 class="sec">閉店15分前 ｜ 営業終了へ</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>打席を回って最終のご案内をした</li>
      <li>未提供のドリンク注文が残っていないか確認</li>
      <li>未会計のお客様がいないか確認</li>
      <li>次回のご予約をおすすめした</li>
    </ul>
    <h2 class="sec mt">閉店</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>全員お見送りした</li>
      <li><b>忘れ物を確認</b>した（打席・トイレ・カウンター）</li>
      <li>入口を施錠し、看板の電源を切った</li>
    </ul>
    <h2 class="sec mt">+3分 ｜ お金</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>現金を数えた</li>
      <li>Squareの当日売上と照合した</li>
      <li>差異があれば<b>金額と状況を記録</b>した</li>
      <li>返金・訂正のメモを確認した</li>
      <li>売上金と釣銭準備金を<b>金庫へ入れ、施錠</b>した</li>
    </ul>
  </div>
  <div>
    <h2 class="sec">+7分 ｜ 打席・機器</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li><b>カルテの記入漏れがないか</b>確認した</li>
      <li>ボールを回収し、数を確認した</li>
      <li>マット・打席まわりを清掃した</li>
      <li>貸クラブ・グローブを拭いて所定の位置へ</li>
      <li>モニター・計測機器を<b>正しい手順で終了</b>した</li>
      <li>打席PCをシャットダウンした</li>
      <li>不具合があれば<b>記録に残した</b></li>
    </ul>
    <h2 class="sec mt">+11分 ｜ カフェ</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>洗い物をすべて済ませた</li>
      <li>コーヒーマシンを洗浄・停止した</li>
      <li>牛乳など要冷蔵品を冷蔵庫へ戻した</li>
      <li>ドリンクを補充した（翌日ぶん）</li>
      <li>ゴミをまとめ、所定の場所へ出した</li>
      <li>カウンター・シンクを拭いた</li>
    </ul>
  </div>
  <div>
    <h2 class="sec">+13分 ｜ 店内</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>トイレを清掃した（便器・洗面・鏡・床）</li>
      <li>トイレットペーパー・ハンドソープを補充</li>
      <li>床に掃除機をかけた（1F・2F）</li>
      <li>テーブル・ソファを拭いた</li>
      <li>翌日の予約と体験を確認し、<b>引き継ぎメモを残した</b></li>
      <li><b>日報を提出した</b>（シフトクラウド）</li>
    </ul>
    <h2 class="sec mt">+15分 ｜ 退館</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>受付PC・iPadを充電に挿した</li>
      <li>BGM・空調・照明を切った</li>
      <li>裏口・窓の施錠を<b>もう一度</b>確認した<br><span class="small">※警備会社の契約はまだありません（導入後にここへ追記）</span></li>
      <li>入口を施錠した</li>
    </ul>
    <p class="small" style="margin-top:6px"><b>警備会社との契約は現時点でなし。</b>導入したら、ここに解除とセットの手順を追記します。</p>
  </div>
</div>
""", sub="上から順に、そのまま実行してください", foot_l=F, foot_r="02"))

# 03
S.append(slide("03", "清掃の基準", """
<p class="lead">インドアゴルフは<b>清潔感がそのまま入会率と継続率</b>に出ます。「汚れていないか」ではなく<b>「新品に見えるか」</b>で判断してください。</p>
<div class="cols">
  <div>
    <table class="tight">
      <tr><th style="width:96px">場所</th><th style="width:60px">頻度</th><th>基準</th></tr>
      <tr><td class="k">打席マット</td><td class="c">毎日</td><td>ボール・ティー・芝クズが落ちていない</td></tr>
      <tr><td class="k">打席まわり</td><td class="c">毎日</td><td>タオル・空きカップが残っていない</td></tr>
      <tr><td class="k">貸クラブ</td><td class="c">毎日</td><td>グリップとフェースを拭く。<b>汗が残っていない</b></td></tr>
      <tr><td class="k">モニター<br>スクリーン</td><td class="c">毎日</td><td>指紋・ホコリがない</td></tr>
      <tr><td class="k">カウンター<br>テーブル</td><td class="c">毎日</td><td>水滴の輪ジミがない</td></tr>
    </table>
  </div>
  <div>
    <table class="tight">
      <tr><th style="width:96px">場所</th><th style="width:60px">頻度</th><th>基準</th></tr>
      <tr><td class="k">トイレ</td><td class="c">毎日</td><td><b>においがしない。</b>鏡に水はねがない</td></tr>
      <tr><td class="k">床</td><td class="c">毎日</td><td>1F・2Fとも掃除機。入口マットも</td></tr>
      <tr><td class="k">シンク</td><td class="c">毎日</td><td>水垢・洗い残しがない</td></tr>
      <tr><td class="k">冷蔵庫の中</td><td class="c">週1</td><td>賞味期限を確認し、拭き上げる</td></tr>
      <tr><td class="k">ネット・<br>スクリーン裏</td><td class="c">週1</td><td>ボール溜まり・ホコリを除去</td></tr>
    </table>
  </div>
</div>
<div class="cols" style="margin-top:12px">
  <div class="c60">
    <div class="box gold">
      <h4>営業中もこまめに</h4>
      <p style="font-size:9.8pt">お客様が退席された打席は、<b>次の方が入る前に必ず一度整える</b>。<br>
      前の方のカップ・タオルが残っている打席に案内するのが、いちばん印象を落とします。</p>
    </div>
  </div>
  <div class="c40">
    <div class="box">
      <h4>不具合を見つけたら</h4>
      <p style="font-size:9.7pt">直せないものは<b>その場で記録に残し、店長へ報告</b>。<br>
      「明日言おう」で忘れられ、お客様から指摘されるのが最悪のパターンです。</p>
    </div>
  </div>
</div>
""", sub="「汚れていないか」ではなく「新品に見えるか」", foot_l=F, foot_r="03"))

# 04
S.append(slide("04", "引き継ぎと日報", """
<div class="cols">
  <div class="c60">
    <h2 class="sec">引き継ぎメモに残すこと</h2>
    <table class="tight">
      <tr><td class="k c" style="width:26px">1</td><td><b>設備の不具合</b>（どの打席の何が、どうなっているか）</td></tr>
      <tr><td class="k c">2</td><td><b>在庫切れ・残りわずかなもの</b>（ドリンク・消耗品）</td></tr>
      <tr><td class="k c">3</td><td><b>お客様からのご要望・お叱り</b>（言われた言葉のまま）</td></tr>
      <tr><td class="k c">4</td><td><b>忘れ物</b>（何を、どこで、誰の可能性があるか）</td></tr>
      <tr><td class="k c">5</td><td><b>現金の差異</b>（あった場合のみ・金額と状況）</td></tr>
      <tr><td class="k c">6</td><td><b>翌日の注意点</b>（体験の有無、混雑予想、担当の変更）</td></tr>
    </table>
    <div class="box ng" style="margin-top:12px">
      <p style="font-size:9.8pt"><b>「特になし」で終わらせない。</b><br>
      何もなかった日は「異常なし」と書く。空欄は「書き忘れ」と区別がつきません。</p>
    </div>
  </div>
  <div class="c40">
    <h2 class="sec">日報</h2>
    <div class="box">
      <p style="font-size:9.8pt">提出先：<b>シフトクラウド</b>（勤怠と同じ画面から入力）</p>
      <p class="small" style="margin-top:5px"><b>日報は簡単でOK。</b>次の5つだけ書いてください。</p>
      <table class="xtight" style="margin-top:5px">
        <tr><td class="k">1</td><td>来店数（会員／ビジター）</td></tr>
        <tr><td class="k">2</td><td>体験の件数と入会数</td></tr>
        <tr><td class="k">3</td><td>当日売上</td></tr>
        <tr><td class="k">4</td><td>現金差異（あり／なし）</td></tr>
        <tr><td class="k">5</td><td>引き継ぎ（なければ「異常なし」）</td></tr>
      </table>
    </div>
    <div class="box gold" style="margin-top:11px">
      <p style="font-size:9.7pt"><b>レジ締めは週1回・林さんが行います。</b><br>
      日々のスタッフは<b>数えて記録するところまで</b>。締め処理はしないでください。</p>
    </div>
  </div>
</div>
""", sub="「特になし」で終わらせない", foot_l=F, foot_r="04"))

SLIDES = S
