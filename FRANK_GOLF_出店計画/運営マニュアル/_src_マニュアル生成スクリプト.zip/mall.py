# -*- coding: utf-8 -*-
"""統合版（全6マニュアル）"""
from common import cover, slide
import m1, m2, m3, m4, m5, m6

S = []

S.append(cover(
    "OPERATION MANUAL",
    "運営マニュアル",
    "体験／レッスン／会計／開店／閉店／ドリンク<br>FRANK GOLF 姫路 全6編",
    meta="株式会社YOZAN ／ FRANK GOLF 姫路 ／ 2026年8月版"))

S.append(slide("目次", "6冊の全体像", """
<div class="idx">
  <div class="card"><div class="n">MANUAL 01</div><div class="t">体験マニュアル</div>
    <div class="d">体験55分の時間割、ヒアリング8項目、体験レッスン、クロージング台本、断られたときの切り返し、フォロー。<b>入会に直結する一番重要な1冊。</b></div></div>
  <div class="card"><div class="n">MANUAL 02</div><div class="t">レッスンマニュアル</div>
    <div class="d">型とコツの違い、スイングチェック4段階、伝わる説明の順番、ラポール形成、NGレッスン集、カルテの書き方、機器の使い分け。</div></div>
  <div class="card"><div class="n">MANUAL 03</div><div class="t">会計マニュアル</div>
    <div class="d">料金一覧、決済手段、現金の扱い、モバイルオーダーと電子伝票、返金・訂正のルール、レジ締めと日報。</div></div>
  <div class="card"><div class="n">MANUAL 04</div><div class="t">開店マニュアル</div>
    <div class="d">開店15分前からの15分。環境・システム・打席・釣銭・当日確認までのチェックリスト。</div></div>
  <div class="card"><div class="n">MANUAL 05</div><div class="t">閉店マニュアル</div>
    <div class="d">閉店15分前から退勤まで。最終案内、レジ締め、清掃基準、引き継ぎと日報、戸締り。</div></div>
  <div class="card"><div class="n">MANUAL 06</div><div class="t">ドリンクマニュアル</div>
    <div class="d">メニュー全22品、注文の受け方、お作りする手順、打席までの提供、衛生と在庫。</div></div>
</div>
<div class="cols" style="margin-top:16px">
  <div class="c60">
    <div class="box gold">
      <h4>この6冊に共通するルール</h4>
      <ul class="dot" style="font-size:9.8pt">
        <li><b>お客様の前では、作業より接客が優先</b></li>
        <li><b>迷ったら、その場で判断せず店長に確認する</b></li>
        <li><b>やったこと・起きたことは必ず記録に残す</b></li>
      </ul>
    </div>
  </div>
  <div class="c40">
    <div class="box">
      <h4>店舗の基本情報</h4>
      <table class="xtight">
        <tr><td class="k">営業時間</td><td>平日 10:00〜22:00 ／ 土日祝 9:00〜20:00<br>定休日 毎週火曜日</td></tr>
        <tr><td class="k">スタッフ</td><td>開店15分前に出勤 ／ 閉店15分後に退勤</td></tr>
        <tr><td class="k">打席</td><td>A（1F・DTECT）／B（2F・TrackMan 4・左右）／C（2F・OKONGOLF）</td></tr>
        <tr><td class="k">D打席</td><td>オープン約3ヶ月後に稼働予定</td></tr>
      </table>
    </div>
  </div>
</div>
""", sub="FRANK GOLF 姫路", foot_l="FRANK GOLF 運営マニュアル", foot_r="目次"))

for m in (m1, m2, m3, m4, m5, m6):
    S.extend(m.SLIDES)

SLIDES = S
