# -*- coding: utf-8 -*-
"""③ 会計マニュアル"""
from common import cover, slide

F = "③ 会計マニュアル"
S = []

S.append(cover(
    "MANUAL 03",
    "会計マニュアル",
    "お金の動くところを、全部ここに。<br>迷ったら、必ずメモを残す。"))

# 01
S.append(slide("01", "お金が動く5つの場面", """
<table class="tight">
  <tr><th style="width:30px">#</th><th style="width:130px">場面</th><th style="width:150px">会計のしかた</th><th>スタッフの操作</th></tr>
  <tr><td class="c">1</td><td class="k">月会費</td><td>Squareの<b>自動課金</b></td><td><b>店頭では何もしない。</b>毎月自動で決済されます</td></tr>
  <tr><td class="c">2</td><td class="k">ビジター来店</td><td>受付でその場会計</td><td>受付iPadのSquareで「ビジター」を選び会計</td></tr>
  <tr><td class="c">3</td><td class="k">体験レッスン</td><td>受付でその場会計<br><b>現在は無料キャンペーン中</b></td><td>無料期間中は会計なし。<b>受付台帳への記録は必ず行う</b></td></tr>
  <tr><td class="c">4</td><td class="k">追加パーソナル<br>レッスン（25分）</td><td>レッスン後に受付で会計<br><b>2,500円</b></td><td>受付iPadのSquareで「レッスン単発」を選び会計</td></tr>
  <tr><td class="c">5</td><td class="k">ドリンク・物販</td><td><b>モバイルオーダー＝注文と同時に自動決済</b><br>それ以外は退店時に会計</td><td>電子伝票を見て提供 →「提供済み」を押す<br>自動決済でない方は退店時に受付で会計</td></tr>
</table>
<div class="cols" style="margin-top:13px">
  <div class="c60">
    <div class="box gold">
      <h4>いま一番間違いやすいところ</h4>
      <p style="font-size:9.8pt">モバイルオーダーは<b>注文された瞬間にお客様のカードから決済</b>されています。<br>
      退店時に<b>もう一度会計してはいけません。</b>電子伝票で「決済済み」になっているか必ず確認してください。<br>
      カードを登録されていない会員様・ビジターの方は、<b>退店時に受付で会計</b>します。</p>
    </div>
  </div>
  <div class="c40">
    <div class="box">
      <h4>受付でお金を扱う端末</h4>
      <ul class="dot" style="font-size:9.7pt">
        <li><b>受付iPad</b>（Square）── 会計はここ1台</li>
        <li><b>受付PC</b>（客側向き）── チェックイン専用。会計はしない</li>
        <li><b>Squareリーダー</b> ── iPadと接続して使う</li>
      </ul>
    </div>
  </div>
</div>
""", sub="月会費は自動、それ以外は店頭", foot_l=F, foot_r="01"))

# 02
S.append(slide("02", "料金一覧", """
<div class="cols">
  <div>
    <h2 class="sec">会員プラン（月会費）</h2>
    <table class="tight">
      <tr><th style="width:120px">プラン</th><th style="width:76px">税込</th><th style="width:70px">税抜</th><th>内容</th></tr>
      <tr><td class="k">ライト会員</td><td class="c">10,780</td><td class="c">9,800</td><td>月4回まで／<b>平日10:00〜15:00</b></td></tr>
      <tr><td class="k">レギュラー会員</td><td class="c">15,180</td><td class="c">13,800</td><td>1日1時間 通い放題</td></tr>
      <tr><td class="k">マスター会員</td><td class="c">21,780</td><td class="c">19,800</td><td>1日最大2時間</td></tr>
      <tr><td class="k">法人ライト</td><td class="c">43,780</td><td class="c">39,800</td><td>最大2名登録</td></tr>
      <tr><td class="k">法人プレミアム</td><td class="c">65,780</td><td class="c">59,800</td><td>最大4名登録<br>同伴ビジター無料枠</td></tr>
    </table>
    <p class="small" style="margin-top:6px">入会金 <b>5,500円（税込）</b>　※現在キャンペーンで0円＋入会月の月会費0円（<b>6ヶ月継続が条件</b>）</p>
  </div>
  <div>
    <h2 class="sec">都度のご利用</h2>
    <table class="tight">
      <tr><th style="width:150px">項目</th><th style="width:90px">料金(税込)</th><th>備考</th></tr>
      <tr><td class="k">ビジター利用</td><td class="c">5,500円</td><td>会員でない方のご利用</td></tr>
      <tr><td class="k">体験レッスン</td><td class="c">3,300円</td><td><b>現在キャンペーンで無料</b></td></tr>
      <tr><td class="k">パーソナルレッスン<br>（25分）</td><td class="c">2,500円</td><td>会員様の追加レッスン</td></tr>
      <tr><td class="k">ワンポイント<br>レッスン（5分）</td><td class="c"><b>無料</b></td><td>会員特典</td></tr>
    </table>
    <div class="box ng" style="margin-top:11px">
      <h4>金額を聞かれたら</h4>
      <p style="font-size:9.7pt"><b>必ず税込で答える。</b>税抜はホームページと社内資料の表記です。<br>
      うろ覚えで答えず、この表かレジの商品一覧を見て答えてください。</p>
    </div>
  </div>
</div>
<p class="small" style="margin-top:10px">ドリンクの価格は <b>⑥ ドリンクマニュアル</b> を参照。会員価格と一般価格が異なります。</p>
""", sub="価格は必ず税込でお伝えする", foot_l=F, foot_r="02"))

# 03
S.append(slide("03", "使える決済手段", """
<div class="cols">
  <div class="c60">
    <table class="tight">
      <tr><th style="width:130px">決済手段</th><th style="width:70px">可否</th><th>注意点</th></tr>
      <tr><td class="k">クレジットカード<br>（Square）</td><td class="c"><b>○</b></td><td>Squareリーダーで読み取り。<b>月会費もこれで自動課金</b></td></tr>
      <tr><td class="k">PayPay</td><td class="c"><b>○</b></td><td>お客様に読み取っていただく／こちらで読み取る</td></tr>
      <tr><td class="k">交通系IC</td><td class="c"><b>○</b></td><td>ICOCA・Suica等。残高不足のときは別の手段をご案内</td></tr>
      <tr><td class="k">現金</td><td class="c"><b>○</b></td><td>釣銭の受け渡しは<b>必ず声に出して復唱</b></td></tr>
    </table>
    <div class="box gold" style="margin-top:12px">
      <h4>会計の基本動作（どの手段でも共通）</h4>
      <ul class="dot" style="font-size:9.7pt">
        <li>金額を<b>声に出して</b>お伝えする　「◯◯円になります」</li>
        <li>お支払い方法を<b>先に伺う</b>　「お支払いはどうされますか？」</li>
        <li>決済完了の画面を<b>お客様にも見えるように</b>向ける</li>
        <li><b>レシートは必ずお渡しする</b>（不要と言われた場合のみ省略）</li>
        <li>最後に「ありがとうございました」＋お名前</li>
      </ul>
    </div>
  </div>
  <div class="c40">
    <div class="box">
      <h4>会計が通らないとき</h4>
      <table class="xtight">
        <tr><td class="k">カードが<br>通らない</td><td>2回まで試して、通らなければ<b>別のお支払い方法</b>をご案内。お客様のせいにしない</td></tr>
        <tr><td class="k">通信が<br>落ちている</td><td>Wi-Fiを確認 → iPadのモバイル回線へ切替。それでも不可なら<b>現金</b>でお願いする</td></tr>
        <tr><td class="k">端末が<br>反応しない</td><td>Squareアプリを再起動。<b>会計をやり直す前に必ず取引履歴を確認</b>（二重決済の防止）</td></tr>
      </table>
    </div>
    <div class="box ng" style="margin-top:11px">
      <p style="font-size:9.7pt"><b>二重決済がいちばん重いミスです。</b><br>
      「通らなかった」と思ってやり直す前に、必ずSquareの取引履歴を見てください。</p>
    </div>
  </div>
</div>
""", sub="Square／PayPay／交通系IC／現金", foot_l=F, foot_r="03"))

# 04
S.append(slide("04", "現金の扱い", """
<div class="cols">
  <div class="c60">
    <h2 class="sec">1日の流れ</h2>
    <div class="stepbox"><div class="stepno">1</div><div class="stepbd"><b>開店時</b>：金庫から釣銭準備金を出し、レジに入れる<br>
      <span class="small">金庫は<b>スタッフルームのプリンター下</b>。釣銭準備金 <span class="tbd">◯◯,◯◯◯円（要記入）</span>　金種を数えて合っているか確認</span></div></div>
    <div class="stepbox"><div class="stepno">2</div><div class="stepbd"><b>営業中</b>：受け取り・お渡しは必ず声に出して復唱する<br>
      <span class="small">「1万円お預かりします」→「4,500円のお返しです」<br>
      お札はお客様の目の前で数える。<b>受け取ったお札はしまう前に一度置く</b></span></div></div>
    <div class="stepbox"><div class="stepno">3</div><div class="stepbd"><b>閉店時</b>：現金を数え、<b>Squareの現金売上と照合</b>する<br>
      <span class="small">釣銭準備金を差し引いた額が、その日の現金売上と一致するか</span></div></div>
    <div class="stepbox"><div class="stepno">4</div><div class="stepbd"><b>保管</b>：売上金と釣銭準備金を金庫へ。金庫は施錠して退店<br>
      <span class="small">金庫の場所＝<b>スタッフルームのプリンター下</b>。暗証番号は <span class="tbd">（要記入）</span></span></div></div>
  </div>
  <div class="c40">
    <div class="box ng">
      <h4>現金が合わないとき</h4>
      <ul class="dot" style="font-size:9.7pt">
        <li><b>絶対に自分の財布で埋めない</b></li>
        <li>金額と状況を<b>そのまま記録に残す</b>（何円多い／少ない）</li>
        <li>その日のうちに<b>店長へ報告</b>する</li>
        <li>翌日以降に「たぶんあれかな」で処理しない</li>
      </ul>
      <p class="small" style="margin-top:6px">合わないこと自体より、<b>隠すこと・後回しにすること</b>が問題になります。</p>
    </div>
    <div class="box" style="margin-top:11px">
      <h4>やってはいけない</h4>
      <ul class="dot" style="font-size:9.6pt">
        <li>レジからの一時的な立替・借用</li>
        <li>釣銭を数えずに渡す</li>
        <li>レジを開けたまま離れる</li>
        <li>金庫を開けたまま作業する</li>
      </ul>
    </div>
  </div>
</div>
""", sub="復唱と記録がすべて", foot_l=F, foot_r="04"))

# 05
S.append(slide("05", "モバイルオーダーと電子伝票", """
<div class="cols">
  <div class="c60">
    <h2 class="sec">注文が入ってから提供までの流れ</h2>
    <div class="stepbox"><div class="stepno">1</div><div class="stepbd">お客様が会員ポータルから注文する<br>
      <span class="small">この時点で<b>登録カードから自動決済</b>されます</span></div></div>
    <div class="stepbox"><div class="stepno">2</div><div class="stepbd"><b>受付iPadの電子伝票</b>に注文が並ぶ（打席番号つき）</div></div>
    <div class="stepbox"><div class="stepno">3</div><div class="stepbd">スタッフが作り、<b>打席までお持ちする</b></div></div>
    <div class="stepbox"><div class="stepno">4</div><div class="stepbd">お渡ししたら<b>電子伝票の「提供済み」を押す</b><br>
      <span class="small">押すのは<b>お渡しした本人</b>。作った時点では押さない</span></div></div>
    <h2 class="sec mt">口頭でご注文をいただいた場合</h2>
    <div class="box">
      <p style="font-size:9.8pt">受付iPadの電子伝票に<b>スタッフが手入力</b>します。<br>
      打席番号を必ず入れてください。会計は<b>退店時</b>にまとめて行います。</p>
    </div>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>いま自動決済が動く条件</h4>
      <p style="font-size:9.7pt">カードを登録されている会員様（＝月会費をカード払いされている方）だけです。<br>
      それ以外の方は<b>退店時会計</b>に自動で切り替わります。故障ではありません。</p>
    </div>
    <div class="box ng" style="margin-top:11px">
      <h4>絶対に守ること</h4>
      <ul class="dot" style="font-size:9.6pt">
        <li><b>二重に会計しない。</b>電子伝票で決済済みかを必ず確認する</li>
        <li><b>提供済みを押し忘れない。</b>押さないと次のスタッフが二重に作ります</li>
        <li>注文が消えても<b>勝手に作り直さない</b>。お客様に確認する</li>
      </ul>
    </div>
    <div class="box" style="margin-top:11px">
      <p style="font-size:9.6pt">在庫切れの品は、電子伝票の<b>メニュー管理から「売切」に切り替える</b>。注文が入ってから謝るのを防ぎます。</p>
    </div>
  </div>
</div>
""", sub="注文＝決済。二重会計に注意", foot_l=F, foot_r="05"))

# 06
S.append(slide("06", "返金・打ち間違いの訂正", """
<div class="banner" style="margin-bottom:14px">返金・訂正をしたときは、必ずメモを残す</div>
<div class="cols">
  <div class="c60">
    <h2 class="sec">手順</h2>
    <div class="stepbox"><div class="stepno">1</div><div class="stepbd">お客様にお待ちいただき、<b>取引履歴で該当の会計を特定</b>する</div></div>
    <div class="stepbox"><div class="stepno">2</div><div class="stepbd">Squareで返金（または訂正）処理を行う<br>
      <span class="small">カード決済の返金は、お客様のカードに戻るまで数日かかることをお伝えする</span></div></div>
    <div class="stepbox"><div class="stepno">3</div><div class="stepbd"><b>メモを残す</b>（下記4点を必ず）</div></div>
    <div class="stepbox"><div class="stepno">4</div><div class="stepbd">当日中に<b>店長へ報告</b>する</div></div>
    <h2 class="sec mt">メモに書く4点</h2>
    <table class="tight">
      <tr><td class="k c" style="width:26px">1</td><td>日時と対応したスタッフ名</td></tr>
      <tr><td class="k c">2</td><td>お客様のお名前（分かる場合）</td></tr>
      <tr><td class="k c">3</td><td><b>何をどう間違えたのか</b>／返金の理由</td></tr>
      <tr><td class="k c">4</td><td>金額と、どう処理したか</td></tr>
    </table>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>メモはどこに残すか</h4>
      <p style="font-size:9.8pt">売上・現金管理システム（Money OS）の<b>メモ欄</b>に残します。<br>
      <span class="small tbd">※ メモ機能が未実装の場合は、実装するまで受付の記録ノートに残してください。実装後はそちらへ移します。</span></p>
    </div>
    <div class="box" style="margin-top:11px">
      <h4>判断に迷ったら</h4>
      <ul class="dot" style="font-size:9.6pt">
        <li>その場で無理に処理しない</li>
        <li>お客様には<b>「確認いたしますので少々お待ちください」</b></li>
        <li><b>店長へ連絡</b>して指示を受ける</li>
        <li>お待たせした場合は必ずお詫びする</li>
      </ul>
    </div>
    <div class="box ng" style="margin-top:11px">
      <p style="font-size:9.7pt"><b>メモのない返金・訂正は、あとから誰も追えません。</b><br>
      月末に売上が合わない原因のほとんどがこれです。<b>面倒でも必ず残してください。</b></p>
    </div>
  </div>
</div>
""", sub="メモのない訂正は、なかったことと同じ", foot_l=F, foot_r="06"))

# 07
S.append(slide("07", "レジ締めと日報", """
<div class="cols">
  <div class="c60">
    <h2 class="sec">レジ締め</h2>
    <table class="tight">
      <tr><td class="k" style="width:96px">頻度</td><td><b>週に1回</b></td></tr>
      <tr><td class="k">担当</td><td><b>林 和希</b>（統括）</td></tr>
      <tr><td class="k">タイミング</td><td><b>毎週、土曜または日曜のどちらか</b></td></tr>
      <tr><td class="k">やること</td><td>① Squareの週次売上を出す<br>
        ② 現金を数え、釣銭準備金を差し引いて<b>現金売上と照合</b><br>
        ③ 差異があれば金額と原因を記録<br>
        ④ 返金・訂正のメモをすべて確認<br>
        ⑤ 売上・現金管理システムへ反映</td></tr>
    </table>
    <div class="box ng" style="margin-top:11px">
      <p style="font-size:9.7pt"><b>日々のスタッフがやるのは「数えて記録するところまで」</b>です。<br>
      締め処理そのものは週1回・林さんが行います。勝手に調整しないでください。</p>
    </div>
  </div>
  <div class="c40">
    <h2 class="sec">日々の記録（毎日）</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>閉店時に現金を数えた</li>
      <li>Squareの当日売上を確認した</li>
      <li>差異があれば<b>金額と状況</b>を記録した</li>
      <li>返金・訂正があればメモを残した</li>
      <li>売上金と釣銭準備金を金庫へ入れ、施錠した</li>
    </ul>
    <h2 class="sec mt">日報</h2>
    <div class="box">
      <p style="font-size:9.7pt">提出先：<b>シフトクラウド</b>（勤怠と同じ画面から入力）</p>
      <p class="small" style="margin-top:5px"><b>日報は簡単でOK。</b>迷ったら次の5つだけ書いてください。<br>
      ① 来店数　② 体験の件数と入会数　③ 当日売上　④ 現金差異の有無　⑤ 引き継ぎ（なければ「異常なし」）</p>
    </div>
  </div>
</div>
""", sub="締めは週1回・林さん", foot_l=F, foot_r="07"))

# 08
S.append(slide("08", "会計チェックリスト", """
<div class="cols">
  <div>
    <h2 class="sec">開店時</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>金庫から釣銭準備金を出した</li>
      <li>金種を数えて金額が合っている</li>
      <li>受付iPadのSquareにログインできる</li>
      <li>Squareリーダーが接続され、充電されている</li>
      <li>レシートロールの残量を確認した</li>
    </ul>
    <h2 class="sec mt">会計のたびに</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>金額を声に出してお伝えした</li>
      <li>お支払い方法を先に伺った</li>
      <li>現金は<b>復唱</b>してお預かり・お返しした</li>
      <li>決済完了画面をお客様に見せた</li>
      <li>レシートをお渡しした</li>
    </ul>
  </div>
  <div>
    <h2 class="sec">モバイルオーダー</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>電子伝票を定期的に見ている</li>
      <li>打席までお持ちした</li>
      <li><b>お渡しした本人が「提供済み」を押した</b></li>
      <li>決済済みかどうかを確認した</li>
      <li>売切の品はメニュー管理で切り替えた</li>
    </ul>
    <h2 class="sec mt">返金・訂正があったら</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>取引履歴で該当の会計を特定した</li>
      <li>Squareで処理した</li>
      <li><b>メモを4点セットで残した</b></li>
      <li>当日中に店長へ報告した</li>
    </ul>
  </div>
  <div>
    <h2 class="sec">閉店時</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>現金を数えた</li>
      <li>Squareの当日売上と照合した</li>
      <li>差異があれば金額と状況を記録した</li>
      <li>売上金・釣銭準備金を金庫へ入れた</li>
      <li>金庫を施錠した</li>
      <li>日報を<b>シフトクラウド</b>に提出した</li>
    </ul>
    <div class="box gold" style="margin-top:12px">
      <h4>3つだけ覚えて帰る</h4>
      <ul class="dot" style="font-size:9.7pt">
        <li>金額は<b>税込</b>で言う</li>
        <li>やり直す前に<b>取引履歴</b></li>
        <li>訂正したら<b>必ずメモ</b></li>
      </ul>
    </div>
  </div>
</div>
""", sub="印刷して受付に置いてください", foot_l=F, foot_r="08"))

SLIDES = S
