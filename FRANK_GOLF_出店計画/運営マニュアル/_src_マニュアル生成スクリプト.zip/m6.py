# -*- coding: utf-8 -*-
"""⑥ ドリンクマニュアル"""
from common import cover, slide

F = "⑥ ドリンクマニュアル"
S = []

S.append(cover(
    "MANUAL 06",
    "ドリンクマニュアル",
    "打席までお持ちする。<br>それがFRANKのドリンクです。"))

# 01
S.append(slide("01", "メニュー一覧（全22品）", """
<div class="cols">
  <div>
    <h2 class="sec">DRINK（15品）</h2>
    <table class="xtight">
      <tr><th>商品</th><th style="width:52px">一般</th><th style="width:52px">会員</th></tr>
      <tr><td>コーヒー</td><td class="c">400</td><td class="c">300</td></tr>
      <tr><td>アイスコーヒー</td><td class="c">400</td><td class="c">300</td></tr>
      <tr><td>カフェラテ</td><td class="c">500</td><td class="c">400</td></tr>
      <tr><td>アイスカフェラテ</td><td class="c">500</td><td class="c">400</td></tr>
      <tr><td>紅茶</td><td class="c">400</td><td class="c">300</td></tr>
      <tr><td>アイスティー</td><td class="c">400</td><td class="c">300</td></tr>
      <tr><td>コカ・コーラ</td><td class="c">400</td><td class="c">300</td></tr>
      <tr><td>ジンジャーエール</td><td class="c">400</td><td class="c">300</td></tr>
      <tr><td>オレンジジュース</td><td class="c">400</td><td class="c">300</td></tr>
      <tr><td>アップルジュース</td><td class="c">400</td><td class="c">300</td></tr>
      <tr><td>ウーロン茶</td><td class="c">400</td><td class="c">300</td></tr>
      <tr><td>炭酸水</td><td class="c">350</td><td class="c">250</td></tr>
      <tr><td>ポカリスエット</td><td class="c">400</td><td class="c">300</td></tr>
      <tr><td>オロナミンC</td><td class="c">400</td><td class="c">300</td></tr>
      <tr><td>レッドブル</td><td class="c">500</td><td class="c">450</td></tr>
    </table>
  </div>
  <div>
    <h2 class="sec">FRANK SPECIAL（4品）</h2>
    <table class="xtight">
      <tr><th>商品</th><th style="width:52px">一般</th><th style="width:52px">会員</th></tr>
      <tr><td>FRANK レモンスカッシュ</td><td class="c">500</td><td class="c">400</td></tr>
      <tr><td>ゆずソーダ</td><td class="c">500</td><td class="c">400</td></tr>
      <tr><td>マンゴーソーダ</td><td class="c">500</td><td class="c">400</td></tr>
      <tr><td>ピーチソーダ</td><td class="c">500</td><td class="c">400</td></tr>
    </table>
    <h2 class="sec mt">NON-ALCOHOL（3品）</h2>
    <table class="xtight">
      <tr><th>商品</th><th style="width:52px">一般</th><th style="width:52px">会員</th></tr>
      <tr><td>ノンアルコールビール</td><td class="c">500</td><td class="c">400</td></tr>
      <tr><td>ノンアルレモンサワー</td><td class="c">500</td><td class="c">400</td></tr>
      <tr><td>ノンアルハイボール</td><td class="c">500</td><td class="c">400</td></tr>
    </table>
    <div class="box gold" style="margin-top:11px">
      <h4>アルコールについて</h4>
      <p style="font-size:9.7pt"><b>現時点でアルコールの提供はありません。</b><br>
      「お酒はありますか？」と聞かれたら「アルコールのお取り扱いはございませんが、<b>ノンアルコールをご用意しています</b>」とご案内してください。</p>
    </div>
  </div>
</div>
""", sub="会員価格と一般価格が違います", foot_l=F, foot_r="01"))

# 02
S.append(slide("02", "ご注文の受け方", """
<div class="cols">
  <div>
    <h2 class="sec">① モバイルオーダー</h2>
    <div class="stepbox"><div class="stepno">1</div><div class="stepbd">お客様が会員ポータルから注文<br>
      <span class="small">この時点で<b>登録カードから自動決済</b>されます</span></div></div>
    <div class="stepbox"><div class="stepno">2</div><div class="stepbd">受付iPadの<b>電子伝票</b>に打席番号つきで並ぶ</div></div>
    <div class="stepbox"><div class="stepno">3</div><div class="stepbd">作って、<b>打席までお持ちする</b></div></div>
    <div class="stepbox"><div class="stepno">4</div><div class="stepbd">お渡しした人が<b>「提供済み」を押す</b></div></div>
    <div class="box ng" style="margin-top:10px">
      <p style="font-size:9.6pt"><b>退店時にもう一度会計しない。</b>電子伝票で決済済みかを必ず確認してください。</p>
    </div>
  </div>
  <div>
    <h2 class="sec">② 口頭でのご注文</h2>
    <div class="stepbox"><div class="stepno">1</div><div class="stepbd">ご注文を承り、<b>復唱</b>する<br>
      <span class="small">「アイスカフェラテをおひとつ、A打席ですね」</span></div></div>
    <div class="stepbox"><div class="stepno">2</div><div class="stepbd">受付iPadの電子伝票に<b>手入力</b>する<br>
      <span class="small">打席番号を必ず入れる</span></div></div>
    <div class="stepbox"><div class="stepno">3</div><div class="stepbd">作って、打席までお持ちする</div></div>
    <div class="stepbox"><div class="stepno">4</div><div class="stepbd"><b>「提供済み」を押す</b>　→　会計は<b>退店時</b></div></div>
    <div class="box" style="margin-top:10px">
      <p style="font-size:9.6pt">カードを登録されていない会員様・ビジターの方は、モバイルオーダーでも<b>退店時会計</b>になります。</p>
    </div>
  </div>
  <div>
    <div class="box gold">
      <h4>おすすめの声かけ</h4>
      <ul class="dot" style="font-size:9.5pt">
        <li>チェックイン時に一言<br>「お飲み物はいかがですか？」</li>
        <li>2杯目は<b>「前回と同じでよろしいですか？」</b>の1言でOK</li>
        <li>暑い日は<b>ポカリ・炭酸水</b>、寒い日は<b>ホット</b>をおすすめする</li>
        <li>レッスン後は<b>ポカリスエット・炭酸水</b>など、さっぱりしたもの</li>
      </ul>
    </div>
    <div class="box" style="margin-top:11px">
      <h4>売切のとき</h4>
      <p style="font-size:9.6pt">在庫が切れた品は、<b>すぐにメニュー管理から「売切」に切り替える</b>。<br>
      <span class="small">注文が入ってから謝るのを防ぎます。補充したら戻すのを忘れずに。</span></p>
    </div>
  </div>
</div>
""", sub="モバイルオーダーと口頭注文", foot_l=F, foot_r="02"))

# 03
S.append(slide("03", "お作りする手順", """
<div class="cols">
  <div class="c60">
    <table class="tight">
      <tr><th style="width:120px">カテゴリ</th><th>手順</th></tr>
      <tr><td class="k">ホットコーヒー<br>紅茶</td><td>① カップを温める ② 抽出する ③ ソーサー・マドラーを添える<br>
        <span class="small">マシン＝<b>デロンギ マグニフィカ スタート（全自動）</b>。豆・水を入れてボタン1つで抽出できます</span></td></tr>
      <tr><td class="k">アイスコーヒー<br>アイスティー</td><td>① グラスに氷を<b>8分目</b> ② 抽出したものを注ぐ ③ ストローを添える</td></tr>
      <tr><td class="k">カフェラテ</td><td>① エスプレッソを抽出 ② ミルクを加える（ホットはスチーム）<br>③ アイスは氷 → ミルク → エスプレッソの順</td></tr>
      <tr><td class="k">ボトル・缶</td><td>① 冷蔵庫から出す ② <b>グラスと氷を添える</b><br>
        <span class="small">缶・ペットのままお出ししない。必ずグラスを付ける</span></td></tr>
      <tr><td class="k">FRANK SPECIAL<br>ソーダ類</td><td>① グラスに氷 ② シロップ <span class="tbd">◯ml</span> ③ 炭酸水で満たす<br>
        ④ <b>下から1回だけ</b>混ぜる（炭酸が抜けます）⑤ 飾りを添える</td></tr>
      <tr><td class="k">ノンアルコール</td><td>① よく冷やしたグラス ② 静かに注ぐ<br>
        <span class="small">ビールは泡が3割になるように</span></td></tr>
    </table>
  </div>
  <div class="c40">
    <div class="box gold">
      <h4>提供の基本</h4>
      <ul class="dot" style="font-size:9.6pt">
        <li><b>打席までお持ちする</b></li>
        <li>お客様が<b>打っている最中は待つ</b>。素振り中も入らない</li>
        <li>打席の<b>後ろから声をかける</b><br>「お待たせしました、アイスカフェラテです」</li>
        <li>置く場所は<b>クラブが当たらない位置</b>。テーブルの奥側へ</li>
        <li>コースターを必ず敷く</li>
        <li><b>打席の扉は必ず閉める</b>（入るときも、出るときも）</li>
        <li>空いたグラスは<b>声をかけてから</b>下げる</li>
      </ul>
    </div>
    <div class="box ng" style="margin-top:11px">
      <h4>安全</h4>
      <p style="font-size:9.6pt">スイング中の打席には<b>絶対に入らない。</b>クラブが当たると大けがになります。<br>
      必ず打ち終わって、こちらを向いてから近づいてください。</p>
    </div>
  </div>
</div>
""", sub="打席までお持ちする", foot_l=F, foot_r="03"))

# 04
S.append(slide("04", "衛生・在庫・チェックリスト", """
<div class="cols">
  <div>
    <h2 class="sec">衛生</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>作業前に<b>手を洗う</b></li>
      <li>グラスの<b>飲み口を持たない</b></li>
      <li>氷はスコップで取る（手・グラスですくわない）</li>
      <li>要冷蔵品は<b>出しっぱなしにしない</b></li>
      <li>賞味期限を週1回確認する</li>
      <li>ふきんは<b>グラス用と台拭きを分ける</b></li>
      <li>体調不良時は提供業務に入らない</li>
    </ul>
    <h2 class="sec mt">アレルギー・体調への配慮</h2>
    <div class="box" style="font-size:9.5pt">
      牛乳・大豆など、お客様から確認があった場合は<b>推測で答えない</b>。<br>
      商品パッケージの表示を一緒にご確認いただいてください。
    </div>
  </div>
  <div>
    <h2 class="sec">在庫</h2>
    <ul class="chk" style="font-size:9.5pt">
      <li>開店時に<b>冷蔵の在庫を数える</b></li>
      <li>切れたものは<b>すぐ「売切」に切り替える</b></li>
      <li>残りわずかなものは引き継ぎメモに書く</li>
      <li>閉店時に翌日ぶんを冷蔵庫へ補充する</li>
      <li>氷の残量を確認する</li>
      <li>カップ・ストロー・コースター・おしぼりの補充</li>
      <li>豆・シロップ・ミルクの残量を確認する</li>
    </ul>
    <div class="box gold" style="margin-top:11px">
      <h4>発注</h4>
      <p style="font-size:9.6pt">在庫が<b>残り3個</b>を切ったら引き継ぎメモに記入。<br>
      <span class="small">発注先＝<b>たか屋</b>　TEL <b>090-5622-6199</b>（担当：堀尾さん）</span></p>
    </div>
  </div>
  <div>
    <h2 class="sec">1日のチェックリスト</h2>
    <ul class="chk" style="font-size:9.3pt">
      <li><b>開店</b>　マシンの電源・水・豆</li>
      <li><b>開店</b>　冷蔵在庫を数え、売切を切替</li>
      <li><b>開店</b>　氷・カップ・ストロー補充</li>
      <li><b>営業中</b>　電子伝票をこまめに見る</li>
      <li><b>営業中</b>　打席まで運び「提供済み」</li>
      <li><b>営業中</b>　空きグラスを声かけて下げる</li>
      <li><b>閉店</b>　洗い物をすべて済ませる</li>
      <li><b>閉店</b>　マシンを洗浄・停止</li>
      <li><b>閉店</b>　要冷蔵品を戻す</li>
      <li><b>閉店</b>　翌日ぶんを補充</li>
      <li><b>閉店</b>　シンク・カウンターを拭く</li>
    </ul>
  </div>
</div>
""", sub="印刷してカフェカウンターに", foot_l=F, foot_r="04"))

SLIDES = S
